"""Extend engagements + add hitl_actions table

Revision ID: a1b2c3d4e5f6
Revises: d2609d8b4fd0
Create Date: 2026-05-06 10:00:00.000000

Changes:
- engagements: add name default, description, client_name, status (enum), roe, att_tactics, updated_at
- Create hitl_actions table (HU-09, HU-10)
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f6'
down_revision: Union[str, Sequence[str], None] = 'd2609d8b4fd0'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ── 1. Enum para EngagementStatus ─────────────────────────────────────────
    # Creamos el tipo en la BD primero (PostgreSQL lo necesita antes de usarlo)
    engagementstatus = sa.Enum(
        'pending', 'running', 'paused', 'completed', 'aborted',
        name='engagementstatus',
    )
    engagementstatus.create(op.get_bind(), checkfirst=True)

    # ── 2. Extender tabla engagements ─────────────────────────────────────────
    op.add_column('engagements',
        sa.Column('description', sa.Text(), nullable=True)
    )
    op.add_column('engagements',
        sa.Column('client_name', sa.String(), nullable=True)
    )
    op.add_column('engagements',
        sa.Column(
            'status',
            sa.Enum('pending', 'running', 'paused', 'completed', 'aborted',
                    name='engagementstatus'),
            nullable=False,
            server_default='pending',
        )
    )
    op.add_column('engagements',
        sa.Column('roe', sa.JSON(), nullable=True)
    )
    op.add_column('engagements',
        sa.Column('att_tactics', sa.JSON(), nullable=True)
    )
    op.add_column('engagements',
        sa.Column('updated_at', sa.DateTime(), nullable=True)
    )

    # Asegurar que la columna 'name' tenga default (retrocompatibilidad)
    op.alter_column('engagements', 'name',
        existing_type=sa.String(),
        nullable=False,
        server_default='Nuevo Análisis',
    )

    # ── 3. Crear tabla hitl_actions ───────────────────────────────────────────
    op.create_table(
        'hitl_actions',
        sa.Column('id',            sa.Integer(),   nullable=False),
        sa.Column('engagement_id', sa.Integer(),   nullable=False),
        sa.Column('agent',         sa.String(),    nullable=False),
        sa.Column('tool',          sa.String(),    nullable=False),
        sa.Column('risk_level',    sa.String(),    nullable=False),
        sa.Column('params',        sa.JSON(),      nullable=True),
        sa.Column('decision',      sa.String(),    nullable=True),
        sa.Column('operator',      sa.String(),    nullable=True),
        sa.Column('notes',         sa.Text(),      nullable=True),
        sa.Column('requested_at',  sa.DateTime(),  nullable=True),
        sa.Column('decided_at',    sa.DateTime(),  nullable=True),
        sa.ForeignKeyConstraint(['engagement_id'], ['engagements.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index(op.f('ix_hitl_actions_id'), 'hitl_actions', ['id'], unique=False)
    op.create_index('ix_hitl_actions_engagement_id', 'hitl_actions', ['engagement_id'], unique=False)


def downgrade() -> None:
    # Revertir en orden inverso
    op.drop_index('ix_hitl_actions_engagement_id', table_name='hitl_actions')
    op.drop_index(op.f('ix_hitl_actions_id'), table_name='hitl_actions')
    op.drop_table('hitl_actions')

    op.drop_column('engagements', 'updated_at')
    op.drop_column('engagements', 'att_tactics')
    op.drop_column('engagements', 'roe')
    op.drop_column('engagements', 'status')
    op.drop_column('engagements', 'client_name')
    op.drop_column('engagements', 'description')

    # Eliminar el enum type de PostgreSQL
    sa.Enum(name='engagementstatus').drop(op.get_bind(), checkfirst=True)
