"""
main.py — ETH-MAS FastAPI application v0.4.0
=============================================
Endpoints organizados por épica:
  E1 · Engagement & Scope  (HU-01, HU-02, HU-03)
  E2 · Reconocimiento      (HU-04 — ReconAgent real Sprint 2)
  E4 · HITL                (HU-09, HU-10)
  E3 · Scan real           (HU-06 — nmap via scan_service/scan_agent)
  E3 · Findings            (HU-07, HU-08 — persistencia + GET /findings)

Sprint 2 v0.4 — cambios:
  - lifespan: reemplaza @on_event deprecated; init Mongo + índices
  - GET /engagements/{id}/findings: endpoint real HU-08
  - POST /scan: ahora usa execute_scan_agent async (persiste en MongoDB)
  - Auth X-API-Key: header X-API-Key requerido en endpoints críticos (HU-22)
  - scope_validator canónico: eliminado scope_service duplicado
"""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from datetime import datetime
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException, Query, Security, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security.api_key import APIKeyHeader
from sqlalchemy.orm import Session

import models
import schemas
from database import engine, get_db
from models import EngagementStatus, VALID_TRANSITIONS
from services import scanner, scope_validator
from services.recon_agent import ReconAgent
from mongo_client import ensure_indexes, surface_map_col, findings_col

# Crea tablas si no existen (dev convenience; en produccion usamos Alembic)
models.Base.metadata.create_all(bind=engine)

# ── Auth X-API-Key (HU-22) ────────────────────────────────────────────────────
_API_KEY        = os.getenv("ETH_MAS_API_KEY", "dev-key-insecure")
_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

async def verify_api_key(key: str = Security(_api_key_header)):
    """
    Dependencia de autenticación.
    En dev, si ETH_MAS_API_KEY no está en .env, acepta 'dev-key-insecure'.
    En producción, ETH_MAS_API_KEY debe ser un secreto real.
    """
    if not key or key != _API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key inválida o ausente. Incluir header X-API-Key.",
        )

# ── Lifespan (reemplaza @on_event deprecated) ─────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Inicializa recursos al arrancar y los libera al apagar.
    - Crea índices MongoDB (idempotente)
    """
    await ensure_indexes()
    yield
    # Cleanup opcional al shutdown (Motor cierra conexiones solo)


# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="ETH-MAS API",
    description="Motor de orquestacion de pentesting multi-agente con HITL",
    version="0.4.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/", tags=["health"])
def read_root():
    return {
        "status": "online",
        "version": "0.3.0",
        "mensaje": "ETH-MAS API activa",
    }


# =============================================================================
# E1 · Engagement & Scope — HU-01, HU-03
# =============================================================================

@app.get("/engagements", response_model=List[schemas.EngagementSummary], tags=["engagements"])
def list_engagements(
    status_filter: Optional[str] = Query(None, alias="status"),
    db: Session = Depends(get_db),
):
    q = db.query(models.Engagement)
    if status_filter:
        try:
            st = EngagementStatus(status_filter.lower())
            q = q.filter(models.Engagement.status == st)
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=f"Status invalido: {status_filter!r}. "
                       f"Opciones: {[e.value for e in EngagementStatus]}",
            )
    engagements = q.order_by(models.Engagement.created_at.desc()).all()
    result = []
    for eng in engagements:
        summary = schemas.EngagementSummary.model_validate(eng)
        summary.scope_count = len(eng.scopes)
        result.append(summary)
    return result


@app.post(
    "/engagements",
    response_model=schemas.EngagementResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["engagements"],
)
def create_engagement(payload: schemas.EngagementCreate, db: Session = Depends(get_db)):
    """Crea un nuevo engagement con scope, ROE y tacticas ATT&CK. (HU-01)"""
    engagement = models.Engagement(
        name=payload.name,
        description=payload.description,
        client_name=payload.client_name,
        status=EngagementStatus.PENDING,
        roe=payload.roe.model_dump() if payload.roe else None,
        att_tactics=payload.att_tactics,
    )
    db.add(engagement)
    db.flush()
    for t in payload.scope_targets:
        db_scope = models.ScopeTarget(
            engagement_id=engagement.id,
            target_value=t.target_value,
            target_type=t.target_type.upper(),
        )
        db.add(db_scope)
    db.commit()
    db.refresh(engagement)
    return engagement


@app.get("/engagements/{engagement_id}", response_model=schemas.EngagementResponse, tags=["engagements"])
def get_engagement(engagement_id: int, db: Session = Depends(get_db)):
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")
    return eng


@app.patch("/engagements/{engagement_id}/status", response_model=schemas.EngagementResponse, tags=["engagements"])
def update_engagement_status(
    engagement_id: int,
    payload: schemas.EngagementStatusUpdate,
    db: Session = Depends(get_db),
):
    """Transiciona el status segun la maquina de estados. (HU-03)"""
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")
    try:
        new_status = EngagementStatus(payload.status.lower())
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Status {payload.status!r} invalido.")
    allowed = VALID_TRANSITIONS.get(eng.status, [])
    if new_status not in allowed:
        raise HTTPException(
            status_code=422,
            detail=(
                f"Transicion ilegal: {eng.status.value} -> {new_status.value}. "
                f"Permitidas: {[t.value for t in allowed] or 'ninguna (estado terminal)'}."
            ),
        )
    eng.status = new_status
    eng.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(eng)
    return eng


# ── Scope targets ─────────────────────────────────────────────────────────────

@app.get("/engagements/{engagement_id}/scope", tags=["scope"])
def get_scopes(engagement_id: int, db: Session = Depends(get_db)):
    scopes = (
        db.query(models.ScopeTarget)
        .filter(models.ScopeTarget.engagement_id == engagement_id)
        .all()
    )
    return {"message": f"{len(scopes)} objetivos", "data": scopes}


@app.post("/engagements/{engagement_id}/scope", tags=["scope"])
def add_scope_target(engagement_id: int, scope: schemas.ScopeCreate, db: Session = Depends(get_db)):
    engagement = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not engagement:
        engagement = models.Engagement(
            id=engagement_id, name=f"Analisis #{engagement_id}", status=EngagementStatus.PENDING,
        )
        db.add(engagement)
        db.commit()
    db_scope = models.ScopeTarget(
        engagement_id=engagement_id,
        target_value=scope.target_value,
        target_type=scope.target_type.upper(),
    )
    db.add(db_scope)
    db.commit()
    db.refresh(db_scope)
    return {"message": "Objetivo guardado", "data": db_scope}


@app.delete("/engagements/{engagement_id}/scope/{target_id}", tags=["scope"])
def delete_scope_target(engagement_id: int, target_id: int, db: Session = Depends(get_db)):
    target = db.query(models.ScopeTarget).filter(
        models.ScopeTarget.id == target_id,
        models.ScopeTarget.engagement_id == engagement_id,
    ).first()
    if not target:
        raise HTTPException(status_code=404, detail="Objetivo no encontrado")
    db.delete(target)
    db.commit()
    return {"message": "Objetivo eliminado"}


@app.get("/engagements/{engagement_id}/validate", tags=["scope"])
def validate_target(engagement_id: int, target: str, db: Session = Depends(get_db)):
    """Verifica si un target esta autorizado en el scope del engagement. (HU-02)"""
    is_valid = scope_validator.is_target_in_scope(target, engagement_id, db)
    return {
        "target": target,
        "engagement_id": engagement_id,
        "status": "AUTORIZADO" if is_valid else "DENEGADO",
        "in_scope": is_valid,
    }


# =============================================================================
# E2 · Reconocimiento — HU-04 / HU-05 (ReconAgent real Sprint 2)
# =============================================================================

@app.post("/engagements/{engagement_id}/recon", tags=["pipeline"], dependencies=[Depends(verify_api_key)])
async def launch_recon(engagement_id: int, db: Session = Depends(get_db)):
    """
    Lanza la fase de reconocimiento OSINT del engagement. (HU-04)
    Sprint 2: ReconAgent real — Haiku 4.5 + OSINT MCP Server.
    Persiste surface_map en MongoDB al finalizar (HU-05).
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    scope_count = (
        db.query(models.ScopeTarget)
        .filter(models.ScopeTarget.engagement_id == engagement_id)
        .count()
    )
    if scope_count == 0:
        raise HTTPException(
            status_code=422,
            detail="No hay scope targets configurados. Agrega targets antes de iniciar recon.",
        )

    if eng.status == EngagementStatus.PENDING:
        eng.status = EngagementStatus.RUNNING
        eng.updated_at = datetime.utcnow()
        db.commit()

    agent  = ReconAgent(engagement_id=engagement_id, db=db)
    result = await agent.run()

    return {
        "message":       "Reconocimiento completado",
        "engagement_id": engagement_id,
        "recon_result":  result,
    }


@app.get("/engagements/{engagement_id}/surface-map", tags=["pipeline"])
async def get_surface_map(engagement_id: int, db: Session = Depends(get_db)):
    """
    Retorna el surface map del engagement desde MongoDB. (HU-05)
    Requiere haber ejecutado POST /recon al menos una vez.
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    doc = await surface_map_col().find_one(
        {"engagement_id": engagement_id},
        sort=[("generated_at", -1)],
    )
    if not doc:
        raise HTTPException(
            status_code=404,
            detail="Surface map no disponible. Ejecutar POST /recon primero.",
        )

    doc["_id"] = str(doc["_id"])
    return doc


# =============================================================================
# E4 · HITL — HU-09, HU-10
# =============================================================================

@app.get(
    "/engagements/{engagement_id}/hitl-actions",
    response_model=List[schemas.HitlActionResponse],
    tags=["hitl"],
)
def list_hitl_actions(
    engagement_id: int,
    pending_only: bool = Query(False),
    db: Session = Depends(get_db),
):
    """Lista acciones HITL. ?pending_only=true muestra solo las sin decision."""
    q = (
        db.query(models.HitlAction)
        .filter(models.HitlAction.engagement_id == engagement_id)
        .order_by(models.HitlAction.requested_at.desc())
    )
    if pending_only:
        q = q.filter(models.HitlAction.decision.is_(None))
    return q.all()


@app.patch(
    "/hitl-actions/{hitl_id}/decision",
    response_model=schemas.HitlActionResponse,
    tags=["hitl"],
    dependencies=[Depends(verify_api_key)],
)
def decide_hitl_action(hitl_id: int, payload: schemas.HitlDecision, db: Session = Depends(get_db)):
    """El operador aprueba o rechaza una accion HITL pendiente. (HU-09)"""
    action = db.query(models.HitlAction).filter(models.HitlAction.id == hitl_id).first()
    if not action:
        raise HTTPException(status_code=404, detail=f"HitlAction {hitl_id} no encontrada")
    if action.decision is not None:
        raise HTTPException(status_code=409, detail=f"Ya tiene decision: {action.decision}")
    valid_decisions = {"APPROVED", "REJECTED", "AUTO-APPROVED"}
    if payload.decision.upper() not in valid_decisions:
        raise HTTPException(status_code=400, detail=f"Decision invalida. Opciones: {sorted(valid_decisions)}")
    action.decision   = payload.decision.upper()
    action.operator   = payload.operator
    action.notes      = payload.notes
    action.decided_at = datetime.utcnow()
    db.commit()
    db.refresh(action)
    return action


@app.get("/hitl-actions/{hitl_id}", response_model=schemas.HitlActionResponse, tags=["hitl"])
def get_hitl_action(hitl_id: int, db: Session = Depends(get_db)):
    """Obtiene una accion HITL por ID (para polling de estado)."""
    action = db.query(models.HitlAction).filter(models.HitlAction.id == hitl_id).first()
    if not action:
        raise HTTPException(status_code=404, detail=f"HitlAction {hitl_id} no encontrada")
    return action


# =============================================================================
# E3 · Scan — HU-06 (Sprint 2 — nmap real via scan_service)
# =============================================================================

@app.post(
    "/engagements/{engagement_id}/scan",
    tags=["pipeline"],
    dependencies=[Depends(verify_api_key)],
)
async def launch_scan(engagement_id: int, db: Session = Depends(get_db)):
    """
    Lanza la fase de escaneo del engagement. (HU-06)
    Sprint 2: execute_scan_agent async → nmap real → findings normalizados + persistidos en MongoDB.
    Requiere header X-API-Key.
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    scopes = (
        db.query(models.ScopeTarget)
        .filter(models.ScopeTarget.engagement_id == engagement_id)
        .all()
    )
    if not scopes:
        raise HTTPException(
            status_code=422,
            detail="No hay scope targets configurados. Agrega targets antes de iniciar scan.",
        )

    targets = [s.target_value for s in scopes]

    from services.scan_service import execute_scan_agent

    try:
        result = await execute_scan_agent(
            engagement_id=engagement_id,
            targets=targets,
            allowed_targets=targets,
        )
        return {
            "status":         "completed",
            "engagement_id":  engagement_id,
            **result,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# E3 · Findings — HU-08 (GET /findings)
# =============================================================================

@app.get("/engagements/{engagement_id}/findings", tags=["pipeline"])
async def get_findings(
    engagement_id: int,
    severity: Optional[str] = Query(None, description="Filtrar por severidad: critical, high, medium, low, info"),
    status_filter: Optional[str] = Query(None, alias="status", description="Filtrar por estado: open, closed, false_positive"),
    tool: Optional[str] = Query(None, description="Filtrar por herramienta: nmap, nuclei, nikto"),
    limit: int = Query(200, ge=1, le=1000, description="Máximo de resultados"),
):
    """
    Lista los findings del engagement desde MongoDB. (HU-08)
    Soporta filtros por severidad, estado y herramienta.
    """
    query: dict = {"engagement_id": engagement_id}
    if severity:
        query["severity"] = severity.lower()
    if status_filter:
        query["status"] = status_filter.lower()
    if tool:
        query["tool"] = tool.lower()

    try:
        docs = await findings_col().find(query).sort("discovered_at", -1).to_list(length=limit)
        # Serializar ObjectId → string
        for doc in docs:
            if "_id" in doc:
                doc["_id"] = str(doc["_id"])
        return {
            "engagement_id": engagement_id,
            "total":         len(docs),
            "filters":       {"severity": severity, "status": status_filter, "tool": tool},
            "findings":      docs,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error consultando findings: {e}")
