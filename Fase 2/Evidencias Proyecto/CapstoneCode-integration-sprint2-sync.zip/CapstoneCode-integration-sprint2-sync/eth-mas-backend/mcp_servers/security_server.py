#!/usr/bin/env python3
"""
security_server.py — Security MCP Server · ETH-MAS Sprint 2/3
==============================================================
MCP Server que expone tools de escaneo activo con scope check + HITL obligatorio.

Tools registradas:
  nmap_scan     → Port scan + service detection (risk_level MEDIUM/HIGH)
  nuclei_run    → Templates de vulnerabilidades (risk_level MEDIUM/HIGH)
  nikto_scan    → Análisis HTTP (risk_level MEDIUM) [stub — Sprint 3]
  gobuster_run  → Dir/DNS bruteforce (risk_level MEDIUM)

Cada tool call ejecuta en orden:
  1. Scope check contra PostgreSQL
  2. Registro en hitl_actions con status="pending" (MEDIUM/HIGH requieren aprobación)
  3. BLOQUEO: espera polling hasta que decision != "pending" (timeout configurable)
  4. Si rechazado → HitlRejectedError
  5. Si aprobado → ejecuta la herramienta real
  6. Retorna JSON {findings, raw_output, hitl_action_id, ...}

Transporte: stdio — FastAPI/scan_agent lanza este script como subprocess.

Diferencia con osint_server.py:
  OSINT → risk_level LOW → AUTO-APPROVED (sin bloqueo)
  Security → risk_level MEDIUM/HIGH → PENDING → espera decisión humana
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import subprocess
import sys
from datetime import datetime
from typing import Optional

# ── Path setup ────────────────────────────────────────────────────────────────
_BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

# ── Imports del backend ───────────────────────────────────────────────────────
from dotenv import load_dotenv
load_dotenv(os.path.join(_BACKEND_DIR, ".env"))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

import models
from services.scope_validator import is_target_in_scope

# ── MCP SDK ───────────────────────────────────────────────────────────────────
from mcp.server.fastmcp import FastMCP

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [security_server] %(levelname)s — %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)

# ── DB connection ─────────────────────────────────────────────────────────────
_DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:admin@localhost:5432/eth_mas_db")
_engine       = create_engine(_DATABASE_URL)
_SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=_engine)

def _get_db() -> Session:
    return _SessionLocal()

# ── Config HITL ───────────────────────────────────────────────────────────────
HITL_POLL_INTERVAL_SECS: float = float(os.getenv("HITL_POLL_INTERVAL", "3"))
HITL_TIMEOUT_SECS: float       = float(os.getenv("HITL_TIMEOUT_SECS", "300"))  # 5 min

# ── MCP Server ────────────────────────────────────────────────────────────────
mcp = FastMCP(
    "eth-mas-security",
    instructions=(
        "Security MCP Server del pipeline ETH-MAS. "
        "Todas las tools son activas (risk_level MEDIUM o HIGH). "
        "Cada llamada REQUIERE aprobación HITL explícita del operador antes de ejecutar. "
        "El sistema bloqueará hasta recibir la decisión o cumplirse el timeout."
    ),
)

AGENT_NAME = "ScanAgent"

# ── Rutas a binarios y wordlist ───────────────────────────────────────────────
_GOBUSTER_EXE = os.path.join(_BACKEND_DIR, "gobuster.exe")
_NUCLEI_EXE   = os.path.join(_BACKEND_DIR, "nuclei.exe")
_WORDLIST     = os.path.join(_BACKEND_DIR, "diccionario.txt")


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers internos
# ═══════════════════════════════════════════════════════════════════════════════

def _register_hitl_pending(
    target: str,
    engagement_id: int,
    tool: str,
    risk_level: str,
    params: dict,
    db: Session,
) -> int:
    """
    Valida scope y registra HitlAction con status PENDING.
    Retorna el hitl_action_id.
    Lanza ValueError si el target está fuera de scope.
    """
    if not is_target_in_scope(target, engagement_id, db):
        raise ValueError(
            f"SCOPE_VIOLATION: '{target}' no está en el scope del engagement {engagement_id}."
        )

    action = models.HitlAction(
        engagement_id = engagement_id,
        agent         = AGENT_NAME,
        tool          = tool,
        risk_level    = risk_level,
        params        = params,
        decision      = "PENDING",
        operator      = None,
        notes         = None,
        requested_at  = datetime.utcnow(),
        decided_at    = None,
    )
    db.add(action)
    db.commit()
    db.refresh(action)
    logger.info(
        "HITL PENDING: id=%d tool=%s target=%s risk=%s",
        action.id, tool, target, risk_level
    )
    return action.id


async def _wait_for_hitl_decision(hitl_action_id: int) -> str:
    """
    Polling de la decisión HITL hasta que sea APPROVED o REJECTED.
    Retorna la decisión final.
    Lanza TimeoutError si se supera HITL_TIMEOUT_SECS.
    """
    elapsed = 0.0
    while elapsed < HITL_TIMEOUT_SECS:
        db = _get_db()
        try:
            action = db.query(models.HitlAction).filter(
                models.HitlAction.id == hitl_action_id
            ).first()
            if action and action.decision not in ("PENDING",):
                logger.info(
                    "HITL decision recibida: id=%d decision=%s",
                    hitl_action_id, action.decision
                )
                return action.decision
        finally:
            db.close()

        await asyncio.sleep(HITL_POLL_INTERVAL_SECS)
        elapsed += HITL_POLL_INTERVAL_SECS

    raise TimeoutError(
        f"HITL timeout después de {HITL_TIMEOUT_SECS}s. "
        f"El operador no respondió para hitl_action_id={hitl_action_id}."
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: nmap_scan
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def nmap_scan(
    target: str,
    engagement_id: int,
    ports: str = "1-1024",
    timing: int = 3,
    scripts: Optional[str] = None,
) -> str:
    """
    Ejecuta nmap sobre el target con detección de versiones.
    Requiere aprobación HITL antes de ejecutar (risk_level MEDIUM/HIGH).
    Escaneos con timing >= 4 o scripts NSE se registran como risk_level HIGH.

    Args:
        target:        IP o CIDR a escanear. Debe estar en el scope del engagement.
        engagement_id: ID del engagement activo (para scope check y HITL).
        ports:         Rango de puertos (default "1-1024"). Usar "1-65535" para full scan.
        timing:        Timing template nmap T0-T5 (default T3=normal).
        scripts:       Scripts NSE separados por coma (ej: "vuln,default"). None = sin scripts.

    Returns:
        JSON string con findings normalizados, raw_output y hitl_action_id.
    """
    # Determinar risk_level según intensidad
    risk_level = "HIGH" if (timing >= 4 or scripts) else "MEDIUM"

    db = _get_db()
    try:
        hitl_id = _register_hitl_pending(
            target, engagement_id, "nmap_scan", risk_level,
            {"target": target, "ports": ports, "timing": timing, "scripts": scripts},
            db,
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "nmap_scan", "status": "blocked", "error": str(e)})
    finally:
        db.close()

    logger.info(
        "nmap_scan esperando HITL: id=%d target=%s risk=%s",
        hitl_id, target, risk_level
    )

    # ── Esperar decisión HITL ─────────────────────────────────────────────────
    try:
        decision = await _wait_for_hitl_decision(hitl_id)
    except TimeoutError as e:
        return json.dumps({
            "tool": "nmap_scan", "status": "hitl_timeout",
            "error": str(e), "hitl_action_id": hitl_id,
        })

    if decision.upper() != "APPROVED":
        logger.info("nmap_scan RECHAZADO por operador: hitl_id=%d", hitl_id)
        return json.dumps({
            "tool": "nmap_scan", "status": "rejected",
            "error": f"Operador rechazó la acción (decision={decision})",
            "hitl_action_id": hitl_id,
        })

    # ── Ejecutar nmap ─────────────────────────────────────────────────────────
    logger.info("nmap_scan APROBADO, ejecutando: target=%s ports=%s", target, ports)

    from services.nmap_service import run_nmap_scan, parse_nmap_xml
    from services.findings_service import normalize_nmap_findings

    try:
        xml_output = await asyncio.to_thread(
            run_nmap_scan, target, ports=ports, timing=timing, scripts=scripts
        )
        raw_findings = parse_nmap_xml(xml_output)
        normalized = normalize_nmap_findings(engagement_id, raw_findings)

        result = {
            "tool":           "nmap_scan",
            "target":         target,
            "engagement_id":  engagement_id,
            "timestamp":      datetime.utcnow().isoformat(),
            "findings":       normalized,
            "findings_count": len(normalized),
            "raw_output":     xml_output[:2000],  # truncar para el contexto del LLM
            "status":         "completed",
            "risk_level":     risk_level,
            "hitl_action_id": hitl_id,
        }

    except Exception as e:
        logger.error("nmap_scan error: %s", e)
        result = {
            "tool":           "nmap_scan",
            "target":         target,
            "engagement_id":  engagement_id,
            "timestamp":      datetime.utcnow().isoformat(),
            "findings":       [],
            "findings_count": 0,
            "raw_output":     str(e),
            "status":         "error",
            "hitl_action_id": hitl_id,
        }

    logger.info(
        "nmap_scan completado: target=%s findings=%d",
        target, result["findings_count"]
    )
    return json.dumps(result)


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: nuclei_run  [stub Sprint 3]
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def nuclei_run(
    target: str,
    engagement_id: int,
    severity: str = "medium",
    templates: Optional[str] = None,
) -> str:
    """
    Ejecuta nuclei con templates de vulnerabilidades sobre el target.
    Requiere aprobación HITL antes de ejecutar.

    Args:
        target:        URL o IP objetivo.
        engagement_id: ID del engagement.
        severity:      Severidad mínima de templates ("low","medium","high","critical").
        templates:     Tags de templates separados por coma. None = "cve,exposed-panels,misconfig".

    Returns:
        JSON con findings normalizados (JSONL de nuclei), raw_output y hitl_action_id.
    """
    risk_level = "HIGH" if severity in ("high", "critical") else "MEDIUM"

    db = _get_db()
    try:
        hitl_id = _register_hitl_pending(
            target, engagement_id, "nuclei_run", risk_level,
            {"target": target, "severity": severity, "templates": templates},
            db,
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "nuclei_run", "status": "blocked", "error": str(e)})
    finally:
        db.close()

    try:
        decision = await _wait_for_hitl_decision(hitl_id)
    except TimeoutError as e:
        return json.dumps({"tool": "nuclei_run", "status": "hitl_timeout", "error": str(e), "hitl_action_id": hitl_id})

    if decision.upper() != "APPROVED":
        return json.dumps({"tool": "nuclei_run", "status": "rejected", "hitl_action_id": hitl_id})

    # ── Ejecutar nuclei ───────────────────────────────────────────────────────
    url_target = target if target.startswith("http") else f"http://{target}"
    tags = templates or "cve,exposed-panels,misconfig"

    logger.info("nuclei_run APROBADO, ejecutando: target=%s tags=%s", url_target, tags)

    cmd = [
        _NUCLEI_EXE,
        "-u", url_target,
        "-tags", tags,
        "-silent",
        "-no-color",
        "-j",        # JSONL output — una línea por hallazgo
    ]

    try:
        proc = await asyncio.to_thread(
            subprocess.run, cmd,
            capture_output=True, text=True, timeout=180,
        )
        raw_output = proc.stdout or ""

        from services.findings_service import normalize_nuclei_findings
        normalized = normalize_nuclei_findings(engagement_id, url_target, raw_output)

        result = {
            "tool":           "nuclei_run",
            "target":         target,
            "engagement_id":  engagement_id,
            "timestamp":      datetime.utcnow().isoformat(),
            "findings":       normalized,
            "findings_count": len(normalized),
            "raw_output":     raw_output[:2000],
            "status":         "completed",
            "risk_level":     risk_level,
            "hitl_action_id": hitl_id,
        }
    except subprocess.TimeoutExpired:
        result = {
            "tool": "nuclei_run", "status": "error",
            "error": "Nuclei tardó demasiado y fue cancelado (timeout 180s)",
            "hitl_action_id": hitl_id,
        }
    except FileNotFoundError:
        result = {
            "tool": "nuclei_run", "status": "error",
            "error": f"nuclei.exe no encontrado en {_NUCLEI_EXE}",
            "hitl_action_id": hitl_id,
        }
    except Exception as e:
        result = {
            "tool": "nuclei_run", "status": "error",
            "error": str(e), "hitl_action_id": hitl_id,
        }

    logger.info(
        "nuclei_run completado: target=%s findings=%d",
        target, result.get("findings_count", 0),
    )
    return json.dumps(result)


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: nikto_scan  [stub Sprint 3]
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def nikto_scan(target: str, engagement_id: int, port: int = 80) -> str:
    """
    [STUB — Sprint 3] Ejecuta nikto para análisis de servidor HTTP.
    Requiere aprobación HITL (risk_level MEDIUM).

    Args:
        target:        IP o hostname del servidor web.
        engagement_id: ID del engagement.
        port:          Puerto HTTP a analizar (default 80).

    Returns:
        JSON stub indicando que está pendiente de implementación.
    """
    db = _get_db()
    try:
        hitl_id = _register_hitl_pending(
            target, engagement_id, "nikto_scan", "MEDIUM",
            {"target": target, "port": port},
            db,
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "nikto_scan", "status": "blocked", "error": str(e)})
    finally:
        db.close()

    try:
        decision = await _wait_for_hitl_decision(hitl_id)
    except TimeoutError as e:
        return json.dumps({"tool": "nikto_scan", "status": "hitl_timeout", "error": str(e), "hitl_action_id": hitl_id})

    if decision.upper() != "APPROVED":
        return json.dumps({"tool": "nikto_scan", "status": "rejected", "hitl_action_id": hitl_id})

    # TODO Sprint 3: subprocess nikto -h <target> -p <port> -Format json
    return json.dumps({
        "tool": "nikto_scan", "status": "not_implemented",
        "message": "nikto_scan implementación pendiente Sprint 3",
        "hitl_action_id": hitl_id,
    })


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: gobuster_run
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def gobuster_run(
    target: str,
    engagement_id: int,
    mode: str = "dir",
) -> str:
    """
    Ejecuta gobuster en modo dir (descubrimiento de rutas HTTP) o dns (brute-force
    de subdominios). Usa el wordlist bundleado en el backend (diccionario.txt).
    Requiere aprobación HITL (risk_level MEDIUM).

    Args:
        target:        URL base (mode=dir) o dominio (mode=dns).
        engagement_id: ID del engagement.
        mode:          "dir" para rutas HTTP, "dns" para subdominios.

    Returns:
        JSON con rutas/subdominios encontrados, findings normalizados y hitl_action_id.
    """
    db = _get_db()
    try:
        hitl_id = _register_hitl_pending(
            target, engagement_id, "gobuster_run", "MEDIUM",
            {"target": target, "mode": mode, "wordlist": _WORDLIST},
            db,
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "gobuster_run", "status": "blocked", "error": str(e)})
    finally:
        db.close()

    try:
        decision = await _wait_for_hitl_decision(hitl_id)
    except TimeoutError as e:
        return json.dumps({"tool": "gobuster_run", "status": "hitl_timeout", "error": str(e), "hitl_action_id": hitl_id})

    if decision.upper() != "APPROVED":
        return json.dumps({"tool": "gobuster_run", "status": "rejected", "hitl_action_id": hitl_id})

    # ── Ejecutar gobuster ─────────────────────────────────────────────────────
    url_target = target if target.startswith("http") else f"http://{target}"

    if mode == "dir":
        scan_target = url_target
        cmd = [
            _GOBUSTER_EXE, "dir",
            "-u", url_target,
            "-w", _WORDLIST,
            "-t", "10",
            "--no-color",
            "-q",
        ]
    else:  # dns
        scan_target = target
        cmd = [
            _GOBUSTER_EXE, "dns",
            "-d", target,
            "-w", _WORDLIST,
            "-t", "10",
            "--no-color",
            "-q",
        ]

    logger.info("gobuster_run APROBADO, ejecutando: mode=%s target=%s", mode, scan_target)

    try:
        proc = await asyncio.to_thread(
            subprocess.run, cmd,
            capture_output=True, text=True, timeout=120,
        )
        raw_output = proc.stdout or ""

        from services.findings_service import normalize_gobuster_findings
        normalized = normalize_gobuster_findings(engagement_id, scan_target, raw_output, mode)

        result = {
            "tool":           "gobuster_run",
            "target":         target,
            "engagement_id":  engagement_id,
            "timestamp":      datetime.utcnow().isoformat(),
            "mode":           mode,
            "findings":       normalized,
            "findings_count": len(normalized),
            "raw_output":     raw_output[:2000],
            "status":         "completed",
            "risk_level":     "MEDIUM",
            "hitl_action_id": hitl_id,
        }
    except subprocess.TimeoutExpired:
        result = {
            "tool": "gobuster_run", "status": "error",
            "error": "Gobuster tardó demasiado y fue cancelado (timeout 120s)",
            "hitl_action_id": hitl_id,
        }
    except FileNotFoundError:
        result = {
            "tool": "gobuster_run", "status": "error",
            "error": f"gobuster.exe no encontrado en {_GOBUSTER_EXE}",
            "hitl_action_id": hitl_id,
        }
    except Exception as e:
        result = {
            "tool": "gobuster_run", "status": "error",
            "error": str(e), "hitl_action_id": hitl_id,
        }

    logger.info(
        "gobuster_run completado: mode=%s target=%s findings=%d",
        mode, target, result.get("findings_count", 0),
    )
    return json.dumps(result)


# ═══════════════════════════════════════════════════════════════════════════════
# Entrypoint
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logger.info("Security MCP Server iniciando (stdio transport)...")
    mcp.run(transport="stdio")
