"""
mongo_client.py — Cliente MongoDB async para ETH-MAS (Sprint 2)
===============================================================
Provee un cliente Motor (async) singleton y shortcuts para las
colecciones usadas por los agentes.

Colecciones:
  - surface_map   → resultado consolidado de ReconAgent (HU-05)
  - findings      → hallazgos normalizados de ScanAgent (HU-07, HU-08)
  - agent_runs    → log de ejecución de cada agente (trazabilidad)

Uso:
    from mongo_client import surface_map_col, findings_col, agent_runs_col

    # En contexto async:
    await surface_map_col().replace_one({"engagement_id": 1}, doc, upsert=True)
"""

from __future__ import annotations

import os
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorCollection
from dotenv import load_dotenv

load_dotenv()

MONGO_URL: str = os.getenv("MONGO_URL", "mongodb://localhost:27017")
MONGO_DB:  str = os.getenv("MONGO_DB",  "eth_mas")

# ── Singleton ─────────────────────────────────────────────────────────────────

_client: AsyncIOMotorClient | None = None


def get_mongo_client() -> AsyncIOMotorClient:
    """Retorna el cliente Motor singleton. Crea uno nuevo si no existe."""
    global _client
    if _client is None:
        _client = AsyncIOMotorClient(MONGO_URL)
    return _client


def get_mongo_db():
    """Retorna la base de datos ETH-MAS."""
    return get_mongo_client()[MONGO_DB]


# ── Shortcuts de colecciones ──────────────────────────────────────────────────

def surface_map_col() -> AsyncIOMotorCollection:
    """Colección 'surface_map' — resultados de ReconAgent."""
    return get_mongo_db()["surface_map"]


def findings_col() -> AsyncIOMotorCollection:
    """Colección 'findings' — hallazgos normalizados de ScanAgent."""
    return get_mongo_db()["findings"]


def agent_runs_col() -> AsyncIOMotorCollection:
    """Colección 'agent_runs' — log de ejecución de agentes."""
    return get_mongo_db()["agent_runs"]


# ── Indexes (llamar una vez al startup de FastAPI) ────────────────────────────

async def ensure_indexes() -> None:
    """
    Crea los índices mínimos necesarios en MongoDB.
    Llamar desde el startup event de FastAPI:

        @app.on_event("startup")
        async def startup():
            await ensure_indexes()
    """
    from pymongo import ASCENDING, DESCENDING

    # surface_map: un doc por engagement (upsert), búsqueda por engagement_id
    await surface_map_col().create_index(
        [("engagement_id", ASCENDING)], unique=True, background=True
    )

    # findings: búsqueda frecuente por engagement + severity + status
    await findings_col().create_index(
        [("engagement_id", ASCENDING), ("severity", ASCENDING)], background=True
    )
    await findings_col().create_index(
        [("engagement_id", ASCENDING), ("status", ASCENDING)], background=True
    )

    # agent_runs: ordenar por fecha para ver el último run
    await agent_runs_col().create_index(
        [("engagement_id", ASCENDING), ("started_at", DESCENDING)], background=True
    )
