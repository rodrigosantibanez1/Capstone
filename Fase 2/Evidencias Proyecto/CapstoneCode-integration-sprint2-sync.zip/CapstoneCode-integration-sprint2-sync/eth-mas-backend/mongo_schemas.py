"""
mongo_schemas.py — Schemas Pydantic para colecciones MongoDB (Sprint 2)
=======================================================================
Define la forma de cada documento que se persiste en MongoDB.
Pydantic v2 valida antes de insertar; motor serializa con model_dump().

Colecciones:
  SurfaceMapDoc  → surface_map   (ReconAgent, HU-05)
  FindingDoc     → findings      (ScanAgent,  HU-07)
  AgentRunDoc    → agent_runs    (ambos agentes, trazabilidad)
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


# ── SurfaceMapDoc ─────────────────────────────────────────────────────────────

class SurfaceMapDoc(BaseModel):
    """
    Documento consolidado de la fase de reconocimiento.
    Un documento por engagement (upsert).
    """
    engagement_id:      int
    scope_original:     list[str]           # targets definidos por el operador

    # Resultados OSINT consolidados
    emails_osint:       list[str]   = []    # emails encontrados por theHarvester
    hosts_discovered:   list[str]   = []    # hosts/IPs descubiertos (union de tools)
    new_vs_scope:       list[str]   = []    # hosts fuera del scope original (interesante)

    # Datos crudos por target (para trazabilidad)
    dns_records:        dict        = {}    # {target: {A:[], MX:[], NS:[], TXT:[]}}
    whois_data:         dict        = {}    # {target: {registrar, org, ...}}
    harvester_data:     dict        = {}    # {target: {emails:[], hosts:[], ips:[]}}

    # Metadata
    generated_at:       datetime    = Field(default_factory=datetime.utcnow)
    agent_run_id:       Optional[str] = None   # _id del AgentRunDoc correspondiente
    model_used:         Optional[str] = None   # ej: "claude-haiku-4-5-20251001"


# ── FindingDoc ────────────────────────────────────────────────────────────────

class FindingDoc(BaseModel):
    """
    Hallazgo individual normalizado de ScanAgent.
    Un documento por hallazgo (puerto, vulnerabilidad, path, etc.).
    """
    engagement_id:      int
    tool:               str             # nmap_scan | nuclei_run | nikto_scan | gobuster_run
    target:             str             # IP o dominio escaneado

    # Contenido del hallazgo
    raw_output:         str             # salida cruda de la herramienta (criterio M2)
    summary:            str             # descripción legible del hallazgo

    # Clasificación de riesgo
    severity:           str             # critical | high | medium | low | info
    cvss_score:         Optional[float] = None
    cvss_source:        Optional[str]   = None   # NVD | manual (criterio M1)

    # Enriquecimiento (AnalysisAgent — Sprint 3)
    cve_ids:            list[str]       = []
    mitre_technique:    Optional[str]   = None   # ej: T1046

    # Estado de gestión
    status:             str             = "open"   # open | confirmed | false_positive | fixed

    # Datos de red (cuando aplica)
    port:               Optional[int]   = None
    service:            Optional[str]   = None
    protocol:           Optional[str]   = None

    # Trazabilidad
    hitl_action_id:     Optional[int]   = None   # FK a PostgreSQL hitl_actions.id
    discovered_at:      datetime        = Field(default_factory=datetime.utcnow)


# ── AgentRunDoc ───────────────────────────────────────────────────────────────

class ToolCallEntry(BaseModel):
    """Entrada en el log de tool calls de un agente."""
    tool:           str
    target:         str
    status:         str             # completed | error | scope_violation | timeout
    hitl_action_id: Optional[int]  = None
    duration_ms:    Optional[int]  = None
    error:          Optional[str]  = None


class AgentRunDoc(BaseModel):
    """
    Log completo de ejecución de un agente.
    Persiste cada run para trazabilidad y debugging.
    """
    engagement_id:  int
    agent:          str                     # ReconAgent | ScanAgent
    model:          str                     # claude-haiku-4-5-20251001 | ...
    targets:        list[str]   = []

    # Timing
    started_at:     datetime    = Field(default_factory=datetime.utcnow)
    finished_at:    Optional[datetime]  = None

    # Resultado
    status:         str         = "running"     # running | completed | failed
    tools_called:   list[ToolCallEntry] = []
    input_tokens:   Optional[int]   = None      # tokens consumidos (para cost tracking)
    output_tokens:  Optional[int]   = None
    error:          Optional[str]   = None
