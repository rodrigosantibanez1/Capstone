from __future__ import annotations

from datetime import datetime
from typing import Any, List, Optional

from pydantic import BaseModel, Field, model_validator
import ipaddress
import re

# ── Utilidades de validación de targets ──────────────────────────────────────

DOMAIN_REGEX = re.compile(
    r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
)


def _validate_target_value(target_value: str, target_type: str) -> None:
    if target_type == "ip":
        try:
            ipaddress.ip_address(target_value)
        except ValueError:
            raise ValueError("Formato de IP inválido")
    elif target_type == "cidr":
        try:
            ipaddress.ip_network(target_value, strict=False)
        except ValueError:
            raise ValueError("Formato CIDR inválido")
    elif target_type == "domain":
        if not DOMAIN_REGEX.match(target_value):
            raise ValueError("Formato de dominio inválido")
    else:
        raise ValueError("target_type debe ser ip, cidr o domain")


# ── Scope ─────────────────────────────────────────────────────────────────────

class ScopeCreate(BaseModel):
    target_value: str
    target_type: str

    @model_validator(mode="after")
    def validate_target(self):
        _validate_target_value(self.target_value, self.target_type)
        return self


class ScopeResponse(BaseModel):
    id: int
    engagement_id: int
    target_value: str
    target_type: str
    created_at: datetime

    model_config = {"from_attributes": True}


# ── ROE ───────────────────────────────────────────────────────────────────────

class TimeWindow(BaseModel):
    start: str = "09:00"
    end: str   = "18:00"
    days: List[str] = ["mon", "tue", "wed", "thu", "fri"]


class ROE(BaseModel):
    time_windows: List[TimeWindow] = []
    scan_intensity: str = "MODERATE"
    excluded_paths: List[str] = []
    max_requests_per_second: int = 50
    auto_approve_hitl_below: str = "LOW"
    notification_email: Optional[str] = None


# ── Engagement ────────────────────────────────────────────────────────────────

class EngagementCreate(BaseModel):
    name: str = Field(default="Nuevo Análisis", min_length=1, max_length=200)
    description: Optional[str] = None
    client_name: Optional[str] = None
    scope_targets: List[ScopeCreate] = Field(default_factory=list)
    roe: Optional[ROE] = None
    att_tactics: Optional[List[str]] = None

    @model_validator(mode="after")
    def validate_scope(self):
        seen = set()
        for t in self.scope_targets:
            key = (t.target_value, t.target_type)
            if key in seen:
                raise ValueError(f"Target duplicado: {t.target_value}")
            seen.add(key)
        return self


class EngagementStatusUpdate(BaseModel):
    status: str
    notes: Optional[str] = None


class EngagementResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    client_name: Optional[str]
    status: str
    roe: Optional[Any]
    att_tactics: Optional[Any]
    created_at: datetime
    updated_at: Optional[datetime]
    scopes: List[ScopeResponse] = []

    model_config = {"from_attributes": True}


class EngagementSummary(BaseModel):
    id: int
    name: str
    client_name: Optional[str]
    status: str
    created_at: datetime
    updated_at: Optional[datetime]
    scope_count: int = 0

    model_config = {"from_attributes": True}


# ── HITL Actions ──────────────────────────────────────────────────────────────

class HitlActionCreate(BaseModel):
    engagement_id: int
    agent: str
    tool: str
    risk_level: str
    params: Optional[Any] = None


class HitlDecision(BaseModel):
    decision: str
    operator: str
    notes: Optional[str] = None


class HitlActionResponse(BaseModel):
    id: int
    engagement_id: int
    agent: str
    tool: str
    risk_level: str
    params: Optional[Any]
    decision: Optional[str]
    operator: Optional[str]
    notes: Optional[str]
    requested_at: datetime
    decided_at: Optional[datetime]

    model_config = {"from_attributes": True}
