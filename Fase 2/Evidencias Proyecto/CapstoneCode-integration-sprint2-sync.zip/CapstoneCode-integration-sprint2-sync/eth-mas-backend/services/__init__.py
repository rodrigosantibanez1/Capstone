"""
enforce_scope.py — HU-02 · Validación programática de scope
============================================================

Provee el decorator @enforce_scope y la función request_hitl_approval()
para que los tool-wrappers de los agentes validen scope y gestionen HITL
de forma automática, sin depender del razonamiento del LLM.

Uso básico en un tool-wrapper:

    from services.enforce_scope import enforce_scope

    @enforce_scope(risk_level="MEDIUM")
    async def nmap_scan(target: str, engagement_id: int, db: Session, **kwargs):
        # Aquí target ya fue validado contra el scope autorizado.
        # Si risk_level >= MEDIUM, HITL fue aprobado antes de llegar aquí.
        ...

El decorator inyecta la lógica de:
1. Verificar que `target` está dentro del scope del engagement_id.
2. Si risk_level >= MEDIUM → crear un registro HitlAction pendiente y
   esperar aprobación (raise ScopeViolation si es rechazado en el ciclo sync,
   o retornar el ID pendiente en flujo async de larga duración).
3. Auto-aprobar si risk_level == LOW.
4. Registrar el resultado (APPROVED/AUTO-APPROVED/REJECTED) en hitl_actions.
"""

from __future__ import annotations

import functools
import logging
from datetime import datetime
from typing import Any, Callable, Optional

from sqlalchemy.orm import Session

import models
from services.scope_validator import is_target_in_scope

logger = logging.getLogger(__name__)


# ── Constantes de riesgo ──────────────────────────────────────────────────────

RISK_LEVELS = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
AUTO_APPROVE_THRESHOLD = "LOW"   # Sólo LOW se auto-aprueba (§4.4 CLAUDE.md)


# ── Excepciones de dominio ────────────────────────────────────────────────────

class ScopeViolationError(Exception):
    """Lanzada cuando el target no está en el scope autorizado del engagement."""
    def __init__(self, target: str, engagement_id: int):
        self.target = target
        self.engagement_id = engagement_id
        super().__init__(
            f"Target '{target}' fuera del scope del engagement {engagement_id}. "
            f"Acción bloqueada por @enforce_scope."
        )


class HitlRejectedError(Exception):
    """Lanzada cuando el operador rechazó la acción HITL."""
    def __init__(self, hitl_id: int, tool: str):
        self.hitl_id = hitl_id
        self.tool = tool
        super().__init__(
            f"Acción '{tool}' rechazada por operador (hitl_actions.id={hitl_id})."
        )


class HitlPendingError(Exception):
    """
    Lanzada en flujos async cuando la acción queda pendiente de aprobación HITL.
    El llamador debe manejar este caso y reanudar cuando el operador decida.
    """
    def __init__(self, hitl_id: int, tool: str, risk_level: str):
        self.hitl_id = hitl_id
        self.tool = tool
        self.risk_level = risk_level
        super().__init__(
            f"Acción '{tool}' (risk={risk_level}) requiere aprobación HITL "
            f"(hitl_actions.id={hitl_id}). En espera de decisión del operador."
        )


# ── Lógica central ────────────────────────────────────────────────────────────

def _risk_requires_hitl(risk_level: str) -> bool:
    """True si risk_level > AUTO_APPROVE_THRESHOLD."""
    try:
        return RISK_LEVELS.index(risk_level.upper()) > RISK_LEVELS.index(AUTO_APPROVE_THRESHOLD)
    except ValueError:
        logger.warning("risk_level desconocido '%s'; tratado como HIGH.", risk_level)
        return True


def register_hitl_action(
    *,
    db: Session,
    engagement_id: int,
    agent: str,
    tool: str,
    risk_level: str,
    params: Optional[dict] = None,
) -> models.HitlAction:
    """Crea un registro HitlAction en estado pendiente (decision=None)."""
    action = models.HitlAction(
        engagement_id=engagement_id,
        agent=agent,
        tool=tool,
        risk_level=risk_level.upper(),
        params=params,
        requested_at=datetime.utcnow(),
    )
    db.add(action)
    db.commit()
    db.refresh(action)
    logger.info(
        "HITL registrado: id=%d engagement=%d agent=%s tool=%s risk=%s",
        action.id, engagement_id, agent, tool, risk_level,
    )
    return action


def auto_approve_hitl(*, db: Session, action: models.HitlAction) -> None:
    """Marca una acción HITL como AUTO-APROBADO (risk_level LOW)."""
    action.decision = "AUTO-APPROVED"
    action.operator = "Sistema"
    action.notes = f"risk_level {action.risk_level} — aprobación automática"
    action.decided_at = datetime.utcnow()
    db.commit()
    logger.info("HITL AUTO-APROBADO: id=%d tool=%s", action.id, action.tool)


def check_scope_and_hitl(
    *,
    target: str,
    engagement_id: int,
    agent: str,
    tool: str,
    risk_level: str,
    params: Optional[dict],
    db: Session,
) -> models.HitlAction:
    """
    Función central de validación. Ejecuta en orden:
      1. Scope check programático (ScopeViolationError si falla).
      2. Registro en hitl_actions.
      3. Auto-approve si LOW; raise HitlPendingError si MEDIUM/HIGH/CRITICAL.

    Returns el HitlAction creado (útil para auditoria).
    Raises ScopeViolationError | HitlPendingError.
    """
    # 1. Scope enforcement
    if not is_target_in_scope(target, engagement_id, db):
        logger.warning(
            "SCOPE VIOLATION: target=%s engagement=%d tool=%s",
            target, engagement_id, tool,
        )
        raise ScopeViolationError(target, engagement_id)

    # 2. Registrar HITL
    action = register_hitl_action(
        db=db,
        engagement_id=engagement_id,
        agent=agent,
        tool=tool,
        risk_level=risk_level,
        params=params,
    )

    # 3. Auto-approve o pedir aprobación
    if not _risk_requires_hitl(risk_level):
        auto_approve_hitl(db=db, action=action)
    else:
        # El operador debe decidir vía PATCH /hitl-actions/{id}/decision
        raise HitlPendingError(action.id, tool, risk_level)

    return action


# ── Decorator ─────────────────────────────────────────────────────────────────

def enforce_scope(
    risk_level: str = "MEDIUM",
    agent: str = "Sistema",
):
    """
    Decorator para tool-wrappers de agentes.

    La función decorada DEBE recibir los kwargs:
        target: str           — IP, CIDR o dominio a atacar
        engagement_id: int    — ID del engagement activo
        db: Session           — sesión SQLAlchemy activa

    Parámetros del decorator:
        risk_level: str  — LOW | MEDIUM | HIGH | CRITICAL  (default MEDIUM)
        agent: str       — nombre del agente (ReconAgent, ScanAgent, ...)

    Comportamiento:
        - Si target no está en scope → ScopeViolationError (no ejecuta la fn).
        - Si risk_level == LOW → auto-aprueba y ejecuta la fn.
        - Si risk_level > LOW  → crea HitlAction pendiente y lanza HitlPendingError.
          El endpoint debe capturar HitlPendingError y devolver 202 Accepted con el hitl_id.
          Cuando el operador apruebe vía PATCH, el pipeline puede reanudar.

    Ejemplo:
        @enforce_scope(risk_level="MEDIUM", agent="ScanAgent")
        async def nmap_scan(target, engagement_id, db, ports="1-1024"):
            # Solo llega aquí si fue AUTO-APROBADO (risk LOW)
            # Para MEDIUM+, el llamador maneja HitlPendingError
            ...
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            target       = kwargs.get("target")
            engagement_id = kwargs.get("engagement_id")
            db: Session  = kwargs.get("db")

            if not all([target, engagement_id, db]):
                raise ValueError(
                    "@enforce_scope requiere kwargs: target, engagement_id, db"
                )

            # Extraer params para auditoria (todo menos target/engagement_id/db)
            params = {
                k: v for k, v in kwargs.items()
                if k not in ("target", "engagement_id", "db")
            }

            check_scope_and_hitl(
                target=target,
                engagement_id=engagement_id,
                agent=agent,
                tool=func.__name__,
                risk_level=risk_level,
                params=params,
                db=db,
            )

            # Si llegamos aquí, fue AUTO-APROBADO (risk LOW)
            return await func(*args, **kwargs)

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            target        = kwargs.get("target")
            engagement_id = kwargs.get("engagement_id")
            db: Session   = kwargs.get("db")

            if not all([target, engagement_id, db]):
                raise ValueError(
                    "@enforce_scope requiere kwargs: target, engagement_id, db"
                )

            params = {
                k: v for k, v in kwargs.items()
                if k not in ("target", "engagement_id", "db")
            }

            check_scope_and_hitl(
                target=target,
                engagement_id=engagement_id,
                agent=agent,
                tool=func.__name__,
                risk_level=risk_level,
                params=params,
                db=db,
            )

            return func(*args, **kwargs)

        import asyncio
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper

    return decorator
