"""
findings_service.py — Normalización y persistencia de findings de ScanAgent
===========================================================================
Responsabilidades:
  1. normalize_nmap_findings()      → dict canónico desde raw nmap output
  2. normalize_gobuster_findings()  → dict canónico desde raw gobuster output
  3. normalize_nuclei_findings()    → dict canónico desde raw nuclei JSONL output
  4. classify_severity()            → severidad basada en puerto/servicio conocidos
  5. persist_finding()              → inserta un FindingDoc en MongoDB (async)
  6. persist_findings_bulk()        → inserta muchos findings de una vez (async)

HU-07: Los findings normalizados DEBEN persistirse en MongoDB findings_col.
HU-08: El endpoint GET /findings consulta esta colección.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any

from mongo_client import findings_col
from mongo_schemas import FindingDoc


# ── Puertos de alto riesgo conocidos ─────────────────────────────────────────

_HIGH_RISK_PORTS: set[int] = {
    21,    # FTP — credenciales en texto plano
    23,    # Telnet — credenciales en texto plano
    25,    # SMTP sin auth
    110,   # POP3
    111,   # RPCBind
    135,   # MSRPC
    139,   # NetBIOS
    445,   # SMB — vector crítico (EternalBlue, etc.)
    512,   # rexec
    513,   # rlogin
    514,   # rsh
    1099,  # Java RMI
    2049,  # NFS
    3306,  # MySQL
    5432,  # PostgreSQL
    5900,  # VNC
    6379,  # Redis sin auth
    8009,  # AJP (Apache JServ — Ghostcat)
    27017, # MongoDB sin auth
}

_MEDIUM_RISK_PORTS: set[int] = {
    22,    # SSH — superficie expuesta
    80,    # HTTP
    443,   # HTTPS
    3000,  # Node / dev servers
    3389,  # RDP
    4848,  # GlassFish admin
    6000,  # X11
    8080,  # HTTP alternativo
    8443,  # HTTPS alternativo
    8888,  # Jupyter / dev
    9090,  # Cockpit / admin panels
    9200,  # Elasticsearch sin auth
}


def classify_severity(port: int, service: str | None = None) -> str:
    """
    Clasifica la severidad de un puerto/servicio abierto.
    Usado por normalize_nmap_findings() — puede ser sobreescrito por AnalysisAgent
    con datos CVE/CVSS reales en Sprint 3.

    Returns: "critical" | "high" | "medium" | "low" | "info"
    """
    if port in _HIGH_RISK_PORTS:
        return "high"
    if port in _MEDIUM_RISK_PORTS:
        return "medium"
    # Puertos privilegiados (< 1024) no en lista conocida → medio
    if 0 < port < 1024:
        return "medium"
    # Servicios web en puertos altos
    svc = (service or "").lower()
    if any(kw in svc for kw in ("http", "https", "web", "tomcat", "nginx", "apache")):
        return "medium"
    return "info"


def normalize_nmap_findings(engagement_id: int, raw_findings: list[dict]) -> list[dict]:
    """
    Convierte raw findings de nmap_service.parse_nmap_xml() al formato canónico.
    No persiste — llamar persist_findings_bulk() después para guardar en MongoDB.
    """
    normalized: list[dict] = []

    for item in raw_findings:
        port: int = item.get("port", 0)
        service: str | None = item.get("service")
        product: str | None = item.get("product")
        version: str | None = item.get("version")

        # Título legible
        svc_label = service or "desconocido"
        title = f"Puerto {port} abierto — {svc_label}"
        if product:
            title += f" ({product}"
            if version:
                title += f" {version}"
            title += ")"

        severity = classify_severity(port, service)

        normalized.append({
            "engagement_id": engagement_id,
            "phase": "scan",
            "tool": "nmap",
            "target": item["target"],
            "title": title,
            "severity": severity,
            "status": "open",
            "evidence": {
                "port": port,
                "protocol": item.get("protocol", "tcp"),
                "state": item.get("state", "open"),
                "service": service,
                "product": product,
                "version": version,
            },
            # Campos ATT&CK / CVE — rellenados por AnalysisAgent en Sprint 3
            "mitre_technique": None,
            "cve_ids": [],
            "cvss_score": None,
            "cvss_source": None,
            # Timestamps
            "discovered_at": datetime.now(timezone.utc).isoformat(),
            "raw_output": item.get("raw_output", ""),
        })

    return normalized


_HIGH_RISK_PATHS: set[str] = {
    "admin", "wp-admin", "private", "backup", "config", "dashboard", "console",
    "phpmyadmin", "manager", "administrator", "secret", "credentials",
}


def normalize_gobuster_findings(
    engagement_id: int,
    target: str,
    raw_output: str,
    mode: str = "dir",
) -> list[dict]:
    """
    Parsea la salida de gobuster y la convierte al formato canónico.

    Dir output:  /admin       (Status: 200) [Size: 1234]
    DNS output:  Found: mail.example.com
    """
    normalized: list[dict] = []

    if mode == "dir":
        pattern = re.compile(
            r"^(/\S*)\s+\(Status:\s*(\d+)\)\s+\[Size:\s*(\d+)\]", re.MULTILINE
        )
        for match in pattern.finditer(raw_output):
            path = match.group(1)
            status_code = int(match.group(2))
            size = int(match.group(3))
            if status_code >= 400:
                continue
            path_key = path.strip("/").split("/")[0].lower()
            severity = "medium" if path_key in _HIGH_RISK_PATHS else "low"
            normalized.append({
                "engagement_id": engagement_id,
                "phase": "scan",
                "tool": "gobuster",
                "target": target,
                "title": f"Ruta web descubierta: {path} (HTTP {status_code})",
                "severity": severity,
                "status": "open",
                "evidence": {
                    "path": path,
                    "status_code": status_code,
                    "size": size,
                    "mode": "dir",
                },
                "mitre_technique": "T1083",
                "cve_ids": [],
                "cvss_score": None,
                "cvss_source": None,
                "discovered_at": datetime.now(timezone.utc).isoformat(),
                "raw_output": raw_output,
            })

    elif mode == "dns":
        pattern = re.compile(r"^Found:\s+(\S+)", re.MULTILINE)
        for match in pattern.finditer(raw_output):
            subdomain = match.group(1)
            normalized.append({
                "engagement_id": engagement_id,
                "phase": "scan",
                "tool": "gobuster",
                "target": target,
                "title": f"Subdominio descubierto: {subdomain}",
                "severity": "info",
                "status": "open",
                "evidence": {"subdomain": subdomain, "mode": "dns"},
                "mitre_technique": "T1018",
                "cve_ids": [],
                "cvss_score": None,
                "cvss_source": None,
                "discovered_at": datetime.now(timezone.utc).isoformat(),
                "raw_output": raw_output,
            })

    return normalized


_NUCLEI_SEVERITY_MAP: dict[str, str] = {
    "critical": "critical",
    "high": "high",
    "medium": "medium",
    "low": "low",
    "info": "info",
}


def normalize_nuclei_findings(
    engagement_id: int,
    target: str,
    raw_output: str,
) -> list[dict]:
    """
    Parsea la salida JSONL de nuclei (-j flag) al formato canónico.
    Cada línea del output es un objeto JSON independiente.
    """
    normalized: list[dict] = []

    for line in raw_output.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue

        info = entry.get("info", {})
        nuclei_sev = info.get("severity", "info").lower()
        severity = _NUCLEI_SEVERITY_MAP.get(nuclei_sev, "info")

        template_id = entry.get("template-id", entry.get("template", "unknown"))
        template_name = info.get("name", template_id)
        matched_at = entry.get("matched-at", target)
        description = info.get("description", "")

        classification = info.get("classification", {}) or {}
        raw_cves = classification.get("cve-id", [])
        if isinstance(raw_cves, str):
            raw_cves = [raw_cves]
        cve_ids = [c.upper() for c in raw_cves if c]

        cvss_raw = classification.get("cvss-score")
        cvss_score = float(cvss_raw) if cvss_raw is not None else None

        normalized.append({
            "engagement_id": engagement_id,
            "phase": "scan",
            "tool": "nuclei",
            "target": target,
            "title": f"[Nuclei] {template_name}",
            "severity": severity,
            "status": "open",
            "evidence": {
                "template_id": template_id,
                "matched_at": matched_at,
                "description": description,
                "tags": info.get("tags", []),
            },
            "mitre_technique": None,
            "cve_ids": cve_ids,
            "cvss_score": cvss_score,
            "cvss_source": "nuclei" if cvss_score is not None else None,
            "discovered_at": datetime.now(timezone.utc).isoformat(),
            "raw_output": line,
        })

    return normalized


async def persist_finding(finding_dict: dict[str, Any]) -> str:
    """
    Inserta un único finding normalizado en MongoDB.
    Retorna el string del ObjectId insertado.
    """
    doc = FindingDoc(
        engagement_id=finding_dict["engagement_id"],
        tool=finding_dict.get("tool", "nmap"),
        target=finding_dict["target"],
        title=finding_dict["title"],
        severity=finding_dict["severity"],
        status=finding_dict.get("status", "open"),
        phase=finding_dict.get("phase", "scan"),
        evidence=finding_dict.get("evidence", {}),
        mitre_technique=finding_dict.get("mitre_technique"),
        cve_ids=finding_dict.get("cve_ids", []),
        cvss_score=finding_dict.get("cvss_score"),
        cvss_source=finding_dict.get("cvss_source"),
        raw_output=finding_dict.get("raw_output", ""),
    )
    result = await findings_col().insert_one(doc.model_dump(exclude_none=False))
    return str(result.inserted_id)


async def persist_findings_bulk(findings: list[dict[str, Any]]) -> int:
    """
    Inserta múltiples findings normalizados de una vez.
    Retorna el número de documentos insertados.
    Llamar desde scan_service o scan_agent después de ejecutar nmap.
    """
    if not findings:
        return 0

    docs = []
    for f in findings:
        doc = FindingDoc(
            engagement_id=f["engagement_id"],
            tool=f.get("tool", "nmap"),
            target=f["target"],
            title=f["title"],
            severity=f["severity"],
            status=f.get("status", "open"),
            phase=f.get("phase", "scan"),
            evidence=f.get("evidence", {}),
            mitre_technique=f.get("mitre_technique"),
            cve_ids=f.get("cve_ids", []),
            cvss_score=f.get("cvss_score"),
            cvss_source=f.get("cvss_source"),
            raw_output=f.get("raw_output", ""),
        )
        docs.append(doc.model_dump(exclude_none=False))

    result = await findings_col().insert_many(docs)
    return len(result.inserted_ids)
