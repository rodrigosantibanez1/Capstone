import subprocess
import xml.etree.ElementTree as ET
from typing import Optional


def run_nmap_scan(
    target: str,
    ports: str = "1-1024",
    timing: int = 3,
    scripts: Optional[str] = None,
) -> str:
    """
    Ejecuta nmap con detección de versiones sobre el target.

    Args:
        target:  IP, CIDR o hostname a escanear.
        ports:   Rango de puertos (default "1-1024"). Usar "1-65535" para full.
        timing:  Template T0-T5 (default T3=normal).
        scripts: Scripts NSE separados por coma (ej: "vuln,default"). None = sin scripts.

    Returns:
        XML output de nmap como string.
    """
    command = [
        "nmap",
        "-Pn",
        "-sV",
        "-p", ports,
        f"-T{timing}",
        "-oX", "-",
        target,
    ]
    if scripts:
        command.extend(["--script", scripts])

    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=180,
    )

    if result.returncode != 0:
        raise Exception(f"Nmap error: {result.stderr}")

    return result.stdout


def parse_nmap_xml(xml_output: str) -> list[dict]:
    findings = []
    root = ET.fromstring(xml_output)

    for host in root.findall("host"):
        address = host.find("address")
        ip_addr = address.get("addr") if address is not None else None

        ports = host.find("ports")
        if ports is None:
            continue

        for port in ports.findall("port"):
            state_elem = port.find("state")
            service_elem = port.find("service")

            state = state_elem.get("state") if state_elem is not None else None
            if state != "open":
                continue

            findings.append({
                "target": ip_addr,
                "port": int(port.get("portid")),
                "protocol": port.get("protocol"),
                "state": state,
                "service": service_elem.get("name") if service_elem is not None else None,
                "product": service_elem.get("product") if service_elem is not None else None,
                "version": service_elem.get("version") if service_elem is not None else None,
            })

    return findings