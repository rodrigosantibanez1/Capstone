"""
recon_agent.py — ReconAgent · HU-04 / HU-05 (Sprint 2)
=======================================================
Agente de reconocimiento OSINT real del pipeline ETH-MAS.

Backend configurable via .env:
  RECON_AGENT_BACKEND=claude   → Anthropic Haiku (default)
  RECON_AGENT_BACKEND=gemini   → Google Gemini (fallback/alternativa)
  RECON_AGENT_MODEL            → nombre del modelo (depende del backend)

El MCP server (osint_server.py) no cambia — es agnóstico al LLM cliente.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

import models
from mongo_client import surface_map_col, agent_runs_col
from mongo_schemas import SurfaceMapDoc, AgentRunDoc, ToolCallEntry

logger = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
RECON_AGENT_BACKEND = os.getenv("RECON_AGENT_BACKEND", "claude").lower()
RECON_AGENT_MODEL   = os.getenv(
    "RECON_AGENT_MODEL",
    "gemini-2.5-flash" if RECON_AGENT_BACKEND == "gemini" else "claude-haiku-4-5-20251001",
)

# Ruta al MCP server relativa al directorio de trabajo (eth-mas-backend/)
_OSINT_SERVER_SCRIPT = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "mcp_servers", "osint_server.py")
)


# ═══════════════════════════════════════════════════════════════════════════════
# ReconAgent
# ═══════════════════════════════════════════════════════════════════════════════

class ReconAgent:
    """
    Agente de reconocimiento OSINT.

    Uso desde FastAPI:
        agent  = ReconAgent(engagement_id=1, db=db_session)
        result = await agent.run()
    """

    def __init__(self, engagement_id: int, db: Session):
        self.engagement_id = engagement_id
        self.db            = db
        self.model         = RECON_AGENT_MODEL
        self._tool_log: list[ToolCallEntry] = []

    # ── Entrypoint público ────────────────────────────────────────────────────

    async def run(self) -> dict:
        """
        Ejecuta el pipeline completo de reconocimiento.
        Retorna un dict con status y surface_map persistido en MongoDB.
        """
        # 1. Obtener targets del engagement
        scopes = (
            self.db.query(models.ScopeTarget)
            .filter(models.ScopeTarget.engagement_id == self.engagement_id)
            .all()
        )
        if not scopes:
            return {
                "status":        "skipped",
                "reason":        "No hay scope targets configurados.",
                "engagement_id": self.engagement_id,
            }

        targets = [s.target_value for s in scopes]
        logger.info(
            "[ReconAgent] Iniciando — engagement=%d model=%s targets=%s",
            self.engagement_id, self.model, targets,
        )

        # 2. Registrar AgentRunDoc en MongoDB
        run_doc    = AgentRunDoc(
            engagement_id = self.engagement_id,
            agent         = "ReconAgent",
            model         = self.model,
            targets       = targets,
        )
        run_result = await agent_runs_col().insert_one(run_doc.model_dump())
        run_id     = str(run_result.inserted_id)

        # 3. Ejecutar agentic loop con MCP
        surface_map: dict         = {}
        final_status              = "completed"
        error_msg: Optional[str]  = None

        try:
            if RECON_AGENT_BACKEND == "gemini":
                surface_map = await self._run_agentic_loop_gemini(targets, scopes)
            else:
                surface_map = await self._run_agentic_loop(targets, scopes)
        except Exception as e:
            logger.error("[ReconAgent] Error en agentic loop: %s", e, exc_info=True)
            final_status = "failed"
            error_msg    = str(e)

        # 4. Actualizar AgentRunDoc con resultado final
        await agent_runs_col().update_one(
            {"_id": run_result.inserted_id},
            {"$set": {
                "status":       final_status,
                "finished_at":  datetime.utcnow(),
                "tools_called": [t.model_dump() for t in self._tool_log],
                "error":        error_msg,
            }},
        )

        logger.info(
            "[ReconAgent] Finalizado — engagement=%d status=%s tools=%d",
            self.engagement_id, final_status, len(self._tool_log),
        )

        return {
            "status":        final_status,
            "engagement_id": self.engagement_id,
            "model":         self.model,
            "surface_map":   surface_map,
            "agent_run_id":  run_id,
            "error":         error_msg,
        }

    # ── Agentic loop ──────────────────────────────────────────────────────────

    async def _run_agentic_loop(self, targets: list[str], scopes: list) -> dict:
        """
        Conecta al OSINT MCP Server y corre el loop de Haiku.
        El LLM decide cuándo llamar cada tool sobre cada target.
        Los resultados se acumulan en Python para construir el surface_map.
        """
        from anthropic import AsyncAnthropic
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

        server_params = StdioServerParameters(
            command = "python",
            args    = [_OSINT_SERVER_SCRIPT],
            env     = {**os.environ},
        )

        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                # Convertir tools MCP → formato Anthropic
                mcp_tools       = await session.list_tools()
                anthropic_tools = [
                    {
                        "name":         t.name,
                        "description":  t.description or "",
                        "input_schema": t.inputSchema,
                    }
                    for t in mcp_tools.tools
                ]
                logger.info(
                    "[ReconAgent] MCP server listo — tools: %s",
                    [t["name"] for t in anthropic_tools],
                )

                messages: list[dict] = [
                    {
                        "role":    "user",
                        "content": (
                            f"Ejecuta reconocimiento OSINT completo sobre los targets "
                            f"del engagement {self.engagement_id}: {targets}.\n"
                            f"Para cada target ejecuta dns_enum, whois_lookup y "
                            f"theharvester_run. Incluye siempre "
                            f"engagement_id={self.engagement_id} en cada call."
                        ),
                    }
                ]

                raw_results: list[dict] = []
                max_iters = len(targets) * 3 * 2 + 5

                for iteration in range(max_iters):
                    response = await client.messages.create(
                        model      = self.model,
                        max_tokens = 4096,
                        system     = self._build_system_prompt(targets),
                        tools      = anthropic_tools,
                        messages   = messages,
                    )

                    messages.append({
                        "role":    "assistant",
                        "content": response.content,
                    })

                    if response.stop_reason == "tool_use":
                        tool_results_content = []

                        for block in response.content:
                            if block.type != "tool_use":
                                continue

                            t_start          = datetime.utcnow()
                            result_text      = "{}"
                            call_status      = "completed"
                            hitl_id: Optional[int] = None

                            try:
                                mcp_result  = await session.call_tool(
                                    block.name, dict(block.input)
                                )
                                result_text = (
                                    mcp_result.content[0].text
                                    if mcp_result.content else "{}"
                                )
                                parsed      = json.loads(result_text)
                                raw_results.append(parsed)
                                hitl_id     = parsed.get("hitl_action_id")

                                if parsed.get("status") == "blocked":
                                    call_status = "scope_violation"
                                    logger.warning(
                                        "[ReconAgent] Scope violation — tool=%s input=%s",
                                        block.name, block.input,
                                    )

                            except Exception as e:
                                result_text = json.dumps({"error": str(e), "status": "error"})
                                call_status = "error"
                                logger.error(
                                    "[ReconAgent] Error tool call %s: %s", block.name, e
                                )

                            duration_ms = int(
                                (datetime.utcnow() - t_start).total_seconds() * 1000
                            )
                            self._tool_log.append(ToolCallEntry(
                                tool           = block.name,
                                target         = dict(block.input).get("target", ""),
                                status         = call_status,
                                hitl_action_id = hitl_id,
                                duration_ms    = duration_ms,
                            ))

                            tool_results_content.append({
                                "type":        "tool_result",
                                "tool_use_id": block.id,
                                "content":     result_text,
                            })

                        messages.append({
                            "role":    "user",
                            "content": tool_results_content,
                        })

                    elif response.stop_reason == "end_turn":
                        logger.info(
                            "[ReconAgent] Loop finalizado — iter=%d tool_calls=%d",
                            iteration + 1, len(self._tool_log),
                        )
                        break

                    else:
                        logger.warning(
                            "[ReconAgent] stop_reason inesperado: %s", response.stop_reason
                        )
                        break

        return await self._build_and_persist_surface_map(raw_results, scopes)

    # ── Agentic loop — Gemini backend ─────────────────────────────────────────

    async def _run_agentic_loop_gemini(self, targets: list[str], scopes: list) -> dict:
        """
        Loop del agente usando Gemini como LLM.
        El MCP server (osint_server.py) no cambia — solo el cliente LLM.
        """
        from google import genai
        from google.genai import types
        from services.mcp_gemini_bridge import load_mcp_tools_for_gemini, call_mcp_tool_from_gemini

        gemini_key = os.getenv("GEMINI_API_KEY")
        if not gemini_key:
            raise RuntimeError(
                "RECON_AGENT_BACKEND=gemini requiere GEMINI_API_KEY en .env"
            )

        gemini_client = genai.Client(api_key=gemini_key)

        declarations, session, stack = await load_mcp_tools_for_gemini(_OSINT_SERVER_SCRIPT)

        raw_results: list[dict] = []

        async with stack:
            messages: list[types.Content] = [
                types.Content(
                    role="user",
                    parts=[types.Part(text=(
                        f"Ejecuta reconocimiento OSINT completo sobre los targets "
                        f"del engagement {self.engagement_id}: {targets}. "
                        f"Para cada target ejecuta dns_enum, whois_lookup y theharvester_run. "
                        f"Incluye siempre engagement_id={self.engagement_id} en cada call."
                    ))],
                )
            ]

            max_iters = len(targets) * 3 * 2 + 5

            for iteration in range(max_iters):
                response = gemini_client.models.generate_content(
                    model    = self.model,
                    contents = messages,
                    config   = types.GenerateContentConfig(
                        system_instruction = self._build_system_prompt(targets),
                        tools              = [types.Tool(function_declarations=declarations)],
                        temperature        = 0.1,
                    ),
                )

                candidate = response.candidates[0]
                messages.append(candidate.content)

                function_calls = [
                    p for p in candidate.content.parts
                    if hasattr(p, "function_call") and p.function_call
                ]

                if not function_calls:
                    logger.info(
                        "[ReconAgent/Gemini] Loop finalizado — iter=%d tool_calls=%d",
                        iteration + 1, len(self._tool_log),
                    )
                    break

                function_responses = []
                for part in function_calls:
                    fc          = part.function_call
                    t_start     = datetime.utcnow()
                    result_text = "{}"
                    call_status = "completed"
                    hitl_id: Optional[int] = None

                    try:
                        result_text = await call_mcp_tool_from_gemini(session, fc)
                        parsed      = json.loads(result_text)
                        raw_results.append(parsed)
                        hitl_id     = parsed.get("hitl_action_id")

                        if parsed.get("status") == "blocked":
                            call_status = "scope_violation"
                            logger.warning(
                                "[ReconAgent/Gemini] Scope violation — tool=%s args=%s",
                                fc.name, dict(fc.args or {}),
                            )
                    except Exception as e:
                        result_text = json.dumps({"error": str(e), "status": "error"})
                        call_status = "error"
                        logger.error("[ReconAgent/Gemini] Error tool call %s: %s", fc.name, e)

                    duration_ms = int((datetime.utcnow() - t_start).total_seconds() * 1000)
                    self._tool_log.append(ToolCallEntry(
                        tool           = fc.name,
                        target         = dict(fc.args or {}).get("target", ""),
                        status         = call_status,
                        hitl_action_id = hitl_id,
                        duration_ms    = duration_ms,
                    ))

                    function_responses.append(
                        types.Part(function_response=types.FunctionResponse(
                            name     = fc.name,
                            response = {"result": result_text},
                        ))
                    )

                messages.append(types.Content(role="user", parts=function_responses))

        return await self._build_and_persist_surface_map(raw_results, scopes)

    # ── Surface map ───────────────────────────────────────────────────────────

    async def _build_and_persist_surface_map(
        self,
        raw_results: list[dict],
        scopes: list,
    ) -> dict:
        """
        Construye el surface_map a partir de los resultados de las tools.
        Lógica Python determinista — no depende del LLM para este paso.
        Persiste en MongoDB con upsert (uno por engagement).
        """
        emails:         set[str] = set()
        ips:            set[str] = set()
        hosts:          set[str] = set()
        dns_records:    dict     = {}
        whois_data:     dict     = {}
        harvester_data: dict     = {}

        for result in raw_results:
            if not isinstance(result, dict):
                continue
            tool   = result.get("tool", "")
            target = result.get("target", "unknown")

            if tool == "dns_enum":
                recs                = result.get("records", {})
                dns_records[target] = recs
                ips.update(recs.get("A", []))

            elif tool == "whois_lookup":
                whois_data[target] = result.get("data", {})

            elif tool == "theharvester_run":
                data                    = result.get("data", {})
                harvester_data[target]  = data
                emails.update(data.get("emails", []))
                hosts.update(data.get("hosts",   []))
                ips.update(data.get("ips",       []))

        scope_values  = [s.target_value for s in scopes]
        all_hosts     = hosts | ips
        new_vs_scope  = sorted(
            h for h in all_hosts
            if not any(
                h == sv or h.endswith(f".{sv}")
                for sv in scope_values
            )
        )

        doc = SurfaceMapDoc(
            engagement_id    = self.engagement_id,
            scope_original   = scope_values,
            emails_osint     = sorted(emails),
            hosts_discovered = sorted(all_hosts),
            new_vs_scope     = new_vs_scope,
            dns_records      = dns_records,
            whois_data       = whois_data,
            harvester_data   = harvester_data,
            model_used       = self.model,
        )

        await surface_map_col().replace_one(
            {"engagement_id": self.engagement_id},
            doc.model_dump(),
            upsert=True,
        )

        logger.info(
            "[ReconAgent] Surface map persistido — engagement=%d "
            "hosts=%d emails=%d new_vs_scope=%d",
            self.engagement_id,
            len(doc.hosts_discovered),
            len(doc.emails_osint),
            len(doc.new_vs_scope),
        )
        return doc.model_dump()

    # ── System prompt ─────────────────────────────────────────────────────────

    def _build_system_prompt(self, targets: list[str]) -> str:
        return (
            f"Eres ReconAgent, el agente de reconocimiento OSINT del sistema ETH-MAS.\n\n"
            f"Tu responsabilidad: ejecutar reconocimiento pasivo sobre los targets "
            f"autorizados del engagement {self.engagement_id} usando las tools disponibles.\n\n"
            f"TARGETS AUTORIZADOS: {targets}\n\n"
            f"INSTRUCCIONES:\n"
            f"1. Para CADA target, ejecuta en orden:\n"
            f"   a) dns_enum      — registros A, MX, NS, TXT\n"
            f"   b) whois_lookup  — información de registro\n"
            f"   c) theharvester_run — emails, hosts, IPs OSINT\n\n"
            f"2. SIEMPRE incluye engagement_id={self.engagement_id} en cada tool call.\n\n"
            f"3. Si una tool retorna status 'blocked': violación de scope.\n"
            f"   No reintentes ese target. Continúa con el siguiente.\n\n"
            f"4. Si una tool retorna 'tool_not_found' o 'timeout': continúa.\n\n"
            f"5. Cuando hayas ejecutado las 3 tools sobre todos los targets,\n"
            f"   responde con un resumen breve de lo encontrado.\n\n"
            f"No hagas suposiciones sobre vulnerabilidades — eso es tarea de AnalysisAgent."
        )
