"""
scan_agent.py — ScanAgent · HU-06 (Sprint 2/3)
===============================================
Agente de escaneo activo del pipeline ETH-MAS.

Modelo LLM: claude-haiku-4-5-20251001 (configurable via env SCAN_AGENT_MODEL)

Flujo:
  1. Conecta al Security MCP Server (security_server.py) via stdio
  2. Obtiene las tools (nmap_scan, nuclei_run, nikto_scan, gobuster_run)
  3. Ejecuta agentic loop: el agente decide qué tools usar sobre cada target
  4. Cada tool call → scope check + HITL PENDING → espera aprobación operador
  5. Tras aprobación → ejecuta herramienta real
  6. Persiste findings en MongoDB (HU-07)
  7. Persiste AgentRunDoc en MongoDB (trazabilidad)

Arquitectura MCP:
  ScanAgent (este archivo)
       │  Anthropic API (claude-haiku-4-5-20251001)
       │  tool calls via agentic loop
       ↓
  MCP Client (mcp.client.stdio)
       │  JSON-RPC sobre stdio
       ↓
  security_server.py (proceso separado)
       │  scope check + HITL PENDING (espera decisión)
       ↓
  nmap / nuclei / nikto / gobuster subprocess
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

import models
from mongo_client import agent_runs_col
from mongo_schemas import AgentRunDoc, ToolCallEntry
from services.findings_service import persist_findings_bulk

logger = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
SCAN_AGENT_BACKEND = os.getenv("SCAN_AGENT_BACKEND", "claude").lower()
SCAN_AGENT_MODEL   = os.getenv(
    "SCAN_AGENT_MODEL",
    "gemini-2.5-flash" if SCAN_AGENT_BACKEND == "gemini" else "claude-haiku-4-5-20251001",
)

_SECURITY_SERVER_SCRIPT = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "mcp_servers", "security_server.py")
)


# ═══════════════════════════════════════════════════════════════════════════════
# ScanAgent
# ═══════════════════════════════════════════════════════════════════════════════

class ScanAgent:
    """
    Agente de escaneo activo.

    Uso desde FastAPI:
        agent  = ScanAgent(engagement_id=1, db=db_session)
        result = await agent.run()
    """

    def __init__(self, engagement_id: int, db: Session):
        self.engagement_id = engagement_id
        self.db            = db
        self.model         = SCAN_AGENT_MODEL
        if SCAN_AGENT_BACKEND == "gemini":
            raise NotImplementedError(
                "SCAN_AGENT_BACKEND=gemini no está implementado aún. "
                "Usar SCAN_AGENT_BACKEND=claude (default) para Sprint 2."
            )
        self._tool_log: list[ToolCallEntry] = []

    # ── Entrypoint público ────────────────────────────────────────────────────

    async def run(self) -> dict:
        """
        Ejecuta el pipeline completo de escaneo.
        Retorna un dict con status, findings persistidos y run_id.
        """
        scopes = (
            self.db.query(models.ScopeTarget)
            .filter(models.ScopeTarget.engagement_id == self.engagement_id)
            .all()
        )
        if not scopes:
            return {
                "status":        "skipped",
                "reason":        "No hay scope targets configurados.",
                "engagement_id": self.engagement_id,
            }

        targets = [s.target_value for s in scopes]
        logger.info(
            "[ScanAgent] Iniciando — engagement=%d model=%s targets=%s",
            self.engagement_id, self.model, targets,
        )

        # Registrar AgentRunDoc
        run_doc    = AgentRunDoc(
            engagement_id = self.engagement_id,
            agent         = "ScanAgent",
            model         = self.model,
            targets       = targets,
        )
        run_result = await agent_runs_col().insert_one(run_doc.model_dump())
        run_id     = str(run_result.inserted_id)

        # Ejecutar agentic loop
        all_findings: list[dict] = []
        final_status             = "completed"
        error_msg: Optional[str] = None

        try:
            all_findings = await self._run_agentic_loop(targets)
        except Exception as e:
            logger.error("[ScanAgent] Error en agentic loop: %s", e, exc_info=True)
            final_status = "failed"
            error_msg    = str(e)

        # Persistir findings en MongoDB (HU-07)
        inserted = 0
        if all_findings:
            inserted = await persist_findings_bulk(all_findings)
            logger.info("[ScanAgent] %d findings persistidos en MongoDB", inserted)

        # Actualizar AgentRunDoc
        await agent_runs_col().update_one(
            {"_id": run_result.inserted_id},
            {"$set": {
                "status":         final_status,
                "finished_at":    datetime.utcnow(),
                "tools_called":   [t.model_dump() for t in self._tool_log],
                "findings_count": inserted,
                "error":          error_msg,
            }},
        )

        logger.info(
            "[ScanAgent] Finalizado — engagement=%d status=%s findings=%d",
            self.engagement_id, final_status, inserted,
        )

        return {
            "status":         final_status,
            "engagement_id":  self.engagement_id,
            "model":          self.model,
            "findings_count": inserted,
            "findings":       all_findings,
            "agent_run_id":   run_id,
            "error":          error_msg,
        }

    # ── Agentic loop ──────────────────────────────────────────────────────────

    async def _run_agentic_loop(self, targets: list[str]) -> list[dict]:
        """
        Conecta al Security MCP Server y corre el loop con el modelo LLM.
        El LLM decide qué herramientas usar sobre cada target.
        Cada tool call pasa por scope check + HITL antes de ejecutarse.
        """
        from anthropic import AsyncAnthropic
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

        server_params = StdioServerParameters(
            command = "python",
            args    = [_SECURITY_SERVER_SCRIPT],
            env     = {**os.environ},
        )

        all_findings: list[dict] = []

        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                mcp_tools       = await session.list_tools()
                anthropic_tools = [
                    {
                        "name":         t.name,
                        "description":  t.description or "",
                        "input_schema": t.inputSchema,
                    }
                    for t in mcp_tools.tools
                ]
                logger.info(
                    "[ScanAgent] MCP server listo — tools: %s",
                    [t["name"] for t in anthropic_tools],
                )

                messages: list[dict] = [
                    {
                        "role":    "user",
                        "content": (
                            f"Ejecuta escaneo activo sobre los targets del engagement "
                            f"{self.engagement_id}: {targets}.\n"
                            f"Para cada target ejecuta nmap_scan con parámetros apropiados. "
                            f"Incluye siempre engagement_id={self.engagement_id}."
                        ),
                    }
                ]

                # Máx iteraciones = targets × tools disponibles × margen
                max_iters = len(targets) * len(anthropic_tools) * 2 + 5

                for iteration in range(max_iters):
                    response = await client.messages.create(
                        model      = self.model,
                        max_tokens = 4096,
                        system     = self._build_system_prompt(targets),
                        tools      = anthropic_tools,
                        messages   = messages,
                    )

                    messages.append({
                        "role":    "assistant",
                        "content": response.content,
                    })

                    if response.stop_reason == "tool_use":
                        tool_results_content = []

                        for block in response.content:
                            if block.type != "tool_use":
                                continue

                            t_start     = datetime.utcnow()
                            result_text = "{}"
                            call_status = "completed"
                            hitl_id: Optional[int] = None

                            try:
                                mcp_result  = await session.call_tool(
                                    block.name, dict(block.input)
                                )
                                result_text = (
                                    mcp_result.content[0].text
                                    if mcp_result.content else "{}"
                                )
                                parsed      = json.loads(result_text)
                                hitl_id     = parsed.get("hitl_action_id")

                                status = parsed.get("status", "")
                                if status == "blocked":
                                    call_status = "scope_violation"
                                    logger.warning(
                                        "[ScanAgent] Scope violation — tool=%s input=%s",
                                        block.name, block.input,
                                    )
                                elif status == "rejected":
                                    call_status = "hitl_rejected"
                                    logger.info(
                                        "[ScanAgent] HITL rechazado — tool=%s hitl_id=%s",
                                        block.name, hitl_id,
                                    )
                                elif status == "hitl_timeout":
                                    call_status = "hitl_timeout"
                                    logger.warning(
                                        "[ScanAgent] HITL timeout — tool=%s hitl_id=%s",
                                        block.name, hitl_id,
                                    )
                                elif status == "completed":
                                    # Acumular findings del nmap_scan
                                    findings = parsed.get("findings", [])
                                    all_findings.extend(findings)
                                    logger.info(
                                        "[ScanAgent] tool=%s target=%s findings=%d",
                                        block.name,
                                        dict(block.input).get("target", "?"),
                                        len(findings),
                                    )

                            except Exception as e:
                                result_text = json.dumps({"error": str(e), "status": "error"})
                                call_status = "error"
                                logger.error(
                                    "[ScanAgent] Error tool call %s: %s", block.name, e
                                )

                            duration_ms = int(
                                (datetime.utcnow() - t_start).total_seconds() * 1000
                            )
                            self._tool_log.append(ToolCallEntry(
                                tool           = block.name,
                                target         = dict(block.input).get("target", ""),
                                status         = call_status,
                                hitl_action_id = hitl_id,
                                duration_ms    = duration_ms,
                            ))

                            tool_results_content.append({
                                "type":        "tool_result",
                                "tool_use_id": block.id,
                                "content":     result_text,
                            })

                        messages.append({
                            "role":    "user",
                            "content": tool_results_content,
                        })

                    elif response.stop_reason == "end_turn":
                        logger.info(
                            "[ScanAgent] Loop finalizado — iter=%d tool_calls=%d findings=%d",
                            iteration + 1, len(self._tool_log), len(all_findings),
                        )
                        break

                    else:
                        logger.warning(
                            "[ScanAgent] stop_reason inesperado: %s", response.stop_reason
                        )
                        break

        return all_findings

    # ── System prompt ─────────────────────────────────────────────────────────

    def _build_system_prompt(self, targets: list[str]) -> str:
        return (
            f"Eres ScanAgent, el agente de escaneo activo del sistema ETH-MAS.\n\n"
            f"Tu responsabilidad: ejecutar escaneo de puertos y servicios sobre los targets\n"
            f"autorizados del engagement {self.engagement_id}.\n\n"
            f"TARGETS AUTORIZADOS: {targets}\n\n"
            f"INSTRUCCIONES:\n"
            f"1. Para CADA target ejecuta nmap_scan con:\n"
            f"   - ports='1-1024' para el primer escaneo\n"
            f"   - timing=3 (normal, no agresivo)\n"
            f"   - Incluye siempre engagement_id={self.engagement_id}\n\n"
            f"2. HITL: cada nmap_scan requiere aprobación humana.\n"
            f"   Si una tool retorna status 'rejected': el operador rechazó.\n"
            f"   No reintentes el mismo target con los mismos parámetros.\n\n"
            f"3. Si status='hitl_timeout': el operador no respondió a tiempo.\n"
            f"   Continúa con el siguiente target.\n\n"
            f"4. Si status='blocked': violación de scope. No reintentes.\n\n"
            f"5. Cuando hayas escaneado todos los targets posibles,\n"
            f"   resume brevemente los hallazgos encontrados.\n\n"
            f"No intentes explotar vulnerabilidades — solo enumerar servicios."
        )
