"""
scan_service.py — Entry point de scan para el endpoint POST /scan
=================================================================
NOTA ARQUITECTURAL (Sprint 2 → Sprint 3):
  Este módulo es el entry point ACTUAL del scan hasta que security_server.py
  (MCP) + scan_agent.py estén completos. Realiza scope check programático y
  persiste findings en MongoDB, pero aún NO tiene HITL (G-03 → ver security_server.py).

  Cuando scan_agent.py esté listo, el endpoint /scan llamará a scan_agent.run()
  y este módulo quedará como helper interno.
"""

from __future__ import annotations

import asyncio

from services.nmap_service import run_nmap_scan, parse_nmap_xml
from services.findings_service import normalize_nmap_findings, persist_findings_bulk


async def execute_scan_agent(
    engagement_id: int,
    targets: list[str],
    allowed_targets: list[str],
) -> dict:
    """
    Ejecuta nmap sobre cada target in-scope, normaliza los findings
    con severidad real y los persiste en MongoDB.

    El scope check usa comparación directa contra allowed_targets (los scope_targets
    del engagement ya validados en el endpoint). Para validación avanzada IP/CIDR/domain
    usar ScanAgent vía security_server.py (Sprint 3).

    Returns:
        {
            "scanned": int,        # targets escaneados
            "skipped": int,        # targets fuera de scope
            "findings_count": int, # total findings insertados en MongoDB
            "findings": list[dict] # findings normalizados (para respuesta API)
        }
    """
    all_findings: list[dict] = []
    skipped: list[str] = []

    for target in targets:
        if target not in allowed_targets:
            print(f"[SCAN] Target fuera de scope, omitido: {target}")
            skipped.append(target)
            continue

        print(f"[SCAN] Escaneando: {target}")
        # run_nmap_scan es síncrono (subprocess) — ejecutar en thread pool
        xml_output = await asyncio.to_thread(run_nmap_scan, target)
        raw_findings = parse_nmap_xml(xml_output)
        normalized = normalize_nmap_findings(engagement_id, raw_findings)
        all_findings.extend(normalized)

    # Persistir todos los findings en MongoDB (HU-07)
    inserted = await persist_findings_bulk(all_findings)
    print(f"[SCAN] {inserted} findings persistidos en MongoDB")

    return {
        "scanned": len(targets) - len(skipped),
        "skipped": len(skipped),
        "findings_count": inserted,
        "findings": all_findings,
    }
