import asyncio

async def run_dummy_scan(target_value: str, target_type: str):
    """
    Simula un escaneo de seguridad sobre un objetivo.
    Más adelante, aquí conectaremos las herramientas reales.
    """
    # 1. Simulamos el inicio del escaneo
    print(f"[*] MOTOR ETH-MAS: Iniciando reconocimiento sobre {target_value} ({target_type})...")
    
    # 2. Simulamos que la herramienta (ej. Nmap) tarda 3 segundos en hacer su trabajo
    await asyncio.sleep(3)
    
    # 3. Armamos un reporte de mentira (mock) para devolver a la base de datos
    reporte = {
        "target": target_value,
        "status": "completado",
        "open_ports": [80, 443, 22],
        "risk_level": "Medio"
    }
    
    print(f"[+] MOTOR ETH-MAS: Escaneo completado para {target_value}")
    
    return reporte