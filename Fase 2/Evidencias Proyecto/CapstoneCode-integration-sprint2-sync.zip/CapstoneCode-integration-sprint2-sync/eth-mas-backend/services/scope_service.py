"""
scope_service.py — DEPRECADO (G-11)
=====================================
Duplicado de scope_validator.py con firma diferente.
Mantenido como shim de compatibilidad mientras se migra código legacy.

USAR SIEMPRE:  from services.scope_validator import is_target_in_scope
NO USAR:       from services.scope_service import is_target_in_scope

La firma canónica es: is_target_in_scope(target, engagement_id, db)
que consulta PostgreSQL. Este módulo tenía una firma incompatible
is_target_in_scope(target, allowed_targets: list[str]).

scan_service.py ya fue migrado a scope_validator.
Este archivo puede eliminarse cuando no queden otros importadores.
"""
# Re-export para no romper imports legacy (eliminar cuando sea seguro)
from services.scope_validator import is_target_in_scope  # noqa: F401
