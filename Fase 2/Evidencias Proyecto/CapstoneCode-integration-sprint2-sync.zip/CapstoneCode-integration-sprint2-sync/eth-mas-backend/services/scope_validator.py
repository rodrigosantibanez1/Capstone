import ipaddress
from sqlalchemy.orm import Session
import models

def is_target_in_scope(target: str, engagement_id: int, db: Session) -> bool:
    """
    Verifica si un objetivo encontrado (target) está dentro del alcance (scope) autorizado.
    """
    # 1. Traemos de la base de datos todos los objetivos autorizados para este análisis
    scopes_autorizados = db.query(models.ScopeTarget).filter(models.ScopeTarget.engagement_id == engagement_id).all()

    for scope in scopes_autorizados:
        
        # MAGIA AQUÍ: Extraemos el nombre en texto (IP, CIDR, DOMAIN) para que Python pueda compararlo
        tipo = scope.target_type.name if hasattr(scope.target_type, 'name') else str(scope.target_type).upper()
        
        # CASO 1: Comparación de IP exacta
        if tipo == "IP":
            if target == scope.target_value:
                return True
                
        # CASO 2: Comparación de rango de red (CIDR)
        elif tipo == "CIDR":
            try:
                # Verificamos si la IP encontrada pertenece al rango autorizado
                if ipaddress.ip_address(target) in ipaddress.ip_network(scope.target_value, strict=False):
                    return True
            except ValueError:
                pass # Si el target no era una IP válida, ignoramos este error y seguimos buscando
                
        # CASO 3: Comparación de dominios y subdominios
        elif tipo == "DOMAIN":
            # Es válido si es el dominio exacto (ej: google.com) 
            # o si es un subdominio válido (ej: api.google.com)
            if target == scope.target_value or target.endswith(f".{scope.target_value}"):
                return True

    # Si revisamos toda la lista y no hubo ninguna coincidencia... es ilegal atacarlo
    return False