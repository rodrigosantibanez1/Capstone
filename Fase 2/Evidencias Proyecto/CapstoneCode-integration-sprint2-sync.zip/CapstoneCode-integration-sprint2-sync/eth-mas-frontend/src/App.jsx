import { useState } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from './theme'

// Vistas originales
import LoginView           from './views/LoginView'
import DashboardView       from './views/DashboardView'
import EngagementsView     from './views/EngagementsView'
import PipelineView        from './views/PipelineView'
import HitlView            from './views/HitlView'
import HallazgosView       from './views/HallazgosView'
import ReportesView        from './views/ReportesView'

// Vistas nuevas
import EngagementSetupView  from './views/EngagementSetupView'
import EngagementsListView  from './views/EngagementsListView'
import ReporteEjecutivoView from './views/ReporteEjecutivoView'
import AttackCoverageView   from './views/AttackCoverageView'
import AttackVectorsView    from './views/AttackVectorsView'
import SurfaceMapView       from './views/SurfaceMapView'
import HitlAuditView        from './views/HitlAuditView'

// ─── Grupos de navegación ───────────────────────────────────────────────────
const NAV_GROUPS = [
  {
    label: 'General',
    items: [
      { id: 'Dashboard',        label: 'Dashboard',         icon: '▦' },
      { id: 'Pipeline',         label: 'Pipeline',          icon: '▶' },
    ],
  },
  {
    label: 'Engagements',
    items: [
      { id: 'EngagementsList',  label: 'Todos los Engagements', icon: '◎' },
      { id: 'EngagementSetup',  label: 'Nuevo Engagement',      icon: '+' },
      { id: 'Engagements',      label: 'Scope Activo',          icon: '◉' },
      { id: 'SurfaceMap',       label: 'Surface Map',           icon: '⊙' },
    ],
  },
  {
    label: 'Análisis',
    items: [
      { id: 'Hallazgos',        label: 'Hallazgos',             icon: '⚑' },
      { id: 'AttackVectors',    label: 'Vectores de Ataque',    icon: '⇢' },
      { id: 'AttackCoverage',   label: 'ATT&CK Coverage',       icon: '⊞' },
    ],
  },
  {
    label: 'Control',
    items: [
      { id: 'HITL',             label: 'Consola HITL',          icon: '⚡', badge: 2 },
      { id: 'HitlAudit',        label: 'HITL Audit Log',        icon: '☰' },
    ],
  },
  {
    label: 'Reportes',
    items: [
      { id: 'Reportes',         label: 'Reportes',              icon: '↓' },
      { id: 'ReporteEjecutivo', label: 'Reporte Ejecutivo',     icon: '★' },
    ],
  },
]

// ─── Sidebar ─────────────────────────────────────────────────────────────────
function Sidebar({ vistaActual, setVista, onLogout }) {
  return (
    <div style={{
      width: '220px', flexShrink: 0,
      backgroundColor: COLORS.bgSidebar,
      borderRight: `1px solid ${COLORS.border}`,
      display: 'flex', flexDirection: 'column',
      height: '100vh', boxSizing: 'border-box',
      overflowY: 'auto',
    }}>
      {/* Logo */}
      <div style={{ padding: `${SPACING.lg} ${SPACING.md} ${SPACING.sm}` }}>
        <div style={{ fontSize: FONT.sizeXL, fontWeight: '800', color: COLORS.accent,
          letterSpacing: '2px', fontFamily: FONT.mono }}>ETH-MAS</div>
        <div style={{ fontSize: FONT.sizeXS, color: COLORS.textDim, marginTop: '2px' }}>
          v0.1 · academic prototype
        </div>
      </div>

      <div style={{ borderTop: `1px solid ${COLORS.border}`, margin: `0 ${SPACING.md}` }} />

      {/* Grupos nav */}
      <nav style={{ flex: 1, padding: `${SPACING.sm} ${SPACING.sm}` }}>
        {NAV_GROUPS.map((grupo) => (
          <div key={grupo.label} style={{ marginBottom: SPACING.sm }}>
            <div style={{ fontSize: FONT.sizeXS, color: COLORS.textDim, fontWeight: '600',
              letterSpacing: '1px', textTransform: 'uppercase',
              padding: `${SPACING.xs} ${SPACING.sm}`, marginBottom: '2px' }}>
              {grupo.label}
            </div>
            {grupo.items.map((item) => {
              const activo = vistaActual === item.id
              return (
                <div key={item.id} onClick={() => setVista(item.id)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: SPACING.xs,
                    padding: '7px 10px', borderRadius: RADIUS.md, cursor: 'pointer',
                    backgroundColor: activo ? COLORS.accentAlpha : 'transparent',
                    color: activo ? COLORS.accent : COLORS.textMuted,
                    fontWeight: activo ? '700' : '400',
                    fontSize: FONT.sizeSM,
                    borderLeft: activo ? `3px solid ${COLORS.accent}` : '3px solid transparent',
                    transition: 'all 0.15s',
                    marginBottom: '1px',
                  }}>
                  <span style={{ fontSize: '13px', lineHeight: 1, flexShrink: 0 }}>{item.icon}</span>
                  <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {item.label}
                  </span>
                  {item.badge && (
                    <span style={{ padding: '1px 6px', backgroundColor: COLORS.danger,
                      color: '#fff', borderRadius: RADIUS.full, fontSize: FONT.sizeXS, fontWeight: '700' }}>
                      {item.badge}
                    </span>
                  )}
                </div>
              )
            })}
          </div>
        ))}
      </nav>

      <div style={{ borderTop: `1px solid ${COLORS.border}`, margin: `0 ${SPACING.md}` }} />

      {/* Footer */}
      <div style={{ padding: SPACING.md }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.xs,
          fontSize: FONT.sizeSM, color: COLORS.textMuted, marginBottom: SPACING.sm }}>
          <span style={{ color: COLORS.success, fontSize: '10px' }}>●</span>
          Sistema: Activo
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm }}>
          <div style={{ width: '32px', height: '32px', borderRadius: '50%',
            backgroundColor: COLORS.accent, display: 'flex', alignItems: 'center',
            justifyContent: 'center', fontSize: FONT.sizeMD, fontWeight: '700',
            color: '#fff', flexShrink: 0 }}>A</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: FONT.sizeSM, fontWeight: '600', color: COLORS.textPrimary,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>Admin User</div>
            <div style={{ fontSize: FONT.sizeXS, color: COLORS.textDim,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>admin@eth-mas.cl</div>
          </div>
          <button onClick={onLogout} title="Cerrar sesión"
            style={{ background: 'none', border: 'none', color: COLORS.textDim,
              cursor: 'pointer', fontSize: '16px', padding: '4px', flexShrink: 0 }}>⏻</button>
        </div>
      </div>
    </div>
  )
}

// ─── Router de vistas ─────────────────────────────────────────────────────────
function renderVista(vistaActual, setVista) {
  switch (vistaActual) {
    // Originales
    case 'Dashboard':        return <DashboardView />
    case 'Pipeline':         return <PipelineView />
    case 'Engagements':      return <EngagementsView />
    case 'HITL':             return <HitlView />
    case 'Hallazgos':        return <HallazgosView />
    case 'Reportes':         return <ReportesView />
    // Nuevas
    case 'EngagementSetup':  return <EngagementSetupView onCreated={() => setVista('EngagementsList')} />
    case 'EngagementsList':  return <EngagementsListView onNuevoEngagement={() => setVista('EngagementSetup')} />
    case 'ReporteEjecutivo': return <ReporteEjecutivoView />
    case 'AttackCoverage':   return <AttackCoverageView />
    case 'AttackVectors':    return <AttackVectorsView />
    case 'SurfaceMap':       return <SurfaceMapView />
    case 'HitlAudit':        return <HitlAuditView />
    default:                 return <DashboardView />
  }
}

// ─── App root ─────────────────────────────────────────────────────────────────
export default function App() {
  // LoginView desactivado temporalmente — no es foco del sprint académico.
  // Para reactivar auth: cambiar useState(true) a useState(false)
  const [isLoggedIn,  setIsLoggedIn]  = useState(true)
  const [vistaActual, setVistaActual] = useState('Dashboard')

  if (!isLoggedIn) {
    return <LoginView onLogin={() => setIsLoggedIn(true)} />
  }

  return (
    <div style={{
      display: 'flex', height: '100vh',
      backgroundColor: COLORS.bgApp,
      color: COLORS.textPrimary,
      fontFamily: FONT.base,
      overflow: 'hidden',
    }}>
      <Sidebar
        vistaActual={vistaActual}
        setVista={setVistaActual}
        onLogout={() => setIsLoggedIn(false)}
      />
      <main style={{ flex: 1, overflowY: 'auto', padding: SPACING.xxl }}>
        {renderVista(vistaActual, setVistaActual)}
      </main>
    </div>
  )
}
