// theme.js — Design tokens canónicos de ETH-MAS
// Fuente única de verdad para colores, tipografía y espaciado.
// Importar en cualquier componente: import { COLORS, FONT, RADIUS, SPACING } from '../theme'

export const COLORS = {
  // Fondos
  bgApp:       '#14151a',
  bgSidebar:   '#1a1c23',
  bgCard:      '#22252e',
  bgTerminal:  '#000000',
  bgInput:     '#14151a',

  // Bordes
  border:      '#2c2f3a',

  // Texto
  textPrimary: '#ffffff',
  textMuted:   '#8b949e',
  textDim:     '#555555',

  // Acentos
  accent:      '#2d68ff',
  accentAlpha: '#2d68ff22',
  danger:      '#ff2e63',
  dangerAlpha: '#ff2e6322',
  warning:     '#f59e0b',
  warningAlpha:'#f59e0b22',
  success:     '#22c55e',
  successAlpha:'#22c55e22',
  terminal:    '#00ff00',
  info:        '#38bdf8',
  infoAlpha:   '#38bdf822',

  // Severidades
  sevCritical: '#ff2e63',
  sevHigh:     '#f97316',
  sevMedium:   '#f59e0b',
  sevLow:      '#38bdf8',
  sevInfo:     '#8b949e',
};

export const FONT = {
  base:    "system-ui, -apple-system, sans-serif",
  mono:    "'Courier New', Courier, monospace",
  sizeXS:  '11px',
  sizeSM:  '12px',
  sizeMD:  '14px',
  sizeLG:  '16px',
  sizeXL:  '20px',
  size2XL: '24px',
  size3XL: '32px',
  size4XL: '48px',
};

export const RADIUS = {
  sm:   '4px',
  md:   '8px',
  lg:   '12px',
  full: '9999px',
};

export const SPACING = {
  xs:  '4px',
  sm:  '8px',
  md:  '16px',
  lg:  '24px',
  xl:  '32px',
  xxl: '40px',
};
