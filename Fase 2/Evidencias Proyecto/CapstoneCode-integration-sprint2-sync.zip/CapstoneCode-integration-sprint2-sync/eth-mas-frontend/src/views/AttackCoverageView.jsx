import { COLORS, FONT, RADIUS, SPACING } from '../theme'

export default function AttackCoverageView() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl, fontFamily: FONT.base }}>
      <div>
        <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>
          ATT&CK Coverage Matrix
        </h1>
        <p style={{ margin: '4px 0 0', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
          Cobertura del engagement · Heatmap por CVSS máximo y conteo de findings
        </p>
      </div>
      <div style={{
        backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg, padding: SPACING.xl,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: SPACING.lg,
        textAlign: 'center',
      }}>
        <div style={{ fontSize: '48px', opacity: 0.3 }}>⬡</div>
        <div style={{ fontSize: FONT.sizeLG, fontWeight: '600', color: COLORS.textMuted }}>
          Datos pendientes
        </div>
        <div style={{ fontSize: FONT.sizeMD, color: COLORS.textDim, maxWidth: '480px', lineHeight: '1.6' }}>
          El heatmap ATT&CK se genera automáticamente cuando <strong style={{ color: COLORS.accent }}>AnalysisAgent</strong> completa
          el mapeo de findings a tácticas y técnicas MITRE.<br />
          Ejecuta el pipeline completo: Recon → Scan → Analysis.
        </div>
      </div>
    </div>
  )
}
