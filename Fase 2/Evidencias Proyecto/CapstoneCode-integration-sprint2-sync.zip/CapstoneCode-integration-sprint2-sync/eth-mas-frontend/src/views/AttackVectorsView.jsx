import { COLORS, FONT, RADIUS, SPACING } from '../theme'

export default function AttackVectorsView() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl, fontFamily: FONT.base }}>
      <div>
        <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>
          Vectores de Ataque
        </h1>
        <p style={{ margin: '4px 0 0', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
          Cadenas de ataque identificadas por AnalysisAgent
        </p>
      </div>
      <div style={{
        backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg, padding: SPACING.xl,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: SPACING.lg,
        textAlign: 'center',
      }}>
        <div style={{ fontSize: '48px', opacity: 0.3 }}>⛓</div>
        <div style={{ fontSize: FONT.sizeLG, fontWeight: '600', color: COLORS.textMuted }}>
          Sin vectores identificados
        </div>
        <div style={{ fontSize: FONT.sizeMD, color: COLORS.textDim, maxWidth: '480px', lineHeight: '1.6' }}>
          Los vectores de ataque (kill chains) son generados por <strong style={{ color: COLORS.accent }}>AnalysisAgent</strong> tras
          correlacionar los findings del escaneo con CVEs y tácticas MITRE ATT&CK.<br />
          Disponible en Sprint 3.
        </div>
      </div>
    </div>
  )
}
