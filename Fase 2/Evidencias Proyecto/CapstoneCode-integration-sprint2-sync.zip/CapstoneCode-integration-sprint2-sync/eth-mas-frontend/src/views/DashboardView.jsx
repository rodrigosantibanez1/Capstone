import { useState, useEffect } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

const API_BASE = 'http://localhost:8000'

// Mapeo status backend → label UI
const STATUS_LABEL = {
  pending:   'Pendiente',
  running:   'En progreso',
  paused:    'Pausado',
  completed: 'Completo',
  aborted:   'Detenido',
}

function KpiCard({ label, value, color, icon, loading }) {
  return (
    <div style={{
      flex: 1,
      backgroundColor: COLORS.bgCard,
      border: `1px solid ${COLORS.border}`,
      borderRadius: RADIUS.lg,
      padding: SPACING.lg,
    }}>
      <div style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted, marginBottom: SPACING.sm }}>
        {icon} {label}
      </div>
      <div style={{ fontSize: FONT.size4XL, fontWeight: '800', color, lineHeight: 1 }}>
        {loading ? <span style={{ opacity: 0.3 }}>—</span> : value}
      </div>
    </div>
  )
}

function EstadoBadge({ status }) {
  const map = {
    running:   { bg: COLORS.accentAlpha,   text: COLORS.accent },
    pending:   { bg: COLORS.infoAlpha,     text: COLORS.info },
    paused:    { bg: COLORS.warningAlpha,  text: COLORS.warning },
    completed: { bg: COLORS.successAlpha,  text: COLORS.success },
    aborted:   { bg: COLORS.dangerAlpha,   text: COLORS.danger },
  }
  const s = map[status] || { bg: COLORS.border, text: COLORS.textMuted }
  return (
    <span style={{
      backgroundColor: s.bg,
      color: s.text,
      padding: '3px 10px',
      borderRadius: RADIUS.full,
      fontSize: FONT.sizeSM,
      fontWeight: '600',
    }}>
      {STATUS_LABEL[status] || status}
    </span>
  )
}

export default function DashboardView() {
  const [engagements,    setEngagements]    = useState([])
  const [loading,        setLoading]        = useState(true)
  const [error,          setError]          = useState(null)
  const [lastFetch,      setLastFetch]      = useState(null)

  useEffect(() => {
    fetchEngagements()
  }, [])

  async function fetchEngagements() {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`${API_BASE}/engagements`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setEngagements(data)
      setLastFetch(new Date().toLocaleTimeString('es-CL'))
    } catch (err) {
      setError('Backend no disponible. Inicia el servidor con uvicorn.')
      setEngagements([])
    } finally {
      setLoading(false)
    }
  }

  // Métricas derivadas de los datos reales
  const activeCount    = engagements.filter(e => e.status === 'running').length
  const totalScopeTargets = engagements.reduce((s, e) => s + (e.scope_count || 0), 0)
  const pendingCount   = engagements.filter(e => e.status === 'pending').length

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl, fontFamily: FONT.base }}>

      {/* Título */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>Dashboard</h1>
          <p style={{ margin: '4px 0 0', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
            Resumen del estado actual del sistema
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm }}>
          {lastFetch && (
            <span style={{ fontSize: FONT.sizeXS, color: COLORS.textDim }}>
              Actualizado: {lastFetch}
            </span>
          )}
          <button
            onClick={fetchEngagements}
            disabled={loading}
            style={{
              padding: '7px 14px', backgroundColor: COLORS.accentAlpha,
              color: COLORS.accent, border: `1px solid ${COLORS.accent}44`,
              borderRadius: RADIUS.md, cursor: loading ? 'not-allowed' : 'pointer',
              fontFamily: FONT.base, fontSize: FONT.sizeSM, opacity: loading ? 0.6 : 1,
            }}
          >
            {loading ? '↻ Cargando…' : '↻ Actualizar'}
          </button>
        </div>
      </div>

      {/* Error banner */}
      {error && (
        <div style={{
          backgroundColor: COLORS.warningAlpha, border: `1px solid ${COLORS.warning}44`,
          borderRadius: RADIUS.md, padding: SPACING.md,
          fontSize: FONT.sizeSM, color: COLORS.warning,
          display: 'flex', alignItems: 'center', gap: SPACING.sm,
        }}>
          <span>⚠</span> {error}
        </div>
      )}

      {/* KPI Cards */}
      <div style={{ display: 'flex', gap: SPACING.md }}>
        <KpiCard label="Riesgo Global"         value="—"             color={COLORS.textMuted}   icon="⚡" loading={false} />
        <KpiCard label="Hallazgos Críticos"    value="—"             color={COLORS.textMuted}   icon="🔴" loading={false} />
        <KpiCard label="Engagements Activos"   value={activeCount}   color={COLORS.accent}      icon="▶" loading={loading} />
        <KpiCard label="Targets en Scope"      value={totalScopeTargets} color={COLORS.success} icon="◎" loading={loading} />
      </div>

      {/* Fila media: chart + estado */}
      <div style={{ display: 'flex', gap: SPACING.md }}>

        {/* Chart */}
        <div style={{
          flex: 2, backgroundColor: COLORS.bgCard,
          border: `1px solid ${COLORS.border}`, borderRadius: RADIUS.lg, padding: SPACING.lg,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          gap: SPACING.md, minHeight: '160px',
        }}>
          <div style={{ fontSize: FONT.sizeMD, fontWeight: '600', color: COLORS.textPrimary, alignSelf: 'flex-start' }}>
            Hallazgos por severidad
          </div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: SPACING.sm }}>
            <div style={{ fontSize: '32px', opacity: 0.2 }}>📊</div>
            <div style={{ fontSize: FONT.sizeSM, color: COLORS.textDim }}>
              Sin findings — ejecutar pipeline completo
            </div>
          </div>
        </div>

        {/* Panel lateral */}
        <div style={{
          flex: 1, backgroundColor: COLORS.bgCard,
          border: `1px solid ${COLORS.border}`, borderRadius: RADIUS.lg,
          padding: SPACING.lg, display: 'flex', flexDirection: 'column', gap: SPACING.md,
        }}>
          <div style={{ fontSize: FONT.sizeMD, fontWeight: '600', color: COLORS.textPrimary }}>
            Estado del sistema
          </div>

          {[
            { label: 'HITL pendientes',     value: '—',                              color: COLORS.warning  },
            { label: 'Engagements activos', value: loading ? '…' : String(activeCount),  color: COLORS.accent   },
            { label: 'Engagements pending', value: loading ? '…' : String(pendingCount), color: COLORS.info     },
            { label: 'Targets en scope',    value: loading ? '…' : String(totalScopeTargets), color: COLORS.success },
          ].map((item) => (
            <div key={item.label} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              paddingBottom: SPACING.sm, borderBottom: `1px solid ${COLORS.border}`,
            }}>
              <span style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted }}>{item.label}</span>
              <span style={{ fontSize: FONT.sizeMD, fontWeight: '700', color: item.color }}>{item.value}</span>
            </div>
          ))}

          {/* Indicador pipeline */}
          <div style={{
            marginTop: 'auto', backgroundColor: COLORS.bgApp,
            borderRadius: RADIUS.md, padding: SPACING.sm,
            borderLeft: `3px solid ${COLORS.accent}`,
          }}>
            <div style={{ fontSize: FONT.sizeXS, color: COLORS.textMuted, marginBottom: '4px' }}>Pipeline</div>
            <div style={{ fontSize: FONT.sizeSM, color: COLORS.textPrimary }}>
              {activeCount > 0 ? `${activeCount} engagement(s) en curso` : 'Sin engagements activos'}
            </div>
            <div style={{
              marginTop: SPACING.xs, height: '4px', backgroundColor: COLORS.border,
              borderRadius: RADIUS.full, overflow: 'hidden',
            }}>
              <div style={{
                width: activeCount > 0 ? '60%' : '0%',
                height: '100%', backgroundColor: COLORS.accent, borderRadius: RADIUS.full,
                transition: 'width 0.6s ease',
              }} />
            </div>
          </div>
        </div>
      </div>

      {/* Tabla engagements reales */}
      <div style={{
        backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg, overflow: 'hidden',
      }}>
        <div style={{
          padding: `${SPACING.md} ${SPACING.lg}`, borderBottom: `1px solid ${COLORS.border}`,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <span style={{ fontSize: FONT.sizeMD, fontWeight: '600', color: COLORS.textPrimary }}>
            Todos los Engagements
          </span>
          <span style={{ fontSize: FONT.sizeXS, color: COLORS.textDim }}>
            {loading ? 'Cargando…' : `${engagements.length} total`}
          </span>
        </div>

        {loading ? (
          <div style={{ padding: SPACING.xl, textAlign: 'center', color: COLORS.textDim, fontSize: FONT.sizeSM }}>
            Cargando engagements desde API…
          </div>
        ) : engagements.length === 0 ? (
          <div style={{ padding: SPACING.xl, textAlign: 'center', color: COLORS.textDim, fontSize: FONT.sizeSM }}>
            Sin engagements. Crea uno desde "Nuevo Engagement".
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: COLORS.bgApp }}>
                {['ID', 'Nombre', 'Cliente', 'Estado', 'Scope Targets', 'Creado'].map((col) => (
                  <th key={col} style={{
                    padding: `${SPACING.sm} ${SPACING.md}`, color: COLORS.textMuted,
                    fontSize: FONT.sizeSM, fontWeight: '500', borderBottom: `1px solid ${COLORS.border}`,
                  }}>
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {engagements.map((eng) => (
                <tr key={eng.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontFamily: FONT.mono, fontSize: FONT.sizeSM, color: COLORS.textDim }}>
                    #{eng.id}
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontWeight: '600', color: COLORS.textPrimary }}>
                    {eng.name}
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM, color: COLORS.textMuted }}>
                    {eng.client_name || '—'}
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}` }}>
                    <EstadoBadge status={eng.status} />
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM, color: COLORS.info, textAlign: 'center' }}>
                    {eng.scope_count ?? 0}
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM, color: COLORS.textDim }}>
                    {new Date(eng.created_at).toLocaleString('es-CL', {
                      day: '2-digit', month: '2-digit', year: 'numeric',
                      hour: '2-digit', minute: '2-digit',
                    })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
