import { useState } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

// Tácticas ATT&CK habilitables
const ATTACK_TACTICS = [
  { id: 'TA0043', name: 'Reconnaissance',        desc: 'Recopilación de información del objetivo' },
  { id: 'TA0042', name: 'Resource Development',  desc: 'Establecimiento de recursos para el ataque' },
  { id: 'TA0001', name: 'Initial Access',         desc: 'Acceso inicial al entorno objetivo' },
  { id: 'TA0002', name: 'Execution',              desc: 'Ejecución de código malicioso' },
  { id: 'TA0003', name: 'Persistence',            desc: 'Mantenimiento del acceso' },
  { id: 'TA0004', name: 'Privilege Escalation',   desc: 'Elevación de privilegios' },
  { id: 'TA0005', name: 'Defense Evasion',        desc: 'Evasión de defensas' },
  { id: 'TA0006', name: 'Credential Access',      desc: 'Robo de credenciales' },
  { id: 'TA0007', name: 'Discovery',              desc: 'Descubrimiento del entorno' },
  { id: 'TA0008', name: 'Lateral Movement',       desc: 'Movimiento lateral en la red' },
  { id: 'TA0009', name: 'Collection',             desc: 'Recopilación de datos sensibles' },
  { id: 'TA0011', name: 'Command and Control',    desc: 'Comunicación con sistemas comprometidos' },
  { id: 'TA0010', name: 'Exfiltration',           desc: 'Extracción de datos del entorno' },
  { id: 'TA0040', name: 'Impact',                 desc: 'Manipulación, interrupción o destrucción' },
]

const DEFAULT_ROE = {
  time_windows: [{ start: '09:00', end: '18:00', days: ['mon','tue','wed','thu','fri'] }],
  scan_intensity: 'MODERATE',
  excluded_paths: [],
  max_requests_per_second: 50,
  auto_approve_hitl_below: 'MEDIUM',
}

function validarTarget(val) {
  // IPv4
  const ipv4 = /^(\d{1,3}\.){3}\d{1,3}$/
  // CIDR
  const cidr = /^(\d{1,3}\.){3}\d{1,3}\/\d{1,2}$/
  // Dominio simple
  const domain = /^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+$/
  if (ipv4.test(val)) return 'ip'
  if (cidr.test(val)) return 'cidr'
  if (domain.test(val)) return 'domain'
  return null
}

const TIPO_BADGE = {
  ip:     { bg: COLORS.accentAlpha,  text: COLORS.accent  },
  cidr:   { bg: COLORS.warningAlpha, text: COLORS.warning },
  domain: { bg: COLORS.infoAlpha,    text: COLORS.info    },
}

export default function EngagementSetupView({ onCreated }) {
  // Campos del engagement
  const [nombre, setNombre]       = useState('')
  const [descripcion, setDesc]    = useState('')
  const [clienteNombre, setCliente] = useState('')

  // Multi-tag targets
  const [tagInput, setTagInput]   = useState('')
  const [targets, setTargets]     = useState([])
  const [tagError, setTagError]   = useState('')

  // ATT&CK tactics
  const [tactics, setTactics]     = useState(['TA0043','TA0001','TA0007'])

  // ROE
  const [roeText, setRoeText]     = useState(JSON.stringify(DEFAULT_ROE, null, 2))
  const [roeError, setRoeError]   = useState('')
  const [roeValid, setRoeValid]   = useState(true)

  // Submit
  const [enviando, setEnviando]   = useState(false)
  const [exito, setExito]         = useState(false)
  const [submitError, setSubmitError] = useState('')

  // --- Tag handlers ---
  const agregarTag = () => {
    const val = tagInput.trim()
    if (!val) return
    const tipo = validarTarget(val)
    if (!tipo) { setTagError(`"${val}" no es una IP, CIDR ni dominio válido`); return }
    if (targets.find((t) => t.value === val)) { setTagError('Este target ya está en la lista'); return }
    setTargets((prev) => [...prev, { value: val, type: tipo }])
    setTagInput('')
    setTagError('')
  }

  const onTagKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === ',' || e.key === ' ') {
      e.preventDefault()
      agregarTag()
    }
    if (e.key === 'Backspace' && tagInput === '' && targets.length > 0) {
      setTargets((prev) => prev.slice(0, -1))
    }
  }

  const quitarTag = (val) => setTargets((prev) => prev.filter((t) => t.value !== val))

  // --- ROE handler ---
  const onRoeChange = (val) => {
    setRoeText(val)
    try { JSON.parse(val); setRoeValid(true); setRoeError('') }
    catch { setRoeValid(false); setRoeError('JSON inválido — revisa la sintaxis') }
  }

  // --- ATT&CK toggle ---
  const toggleTactic = (id) => {
    setTactics((prev) =>
      prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id]
    )
  }

  // --- Submit ---
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (targets.length === 0) { setTagError('Agrega al menos un target al scope'); return }
    if (!roeValid) return
    setEnviando(true)
    setSubmitError('')
    try {
      const roe = JSON.parse(roeText)
      const payload = {
        name: nombre || 'Nuevo Análisis',
        description: descripcion || null,
        client_name: clienteNombre || null,
        scope_targets: targets.map((t) => ({ target_value: t.value, target_type: t.type })),
        roe,
        att_tactics: tactics.length > 0 ? tactics : null,
      }
      const res = await fetch('http://localhost:8000/engagements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.detail || `HTTP ${res.status}`)
      }
      setExito(true)
      if (onCreated) setTimeout(() => onCreated(), 1500)
    } catch (err) {
      setSubmitError(err.message || 'Error al crear el engagement')
    } finally {
      setEnviando(false)
    }
  }

  const inputStyle = {
    width: '100%', padding: '10px 14px',
    backgroundColor: COLORS.bgInput, border: `1px solid ${COLORS.border}`,
    borderRadius: RADIUS.md, color: COLORS.textPrimary,
    fontFamily: FONT.base, fontSize: FONT.sizeMD, outline: 'none', boxSizing: 'border-box',
  }
  const labelStyle = {
    display: 'block', marginBottom: SPACING.xs,
    fontSize: FONT.sizeSM, color: COLORS.textMuted, fontWeight: '500',
  }
  const sectionTitle = (text, badge) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm, marginBottom: SPACING.md }}>
      <span style={{ fontSize: FONT.sizeMD, fontWeight: '700', color: COLORS.textPrimary }}>{text}</span>
      {badge && (
        <span style={{ padding: '1px 8px', backgroundColor: COLORS.dangerAlpha, color: COLORS.danger,
          borderRadius: RADIUS.full, fontSize: FONT.sizeXS, fontWeight: '700' }}>
          {badge}
        </span>
      )}
    </div>
  )

  if (exito) return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      height: '60vh', gap: SPACING.md, fontFamily: FONT.base }}>
      <div style={{ fontSize: '48px' }}>✓</div>
      <div style={{ fontSize: FONT.size2XL, fontWeight: '700', color: COLORS.success }}>Engagement creado</div>
      <div style={{ color: COLORS.textMuted }}>Redirigiendo al pipeline...</div>
    </div>
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl, fontFamily: FONT.base }}>

      {/* Header */}
      <div>
        <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>Nuevo Engagement</h1>
        <p style={{ margin: '4px 0 0', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
          Define el scope, las ROE y las tácticas autorizadas antes de iniciar el pipeline
        </p>
      </div>

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl }}>

        {/* ── SECCIÓN 1: Información general ── */}
        <div style={{ backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
          borderRadius: RADIUS.lg, padding: SPACING.lg }}>
          {sectionTitle('1. Información general')}
          <div style={{ display: 'flex', gap: SPACING.md, flexWrap: 'wrap' }}>
            <div style={{ flex: 2, minWidth: '200px' }}>
              <label style={labelStyle}>Nombre del engagement *</label>
              <input required value={nombre} onChange={(e) => setNombre(e.target.value)}
                placeholder="Ej: Lab Metasploitable2 — Pentesting Q2 2026"
                style={inputStyle} />
            </div>
            <div style={{ flex: 1, minWidth: '160px' }}>
              <label style={labelStyle}>Cliente / Organización</label>
              <input value={clienteNombre} onChange={(e) => setCliente(e.target.value)}
                placeholder="DUOC UC — Lab" style={inputStyle} />
            </div>
          </div>
          <div style={{ marginTop: SPACING.md }}>
            <label style={labelStyle}>Descripción</label>
            <textarea value={descripcion} onChange={(e) => setDesc(e.target.value)}
              placeholder="Objetivo del análisis, alcance general, contexto..."
              rows={3}
              style={{ ...inputStyle, resize: 'vertical', lineHeight: '1.5' }} />
          </div>
        </div>

        {/* ── SECCIÓN 2: Scope / Targets ── */}
        <div style={{ backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
          borderRadius: RADIUS.lg, padding: SPACING.lg }}>
          {sectionTitle('2. Scope — Targets autorizados', 'REQUERIDO')}
          <div style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted, marginBottom: SPACING.md }}>
            Ingresa IPs (<span style={{ color: COLORS.accent }}>192.168.1.1</span>), CIDRs (<span style={{ color: COLORS.warning }}>192.168.56.0/24</span>) o dominios (<span style={{ color: COLORS.info }}>vulnsite.com</span>). Presiona <kbd style={{ backgroundColor: COLORS.bgApp, padding: '1px 6px', borderRadius: RADIUS.sm, fontSize: FONT.sizeXS, color: COLORS.textMuted }}>Enter</kbd> o <kbd style={{ backgroundColor: COLORS.bgApp, padding: '1px 6px', borderRadius: RADIUS.sm, fontSize: FONT.sizeXS, color: COLORS.textMuted }}>,</kbd> para agregar.
          </div>

          {/* Tag input */}
          <div style={{
            display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: SPACING.xs,
            padding: '8px 12px', backgroundColor: COLORS.bgInput,
            border: `1px solid ${tagError ? COLORS.danger : COLORS.border}`,
            borderRadius: RADIUS.md, minHeight: '48px', cursor: 'text',
          }}
            onClick={() => document.getElementById('tag-input').focus()}
          >
            {targets.map((t) => (
              <span key={t.value} style={{
                display: 'inline-flex', alignItems: 'center', gap: '4px',
                padding: '3px 10px', borderRadius: RADIUS.full,
                backgroundColor: TIPO_BADGE[t.type]?.bg, color: TIPO_BADGE[t.type]?.text,
                fontSize: FONT.sizeSM, fontWeight: '600', fontFamily: FONT.mono,
              }}>
                {t.value}
                <button type="button" onClick={() => quitarTag(t.value)}
                  style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer',
                    fontSize: '12px', padding: '0 0 0 2px', lineHeight: 1 }}>✕</button>
              </span>
            ))}
            <input
              id="tag-input"
              value={tagInput}
              onChange={(e) => { setTagInput(e.target.value); setTagError('') }}
              onKeyDown={onTagKeyDown}
              onBlur={agregarTag}
              placeholder={targets.length === 0 ? '192.168.56.101, 192.168.56.0/24, vulnsite.com...' : ''}
              style={{ background: 'none', border: 'none', outline: 'none', color: COLORS.textPrimary,
                fontFamily: FONT.mono, fontSize: FONT.sizeSM, flex: 1, minWidth: '160px' }}
            />
          </div>
          {tagError && (
            <div style={{ marginTop: SPACING.xs, fontSize: FONT.sizeSM, color: COLORS.danger }}>
              ✕ {tagError}
            </div>
          )}
          {targets.length > 0 && (
            <div style={{ marginTop: SPACING.xs, fontSize: FONT.sizeXS, color: COLORS.textDim }}>
              {targets.length} target{targets.length > 1 ? 's' : ''} definido{targets.length > 1 ? 's' : ''} · Todos serán validados por @enforce_scope antes de cada acción
            </div>
          )}
        </div>

        {/* ── SECCIÓN 3: ATT&CK Tactics ── */}
        <div style={{ backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
          borderRadius: RADIUS.lg, padding: SPACING.lg }}>
          {sectionTitle('3. Tácticas ATT&CK habilitadas')}
          <div style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted, marginBottom: SPACING.md }}>
            Solo las tácticas seleccionadas serán autorizadas en el engagement. Mínimo recomendado: Reconnaissance + Discovery.
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: SPACING.sm }}>
            {ATTACK_TACTICS.map((tac) => {
              const sel = tactics.includes(tac.id)
              return (
                <label key={tac.id} style={{
                  display: 'flex', alignItems: 'flex-start', gap: SPACING.sm,
                  padding: SPACING.sm, borderRadius: RADIUS.md, cursor: 'pointer',
                  backgroundColor: sel ? COLORS.accentAlpha : 'transparent',
                  border: `1px solid ${sel ? COLORS.accent + '44' : COLORS.border}`,
                  transition: 'all 0.15s',
                }}>
                  <input type="checkbox" checked={sel} onChange={() => toggleTactic(tac.id)}
                    style={{ marginTop: '2px', accentColor: COLORS.accent, cursor: 'pointer' }} />
                  <div>
                    <div style={{ fontSize: FONT.sizeSM, fontWeight: sel ? '700' : '400',
                      color: sel ? COLORS.accent : COLORS.textMuted }}>
                      <span style={{ fontFamily: FONT.mono, marginRight: SPACING.xs }}>{tac.id}</span>
                      {tac.name}
                    </div>
                    <div style={{ fontSize: FONT.sizeXS, color: COLORS.textDim, marginTop: '2px' }}>
                      {tac.desc}
                    </div>
                  </div>
                </label>
              )
            })}
          </div>
          <div style={{ marginTop: SPACING.md, fontSize: FONT.sizeXS, color: COLORS.textDim }}>
            {tactics.length} de {ATTACK_TACTICS.length} tácticas habilitadas
          </div>
        </div>

        {/* ── SECCIÓN 4: ROE ── */}
        <div style={{ backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
          borderRadius: RADIUS.lg, padding: SPACING.lg }}>
          {sectionTitle('4. Rules of Engagement (ROE)')}
          <div style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted, marginBottom: SPACING.md }}>
            Define ventanas de tiempo, intensidad de escaneo, paths excluidos y límites de velocidad.
            El schema es validado antes de persistir.
          </div>

          {/* Guía rápida */}
          <div style={{ display: 'flex', gap: SPACING.sm, flexWrap: 'wrap', marginBottom: SPACING.md }}>
            {[
              { key: 'scan_intensity', vals: 'STEALTH · MODERATE · AGGRESSIVE' },
              { key: 'auto_approve_hitl_below', vals: 'LOW · MEDIUM (máx recomendado)' },
            ].map((item) => (
              <div key={item.key} style={{ padding: `${SPACING.xs} ${SPACING.sm}`,
                backgroundColor: COLORS.bgApp, borderRadius: RADIUS.sm,
                border: `1px solid ${COLORS.border}`, fontSize: FONT.sizeXS }}>
                <span style={{ color: COLORS.info, fontFamily: FONT.mono }}>{item.key}</span>
                <span style={{ color: COLORS.textDim }}> → {item.vals}</span>
              </div>
            ))}
          </div>

          <textarea
            value={roeText}
            onChange={(e) => onRoeChange(e.target.value)}
            rows={14}
            style={{
              ...inputStyle,
              fontFamily: FONT.mono, fontSize: FONT.sizeSM,
              border: `1px solid ${roeValid ? COLORS.border : COLORS.danger}`,
              lineHeight: '1.6', resize: 'vertical',
            }}
          />
          {!roeValid && (
            <div style={{ marginTop: SPACING.xs, fontSize: FONT.sizeSM, color: COLORS.danger }}>
              ✕ {roeError}
            </div>
          )}
          {roeValid && roeText.trim() && (
            <div style={{ marginTop: SPACING.xs, fontSize: FONT.sizeSM, color: COLORS.success }}>
              ✓ JSON válido
            </div>
          )}
        </div>

        {/* ── Error ── */}
        {submitError && (
          <div style={{ padding: SPACING.md, backgroundColor: COLORS.dangerAlpha,
            border: `1px solid ${COLORS.danger}44`, borderRadius: RADIUS.md,
            fontSize: FONT.sizeSM, color: COLORS.danger }}>
            ✕ {submitError}
          </div>
        )}

        {/* ── Botones ── */}
        <div style={{ display: 'flex', gap: SPACING.md, justifyContent: 'flex-end', paddingBottom: SPACING.xl }}>
          <button type="button"
            style={{ padding: '11px 28px', backgroundColor: 'transparent',
              border: `1px solid ${COLORS.border}`, borderRadius: RADIUS.md,
              color: COLORS.textMuted, cursor: 'pointer', fontFamily: FONT.base, fontSize: FONT.sizeMD }}>
            Cancelar
          </button>
          <button type="submit" disabled={enviando}
            style={{ padding: '11px 32px',
              backgroundColor: enviando ? COLORS.textDim : COLORS.accent,
              color: COLORS.textPrimary, border: 'none', borderRadius: RADIUS.md,
              fontWeight: '700', cursor: enviando ? 'not-allowed' : 'pointer',
              fontFamily: FONT.base, fontSize: FONT.sizeMD }}>
            {enviando ? 'Creando engagement...' : '▶ Crear Engagement'}
          </button>
        </div>
      </form>
    </div>
  )
}
