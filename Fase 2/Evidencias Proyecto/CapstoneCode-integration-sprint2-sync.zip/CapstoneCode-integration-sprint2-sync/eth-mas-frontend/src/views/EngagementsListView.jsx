import { useState, useEffect } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const ESTADO_STYLE = {
  running:   { bg: COLORS.accentAlpha,  text: COLORS.accent,   label: '▶ Running'   },
  pending:   { bg: COLORS.infoAlpha,    text: COLORS.info,     label: '○ Pending'   },
  paused:    { bg: COLORS.warningAlpha, text: COLORS.warning,  label: '⏸ Paused'   },
  completed: { bg: COLORS.successAlpha, text: COLORS.success,  label: '✓ Completed' },
  aborted:   { bg: COLORS.dangerAlpha,  text: COLORS.danger,   label: '✕ Aborted'  },
}

function EstadoBadge({ estado }) {
  const s = ESTADO_STYLE[estado] || { bg: COLORS.border, text: COLORS.textMuted, label: estado || '—' }
  return (
    <span style={{ padding: '3px 10px', backgroundColor: s.bg, color: s.text,
      borderRadius: RADIUS.full, fontSize: FONT.sizeSM, fontWeight: '600', whiteSpace: 'nowrap' }}>
      {s.label}
    </span>
  )
}

function fmtDate(ts) {
  if (!ts) return '—'
  try {
    return new Date(ts).toLocaleString('es-CL', {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    })
  } catch { return ts }
}

function DrawerDetalle({ eng, onClose, onAbort }) {
  return (
    <div style={{ position: 'fixed', top: 0, right: 0, bottom: 0, width: '460px',
      backgroundColor: COLORS.bgSidebar, borderLeft: `1px solid ${COLORS.border}`,
      display: 'flex', flexDirection: 'column', zIndex: 100, fontFamily: FONT.base }}>

      {/* Header */}
      <div style={{ padding: SPACING.lg, borderBottom: `1px solid ${COLORS.border}`,
        display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: FONT.sizeLG, fontWeight: '700', color: COLORS.textPrimary }}>
            {eng.name}
          </div>
          <div style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted, marginTop: '2px' }}>
            ID #{eng.id} · {eng.client_name || 'Sin cliente'}
          </div>
        </div>
        <button onClick={onClose} style={{ background: 'none', border: 'none',
          color: COLORS.textMuted, cursor: 'pointer', fontSize: '20px', lineHeight: 1, padding: '2px' }}>
          ✕
        </button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: SPACING.lg,
        display: 'flex', flexDirection: 'column', gap: SPACING.lg }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: SPACING.sm }}>
          {[
            { label: 'Estado',      value: <EstadoBadge estado={eng.status} /> },
            { label: 'Scope',       value: `${eng.scope_count || 0} targets`, color: COLORS.info },
            { label: 'Creado',      value: fmtDate(eng.created_at) },
            { label: 'Actualizado', value: fmtDate(eng.updated_at) },
          ].map((s, i) => (
            <div key={i} style={{ backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md,
              padding: SPACING.md, border: `1px solid ${COLORS.border}` }}>
              <div style={{ fontSize: FONT.sizeXS, color: COLORS.textDim, marginBottom: '4px' }}>{s.label}</div>
              <div style={{ fontSize: FONT.sizeMD, fontWeight: '600', color: s.color || COLORS.textPrimary }}>
                {s.value}
              </div>
            </div>
          ))}
        </div>

        {eng.description && (
          <div>
            <div style={{ fontSize: FONT.sizeSM, fontWeight: '600', color: COLORS.textMuted, marginBottom: SPACING.xs }}>
              Descripción
            </div>
            <div style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted, lineHeight: '1.5' }}>
              {eng.description}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={{ padding: SPACING.lg, borderTop: `1px solid ${COLORS.border}`, display: 'flex', gap: SPACING.sm }}>
        {(eng.status === 'running' || eng.status === 'paused') && (
          <button onClick={() => onAbort(eng.id)}
            style={{ flex: 1, padding: '10px', backgroundColor: COLORS.dangerAlpha,
              color: COLORS.danger, border: `1px solid ${COLORS.danger}44`,
              borderRadius: RADIUS.md, fontWeight: '700', cursor: 'pointer',
              fontFamily: FONT.base, fontSize: FONT.sizeMD }}>
            ✕ Abort Engagement
          </button>
        )}
        {eng.status === 'completed' && (
          <button style={{ flex: 1, padding: '10px', backgroundColor: COLORS.accentAlpha,
            color: COLORS.accent, border: `1px solid ${COLORS.accent}44`,
            borderRadius: RADIUS.md, fontWeight: '700', cursor: 'pointer',
            fontFamily: FONT.base, fontSize: FONT.sizeMD }}>
            ↓ Ver reportes
          </button>
        )}
        <button onClick={onClose}
          style={{ padding: '10px 20px', backgroundColor: 'transparent',
            border: `1px solid ${COLORS.border}`, borderRadius: RADIUS.md,
            color: COLORS.textMuted, cursor: 'pointer', fontFamily: FONT.base, fontSize: FONT.sizeMD }}>
          Cerrar
        </button>
      </div>
    </div>
  )
}

export default function EngagementsListView({ onNuevoEngagement }) {
  const [engagements,  setEngagements]  = useState([])
  const [loading,      setLoading]      = useState(true)
  const [error,        setError]        = useState(null)
  const [detalle,      setDetalle]      = useState(null)
  const [abortConfirm, setAbortConfirm] = useState(null)

  const cargar = async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`${API_BASE}/engagements`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      setEngagements(await res.json())
    } catch (err) {
      setError(`No se pudo conectar al backend: ${err.message}`)
      setEngagements([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { cargar() }, [])

  const confirmarAbort = async () => {
    try {
      await fetch(`${API_BASE}/engagements/${abortConfirm}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'aborted' }),
      })
      await cargar()
      if (detalle?.id === abortConfirm) setDetalle(null)
    } catch (err) {
      console.error('Error al abortar:', err)
    } finally {
      setAbortConfirm(null)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl, fontFamily: FONT.base }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.md }}>
        <div>
          <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>Engagements</h1>
          <p style={{ margin: '4px 0 0', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
            Historial completo de sesiones de pentesting
          </p>
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: SPACING.sm }}>
          <button onClick={cargar} disabled={loading}
            style={{ padding: '10px 18px', backgroundColor: 'transparent',
              border: `1px solid ${COLORS.border}`, borderRadius: RADIUS.md,
              color: COLORS.textMuted, cursor: loading ? 'not-allowed' : 'pointer',
              fontFamily: FONT.base, fontSize: FONT.sizeMD, opacity: loading ? 0.6 : 1 }}>
            {loading ? '↻ Cargando…' : '↻ Refrescar'}
          </button>
          <button onClick={onNuevoEngagement}
            style={{ padding: '10px 24px', backgroundColor: COLORS.accent, color: COLORS.textPrimary,
              border: 'none', borderRadius: RADIUS.md, fontWeight: '700',
              cursor: 'pointer', fontFamily: FONT.base, fontSize: FONT.sizeMD }}>
            + Nuevo Engagement
          </button>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div style={{ backgroundColor: COLORS.dangerAlpha, border: `1px solid ${COLORS.danger}44`,
          borderRadius: RADIUS.md, padding: SPACING.md, fontSize: FONT.sizeSM, color: COLORS.danger }}>
          ✕ {error}
        </div>
      )}

      {/* Tabla */}
      <div style={{ backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg, overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: SPACING.xl, textAlign: 'center', color: COLORS.textDim, fontSize: FONT.sizeSM }}>
            Cargando engagements…
          </div>
        ) : engagements.length === 0 ? (
          <div style={{ padding: SPACING.xl, textAlign: 'center', color: COLORS.textDim, fontSize: FONT.sizeSM }}>
            Sin engagements. Crea uno con "+ Nuevo Engagement".
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: COLORS.bgApp }}>
                {['ID','Nombre','Cliente','Estado','Scope','Creado',''].map((col) => (
                  <th key={col} style={{ padding: `${SPACING.sm} ${SPACING.md}`,
                    color: COLORS.textMuted, fontSize: FONT.sizeSM, fontWeight: '500',
                    borderBottom: `1px solid ${COLORS.border}`, whiteSpace: 'nowrap' }}>
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {engagements.map((eng) => (
                <tr key={eng.id}
                  style={{ borderBottom: `1px solid ${COLORS.border}`, cursor: 'pointer' }}
                  onClick={() => setDetalle(eng)}>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, color: COLORS.textDim,
                    fontFamily: FONT.mono, fontSize: FONT.sizeSM }}>#{eng.id}</td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontWeight: '600',
                    color: COLORS.textPrimary }}>{eng.name}</td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM,
                    color: COLORS.textMuted }}>{eng.client_name || '—'}</td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}` }}>
                    <EstadoBadge estado={eng.status} />
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM,
                    color: COLORS.info, textAlign: 'center' }}>{eng.scope_count ?? 0}</td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM,
                    color: COLORS.textDim, fontFamily: FONT.mono, whiteSpace: 'nowrap' }}>
                    {fmtDate(eng.created_at)}
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}` }}>
                    {(eng.status === 'running' || eng.status === 'paused') && (
                      <button
                        onClick={(e) => { e.stopPropagation(); setAbortConfirm(eng.id) }}
                        style={{ padding: '4px 12px', backgroundColor: 'transparent',
                          border: `1px solid ${COLORS.danger}`, color: COLORS.danger,
                          borderRadius: RADIUS.sm, fontSize: FONT.sizeSM, fontWeight: '600',
                          cursor: 'pointer', fontFamily: FONT.base, whiteSpace: 'nowrap' }}>
                        Abort
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Drawer detalle */}
      {detalle && (
        <>
          <div onClick={() => setDetalle(null)}
            style={{ position: 'fixed', inset: 0, backgroundColor: '#00000066', zIndex: 99 }} />
          <DrawerDetalle eng={detalle} onClose={() => setDetalle(null)} onAbort={setAbortConfirm} />
        </>
      )}

      {/* Modal abort */}
      {abortConfirm && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: '#00000088',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }}>
          <div style={{ backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.danger}44`,
            borderRadius: RADIUS.lg, padding: SPACING.xl, maxWidth: '420px', fontFamily: FONT.base }}>
            <div style={{ fontSize: FONT.size2XL, fontWeight: '700', color: COLORS.danger, marginBottom: SPACING.sm }}>
              ⚠ Abort Engagement
            </div>
            <div style={{ color: COLORS.textMuted, marginBottom: SPACING.xl, lineHeight: '1.5' }}>
              Esta acción detiene el pipeline inmediatamente y cambia el estado a <strong>aborted</strong>.
              Los findings ya persistidos se conservan. ¿Confirmas?
            </div>
            <div style={{ display: 'flex', gap: SPACING.md, justifyContent: 'flex-end' }}>
              <button onClick={() => setAbortConfirm(null)}
                style={{ padding: '10px 24px', backgroundColor: 'transparent',
                  border: `1px solid ${COLORS.border}`, borderRadius: RADIUS.md,
                  color: COLORS.textMuted, cursor: 'pointer', fontFamily: FONT.base }}>
                Cancelar
              </button>
              <button onClick={confirmarAbort}
                style={{ padding: '10px 24px', backgroundColor: COLORS.danger,
                  color: COLORS.textPrimary, border: 'none', borderRadius: RADIUS.md,
                  fontWeight: '700', cursor: 'pointer', fontFamily: FONT.base }}>
                Sí, abortar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
