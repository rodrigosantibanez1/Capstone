import { useState, useEffect } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

const TIPO_BADGE = {
  ip:     { bg: COLORS.accentAlpha,   text: COLORS.accent },
  domain: { bg: COLORS.infoAlpha,     text: COLORS.info   },
  cidr:   { bg: COLORS.warningAlpha,  text: COLORS.warning },
}

export default function EngagementsView() {
  const [listaObjetivos, setListaObjetivos] = useState([])
  const [nuevoTarget, setNuevoTarget]       = useState('')
  const [tipoTarget, setTipoTarget]         = useState('ip')
  const [enviando, setEnviando]             = useState(false)

  const cargarObjetivos = () => {
    fetch('http://127.0.0.1:8000/engagements/1/scope')
      .then((r) => r.json())
      .then((data) => { if (data.data) setListaObjetivos(data.data) })
      .catch((err) => console.error('Error conectando a FastAPI:', err))
  }

  useEffect(() => { cargarObjetivos() }, [])

  const manejarEnvio = async (e) => {
    e.preventDefault()
    setEnviando(true)
    try {
      const res = await fetch('http://127.0.0.1:8000/engagements/1/scope', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target_value: nuevoTarget, target_type: tipoTarget }),
      })
      if (res.ok) { setNuevoTarget(''); cargarObjetivos() }
      else console.error('Error al agregar target')
    } catch (err) {
      console.error('Error enviando datos:', err)
    } finally {
      setEnviando(false)
    }
  }

  const eliminarObjetivo = async (id) => {
    if (!window.confirm('¿Eliminar este target del scope?')) return
    try {
      const res = await fetch(`http://127.0.0.1:8000/engagements/1/scope/${id}`, { method: 'DELETE' })
      if (res.ok) cargarObjetivos()
    } catch (err) {
      console.error('Error eliminando:', err)
    }
  }

  const inputStyle = {
    width: '100%',
    padding: '10px 14px',
    backgroundColor: COLORS.bgInput,
    border: `1px solid ${COLORS.border}`,
    borderRadius: RADIUS.md,
    color: COLORS.textPrimary,
    fontFamily: FONT.base,
    fontSize: FONT.sizeMD,
    outline: 'none',
    boxSizing: 'border-box',
  }

  const labelStyle = {
    display: 'block',
    marginBottom: SPACING.xs,
    fontSize: FONT.sizeSM,
    color: COLORS.textMuted,
    fontWeight: '500',
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl, fontFamily: FONT.base }}>

      {/* Header */}
      <div>
        <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>
          Definición de Scope
        </h1>
        <p style={{ margin: '4px 0 0', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
          Gestión de targets autorizados para el engagement activo
        </p>
      </div>

      {/* Mini-stats */}
      <div style={{ display: 'flex', gap: SPACING.md }}>
        {[
          { label: 'Estado',           value: '● Activo',                    color: COLORS.success },
          { label: 'Targets en scope', value: String(listaObjetivos.length), color: COLORS.textPrimary },
        ].map((stat) => (
          <div key={stat.label} style={{
            flex: 1,
            backgroundColor: COLORS.bgCard,
            border: `1px solid ${COLORS.border}`,
            borderRadius: RADIUS.md,
            padding: `${SPACING.md} ${SPACING.lg}`,
          }}>
            <div style={{ fontSize: FONT.sizeXS, color: COLORS.textDim, marginBottom: '4px' }}>{stat.label}</div>
            <div style={{ fontSize: FONT.sizeLG, fontWeight: '700', color: stat.color }}>{stat.value}</div>
          </div>
        ))}
      </div>

      {/* Formulario */}
      <div style={{
        backgroundColor: COLORS.bgCard,
        border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg,
        padding: SPACING.lg,
      }}>
        <div style={{ fontSize: FONT.sizeMD, fontWeight: '600', color: COLORS.textPrimary, marginBottom: SPACING.md }}>
          + Agregar nuevo target
        </div>
        <div style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted, marginBottom: SPACING.md }}>
          Tipos soportados: <span style={{ color: COLORS.accent }}>IP</span> (ej: 192.168.1.1) · <span style={{ color: COLORS.info }}>Dominio</span> (ej: vulnsite.com) · <span style={{ color: COLORS.warning }}>CIDR</span> (ej: 192.168.56.0/24)
        </div>

        <form onSubmit={manejarEnvio} style={{ display: 'flex', gap: SPACING.md, alignItems: 'flex-end' }}>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Objetivo (IP o Dominio)</label>
            <input
              type="text"
              value={nuevoTarget}
              onChange={(e) => setNuevoTarget(e.target.value)}
              placeholder="Ej: 192.168.1.100 o vulnsite.com"
              required
              style={inputStyle}
            />
          </div>

          <div style={{ minWidth: '160px' }}>
            <label style={labelStyle}>Tipo</label>
            <select
              value={tipoTarget}
              onChange={(e) => setTipoTarget(e.target.value)}
              style={{ ...inputStyle, cursor: 'pointer' }}
            >
              <option value="ip">IP</option>
              <option value="domain">Dominio</option>
              <option value="cidr">CIDR (Red)</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={enviando}
            style={{
              padding: '10px 24px',
              backgroundColor: enviando ? COLORS.textDim : COLORS.accent,
              color: COLORS.textPrimary,
              border: 'none',
              borderRadius: RADIUS.md,
              fontSize: FONT.sizeMD,
              fontWeight: '600',
              cursor: enviando ? 'not-allowed' : 'pointer',
              whiteSpace: 'nowrap',
              fontFamily: FONT.base,
            }}
          >
            {enviando ? 'Agregando...' : '+ Agregar al Scope'}
          </button>
        </form>
      </div>

      {/* Tabla */}
      <div style={{
        backgroundColor: COLORS.bgCard,
        border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg,
        overflow: 'hidden',
      }}>
        <div style={{
          padding: `${SPACING.md} ${SPACING.lg}`,
          borderBottom: `1px solid ${COLORS.border}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <span style={{ fontSize: FONT.sizeMD, fontWeight: '600', color: COLORS.textPrimary }}>
            Objetivos Autorizados
          </span>
          <span style={{
            padding: '2px 10px',
            backgroundColor: COLORS.accentAlpha,
            color: COLORS.accent,
            borderRadius: RADIUS.full,
            fontSize: FONT.sizeSM,
            fontWeight: '600',
          }}>
            {listaObjetivos.length} targets
          </span>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ backgroundColor: COLORS.bgApp }}>
              {['ID', 'Target', 'Tipo', 'Estado', 'Validado', 'Acción'].map((col) => (
                <th key={col} style={{
                  padding: `${SPACING.sm} ${SPACING.md}`,
                  color: COLORS.textMuted,
                  fontSize: FONT.sizeSM,
                  fontWeight: '500',
                  borderBottom: `1px solid ${COLORS.border}`,
                }}>
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {listaObjetivos.map((obj) => {
              const tipoBadge = TIPO_BADGE[obj.target_type] || { bg: COLORS.border, text: COLORS.textMuted }
              return (
                <tr key={obj.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, color: COLORS.textDim, fontFamily: FONT.mono, fontSize: FONT.sizeSM }}>
                    #{obj.id}
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontWeight: '600', color: COLORS.textPrimary, fontFamily: FONT.mono }}>
                    {obj.target_value}
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}` }}>
                    <span style={{
                      backgroundColor: tipoBadge.bg,
                      color: tipoBadge.text,
                      padding: '3px 10px',
                      borderRadius: RADIUS.full,
                      fontSize: FONT.sizeSM,
                      fontWeight: '600',
                      textTransform: 'uppercase',
                    }}>
                      {obj.target_type}
                    </span>
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM, color: COLORS.success }}>
                    ● Activo
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM, color: COLORS.success }}>
                    ✓ En scope
                  </td>
                  <td style={{ padding: `${SPACING.md} ${SPACING.md}` }}>
                    <button
                      onClick={() => eliminarObjetivo(obj.id)}
                      style={{
                        padding: '5px 14px',
                        backgroundColor: 'transparent',
                        border: `1px solid ${COLORS.danger}`,
                        color: COLORS.danger,
                        borderRadius: RADIUS.sm,
                        fontSize: FONT.sizeSM,
                        fontWeight: '600',
                        cursor: 'pointer',
                        fontFamily: FONT.base,
                      }}
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              )
            })}
            {listaObjetivos.length === 0 && (
              <tr>
                <td colSpan="6" style={{ padding: '40px', textAlign: 'center', color: COLORS.textDim }}>
                  No hay objetivos definidos aún.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Aviso Scope Enforcement */}
      <div style={{
        backgroundColor: COLORS.bgSidebar,
        border: `1px solid ${COLORS.border}`,
        borderLeft: `3px solid ${COLORS.warning}`,
        borderRadius: RADIUS.md,
        padding: SPACING.md,
        display: 'flex',
        alignItems: 'center',
        gap: SPACING.md,
      }}>
        <span style={{ fontSize: '18px' }}>⚠</span>
        <div>
          <div style={{ fontSize: FONT.sizeSM, fontWeight: '600', color: COLORS.warning, marginBottom: '2px' }}>
            Scope Enforcement Activo
          </div>
          <div style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted }}>
            Todas las acciones de los agentes son validadas contra este scope antes de ejecutarse. Targets fuera del scope son bloqueados automáticamente.
          </div>
        </div>
      </div>

    </div>
  )
}
