import { useState, useEffect, useCallback } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

// ─── Config ───────────────────────────────────────────────────────────────────
const API_BASE      = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const API_KEY       = import.meta.env.VITE_API_KEY  || 'dev-key-insecure'
const ENGAGEMENT_ID = 1   // TODO: recibir como prop desde EngagementsListView

// ─── Severidad → colores ──────────────────────────────────────────────────────
const SEV_MAP = {
  critical: { label:'CRITICAL', bg: COLORS.dangerAlpha,  text: COLORS.sevCritical },
  high:     { label:'HIGH',     bg: '#f9731622',          text: COLORS.sevHigh     },
  medium:   { label:'MEDIUM',   bg: COLORS.warningAlpha, text: COLORS.sevMedium   },
  low:      { label:'LOW',      bg: COLORS.infoAlpha,    text: COLORS.sevLow      },
  info:     { label:'INFO',     bg: COLORS.bgApp,        text: COLORS.textDim     },
}

const MITRE_NAMES = {
  T1190:'Exploit Public App', T1210:'Exploit Remote Svc',
  T1078:'Valid Accounts',     T1110:'Brute Force',
  T1021:'Remote Services',    T1083:'File Discovery',
  T1040:'Network Sniffing',   T1082:'System Info',
}

function SevBadge({ sev }) {
  const s = SEV_MAP[sev?.toLowerCase()] || SEV_MAP.info
  return (
    <span style={{ padding:'3px 10px', backgroundColor:s.bg, color:s.text,
      borderRadius:RADIUS.full, fontSize:FONT.sizeSM, fontWeight:'700' }}>
      {s.label}
    </span>
  )
}

function CvssScore({ score }) {
  if (score == null) return <span style={{ color:COLORS.textDim, fontFamily:FONT.mono }}>—</span>
  const color = score>=9 ? COLORS.sevCritical : score>=7 ? COLORS.sevHigh
              : score>=4 ? COLORS.sevMedium   : COLORS.sevLow
  return <span style={{ fontWeight:'700', color, fontFamily:FONT.mono }}>{Number(score).toFixed(1)}</span>
}

const POR_PAGINA = 10

// ─── Vista ────────────────────────────────────────────────────────────────────
export default function HallazgosView({ engagementId = ENGAGEMENT_ID }) {
  const [findings,  setFindings]  = useState([])
  const [loading,   setLoading]   = useState(true)
  const [filSev,    setFilSev]    = useState('todos')
  const [filStatus, setFilStatus] = useState('todos')
  const [busqueda,  setBusqueda]  = useState('')
  const [pagina,    setPagina]    = useState(1)

  const cargar = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch(`${API_BASE}/engagements/${engagementId}/findings`, {
        headers: { 'X-API-Key': API_KEY },
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setFindings(data.findings || [])
    } catch {
      setFindings([])
    } finally {
      setLoading(false)
    }
  }, [engagementId])

  useEffect(() => { cargar() }, [cargar])

  // Filtros
  const filtrados = findings.filter((f) => {
    if (filSev    !== 'todos' && (f.severity||'').toLowerCase() !== filSev)    return false
    if (filStatus !== 'todos' && (f.status  ||'').toLowerCase() !== filStatus) return false
    if (busqueda) {
      const q = busqueda.toLowerCase()
      return (
        (f.cve_ids||[]).join(' ').toLowerCase().includes(q) ||
        (f.target||'').toLowerCase().includes(q) ||
        (f.title ||'').toLowerCase().includes(q) ||
        (f.mitre_technique||'').toLowerCase().includes(q)
      )
    }
    return true
  })

  const totalPaginas = Math.max(1, Math.ceil(filtrados.length / POR_PAGINA))
  const items = filtrados.slice((pagina-1)*POR_PAGINA, pagina*POR_PAGINA)

  const sel = {
    padding:'7px 12px', backgroundColor:COLORS.bgInput,
    border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.md,
    color:COLORS.textPrimary, fontFamily:FONT.base, fontSize:FONT.sizeSM,
    outline:'none', cursor:'pointer',
  }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:SPACING.xl, fontFamily:FONT.base }}>

      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', gap:SPACING.md }}>
        <div>
          <h1 style={{ margin:0, fontSize:FONT.size2XL, color:COLORS.textPrimary }}>Hallazgos</h1>
          <p style={{ margin:'4px 0 0', fontSize:FONT.sizeMD, color:COLORS.textMuted }}>
            Engagement #{engagementId}
          </p>
        </div>
        <div style={{ marginLeft:'auto', display:'flex', gap:SPACING.sm, alignItems:'center' }}>
          <button onClick={cargar} disabled={loading}
            style={{ padding:'6px 14px', background:'transparent',
              border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.md,
              color:COLORS.textMuted, cursor:loading?'not-allowed':'pointer',
              fontSize:FONT.sizeSM, fontFamily:FONT.base }}>
            {loading ? '…' : '↻ Actualizar'}
          </button>
          <span style={{ padding:'6px 16px', backgroundColor:COLORS.accentAlpha,
            color:COLORS.accent, borderRadius:RADIUS.full, fontSize:FONT.sizeMD, fontWeight:'700' }}>
            {findings.length} findings
          </span>
        </div>
      </div>

      {/* Filtros */}
      <div style={{ backgroundColor:COLORS.bgCard, border:`1px solid ${COLORS.border}`,
        borderRadius:RADIUS.lg, padding:SPACING.md,
        display:'flex', gap:SPACING.md, alignItems:'center', flexWrap:'wrap' }}>
        <select value={filSev} onChange={(e)=>{setFilSev(e.target.value);setPagina(1)}} style={sel}>
          <option value="todos">Severidad: Todos</option>
          {['critical','high','medium','low','info'].map(s=>(
            <option key={s} value={s}>{s.toUpperCase()}</option>
          ))}
        </select>
        <select value={filStatus} onChange={(e)=>{setFilStatus(e.target.value);setPagina(1)}} style={sel}>
          <option value="todos">Estado: Todos</option>
          {['open','closed','false_positive'].map(s=>(
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <input type="text" placeholder="Buscar CVE, host, título, MITRE…"
          value={busqueda} onChange={(e)=>{setBusqueda(e.target.value);setPagina(1)}}
          style={{ flex:1, minWidth:'220px', padding:'7px 14px',
            backgroundColor:COLORS.bgInput, border:`1px solid ${COLORS.border}`,
            borderRadius:RADIUS.md, color:COLORS.textPrimary,
            fontFamily:FONT.base, fontSize:FONT.sizeSM, outline:'none' }} />
        <span style={{ fontSize:FONT.sizeSM, color:COLORS.textDim, whiteSpace:'nowrap' }}>
          {filtrados.length} resultado{filtrados.length!==1?'s':''}
        </span>
      </div>

      {/* Tabla */}
      <div style={{ backgroundColor:COLORS.bgCard, border:`1px solid ${COLORS.border}`,
        borderRadius:RADIUS.lg, overflow:'hidden' }}>
        {loading ? (
          <div style={{ padding:'60px', textAlign:'center', color:COLORS.textDim }}>
            Cargando findings desde el backend…
          </div>
        ) : (
          <table style={{ width:'100%', borderCollapse:'collapse', textAlign:'left' }}>
            <thead>
              <tr style={{ backgroundColor:COLORS.bgApp }}>
                {['Severidad','CVE','Host · Puerto','Título','MITRE','CVSS','Estado','Tool'].map(col=>(
                  <th key={col} style={{ padding:`${SPACING.sm} ${SPACING.md}`,
                    color:COLORS.textMuted, fontSize:FONT.sizeSM, fontWeight:'500',
                    borderBottom:`1px solid ${COLORS.border}`, whiteSpace:'nowrap' }}>
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {items.map((f, i) => {
                const port = f.evidence?.port
                const svc  = f.evidence?.service
                const cves = (f.cve_ids||[]).slice(0,2)
                return (
                  <tr key={f._id||i} style={{ borderBottom:`1px solid ${COLORS.border}`,
                    backgroundColor:i%2===0?'transparent':`${COLORS.bgApp}88` }}>
                    <td style={{ padding:`${SPACING.sm} ${SPACING.md}` }}>
                      <SevBadge sev={f.severity} />
                    </td>
                    <td style={{ padding:`${SPACING.sm} ${SPACING.md}`, fontFamily:FONT.mono, fontSize:FONT.sizeSM }}>
                      {cves.length>0
                        ? cves.map(c=><div key={c} style={{ color:COLORS.accent }}>{c}</div>)
                        : <span style={{ color:COLORS.textDim }}>—</span>}
                    </td>
                    <td style={{ padding:`${SPACING.sm} ${SPACING.md}`, fontFamily:FONT.mono, fontSize:FONT.sizeSM }}>
                      <div style={{ color:COLORS.textPrimary }}>{f.target}</div>
                      {port && <div style={{ color:COLORS.textDim, fontSize:FONT.sizeXS }}>{port}/{svc}</div>}
                    </td>
                    <td style={{ padding:`${SPACING.sm} ${SPACING.md}`, fontSize:FONT.sizeSM,
                      color:COLORS.textMuted, maxWidth:'260px' }}>
                      {f.title}
                    </td>
                    <td style={{ padding:`${SPACING.sm} ${SPACING.md}` }}>
                      {f.mitre_technique
                        ? <span title={MITRE_NAMES[f.mitre_technique]||f.mitre_technique}
                            style={{ padding:'3px 8px', backgroundColor:COLORS.bgApp,
                              border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.sm,
                              fontFamily:FONT.mono, fontSize:FONT.sizeSM,
                              color:COLORS.textMuted, cursor:'help' }}>
                            {f.mitre_technique}
                          </span>
                        : <span style={{ color:COLORS.textDim }}>—</span>}
                    </td>
                    <td style={{ padding:`${SPACING.sm} ${SPACING.md}` }}>
                      <CvssScore score={f.cvss_score} />
                    </td>
                    <td style={{ padding:`${SPACING.sm} ${SPACING.md}` }}>
                      <span style={{ padding:'3px 10px',
                        backgroundColor:f.status==='open'?COLORS.warningAlpha:COLORS.successAlpha,
                        color:f.status==='open'?COLORS.warning:COLORS.success,
                        borderRadius:RADIUS.full, fontSize:FONT.sizeSM, fontWeight:'600' }}>
                        {f.status||'open'}
                      </span>
                    </td>
                    <td style={{ padding:`${SPACING.sm} ${SPACING.md}`, fontSize:FONT.sizeSM, color:COLORS.info }}>
                      {f.tool||'nmap'}
                    </td>
                  </tr>
                )
              })}
              {items.length===0 && (
                <tr><td colSpan="8" style={{ padding:'40px', textAlign:'center', color:COLORS.textDim }}>
                  Sin resultados para los filtros aplicados.
                </td></tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* Paginación */}
      {totalPaginas > 1 && (
        <div style={{ display:'flex', justifyContent:'flex-end', alignItems:'center', gap:SPACING.md }}>
          <span style={{ fontSize:FONT.sizeSM, color:COLORS.textDim }}>
            Página {pagina} de {totalPaginas}
          </span>
          {[['← Anterior',-1],['Siguiente →',1]].map(([label,dir])=>{
            const disabled = dir===-1 ? pagina===1 : pagina===totalPaginas
            return (
              <button key={label} onClick={()=>setPagina(p=>p+dir)} disabled={disabled}
                style={{ padding:'6px 16px', backgroundColor:'transparent',
                  border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.md,
                  color:disabled?COLORS.textDim:COLORS.textPrimary,
                  cursor:disabled?'not-allowed':'pointer',
                  fontFamily:FONT.base, fontSize:FONT.sizeSM }}>
                {label}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
