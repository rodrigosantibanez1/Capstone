import { useState, useEffect } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000'

// Normalise API record → display record
function normalise(r) {
  return {
    id:        r.id ? `HITL-${String(r.id).padStart(3, '0')}` : '—',
    ts:        r.decided_at || r.requested_at || '—',
    agente:    r.agent   || '—',
    tool:      r.tool    || '—',
    riskLevel: (r.risk_level || 'low').toUpperCase(),
    decision:  decisionLabel(r.decision || r.status),
    operador:  r.operator || 'Sistema',
    notas:     r.notes   || '',
  }
}

function decisionLabel(val) {
  if (!val) return '—'
  const v = val.toLowerCase()
  if (v === 'approved')      return 'APROBADO'
  if (v === 'auto_approved') return 'AUTO-APROBADO'
  if (v === 'rejected')      return 'RECHAZADO'
  if (v === 'pending')       return 'PENDIENTE'
  return val.toUpperCase()
}

const RISK_STYLE = {
  CRITICAL: { bg: COLORS.dangerAlpha,  text: COLORS.danger,  border: `${COLORS.danger}44`  },
  HIGH:     { bg: COLORS.dangerAlpha,  text: COLORS.danger,  border: `${COLORS.danger}44`  },
  MEDIUM:   { bg: COLORS.warningAlpha, text: COLORS.warning, border: `${COLORS.warning}44` },
  LOW:      { bg: COLORS.infoAlpha,    text: COLORS.info,    border: `${COLORS.info}44`    },
}

function RiskBadge({ level }) {
  const s = RISK_STYLE[level] || RISK_STYLE.LOW
  return (
    <span style={{ padding: '2px 8px', backgroundColor: s.bg, color: s.text,
      borderRadius: RADIUS.full, fontSize: FONT.sizeSM, fontWeight: '700', border: `1px solid ${s.border}` }}>
      {level}
    </span>
  )
}

function DecisionBadge({ decision }) {
  const isAuto   = decision === 'AUTO-APROBADO'
  const isAprob  = decision === 'APROBADO' || isAuto
  return (
    <span style={{
      padding: '2px 10px',
      backgroundColor: isAprob ? COLORS.successAlpha : COLORS.dangerAlpha,
      color: isAprob ? COLORS.success : COLORS.danger,
      borderRadius: RADIUS.full, fontSize: FONT.sizeSM, fontWeight: '600',
      opacity: isAuto ? 0.7 : 1,
    }}>
      {decision}
    </span>
  )
}

function descargarCSV(data) {
  const cols = ['ID','Timestamp','Agente','Tool','Risk Level','Decisión','Operador','Notas']
  const rows = data.map((r) =>
    [r.id, r.ts, r.agente, r.tool, r.riskLevel, r.decision, r.operador, r.notas]
      .map((v) => `"${String(v).replace(/"/g,'""')}"`)
      .join(',')
  )
  const csv = [cols.join(','), ...rows].join('\n')
  const blob = new Blob([csv], { type: 'text/csv' })
  const url  = URL.createObjectURL(blob)
  const a    = document.createElement('a')
  a.href     = url
  a.download = 'hitl_audit.csv'
  a.click()
  URL.revokeObjectURL(url)
}

export default function HitlAuditView() {
  const [audit,       setAudit]       = useState([])
  const [loading,     setLoading]     = useState(true)
  const [filAgente,   setFilAgente]   = useState('Todos')
  const [filRisk,     setFilRisk]     = useState('Todos')
  const [filDecision, setFilDecision] = useState('Todos')
  const [vista,       setVista]       = useState('tabla') // 'tabla' | 'timeline'

  useEffect(() => {
    const cargar = async () => {
      setLoading(true)
      try {
        // Fetch all engagements, then load HITL actions for each
        const engRes = await fetch(`${API_BASE}/engagements`)
        if (!engRes.ok) throw new Error(`HTTP ${engRes.status}`)
        const engs = await engRes.json()
        if (!engs.length) { setAudit([]); return }

        const allActions = await Promise.all(
          engs.map((eng) =>
            fetch(`${API_BASE}/engagements/${eng.id}/hitl-actions`)
              .then((r) => (r.ok ? r.json() : []))
              .catch(() => [])
          )
        )
        const flat = allActions.flat().map(normalise)
        flat.sort((a, b) => b.ts.localeCompare(a.ts))
        setAudit(flat)
      } catch {
        setAudit([])
      } finally {
        setLoading(false)
      }
    }
    cargar()
  }, [])

  const filtrados = audit.filter((r) => {
    if (filAgente   !== 'Todos' && r.agente    !== filAgente)   return false
    if (filRisk     !== 'Todos' && r.riskLevel !== filRisk)     return false
    if (filDecision !== 'Todos') {
      if (filDecision === 'APROBADO'  && !r.decision.includes('APROBADO'))  return false
      if (filDecision === 'RECHAZADO' && r.decision !== 'RECHAZADO')        return false
    }
    return true
  })

  const selectStyle = {
    padding: '7px 12px', backgroundColor: COLORS.bgInput,
    border: `1px solid ${COLORS.border}`, borderRadius: RADIUS.md,
    color: COLORS.textPrimary, fontFamily: FONT.base,
    fontSize: FONT.sizeSM, outline: 'none', cursor: 'pointer',
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl, fontFamily: FONT.base }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: SPACING.md }}>
        <div>
          <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>
            HITL Audit Log
          </h1>
          <p style={{ margin: '4px 0 0', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
            Bitácora inmutable de decisiones humanas · {loading ? '…' : `${audit.length} entradas`}
          </p>
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: SPACING.sm }}>
          <button
            onClick={() => setVista(vista === 'tabla' ? 'timeline' : 'tabla')}
            style={{ padding: '9px 18px', backgroundColor: COLORS.accentAlpha,
              color: COLORS.accent, border: `1px solid ${COLORS.accent}44`,
              borderRadius: RADIUS.md, cursor: 'pointer', fontFamily: FONT.base, fontSize: FONT.sizeSM }}>
            {vista === 'tabla' ? '☰ Timeline' : '⊞ Tabla'}
          </button>
          <button
            onClick={() => descargarCSV(filtrados)}
            disabled={filtrados.length === 0}
            style={{ padding: '9px 18px', backgroundColor: COLORS.successAlpha,
              color: COLORS.success, border: `1px solid ${COLORS.success}44`,
              borderRadius: RADIUS.md, cursor: filtrados.length === 0 ? 'not-allowed' : 'pointer',
              fontFamily: FONT.base, fontSize: FONT.sizeSM,
              opacity: filtrados.length === 0 ? 0.5 : 1 }}>
            ↓ Export CSV
          </button>
        </div>
      </div>

      {/* Filtros */}
      <div style={{ backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg, padding: SPACING.md, display: 'flex', gap: SPACING.md, flexWrap: 'wrap' }}>
        <select value={filAgente} onChange={(e) => setFilAgente(e.target.value)} style={selectStyle}>
          <option value="Todos">Agente: Todos</option>
          {['ReconAgent','ScanAgent','AnalysisAgent','Sistema'].map((a) => (
            <option key={a} value={a}>{a}</option>
          ))}
        </select>
        <select value={filRisk} onChange={(e) => setFilRisk(e.target.value)} style={selectStyle}>
          <option value="Todos">Riesgo: Todos</option>
          {['CRITICAL','HIGH','MEDIUM','LOW'].map((r) => <option key={r} value={r}>{r}</option>)}
        </select>
        <select value={filDecision} onChange={(e) => setFilDecision(e.target.value)} style={selectStyle}>
          <option value="Todos">Decisión: Todas</option>
          <option value="APROBADO">Aprobadas (incl. auto)</option>
          <option value="RECHAZADO">Rechazadas</option>
        </select>
        <span style={{ fontSize: FONT.sizeSM, color: COLORS.textDim, alignSelf: 'center' }}>
          {loading ? 'Cargando…' : `${filtrados.length} de ${audit.length} entradas`}
        </span>
      </div>

      {/* Estado carga / vacío */}
      {loading && (
        <div style={{ padding: SPACING.xl, textAlign: 'center', color: COLORS.textDim, fontSize: FONT.sizeSM }}>
          Cargando bitácora HITL…
        </div>
      )}

      {!loading && audit.length === 0 && (
        <div style={{ backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
          borderRadius: RADIUS.lg, padding: SPACING.xl,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: SPACING.md,
          textAlign: 'center' }}>
          <div style={{ fontSize: '40px', opacity: 0.2 }}>🔍</div>
          <div style={{ fontSize: FONT.sizeLG, fontWeight: '600', color: COLORS.textMuted }}>
            Sin entradas HITL
          </div>
          <div style={{ fontSize: FONT.sizeMD, color: COLORS.textDim, maxWidth: '480px', lineHeight: '1.6' }}>
            El audit log se llena cuando los agentes ejecutan acciones con <code style={{ color: COLORS.accent }}>risk_level ≥ medium</code> y un operador las aprueba o rechaza.
          </div>
        </div>
      )}

      {/* VISTA TABLA */}
      {!loading && filtrados.length > 0 && vista === 'tabla' && (
        <div style={{ backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
          borderRadius: RADIUS.lg, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: COLORS.bgApp }}>
                {['Timestamp','ID','Agente · Tool','Riesgo','Decisión','Operador','Notas'].map((col) => (
                  <th key={col} style={{ padding: `${SPACING.sm} ${SPACING.md}`,
                    color: COLORS.textMuted, fontSize: FONT.sizeSM, fontWeight: '500',
                    borderBottom: `1px solid ${COLORS.border}`, whiteSpace: 'nowrap' }}>
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtrados.map((r, i) => (
                <tr key={i} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: `${SPACING.sm} ${SPACING.md}`,
                    fontFamily: FONT.mono, fontSize: FONT.sizeSM, color: COLORS.textDim, whiteSpace: 'nowrap' }}>
                    {r.ts}
                  </td>
                  <td style={{ padding: `${SPACING.sm} ${SPACING.md}`,
                    fontFamily: FONT.mono, fontSize: FONT.sizeSM, color: COLORS.textDim }}>
                    {r.id}
                  </td>
                  <td style={{ padding: `${SPACING.sm} ${SPACING.md}` }}>
                    <span style={{ color: COLORS.textPrimary }}>{r.agente}</span>
                    <span style={{ color: COLORS.textDim }}> · </span>
                    <span style={{ color: COLORS.info, fontFamily: FONT.mono, fontSize: FONT.sizeSM }}>{r.tool}</span>
                  </td>
                  <td style={{ padding: `${SPACING.sm} ${SPACING.md}` }}>
                    <RiskBadge level={r.riskLevel} />
                  </td>
                  <td style={{ padding: `${SPACING.sm} ${SPACING.md}` }}>
                    <DecisionBadge decision={r.decision} />
                  </td>
                  <td style={{ padding: `${SPACING.sm} ${SPACING.md}`,
                    fontSize: FONT.sizeSM, color: COLORS.textMuted }}>{r.operador}</td>
                  <td style={{ padding: `${SPACING.sm} ${SPACING.md}`,
                    fontSize: FONT.sizeSM, color: COLORS.textDim, fontStyle: r.notas ? 'normal' : 'italic' }}>
                    {r.notas || '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* VISTA TIMELINE */}
      {!loading && filtrados.length > 0 && vista === 'timeline' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {filtrados.map((r, i) => {
            const isAprob = r.decision !== 'RECHAZADO'
            const dotColor = isAprob ? COLORS.success : COLORS.danger
            return (
              <div key={i} style={{ display: 'flex', gap: SPACING.md }}>
                {/* Línea + dot */}
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: '20px', flexShrink: 0 }}>
                  <div style={{ width: '12px', height: '12px', borderRadius: '50%',
                    backgroundColor: dotColor, flexShrink: 0, marginTop: '16px' }} />
                  {i < filtrados.length - 1 && (
                    <div style={{ width: '2px', flex: 1, minHeight: '24px',
                      backgroundColor: COLORS.border, margin: '4px 0' }} />
                  )}
                </div>
                {/* Card */}
                <div style={{ flex: 1, paddingBottom: SPACING.md }}>
                  <div style={{ backgroundColor: COLORS.bgCard,
                    border: `1px solid ${COLORS.border}`,
                    borderRadius: RADIUS.md, padding: SPACING.md }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm,
                      flexWrap: 'wrap', marginBottom: SPACING.xs }}>
                      <span style={{ fontFamily: FONT.mono, fontSize: FONT.sizeSM, color: COLORS.textDim }}>{r.ts}</span>
                      <DecisionBadge decision={r.decision} />
                      <RiskBadge level={r.riskLevel} />
                    </div>
                    <div style={{ fontSize: FONT.sizeMD, color: COLORS.textPrimary, marginBottom: '2px' }}>
                      <span style={{ fontWeight: '600' }}>{r.agente}</span>
                      <span style={{ color: COLORS.textDim }}> · </span>
                      <span style={{ color: COLORS.info, fontFamily: FONT.mono }}>{r.tool}</span>
                    </div>
                    <div style={{ fontSize: FONT.sizeSM, color: COLORS.textDim }}>
                      Operador: {r.operador}
                      {r.notas && <> · <span style={{ fontStyle: 'italic' }}>"{r.notas}"</span></>}
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
