import { useState, useEffect, useCallback } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

// ─── Config ───────────────────────────────────────────────────────────────────
const API_BASE      = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const API_KEY       = import.meta.env.VITE_API_KEY  || 'dev-key-insecure'
const ENGAGEMENT_ID = 1
const POLL_INTERVAL = 8000  // ms entre actualizaciones automáticas

// ─── Helpers visuales ─────────────────────────────────────────────────────────
const RISK_STYLE = {
  CRITICAL: { bg: COLORS.dangerAlpha,  text: COLORS.danger,   border: `${COLORS.danger}44`   },
  HIGH:     { bg: COLORS.dangerAlpha,  text: COLORS.sevHigh,  border: `${COLORS.sevHigh}44`  },
  MEDIUM:   { bg: COLORS.warningAlpha, text: COLORS.warning,  border: `${COLORS.warning}44`  },
  LOW:      { bg: COLORS.infoAlpha,    text: COLORS.info,     border: `${COLORS.info}44`     },
}

function RiskBadge({ level }) {
  const s = RISK_STYLE[level?.toUpperCase()] || RISK_STYLE.LOW
  return (
    <span style={{ padding:'3px 12px', backgroundColor:s.bg, color:s.text,
      borderRadius:RADIUS.full, fontSize:FONT.sizeSM, fontWeight:'700',
      border:`1px solid ${s.border}` }}>
      {level?.toUpperCase()}
    </span>
  )
}

function DecisionBadge({ decision }) {
  const d = decision?.toUpperCase() || ''
  const ok = d.includes('APPROVED')
  const rej = d.includes('REJECTED')
  return (
    <span style={{ padding:'3px 10px',
      backgroundColor: ok ? COLORS.successAlpha : rej ? COLORS.dangerAlpha : COLORS.warningAlpha,
      color: ok ? COLORS.success : rej ? COLORS.danger : COLORS.warning,
      borderRadius:RADIUS.full, fontSize:FONT.sizeSM, fontWeight:'600' }}>
      {d}
    </span>
  )
}

function fmtTs(ts) {
  if (!ts) return '—'
  try { return new Date(ts).toLocaleString('sv').replace('T', ' ') } catch { return ts }
}

// ─── Vista ────────────────────────────────────────────────────────────────────
export default function HitlView({ engagementId = ENGAGEMENT_ID }) {
  const [pendientes,  setPendientes]  = useState([])
  const [historial,   setHistorial]   = useState([])
  const [loading,     setLoading]     = useState(true)
  const [notas,       setNotas]       = useState({})
  const [submitting,  setSubmitting]  = useState({})

  // ── Cargar acciones HITL ──────────────────────────────────────────────────
  const cargar = useCallback(async () => {
    try {
      const res = await fetch(
        `${API_BASE}/engagements/${engagementId}/hitl-actions`,
        { headers: { 'X-API-Key': API_KEY } }
      )
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const actions = await res.json()   // el endpoint devuelve lista directa
      const all = Array.isArray(actions) ? actions : (actions.items || [])
      setPendientes(all.filter(a => a.decision === 'PENDING'))
      setHistorial(all.filter(a => a.decision !== 'PENDING'))
    } catch {
      setPendientes([])
      setHistorial([])
    } finally {
      setLoading(false)
    }
  }, [engagementId, loading])

  useEffect(() => {
    cargar()
    const timer = setInterval(cargar, POLL_INTERVAL)
    return () => clearInterval(timer)
  }, [cargar])

  // ── Aprobar / Rechazar ────────────────────────────────────────────────────
  const decidir = async (id, decision) => {
    setSubmitting(prev => ({ ...prev, [id]: true }))
    try {
      const res = await fetch(`${API_BASE}/hitl-actions/${id}/decision`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': API_KEY,
        },
        body: JSON.stringify({
          decision,
          operator: 'Admin User',
          notes: notas[id] || null,
        }),
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      setNotas(prev => { const n = {...prev}; delete n[id]; return n })
      await cargar()   // refrescar lista inmediatamente
    } catch (err) {
      console.error('Error al decidir HITL:', err)
    } finally {
      setSubmitting(prev => { const s = {...prev}; delete s[id]; return s })
    }
  }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:SPACING.xl, fontFamily:FONT.base }}>

      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', gap:SPACING.md }}>
        <div>
          <h1 style={{ margin:0, fontSize:FONT.size2XL, color:COLORS.textPrimary }}>Consola HITL</h1>
          <p style={{ margin:'4px 0 0', fontSize:FONT.sizeMD, color:COLORS.textMuted }}>
            Human-In-The-Loop · Control de acciones de riesgo
          </p>
        </div>
        <div style={{ marginLeft:'auto', display:'flex', gap:SPACING.sm, alignItems:'center' }}>
          <span style={{ fontSize:FONT.sizeXS, color:COLORS.textDim }}>
            Auto-refresh {POLL_INTERVAL/1000}s
          </span>
          <button onClick={cargar}
            style={{ padding:'6px 14px', background:'transparent',
              border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.md,
              color:COLORS.textMuted, cursor:'pointer',
              fontSize:FONT.sizeSM, fontFamily:FONT.base }}>
            ↻ Actualizar
          </button>
          {pendientes.length > 0 && (
            <div style={{ padding:'6px 16px', backgroundColor:COLORS.dangerAlpha,
              color:COLORS.danger, border:`1px solid ${COLORS.danger}44`,
              borderRadius:RADIUS.full, fontSize:FONT.sizeMD, fontWeight:'700' }}>
              ⚠ {pendientes.length} pendiente{pendientes.length>1?'s':''}
            </div>
          )}
        </div>
      </div>

      {/* Cola pendiente */}
      <div>
        <div style={{ fontSize:FONT.sizeMD, fontWeight:'600', color:COLORS.textPrimary, marginBottom:SPACING.md }}>
          Acciones pendientes de aprobación
        </div>

        {loading ? (
          <div style={{ backgroundColor:COLORS.bgCard, border:`1px solid ${COLORS.border}`,
            borderRadius:RADIUS.lg, padding:SPACING.xl, textAlign:'center', color:COLORS.textDim }}>
            Cargando…
          </div>
        ) : pendientes.length === 0 ? (
          <div style={{ backgroundColor:COLORS.bgCard, border:`1px solid ${COLORS.border}`,
            borderRadius:RADIUS.lg, padding:SPACING.xl, textAlign:'center', color:COLORS.textDim }}>
            ✓ Sin acciones pendientes. El pipeline continúa automáticamente.
          </div>
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:SPACING.md }}>
            {pendientes.map(accion => {
              const riskKey = accion.risk_level?.toUpperCase() || 'LOW'
              const isSub = submitting[accion.id]
              return (
                <div key={accion.id} style={{ backgroundColor:COLORS.bgCard,
                  border:`1px solid ${RISK_STYLE[riskKey]?.border||COLORS.border}`,
                  borderRadius:RADIUS.lg, padding:SPACING.lg }}>

                  {/* Cabecera */}
                  <div style={{ display:'flex', alignItems:'center', gap:SPACING.md, marginBottom:SPACING.md }}>
                    <RiskBadge level={riskKey} />
                    <span style={{ fontSize:FONT.sizeLG, fontWeight:'700', color:COLORS.textPrimary }}>
                      {accion.agent}
                    </span>
                    <span style={{ color:COLORS.textDim }}>·</span>
                    <span style={{ fontFamily:FONT.mono, fontSize:FONT.sizeMD, color:COLORS.info,
                      backgroundColor:COLORS.infoAlpha, padding:'2px 10px', borderRadius:RADIUS.sm }}>
                      {accion.tool}
                    </span>
                    <span style={{ marginLeft:'auto', fontSize:FONT.sizeSM, color:COLORS.textDim, fontFamily:FONT.mono }}>
                      #{accion.id} · {fmtTs(accion.requested_at)}
                    </span>
                  </div>

                  {/* Parámetros */}
                  <div style={{ backgroundColor:COLORS.bgApp, border:`1px solid ${COLORS.border}`,
                    borderRadius:RADIUS.md, padding:SPACING.md, marginBottom:SPACING.md,
                    fontFamily:FONT.mono, fontSize:FONT.sizeSM, color:COLORS.textMuted,
                    display:'flex', flexWrap:'wrap', gap:SPACING.md }}>
                    {Object.entries(accion.params||{}).map(([k,v]) => (
                      <span key={k}>
                        <span style={{ color:COLORS.textDim }}>{k}:</span>{' '}
                        <span style={{ color:COLORS.textPrimary }}>{JSON.stringify(v)}</span>
                      </span>
                    ))}
                  </div>

                  {/* Notas + botones */}
                  <div style={{ display:'flex', gap:SPACING.md, alignItems:'flex-end' }}>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:FONT.sizeSM, color:COLORS.textDim, marginBottom:'4px' }}>
                        Notas del operador (opcional):
                      </div>
                      <input type="text" placeholder="Ej: Aprobado para ventana de mantenimiento…"
                        value={notas[accion.id]||''}
                        onChange={(e) => setNotas(prev => ({...prev,[accion.id]:e.target.value}))}
                        disabled={isSub}
                        style={{ width:'100%', padding:'8px 12px',
                          backgroundColor:COLORS.bgInput, border:`1px solid ${COLORS.border}`,
                          borderRadius:RADIUS.md, color:COLORS.textPrimary,
                          fontFamily:FONT.base, fontSize:FONT.sizeSM,
                          outline:'none', boxSizing:'border-box' }} />
                    </div>
                    <button onClick={() => decidir(accion.id,'APPROVED')} disabled={isSub}
                      style={{ padding:'8px 24px', backgroundColor:COLORS.successAlpha,
                        color:COLORS.success, border:`1px solid ${COLORS.success}44`,
                        borderRadius:RADIUS.md, fontSize:FONT.sizeMD, fontWeight:'700',
                        cursor:isSub?'not-allowed':'pointer', fontFamily:FONT.base, whiteSpace:'nowrap' }}>
                      {isSub ? '…' : '✓ Aprobar'}
                    </button>
                    <button onClick={() => decidir(accion.id,'REJECTED')} disabled={isSub}
                      style={{ padding:'8px 24px', backgroundColor:COLORS.dangerAlpha,
                        color:COLORS.danger, border:`1px solid ${COLORS.danger}44`,
                        borderRadius:RADIUS.md, fontSize:FONT.sizeMD, fontWeight:'700',
                        cursor:isSub?'not-allowed':'pointer', fontFamily:FONT.base, whiteSpace:'nowrap' }}>
                      {isSub ? '…' : '✕ Rechazar'}
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Historial */}
      <div>
        <div style={{ fontSize:FONT.sizeMD, fontWeight:'600', color:COLORS.textPrimary, marginBottom:SPACING.md }}>
          Historial de decisiones ({historial.length})
        </div>
        <div style={{ backgroundColor:COLORS.bgCard, border:`1px solid ${COLORS.border}`,
          borderRadius:RADIUS.lg, overflow:'hidden' }}>
          <table style={{ width:'100%', borderCollapse:'collapse', textAlign:'left' }}>
            <thead>
              <tr style={{ backgroundColor:COLORS.bgApp }}>
                {['ID','Agente · Tool','Riesgo','Decisión','Operador','Timestamp'].map(col=>(
                  <th key={col} style={{ padding:`${SPACING.sm} ${SPACING.md}`,
                    color:COLORS.textMuted, fontSize:FONT.sizeSM, fontWeight:'500',
                    borderBottom:`1px solid ${COLORS.border}` }}>
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {historial.length === 0 ? (
                <tr><td colSpan="6" style={{ padding:'24px', textAlign:'center', color:COLORS.textDim }}>
                  Sin historial aún.
                </td></tr>
              ) : historial.map(h => (
                <tr key={`${h.id}-${h.decided_at}`} style={{ borderBottom:`1px solid ${COLORS.border}` }}>
                  <td style={{ padding:`${SPACING.sm} ${SPACING.md}`, fontFamily:FONT.mono,
                    fontSize:FONT.sizeSM, color:COLORS.textDim }}>#{h.id}</td>
                  <td style={{ padding:`${SPACING.sm} ${SPACING.md}` }}>
                    <span style={{ color:COLORS.textPrimary }}>{h.agent}</span>
                    <span style={{ color:COLORS.textDim }}> · </span>
                    <span style={{ color:COLORS.info, fontFamily:FONT.mono, fontSize:FONT.sizeSM }}>{h.tool}</span>
                  </td>
                  <td style={{ padding:`${SPACING.sm} ${SPACING.md}` }}>
                    <RiskBadge level={h.risk_level} />
                  </td>
                  <td style={{ padding:`${SPACING.sm} ${SPACING.md}` }}>
                    <DecisionBadge decision={h.decision} />
                  </td>
                  <td style={{ padding:`${SPACING.sm} ${SPACING.md}`, fontSize:FONT.sizeSM, color:COLORS.textMuted }}>
                    {h.operator||'—'}
                  </td>
                  <td style={{ padding:`${SPACING.sm} ${SPACING.md}`, fontSize:FONT.sizeSM,
                    color:COLORS.textDim, fontFamily:FONT.mono }}>
                    {fmtTs(h.decided_at||h.requested_at)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
