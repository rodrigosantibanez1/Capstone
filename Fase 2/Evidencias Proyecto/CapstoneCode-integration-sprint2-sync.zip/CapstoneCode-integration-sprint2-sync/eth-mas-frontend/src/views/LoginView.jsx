import { useState } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

export default function LoginView({ onLogin }) {
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading]   = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      onLogin()
    }, 800)
  }

  const inputStyle = {
    width: '100%',
    padding: '11px 14px',
    backgroundColor: COLORS.bgInput,
    border: `1px solid ${COLORS.border}`,
    borderRadius: RADIUS.md,
    color: COLORS.textPrimary,
    fontFamily: FONT.base,
    fontSize: FONT.sizeMD,
    outline: 'none',
    boxSizing: 'border-box',
  }

  const labelStyle = {
    display: 'block',
    marginBottom: SPACING.xs,
    color: COLORS.textMuted,
    fontSize: FONT.sizeSM,
    fontWeight: '500',
  }

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: '100vw',
      height: '100vh',
      backgroundColor: COLORS.bgApp,
      fontFamily: FONT.base,
    }}>
      {/* Panel central */}
      <div style={{
        width: '400px',
        backgroundColor: COLORS.bgCard,
        border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg,
        padding: '40px',
      }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: SPACING.xl }}>
          <div style={{
            fontSize: '36px',
            fontWeight: '800',
            color: COLORS.accent,
            letterSpacing: '3px',
            fontFamily: FONT.mono,
          }}>
            ETH-MAS
          </div>
          <div style={{
            fontSize: FONT.sizeSM,
            color: COLORS.textMuted,
            marginTop: SPACING.xs,
          }}>
            Ethical Hacking Multi-Agent System
          </div>
          <div style={{
            display: 'inline-block',
            marginTop: SPACING.sm,
            padding: '2px 10px',
            backgroundColor: COLORS.bgApp,
            border: `1px solid ${COLORS.border}`,
            borderRadius: RADIUS.full,
            fontSize: FONT.sizeXS,
            color: COLORS.textDim,
          }}>
            v0.1 · academic prototype
          </div>
        </div>

        {/* Separador */}
        <div style={{ borderTop: `1px solid ${COLORS.border}`, marginBottom: SPACING.xl }} />

        {/* Formulario */}
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: SPACING.md }}>
            <label style={labelStyle}>Correo institucional</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="operador@eth-mas.cl"
              required
              style={inputStyle}
            />
          </div>

          <div style={{ marginBottom: SPACING.xl }}>
            <label style={labelStyle}>Contraseña</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              style={inputStyle}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '13px',
              backgroundColor: loading ? COLORS.textDim : COLORS.accent,
              color: COLORS.textPrimary,
              border: 'none',
              borderRadius: RADIUS.md,
              fontSize: FONT.sizeMD,
              fontWeight: '600',
              cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'background-color 0.2s',
              fontFamily: FONT.base,
            }}
          >
            {loading ? 'Autenticando...' : 'Iniciar sesión'}
          </button>
        </form>

        {/* Link olvidé */}
        <div style={{ textAlign: 'center', marginTop: SPACING.md }}>
          <span style={{
            fontSize: FONT.sizeSM,
            color: COLORS.textMuted,
            cursor: 'pointer',
            textDecoration: 'underline',
          }}>
            ¿Olvidaste tu contraseña?
          </span>
        </div>

        {/* Nota de seguridad */}
        <div style={{
          marginTop: SPACING.xl,
          borderTop: `1px solid ${COLORS.border}`,
          paddingTop: SPACING.md,
          textAlign: 'center',
          fontSize: FONT.sizeXS,
          color: COLORS.textDim,
        }}>
          Acceso restringido · Solo personal autorizado
        </div>
      </div>
    </div>
  )
}
