import { COLORS, FONT, RADIUS, SPACING } from '../theme'

export default function PipelineView() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl, fontFamily: FONT.base }}>

      <div>
        <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>Pipeline</h1>
        <p style={{ margin: '4px 0 0', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
          Monitoreo en tiempo real del pipeline de agentes
        </p>
      </div>

      <div style={{
        backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg, padding: SPACING.xl,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: SPACING.lg,
        textAlign: 'center', minHeight: '300px', justifyContent: 'center',
      }}>
        <div style={{ fontSize: '48px', opacity: 0.25 }}>▶</div>
        <div style={{ fontSize: FONT.sizeLG, fontWeight: '600', color: COLORS.textMuted }}>
          Sin pipeline activo
        </div>
        <div style={{ fontSize: FONT.sizeMD, color: COLORS.textDim, maxWidth: '520px', lineHeight: '1.7' }}>
          Inicia el pipeline desde un engagement usando los endpoints del backend:<br />
          <span style={{ fontFamily: FONT.mono, color: COLORS.accent }}>POST /engagements/&#123;id&#125;/recon</span>
          {' → '}
          <span style={{ fontFamily: FONT.mono, color: COLORS.accent }}>POST /engagements/&#123;id&#125;/scan</span><br />
          El monitoreo en tiempo real (WebSocket) estará disponible en Sprint 3.
        </div>

        {/* Stepper decorativo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm, flexWrap: 'wrap', justifyContent: 'center', marginTop: SPACING.md }}>
          {[
            { num: 1, label: 'ReconAgent',    color: COLORS.textDim },
            { num: 2, label: 'ScanAgent',     color: COLORS.textDim },
            { num: 3, label: 'AnalysisAgent', color: COLORS.textDim },
            { num: 4, label: 'ReporterAgent', color: COLORS.textDim },
          ].map((step, i) => (
            <div key={step.label} style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm }}>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
                <div style={{
                  width: '32px', height: '32px', borderRadius: '50%',
                  border: `2px solid ${COLORS.border}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: FONT.sizeSM, color: COLORS.textDim, fontWeight: '700',
                }}>
                  {step.num}
                </div>
                <span style={{ fontSize: FONT.sizeXS, color: COLORS.textDim }}>{step.label}</span>
              </div>
              {i < 3 && (
                <div style={{ width: '32px', height: '2px', backgroundColor: COLORS.border, marginBottom: '16px' }} />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
