import { COLORS, FONT, RADIUS, SPACING } from '../theme'

export default function ReporteEjecutivoView() {
  return (
    <div style={{ fontFamily: FONT.base, display: 'flex', flexDirection: 'column', gap: SPACING.xl }}>

      <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.md }}>
        <div>
          <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>
            Reporte Ejecutivo
          </h1>
          <p style={{ margin: '4px 0 0', color: COLORS.textMuted, fontSize: FONT.sizeMD }}>
            Informe de alto nivel para stakeholders — sin evidencia técnica
          </p>
        </div>
      </div>

      <div style={{
        backgroundColor: COLORS.bgCard, border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg, padding: SPACING.xl,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: SPACING.lg,
        textAlign: 'center', minHeight: '300px', justifyContent: 'center',
      }}>
        <div style={{ fontSize: '48px', opacity: 0.25 }}>📄</div>
        <div style={{ fontSize: FONT.sizeLG, fontWeight: '600', color: COLORS.textMuted }}>
          Reporte no disponible
        </div>
        <div style={{ fontSize: FONT.sizeMD, color: COLORS.textDim, maxWidth: '500px', lineHeight: '1.7' }}>
          El reporte ejecutivo es generado por{' '}
          <strong style={{ color: COLORS.accent }}>ReporterAgent</strong> al finalizar el pipeline:<br />
          Recon → Scan → Analysis (CVSS + ATT&CK) → Report.<br />
          Disponible en Sprint 3.
        </div>
        <div style={{ display: 'flex', gap: SPACING.md, marginTop: SPACING.sm }}>
          {['Riesgo global', 'Críticos', 'Altos', 'Tiempo análisis'].map(k => (
            <div key={k} style={{
              padding: `${SPACING.md} ${SPACING.lg}`,
              backgroundColor: COLORS.bgApp, border: `1px solid ${COLORS.border}`,
              borderRadius: RADIUS.md, textAlign: 'center', minWidth: '100px',
            }}>
              <div style={{ fontSize: FONT.size2XL, fontWeight: '800', color: COLORS.textDim }}>—</div>
              <div style={{ fontSize: FONT.sizeXS, color: COLORS.textDim, marginTop: '4px',
                textTransform: 'uppercase', letterSpacing: '1px' }}>{k}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
