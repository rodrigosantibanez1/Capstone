import { useState } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

export default function ReportesView() {
  const [tipoReporte, setTipoReporte]       = useState('Técnico (detallado)')
  const [incEvidencia, setIncEvidencia]     = useState(true)
  const [incRecomend, setIncRecomend]       = useState(true)
  const [generando, setGenerando]           = useState(false)
  const [progreso, setProgreso]             = useState(0)
  const [reportes, setReportes]             = useState([])

  const iniciarGeneracion = () => {
    setGenerando(true)
    setProgreso(0)
    const interval = setInterval(() => {
      setProgreso((p) => {
        if (p >= 100) {
          clearInterval(interval)
          setGenerando(false)
          return 100
        }
        return p + 8
      })
    }, 200)
  }

  const selectStyle = {
    width: '100%',
    padding: '10px 14px',
    backgroundColor: COLORS.bgInput,
    border: `1px solid ${COLORS.border}`,
    borderRadius: RADIUS.md,
    color: COLORS.textPrimary,
    fontFamily: FONT.base,
    fontSize: FONT.sizeMD,
    outline: 'none',
    cursor: 'pointer',
  }

  const labelStyle = {
    display: 'block',
    marginBottom: SPACING.xs,
    fontSize: FONT.sizeSM,
    color: COLORS.textMuted,
    fontWeight: '500',
  }

  const checkboxRow = (label, value, setter) => (
    <label style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm, cursor: 'pointer', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
      <input
        type="checkbox"
        checked={value}
        onChange={(e) => setter(e.target.checked)}
        style={{ width: '16px', height: '16px', accentColor: COLORS.accent, cursor: 'pointer' }}
      />
      {label}
    </label>
  )

  const tipoBadge = (tipo) => {
    const isEjec = tipo === 'Ejecutivo'
    return (
      <span style={{
        padding: '3px 10px',
        backgroundColor: isEjec ? COLORS.infoAlpha : COLORS.accentAlpha,
        color: isEjec ? COLORS.info : COLORS.accent,
        borderRadius: RADIUS.full,
        fontSize: FONT.sizeSM,
        fontWeight: '600',
      }}>
        {tipo}
      </span>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.xl, fontFamily: FONT.base }}>

      {/* Header */}
      <div>
        <h1 style={{ margin: 0, fontSize: FONT.size2XL, color: COLORS.textPrimary }}>Reportes</h1>
        <p style={{ margin: '4px 0 0', fontSize: FONT.sizeMD, color: COLORS.textMuted }}>
          Generación y descarga de informes de pentesting
        </p>
      </div>

      {/* Generador */}
      <div style={{
        backgroundColor: COLORS.bgCard,
        border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg,
        padding: SPACING.lg,
      }}>
        <div style={{ fontSize: FONT.sizeMD, fontWeight: '600', color: COLORS.textPrimary, marginBottom: SPACING.lg }}>
          Generar nuevo reporte
        </div>

        <div style={{ display: 'flex', gap: SPACING.xl, flexWrap: 'wrap' }}>
          {/* Campos */}
          <div style={{ flex: 1, minWidth: '220px', display: 'flex', flexDirection: 'column', gap: SPACING.md }}>
            <div>
              <label style={labelStyle}>Engagement</label>
              <select style={selectStyle} defaultValue="">
                <option value="" disabled>Selecciona un engagement…</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Tipo de reporte</label>
              <select
                value={tipoReporte}
                onChange={(e) => setTipoReporte(e.target.value)}
                style={selectStyle}
              >
                <option>Técnico (detallado)</option>
                <option>Ejecutivo (resumen)</option>
              </select>
            </div>
          </div>

          {/* Opciones */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.md, justifyContent: 'center' }}>
            <div style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted, fontWeight: '500', marginBottom: '2px' }}>
              Opciones
            </div>
            {checkboxRow('Incluir evidencia de findings', incEvidencia, setIncEvidencia)}
            {checkboxRow('Incluir recomendaciones de remediación', incRecomend, setIncRecomend)}
          </div>

          {/* Botón */}
          <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
            <button
              onClick={iniciarGeneracion}
              disabled={generando}
              style={{
                padding: '12px 32px',
                backgroundColor: generando ? COLORS.textDim : COLORS.accent,
                color: COLORS.textPrimary,
                border: 'none',
                borderRadius: RADIUS.md,
                fontSize: FONT.sizeMD,
                fontWeight: '700',
                cursor: generando ? 'not-allowed' : 'pointer',
                fontFamily: FONT.base,
                whiteSpace: 'nowrap',
              }}
            >
              {generando ? '⏳ Generando...' : '▶ Generar reporte'}
            </button>
            <div style={{ fontSize: FONT.sizeSM, color: COLORS.textDim, marginTop: SPACING.xs, textAlign: 'center' }}>
              ~30 segundos de procesamiento
            </div>
          </div>
        </div>

        {/* Barra de progreso */}
        {generando && (
          <div style={{
            marginTop: SPACING.lg,
            backgroundColor: COLORS.bgApp,
            borderRadius: RADIUS.md,
            padding: SPACING.md,
            border: `1px solid ${COLORS.border}`,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: SPACING.xs }}>
              <span style={{ fontSize: FONT.sizeSM, color: COLORS.textMuted }}>
                ReporterAgent procesando...
              </span>
              <span style={{ fontSize: FONT.sizeSM, fontWeight: '700', color: COLORS.accent }}>
                {Math.min(progreso, 100)}%
              </span>
            </div>
            <div style={{ height: '6px', backgroundColor: COLORS.border, borderRadius: RADIUS.full, overflow: 'hidden' }}>
              <div style={{
                width: `${Math.min(progreso, 100)}%`,
                height: '100%',
                backgroundColor: COLORS.accent,
                borderRadius: RADIUS.full,
                transition: 'width 0.2s ease',
              }} />
            </div>
          </div>
        )}
      </div>

      {/* Tabla de reportes */}
      <div style={{
        backgroundColor: COLORS.bgCard,
        border: `1px solid ${COLORS.border}`,
        borderRadius: RADIUS.lg,
        overflow: 'hidden',
      }}>
        <div style={{
          padding: `${SPACING.md} ${SPACING.lg}`,
          borderBottom: `1px solid ${COLORS.border}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <span style={{ fontSize: FONT.sizeMD, fontWeight: '600', color: COLORS.textPrimary }}>
            Reportes disponibles
          </span>
          <span style={{
            padding: '2px 10px',
            backgroundColor: COLORS.accentAlpha,
            color: COLORS.accent,
            borderRadius: RADIUS.full,
            fontSize: FONT.sizeSM,
            fontWeight: '600',
          }}>
            {reportes.length} archivos
          </span>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ backgroundColor: COLORS.bgApp }}>
              {['Nombre', 'Tipo', 'Engagement', 'Generado', 'Tamaño', 'Acciones'].map((col) => (
                <th key={col} style={{
                  padding: `${SPACING.sm} ${SPACING.md}`,
                  color: COLORS.textMuted,
                  fontSize: FONT.sizeSM,
                  fontWeight: '500',
                  borderBottom: `1px solid ${COLORS.border}`,
                  whiteSpace: 'nowrap',
                }}>
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {reportes.map((r, i) => (
              <tr key={i} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontFamily: FONT.mono, fontSize: FONT.sizeSM, color: COLORS.textMuted }}>
                  {r.nombre}
                </td>
                <td style={{ padding: `${SPACING.md} ${SPACING.md}` }}>
                  {tipoBadge(r.tipo)}
                </td>
                <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM, color: COLORS.textPrimary }}>
                  {r.engagement}
                </td>
                <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM, color: COLORS.textDim, fontFamily: FONT.mono }}>
                  {r.fecha}
                </td>
                <td style={{ padding: `${SPACING.md} ${SPACING.md}`, fontSize: FONT.sizeSM, color: COLORS.textMuted }}>
                  {r.size}
                </td>
                <td style={{ padding: `${SPACING.md} ${SPACING.md}` }}>
                  <div style={{ display: 'flex', gap: SPACING.sm }}>
                    <button style={{
                      padding: '5px 12px',
                      backgroundColor: COLORS.accentAlpha,
                      color: COLORS.accent,
                      border: `1px solid ${COLORS.accent}44`,
                      borderRadius: RADIUS.sm,
                      fontSize: FONT.sizeSM,
                      fontWeight: '600',
                      cursor: 'pointer',
                      fontFamily: FONT.base,
                      whiteSpace: 'nowrap',
                    }}>
                      ↓ Descargar PDF
                    </button>
                    <button style={{
                      padding: '5px 12px',
                      backgroundColor: 'transparent',
                      color: COLORS.textMuted,
                      border: `1px solid ${COLORS.border}`,
                      borderRadius: RADIUS.sm,
                      fontSize: FONT.sizeSM,
                      cursor: 'pointer',
                      fontFamily: FONT.base,
                    }}>
                      👁 Preview
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
