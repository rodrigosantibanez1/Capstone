import { useState, useEffect, useCallback } from 'react'
import { COLORS, FONT, RADIUS, SPACING } from '../theme'

// ─── Config ───────────────────────────────────────────────────────────────────
const API_BASE      = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const ENGAGEMENT_ID = 1

// ─── Helpers ──────────────────────────────────────────────────────────────────
const SVC_COLOR = {
  ftp:COLORS.warning, ssh:COLORS.success, telnet:COLORS.danger, http:COLORS.accent,
  smb:COLORS.warning, exec:COLORS.danger, login:COLORS.danger,  mysql:COLORS.info,
  postgres:COLORS.info, irc:COLORS.textMuted, ajp13:COLORS.textMuted,
}

function PuertoBadge({ p }) {
  const color = SVC_COLOR[p.servicio] || COLORS.textMuted
  return (
    <div style={{ display:'flex', alignItems:'center', gap:SPACING.xs,
      padding:`${SPACING.xs} ${SPACING.sm}`, backgroundColor:color+'15',
      border:`1px solid ${color}33`, borderRadius:RADIUS.sm }}>
      <span style={{ fontFamily:FONT.mono, fontSize:FONT.sizeSM, color, fontWeight:'700' }}>{p.puerto}</span>
      <span style={{ fontSize:FONT.sizeXS, color:COLORS.textMuted }}>/</span>
      <span style={{ fontSize:FONT.sizeSM, color:COLORS.textMuted }}>{p.servicio}</span>
    </div>
  )
}

function HostCard({ ip, dns, whois, puertos }) {
  const [abierto, setAbierto] = useState(true)
  const aRecords = dns?.A || []
  const totalPuertos = puertos?.length || 0

  return (
    <div style={{ backgroundColor:COLORS.bgCard, border:`1px solid ${COLORS.border}`,
      borderRadius:RADIUS.lg, overflow:'hidden' }}>
      <div onClick={() => setAbierto(!abierto)}
        style={{ padding:SPACING.md, cursor:'pointer', display:'flex', alignItems:'center',
          gap:SPACING.md, borderBottom:abierto?`1px solid ${COLORS.border}`:'none' }}>
        <span style={{ fontSize:'18px' }}>🖥</span>
        <div style={{ flex:1 }}>
          <div style={{ display:'flex', alignItems:'center', gap:SPACING.sm }}>
            <span style={{ fontFamily:FONT.mono, fontSize:FONT.sizeLG, fontWeight:'700', color:COLORS.textPrimary }}>
              {ip}
            </span>
            {aRecords.length>0 && aRecords[0]!==ip && (
              <span style={{ fontSize:FONT.sizeSM, color:COLORS.textMuted }}>→ {aRecords[0]}</span>
            )}
            <span style={{ padding:'2px 8px', backgroundColor:COLORS.successAlpha,
              color:COLORS.success, borderRadius:RADIUS.full, fontSize:FONT.sizeXS, fontWeight:'700' }}>
              ✓ En scope
            </span>
          </div>
          <div style={{ fontSize:FONT.sizeXS, color:COLORS.textDim, marginTop:'2px' }}>
            {totalPuertos > 0
              ? <>{totalPuertos} puertos abiertos · <span style={{ color:COLORS.info }}>nmap_scan</span></>
              : <span style={{ color:COLORS.warning }}>Sin scan aún — ejecutar POST /scan</span>
            }
          </div>
        </div>
        <span style={{ color:COLORS.textDim }}>{abierto?'▲':'▼'}</span>
      </div>

      {abierto && puertos && puertos.length > 0 && (
        <div style={{ padding:SPACING.md }}>
          <div style={{ fontSize:FONT.sizeSM, fontWeight:'600', color:COLORS.textMuted, marginBottom:SPACING.sm }}>
            Puertos / Servicios detectados
          </div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:SPACING.xs, marginBottom:SPACING.md }}>
            {puertos.map(p => <PuertoBadge key={p.puerto} p={p} />)}
          </div>
          <div style={{ overflowX:'auto' }}>
            <table style={{ width:'100%', borderCollapse:'collapse', textAlign:'left', fontSize:FONT.sizeSM }}>
              <thead>
                <tr style={{ backgroundColor:COLORS.bgApp }}>
                  {['Puerto','Protocolo','Servicio','Versión'].map(c=>(
                    <th key={c} style={{ padding:`${SPACING.xs} ${SPACING.sm}`, color:COLORS.textDim,
                      fontWeight:'500', borderBottom:`1px solid ${COLORS.border}` }}>{c}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {puertos.map(p=>(
                  <tr key={p.puerto} style={{ borderBottom:`1px solid ${COLORS.border}` }}>
                    <td style={{ padding:`${SPACING.xs} ${SPACING.sm}`, fontFamily:FONT.mono,
                      fontWeight:'700', color:SVC_COLOR[p.servicio]||COLORS.textMuted }}>{p.puerto}</td>
                    <td style={{ padding:`${SPACING.xs} ${SPACING.sm}`, color:COLORS.textDim }}>{p.proto}</td>
                    <td style={{ padding:`${SPACING.xs} ${SPACING.sm}`, color:COLORS.textMuted }}>{p.servicio}</td>
                    <td style={{ padding:`${SPACING.xs} ${SPACING.sm}`, fontFamily:FONT.mono,
                      fontSize:FONT.sizeXS, color:COLORS.textMuted }}>{p.version||'—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Vista principal ──────────────────────────────────────────────────────────
export default function SurfaceMapView({ engagementId = ENGAGEMENT_ID }) {
  const [data,    setData]    = useState(null)
  const [loading, setLoading] = useState(true)

  const cargar = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch(`${API_BASE}/engagements/${engagementId}/surface-map`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const json = await res.json()
      setData(json)
    } catch {
      setData(null)
    } finally {
      setLoading(false)
    }
  }, [engagementId])

  useEffect(() => { cargar() }, [cargar])

  if (loading) {
    return (
      <div style={{ padding:'60px', textAlign:'center', color:COLORS.textDim, fontFamily:FONT.base }}>
        Cargando surface map…
      </div>
    )
  }

  if (!data) {
    return (
      <div style={{ padding:'60px', textAlign:'center', color:COLORS.textDim, fontFamily:FONT.base }}>
        Sin surface map — ejecuta POST /recon primero.
      </div>
    )
  }

  const hosts   = data.hosts_discovered || []
  const emails  = data.emails_osint     || []
  const newVs   = data.new_vs_scope     || []
  const dnsMap  = data.dns_records      || {}
  const whoisMap= data.whois_data       || {}

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:SPACING.xl, fontFamily:FONT.base }}>

      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', gap:SPACING.md }}>
        <div>
          <h1 style={{ margin:0, fontSize:FONT.size2XL, color:COLORS.textPrimary }}>Surface Map</h1>
          <p style={{ margin:'4px 0 0', fontSize:FONT.sizeMD, color:COLORS.textMuted }}>
            Mapa de superficie consolidado post-Recon · Engagement #{engagementId}
          </p>
        </div>
        <button onClick={cargar} style={{ marginLeft:'auto', padding:'6px 14px',
          background:'transparent', border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.md,
          color:COLORS.textMuted, cursor:'pointer', fontSize:FONT.sizeSM, fontFamily:FONT.base }}>
          ↻ Actualizar
        </button>
      </div>

      {/* Stats */}
      <div style={{ display:'flex', gap:SPACING.md, flexWrap:'wrap' }}>
        {[
          { label:'Hosts descubiertos',  value:hosts.length,       color:COLORS.textPrimary },
          { label:'Puertos abiertos',    value:'—',                color:COLORS.warning     },
          { label:'Emails OSINT',        value:emails.length,      color:COLORS.textMuted   },
          { label:'Nuevos vs scope',     value:newVs.length,       color:newVs.length>0?COLORS.danger:COLORS.info },
        ].map(s=>(
          <div key={s.label} style={{ flex:1, minWidth:'120px', backgroundColor:COLORS.bgCard,
            border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.md, padding:SPACING.md }}>
            <div style={{ fontSize:FONT.sizeXS, color:COLORS.textDim, marginBottom:'4px' }}>{s.label}</div>
            <div style={{ fontSize:FONT.size3XL, fontWeight:'800', color:s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Scope diff banner */}
      {newVs.length === 0 ? (
        <div style={{ backgroundColor:COLORS.successAlpha, border:`1px solid ${COLORS.success}44`,
          borderRadius:RADIUS.md, padding:SPACING.md, display:'flex', alignItems:'center', gap:SPACING.md }}>
          <span style={{ fontSize:'18px' }}>✓</span>
          <div>
            <div style={{ fontSize:FONT.sizeSM, fontWeight:'600', color:COLORS.success }}>
              Sin hosts fuera de scope
            </div>
            <div style={{ fontSize:FONT.sizeSM, color:COLORS.textMuted }}>
              Todos los hosts descubiertos ({hosts.length}) están dentro del scope autorizado.
            </div>
          </div>
        </div>
      ) : (
        <div style={{ backgroundColor:COLORS.dangerAlpha, border:`1px solid ${COLORS.danger}44`,
          borderRadius:RADIUS.md, padding:SPACING.md }}>
          <div style={{ fontSize:FONT.sizeSM, fontWeight:'600', color:COLORS.danger, marginBottom:SPACING.xs }}>
            ⚠ {newVs.length} host(s) descubiertos fuera del scope original
          </div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:SPACING.xs }}>
            {newVs.map(h=>(
              <span key={h} style={{ fontFamily:FONT.mono, fontSize:FONT.sizeSM,
                color:COLORS.danger, backgroundColor:COLORS.dangerAlpha,
                padding:'2px 8px', borderRadius:RADIUS.sm }}>{h}</span>
            ))}
          </div>
        </div>
      )}

      {/* Hosts */}
      <div>
        <div style={{ fontSize:FONT.sizeMD, fontWeight:'600', color:COLORS.textPrimary, marginBottom:SPACING.md }}>
          Hosts descubiertos ({hosts.length})
        </div>
        {hosts.length === 0 ? (
          <div style={{ backgroundColor:COLORS.bgCard, border:`1px solid ${COLORS.border}`,
            borderRadius:RADIUS.lg, padding:SPACING.xl, textAlign:'center', color:COLORS.textDim }}>
            Sin hosts en el surface map. Ejecutar POST /recon para poblar.
          </div>
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:SPACING.md }}>
            {hosts.map(ip=>(
              <HostCard key={ip}
                ip={ip}
                dns={dnsMap[ip]}
                whois={whoisMap[ip]}
                puertos={[]}
              />
            ))}
          </div>
        )}
      </div>

      {/* DNS + WHOIS + Emails */}
      <div style={{ display:'flex', gap:SPACING.md, flexWrap:'wrap' }}>

        {/* DNS */}
        <div style={{ flex:1, minWidth:'280px', backgroundColor:COLORS.bgCard,
          border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.lg, padding:SPACING.lg }}>
          <div style={{ fontSize:FONT.sizeMD, fontWeight:'600', color:COLORS.textPrimary, marginBottom:SPACING.md }}>
            Registros DNS
          </div>
          {Object.keys(dnsMap).length === 0 ? (
            <div style={{ color:COLORS.textDim, fontSize:FONT.sizeSM }}>Sin datos DNS.</div>
          ) : (
            <table style={{ width:'100%', borderCollapse:'collapse', fontSize:FONT.sizeSM }}>
              <thead>
                <tr>{['Target','Tipo','Valores'].map(c=>(
                  <th key={c} style={{ padding:`${SPACING.xs} ${SPACING.sm}`, color:COLORS.textDim,
                    fontWeight:'500', textAlign:'left', borderBottom:`1px solid ${COLORS.border}` }}>{c}</th>
                ))}</tr>
              </thead>
              <tbody>
                {Object.entries(dnsMap).flatMap(([target, types]) =>
                  Object.entries(types).filter(([,vals])=>vals.length>0).map(([rtype, vals])=>(
                    <tr key={`${target}-${rtype}`} style={{ borderBottom:`1px solid ${COLORS.border}` }}>
                      <td style={{ padding:`${SPACING.xs} ${SPACING.sm}`, fontFamily:FONT.mono,
                        fontSize:FONT.sizeXS, color:COLORS.textDim }}>{target}</td>
                      <td style={{ padding:`${SPACING.xs} ${SPACING.sm}`, fontFamily:FONT.mono,
                        color:COLORS.accent, fontWeight:'700' }}>{rtype}</td>
                      <td style={{ padding:`${SPACING.xs} ${SPACING.sm}`, fontFamily:FONT.mono,
                        fontSize:FONT.sizeXS, color:COLORS.textMuted }}>{vals.join(', ')}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}
        </div>

        {/* WHOIS */}
        <div style={{ flex:1, minWidth:'280px', backgroundColor:COLORS.bgCard,
          border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.lg, padding:SPACING.lg }}>
          <div style={{ fontSize:FONT.sizeMD, fontWeight:'600', color:COLORS.textPrimary, marginBottom:SPACING.md }}>
            WHOIS
          </div>
          {Object.keys(whoisMap).length === 0 ? (
            <div style={{ color:COLORS.textDim, fontSize:FONT.sizeSM }}>Sin datos WHOIS.</div>
          ) : (
            Object.entries(whoisMap).map(([target, w])=>(
              <div key={target}>
                <div style={{ fontSize:FONT.sizeXS, color:COLORS.info,
                  fontFamily:FONT.mono, marginBottom:SPACING.xs }}>{target}</div>
                {Object.entries(w).map(([k,v])=>(
                  <div key={k} style={{ display:'flex', justifyContent:'space-between',
                    paddingBottom:SPACING.xs, borderBottom:`1px solid ${COLORS.border}` }}>
                    <span style={{ fontSize:FONT.sizeSM, color:COLORS.textDim, textTransform:'capitalize' }}>{k}</span>
                    <span style={{ fontSize:FONT.sizeSM, color:COLORS.textMuted,
                      textAlign:'right', maxWidth:'200px' }}>
                      {Array.isArray(v) ? v.join(', ')||'—' : v||'—'}
                    </span>
                  </div>
                ))}
              </div>
            ))
          )}
        </div>

        {/* Emails OSINT */}
        <div style={{ flex:1, minWidth:'240px', backgroundColor:COLORS.bgCard,
          border:`1px solid ${COLORS.border}`, borderRadius:RADIUS.lg, padding:SPACING.lg }}>
          <div style={{ fontSize:FONT.sizeMD, fontWeight:'600', color:COLORS.textPrimary, marginBottom:SPACING.md }}>
            Emails OSINT (theHarvester)
          </div>
          {emails.length === 0 ? (
            <div style={{ color:COLORS.textDim, fontSize:FONT.sizeSM, fontStyle:'italic' }}>
              Sin resultados — red de laboratorio aislada, sin presencia en fuentes OSINT públicas.
            </div>
          ) : (
            emails.map(e=>(
              <div key={e} style={{ fontFamily:FONT.mono, fontSize:FONT.sizeSM,
                color:COLORS.info, marginBottom:'4px' }}>{e}</div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
