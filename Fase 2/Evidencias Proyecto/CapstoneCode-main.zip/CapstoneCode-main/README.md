# ETH-MAS — Sistema multi-agente de pentesting ético con control humano

Prototipo académico (Capstone). Un **orquestador conversacional** coordina cuatro
agentes —Reconocimiento, Escaneo, Análisis y Reporte— sobre herramientas reales
de seguridad, con tres controles en código: **alcance autorizado (scope)**,
**aprobación humana (HITL)** y **mapeo MITRE ATT&CK**.

---

## ¿Vienes a revisar el proyecto? Empieza aquí

1. **Guía de revisión + arquitectura:** abre
   [`docs/architecture.html`](docs/architecture.html) en un navegador. La pestaña
   **★ Guía del docente** explica qué es el sistema, **dónde está cada cosa**
   (mapa del repositorio) y **cómo comprobar que funciona** de verdad.
2. **Levantar el sistema:** sigue [«Cómo levantarlo»](#cómo-levantarlo-en-una-máquina-nueva)
   más abajo (5 comandos, todo en Docker).
3. **Verificar sin correr un pipeline entero:** restaura el engagement de demo ya
   corrido y comprueba por consola que **frontend = API = base de datos**:
   ```bash
   bash scripts/restore_demo_seed.sh      # carga demo-seed/ en Postgres + Mongo
   ```
   > ⚠️ Reemplaza el contenido de las BD locales (pensado para un entorno de demo
   > limpio). Requiere el stack arriba.
   Luego, en PowerShell, `scripts/list_engagements.ps1` y
   `scripts/verify_eth_mas.ps1 -Id <id>`. Detalle en
   [`scripts/README_verificacion.md`](scripts/README_verificacion.md).
4. **Mapa del código (opcional):** grafo de dependencias en
   [`graphify-out/RESUMEN_EJECUTIVO.md`](graphify-out/RESUMEN_EJECUTIVO.md)
   (o el interactivo `graphify-out/graph.html`).

---

## Cómo levantarlo en una máquina nueva

Estos pasos asumen una máquina limpia. No hace falta instalar Python ni Node:
todo corre dentro de contenedores.

### 1. Requisitos previos

- **Docker Desktop** (incluye Docker Compose). Verificar con:
  ```bash
  docker --version
  docker compose version
  ```
- Una **clave de API de Anthropic** (para que los agentes y el orquestador
  piensen). Sin ella, el sistema levanta igual, pero el orquestador no responde.

### 2. Clonar el repositorio

```bash
git clone https://github.com/rodrigosantibanez1/CapstoneCode.git
cd CapstoneCode
```

### 3. Crear el archivo de configuración

Copiar la plantilla y completar la clave:

```bash
cp .env.example .env
```

Luego abrir `.env` y poner tu clave real en `ANTHROPIC_API_KEY`. El resto de los
valores traen defaults que ya funcionan (la clave interna que conecta la interfaz
con el servidor coincide por defecto, así que no hay que tocar nada más).

> Para la defensa/demo, dentro de `.env` hay un bloque comentado ("Tiering
> RECOMENDADO") que activa modelos más potentes en el orquestador y el análisis.
> Descomentarlo si quieres el razonamiento completo.

### 4. Construir y levantar el sistema

```bash
docker compose up -d --build
```

Esto levanta cuatro contenedores: la base de datos relacional, la base de datos
documental, el servidor (backend) y la interfaz (frontend). Las migraciones de
la base de datos se aplican **solas** al arrancar el servidor; no hay ningún
paso manual.

### 5. Abrir la aplicación

- **Interfaz:** http://localhost
- **Servidor (API):** http://localhost:8000
- **Estado de salud:** http://localhost:8000/health/services
  (debería responder `up` cuando todo está arriba)

### 6. (Opcional) Levantar el laboratorio de práctica

Máquinas deliberadamente vulnerables (Metasploitable2 + DVWA) en una **red
aislada**, para tener objetivos reales que auditar:

```bash
docker compose --profile lab up -d
```

Quedan accesibles **solo** desde el servidor, nunca desde el exterior
(`10.42.0.10` y `10.42.0.20`). Detalles y advertencias de seguridad en
[`docs/lab-setup.md`](docs/lab-setup.md).

> ⚠️ El laboratorio contiene software vulnerable a propósito. No exponerlo a
> ninguna red pública.

---

## Comandos útiles

```bash
docker compose ps               # ver el estado de los contenedores
docker compose logs -f backend  # ver los registros del servidor en vivo
docker compose down             # apagar todo (los datos se conservan)
docker compose --profile lab down   # apagar el laboratorio
```

Después de cambiar código de la interfaz, reconstruir su imagen:

```bash
docker compose up -d --build frontend
```

---

## Cómo usarlo (flujo típico)

1. En **Inicio**, crear un engagement nuevo (nombre + objetivos + reglas) o elegir
   uno existente.
2. El **orquestador** aparece en la misma pantalla de Inicio: escríbele en
   lenguaje natural (por ejemplo, "audita el host 10.42.0.10").
3. En modo **Plan** propone qué haría sin ejecutar nada; en modo **Ejecutar**
   delega de verdad en los agentes.
4. Cuando un agente quiere una acción de riesgo, queda **en pausa esperando tu
   aprobación** en la consola de Control HITL.
5. Al terminar, revisa hallazgos, análisis (CVE + MITRE ATT&CK) y descarga los
   reportes en PDF.

Guion paso a paso para una demostración:
[`docs/runsheet-demo-en-vivo-v0.4.md`](docs/runsheet-demo-en-vivo-v0.4.md).

---

## Estructura del proyecto

| Carpeta | Qué contiene |
|---------|--------------|
| `eth-mas-backend/`  | Servidor (FastAPI), agentes, herramientas y migraciones |
| `eth-mas-frontend/` | Interfaz (React + Vite) |
| `docs/`             | Documentación, decisiones de arquitectura, guiones y `architecture.html` (guía de revisión) |
| `scripts/`          | Verificación por consola (front = API = base) y restaurar/volcar el seed de demo |
| `demo-seed/`        | Volcado de un engagement ya corrido (Postgres + Mongo) para revisar sin correr el pipeline |
| `graphify-out/`     | Grafo de dependencias del código (mapa navegable + reporte + resumen ejecutivo) |
| `docker-compose.yml`| Definición de todos los contenedores |
| `.env.example`      | Plantilla de configuración (copiar a `.env`) |

---

## Solución de problemas

- **El puerto 5432 no se puede abrir (Windows):** definir `POSTGRES_HOST_PORT`
  con otro valor en `.env` (por ejemplo `5433`). El servidor no depende del
  puerto del host; es solo comodidad.
- **La interfaz no conecta con el servidor:** confirmar que el servidor
  responde en http://localhost:8000/health/services.
- **El orquestador no contesta:** revisar que `ANTHROPIC_API_KEY` en `.env` es
  válida y reiniciar el servidor con `docker compose up -d backend`.
