--
-- PostgreSQL database dump
--

\restrict TJ2q8Mk3dGQE0YvdDck9Vz2amRWH9HHbVCUD2gLaQxbAMI2jEnShMPnjCHmF00E

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.scope_targets DROP CONSTRAINT IF EXISTS scope_targets_engagement_id_fkey;
ALTER TABLE IF EXISTS ONLY public.hitl_actions DROP CONSTRAINT IF EXISTS hitl_actions_engagement_id_fkey;
DROP INDEX IF EXISTS public.uq_hitl_pending_dedup;
DROP INDEX IF EXISTS public.ix_scope_targets_id;
DROP INDEX IF EXISTS public.ix_hitl_actions_id;
DROP INDEX IF EXISTS public.ix_engagements_id;
ALTER TABLE IF EXISTS ONLY public.scope_targets DROP CONSTRAINT IF EXISTS scope_targets_pkey;
ALTER TABLE IF EXISTS ONLY public.hitl_actions DROP CONSTRAINT IF EXISTS hitl_actions_pkey;
ALTER TABLE IF EXISTS ONLY public.engagements DROP CONSTRAINT IF EXISTS engagements_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.scope_targets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.hitl_actions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.engagements ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.scope_targets_id_seq;
DROP TABLE IF EXISTS public.scope_targets;
DROP SEQUENCE IF EXISTS public.hitl_actions_id_seq;
DROP TABLE IF EXISTS public.hitl_actions;
DROP SEQUENCE IF EXISTS public.engagements_id_seq;
DROP TABLE IF EXISTS public.engagements;
DROP TABLE IF EXISTS public.alembic_version;
DROP TYPE IF EXISTS public.targettype;
DROP TYPE IF EXISTS public.engagementstatus;
--
-- Name: engagementstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.engagementstatus AS ENUM (
    'PENDING',
    'RUNNING',
    'PAUSED',
    'COMPLETED',
    'ABORTED'
);


ALTER TYPE public.engagementstatus OWNER TO postgres;

--
-- Name: targettype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.targettype AS ENUM (
    'IP',
    'CIDR',
    'DOMAIN'
);


ALTER TYPE public.targettype OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: engagements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.engagements (
    id integer NOT NULL,
    name character varying NOT NULL,
    description text,
    client_name character varying,
    status public.engagementstatus NOT NULL,
    roe json,
    att_tactics json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.engagements OWNER TO postgres;

--
-- Name: engagements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.engagements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.engagements_id_seq OWNER TO postgres;

--
-- Name: engagements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.engagements_id_seq OWNED BY public.engagements.id;


--
-- Name: hitl_actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hitl_actions (
    id integer NOT NULL,
    engagement_id integer NOT NULL,
    agent character varying NOT NULL,
    tool character varying NOT NULL,
    risk_level character varying NOT NULL,
    params json,
    decision character varying,
    operator character varying,
    notes text,
    requested_at timestamp without time zone,
    decided_at timestamp without time zone,
    CONSTRAINT ck_hitl_decision_valid CHECK (((decision IS NULL) OR ((decision)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('APPROVED'::character varying)::text, ('REJECTED'::character varying)::text, ('AUTO-APPROVED'::character varying)::text, ('EXPIRED'::character varying)::text])))),
    CONSTRAINT ck_hitl_risk_level_valid CHECK (((risk_level)::text = ANY (ARRAY[('LOW'::character varying)::text, ('MEDIUM'::character varying)::text, ('HIGH'::character varying)::text, ('CRITICAL'::character varying)::text])))
);


ALTER TABLE public.hitl_actions OWNER TO postgres;

--
-- Name: hitl_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hitl_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hitl_actions_id_seq OWNER TO postgres;

--
-- Name: hitl_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hitl_actions_id_seq OWNED BY public.hitl_actions.id;


--
-- Name: scope_targets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scope_targets (
    id integer NOT NULL,
    engagement_id integer NOT NULL,
    target_value character varying NOT NULL,
    target_type public.targettype NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.scope_targets OWNER TO postgres;

--
-- Name: scope_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scope_targets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scope_targets_id_seq OWNER TO postgres;

--
-- Name: scope_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scope_targets_id_seq OWNED BY public.scope_targets.id;


--
-- Name: engagements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engagements ALTER COLUMN id SET DEFAULT nextval('public.engagements_id_seq'::regclass);


--
-- Name: hitl_actions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hitl_actions ALTER COLUMN id SET DEFAULT nextval('public.hitl_actions_id_seq'::regclass);


--
-- Name: scope_targets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scope_targets ALTER COLUMN id SET DEFAULT nextval('public.scope_targets_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
e4f7b2a9c5d6
\.


--
-- Data for Name: engagements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.engagements (id, name, description, client_name, status, roe, att_tactics, created_at, updated_at) FROM stdin;
1	primera prueba	ads	lab1	PENDING	{"time_windows": [{"start": "09:00", "end": "18:00", "days": ["mon", "tue", "wed", "thu", "fri"]}], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "MEDIUM", "notification_email": null}	["TA0043", "TA0001", "TA0007", "TA0004", "TA0009", "TA0011", "TA0005", "TA0006", "TA0010", "TA0042", "TA0002", "TA0040", "TA0008", "TA0003"]	2026-05-15 20:46:34.391581	2026-05-15 20:46:34.391603
2	scanme.nmap.org	\N	\N	PENDING	{"time_windows": [{"start": "09:00", "end": "18:00", "days": ["mon", "tue", "wed", "thu", "fri"]}], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "MEDIUM", "notification_email": null}	["TA0043", "TA0001", "TA0007"]	2026-05-15 20:56:02.042667	2026-05-15 20:56:02.042716
3	Test	\N	\N	PENDING	null	null	2026-05-15 20:58:50.428716	2026-05-15 20:58:50.428721
21	BlockD intensity STEALTH	\N	DUOC UC	RUNNING	{"time_windows": [], "scan_intensity": "STEALTH", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "LOW", "notification_email": null}	null	2026-06-02 22:21:21.941817	2026-06-02 22:21:42.912028
6	Lab Metasploitable 2	Prueba de escaneo en VM local 2	Laboratorio local	PENDING	{"time_windows": [], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "LOW", "notification_email": null}	["TA0043", "TA0001", "TA0007"]	2026-05-16 00:04:12.54657	2026-05-16 00:04:12.546576
4	Test scanme.nmap.org	\N	nmap.org (publico autorizado)	ABORTED	null	null	2026-05-15 20:59:50.440564	2026-05-18 06:00:10.680182
5	Test red Docker interna	\N	Lab Docker	ABORTED	null	null	2026-05-15 20:59:50.464491	2026-05-18 06:00:14.060174
22	BlockD intensity AGGRESSIVE	\N	DUOC UC	RUNNING	{"time_windows": [], "scan_intensity": "AGGRESSIVE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "LOW", "notification_email": null}	null	2026-06-02 22:21:22.471174	2026-06-02 22:21:43.016699
16	409 conflict test	Test scan blocked by pending HITL	ETH-MAS QA	ABORTED	{"time_windows": [], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 10, "auto_approve_hitl_below": "MEDIUM", "notification_email": null}	["TA0043"]	2026-05-26 02:42:24.408542	2026-05-26 02:45:33.887576
10	E2E Clean Multi-Tool	Validar nmap+nuclei+nikto+gobuster + mapeo findings	\N	ABORTED	{"time_windows": [], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "LOW", "notification_email": null}	null	2026-05-19 00:02:57.902488	2026-05-19 00:06:45.267104
9	E2E Test Multi-Tool	Validar nmap+nuclei+nikto+gobuster + mapeo correcto findings	\N	ABORTED	{"time_windows": [], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "LOW", "notification_email": null}	["TA0007"]	2026-05-18 23:44:03.766247	2026-05-19 00:06:46.840079
8	E2E Test Simple	Prueba e2e flujo minimo Sprint 2	Equipo ETH-MAS	ABORTED	{"time_windows": [], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "LOW", "notification_email": null}	["TA0007"]	2026-05-18 22:57:06.114245	2026-05-19 00:06:48.313884
7	pc	1	1	ABORTED	{"time_windows": [{"start": "09:00", "end": "18:00", "days": []}], "scan_intensity": "AGGRESSIVE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "MEDIUM", "notification_email": null}	["TA0043", "TA0042", "TA0001", "TA0002", "TA0003", "TA0004", "TA0005", "TA0006", "TA0007", "TA0008", "TA0009", "TA0011", "TA0010", "TA0040"]	2026-05-18 19:44:44.101637	2026-05-19 00:06:49.759695
15	Anti-zombi expire test	Test expire-pending endpoint	ETH-MAS QA	ABORTED	{"time_windows": [], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 10, "auto_approve_hitl_below": "MEDIUM", "notification_email": null}	["TA0043"]	2026-05-26 02:40:38.958707	2026-05-26 02:45:35.289905
11	Audit Test 2026-05-20	Engagement de validacion post-auditoria	QA Equipo	COMPLETED	{"time_windows": [], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "LOW", "notification_email": null}	["TA0043", "TA0001", "TA0007"]	2026-05-20 21:02:28.275412	2026-05-20 21:02:59.721546
12	HITL Test	\N	\N	PENDING	null	null	2026-05-20 21:03:21.509199	2026-05-20 21:03:21.509215
13	Post-restart D-1/D-2/D-3 test	\N	\N	PENDING	null	null	2026-05-20 21:45:52.119942	2026-05-20 21:45:52.119953
14	E2E test 2026-05-25	End-to-end smoke test post Fase 1 anti-zombi	ETH-MAS QA	ABORTED	{"time_windows": [], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 20, "auto_approve_hitl_below": "MEDIUM", "notification_email": null}	["TA0043", "TA0007"]	2026-05-26 02:29:23.888445	2026-05-26 02:45:36.810883
17	Lab Metasploitable+DVWA E2E	\N	DUOC UC	RUNNING	null	null	2026-05-26 22:26:17.235218	2026-05-26 22:26:39.871591
18	Lab E2E IPs (workaround scope CIDR)	\N	DUOC UC	RUNNING	null	null	2026-05-26 22:28:36.381489	2026-05-26 22:28:44.580362
19	Lab E2E v2 post lab-fixes	\N	DUOC UC	RUNNING	null	null	2026-05-27 22:17:08.780815	2026-05-27 22:17:27.28096
26	S0 — corrida 4/4 .10 (validación B1-B8)	Sesión 0: pipeline completo Recon→Scan→Analysis→Reporter sobre Metasploitable2	ETH-MAS Lab	COMPLETED	{"time_windows": [], "scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "LOW", "notification_email": null}	["TA0007", "TA0001"]	2026-06-18 01:44:44.143116	2026-06-18 01:58:27.283644
23	Sesion C lifecycle test	\N	QA	COMPLETED	null	null	2026-06-10 00:52:10.314132	2026-06-10 00:53:00.408481
24	MyPC	p1	owner	COMPLETED	{"time_windows": [{"start": "00:00", "end": "12:00", "days": ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]}], "scan_intensity": "AGGRESSIVE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "MEDIUM", "notification_email": "devrodrigoss@gmail.com"}	["TA0043", "TA0042", "TA0001", "TA0002", "TA0003", "TA0004", "TA0005", "TA0006", "TA0007", "TA0008", "TA0009", "TA0011", "TA0010", "TA0040"]	2026-06-10 04:12:16.706016	2026-06-10 05:12:05.672328
27	S5 — HU-20 DVWA 10.42.0.20 (E2E 4/4)	Sesión 5: pipeline completo Recon→Scan→Analysis→Reporter sobre DVWA	ETH-MAS Lab	COMPLETED	{"scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "LOW", "notification_email": null}	["TA0001", "TA0007"]	2026-06-18 03:50:06.180883	2026-06-18 04:01:18.52064
25	B8 verify orchestrator	\N	QA	RUNNING	null	null	2026-06-16 02:14:14.512635	2026-06-16 02:14:15.890182
28	E2E Orquestador Demo	Prueba end-to-end del orquestador sobre el lab	Capstone	RUNNING	null	["Reconnaissance", "Initial Access", "Discovery"]	2026-06-23 01:51:51.030031	2026-06-23 01:52:35.994265
29	Probe scope grounding	\N	\N	PENDING	null	null	2026-06-23 02:28:32.826153	2026-06-23 02:28:32.826165
30	smoke-probe	\N	\N	ABORTED	null	null	2026-06-26 15:24:25.438983	2026-06-26 15:24:59.315878
20	Lab E2E v2 IPs explicitas	\N	DUOC UC	COMPLETED	null	null	2026-05-27 22:23:01.621727	2026-06-17 02:01:09.668676
31	smoke-cableado	smoke_engagement.sh	\N	ABORTED	null	null	2026-06-26 15:25:53.194593	2026-06-26 15:25:53.781586
32	x	\N	\N	PENDING	null	null	2026-06-26 15:41:50.097849	2026-06-26 15:41:50.0979
33	x	\N	\N	ABORTED	null	null	2026-06-26 15:41:50.363802	2026-06-26 15:41:50.627447
34	Smoke test — Lab	\N	\N	ABORTED	null	null	2026-06-26 15:42:33.936796	2026-06-26 15:42:33.956766
35	Smoke test — Lab	\N	\N	PENDING	null	null	2026-06-26 15:42:34.09288	2026-06-26 15:42:34.092887
36	Smoke test — Lab	\N	DUOC UC (smoke)	PENDING	null	null	2026-06-26 15:43:56.24881	2026-06-26 15:43:56.248816
37	Defensa Capstone - Metasploitable2 (orquestador)	\N	\N	COMPLETED	{"scan_intensity": "MODERATE", "excluded_paths": [], "max_requests_per_second": 50, "auto_approve_hitl_below": "MEDIUM", "notification_email": null}	["TA0043", "TA0001", "TA0002", "TA0007", "TA0006"]	2026-06-26 15:49:00.102887	2026-06-26 16:41:50.399291
\.


--
-- Data for Name: hitl_actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hitl_actions (id, engagement_id, agent, tool, risk_level, params, decision, operator, notes, requested_at, decided_at) FROM stdin;
1	4	ReconAgent	dns_enum	LOW	{"target": "scanme.nmap.org", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-15 21:04:18.402754	2026-05-15 21:04:18.402756
2	4	ReconAgent	whois_lookup	LOW	{"target": "scanme.nmap.org"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-15 21:04:20.751517	2026-05-15 21:04:20.751519
3	4	ReconAgent	theharvester_run	LOW	{"target": "scanme.nmap.org", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-15 21:04:24.274973	2026-05-15 21:04:24.274976
4	4	ReconAgent	dns_enum	LOW	{"target": "45.33.32.156", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-15 21:04:25.769715	2026-05-15 21:04:25.769717
5	5	ReconAgent	dns_enum	LOW	{"target": "172.19.0.2", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-15 21:04:32.5497	2026-05-15 21:04:32.549702
6	4	ReconAgent	dns_enum	LOW	{"target": "scanme.nmap.org", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:42:30.15614	2026-05-16 00:42:30.156144
7	4	ReconAgent	whois_lookup	LOW	{"target": "scanme.nmap.org"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:42:31.224255	2026-05-16 00:42:31.224256
8	4	ReconAgent	theharvester_run	LOW	{"target": "scanme.nmap.org", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:42:32.867807	2026-05-16 00:42:32.867809
9	4	ReconAgent	dns_enum	LOW	{"target": "45.33.32.156", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:42:32.892914	2026-05-16 00:42:32.892917
10	4	ReconAgent	whois_lookup	LOW	{"target": "45.33.32.156"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:42:33.074992	2026-05-16 00:42:33.074995
11	4	ReconAgent	theharvester_run	LOW	{"target": "45.33.32.156", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:42:33.496529	2026-05-16 00:42:33.496531
12	4	ReconAgent	dns_enum	LOW	{"target": "scanme.nmap.org", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:58:09.887783	2026-05-16 00:58:09.887786
13	4	ReconAgent	whois_lookup	LOW	{"target": "scanme.nmap.org"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:58:10.838862	2026-05-16 00:58:10.838865
14	4	ReconAgent	theharvester_run	LOW	{"target": "scanme.nmap.org", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:58:12.484465	2026-05-16 00:58:12.484467
15	4	ReconAgent	dns_enum	LOW	{"target": "45.33.32.156", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:58:12.497824	2026-05-16 00:58:12.497825
16	4	ReconAgent	whois_lookup	LOW	{"target": "45.33.32.156"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:58:12.660447	2026-05-16 00:58:12.660449
17	4	ReconAgent	theharvester_run	LOW	{"target": "45.33.32.156", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-16 00:58:13.04891	2026-05-16 00:58:13.048912
18	8	ReconAgent	dns_enum	LOW	{"target": "scanme.nmap.org", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 22:57:33.580814	2026-05-18 22:57:33.580816
19	8	ReconAgent	whois_lookup	LOW	{"target": "scanme.nmap.org"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 22:57:34.457511	2026-05-18 22:57:34.457514
20	8	ReconAgent	theharvester_run	LOW	{"target": "scanme.nmap.org", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 22:57:36.564514	2026-05-18 22:57:36.564516
21	8	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	Admin User	\N	2026-05-18 22:58:14.872126	2026-05-18 23:22:13.921064
22	8	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	e2e-tester	e2e auto-approval	2026-05-18 23:24:46.656985	2026-05-18 23:25:14.414639
23	7	ReconAgent	dns_enum	LOW	{"target": "192.168.56.1", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 23:30:10.190334	2026-05-18 23:30:10.190336
24	7	ReconAgent	whois_lookup	LOW	{"target": "192.168.56.1"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 23:30:11.081316	2026-05-18 23:30:11.081319
25	7	ReconAgent	theharvester_run	LOW	{"target": "192.168.56.1", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 23:30:11.561907	2026-05-18 23:30:11.561908
26	7	ScanAgent	nmap_scan	MEDIUM	{"target": "192.168.56.1", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	Admin User	\N	2026-05-18 23:30:18.416252	2026-05-18 23:30:42.044125
27	9	ReconAgent	dns_enum	LOW	{"target": "scanme.nmap.org", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 23:44:20.746765	2026-05-18 23:44:20.746768
28	9	ReconAgent	whois_lookup	LOW	{"target": "scanme.nmap.org"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 23:44:21.394632	2026-05-18 23:44:21.394634
29	9	ReconAgent	theharvester_run	LOW	{"target": "scanme.nmap.org", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 23:44:23.25153	2026-05-18 23:44:23.251533
30	9	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	e2e-tester	e2e	2026-05-18 23:44:38.726143	2026-05-18 23:44:51.171363
31	9	ReconAgent	dns_enum	LOW	{"target": "scanme.nmap.org", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 23:48:10.537155	2026-05-18 23:48:10.537159
32	9	ReconAgent	whois_lookup	LOW	{"target": "scanme.nmap.org"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 23:48:11.333628	2026-05-18 23:48:11.333632
33	9	ReconAgent	theharvester_run	LOW	{"target": "scanme.nmap.org", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-18 23:48:13.668824	2026-05-18 23:48:13.668828
34	9	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	e2e-tester	e2e	2026-05-18 23:48:21.114143	2026-05-18 23:48:24.946671
35	9	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "80,443,8080,8443,22,21,25,3306,5432,27017", "timing": 3, "scripts": null}	APPROVED	e2e-tester	e2e	2026-05-18 23:49:56.531429	2026-05-18 23:49:57.503496
37	10	ReconAgent	dns_enum	LOW	{"target": "scanme.nmap.org", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-19 00:03:48.995456	2026-05-19 00:03:48.995457
38	10	ReconAgent	whois_lookup	LOW	{"target": "scanme.nmap.org"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-19 00:03:49.919052	2026-05-19 00:03:49.919054
39	10	ReconAgent	theharvester_run	LOW	{"target": "scanme.nmap.org", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-19 00:03:52.705239	2026-05-19 00:03:52.705242
36	9	ScanAgent	nuclei_run	MEDIUM	{"target": "scanme.nmap.org", "severity": "medium", "templates": null}	APPROVED	Admin User	\N	2026-05-18 23:50:27.164158	2026-05-19 00:05:35.573042
40	10	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	Admin User	\N	2026-05-19 00:05:13.553115	2026-05-19 00:05:39.53086
42	10	ScanAgent	nuclei_run	MEDIUM	{"target": "scanme.nmap.org", "severity": "medium", "templates": null}	REJECTED	Admin User	\N	2026-05-19 00:15:47.069542	2026-05-19 00:19:53.394515
41	10	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "21-22,25,53,80,110,143,443,445,3306,3389", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-19 00:10:43.825259	2026-05-19 00:19:54.140601
43	10	ScanAgent	nikto_scan	MEDIUM	{"target": "scanme.nmap.org", "port": 80}	REJECTED	Admin User	\N	2026-05-19 00:19:53.488593	2026-05-19 00:20:02.450864
44	10	ScanAgent	gobuster_run	MEDIUM	{"target": "scanme.nmap.org", "mode": "dns", "wordlist": "/app/diccionario.txt"}	APPROVED	Admin User	\N	2026-05-19 00:20:05.364443	2026-05-19 00:20:17.833277
47	12	ScanAgent	nmap_scan	MEDIUM	\N	APPROVED	qa@eth-mas.cl	Test aprobado en QA	2026-05-20 21:03:23.150603	2026-05-20 21:03:37.752212
58	11	ScanAgent	nuclei_run	MEDIUM	{"target": "example.com", "severity": "medium", "templates": null}	REJECTED	Admin User	\N	2026-05-20 21:42:11.835543	2026-05-21 01:19:23.488764
57	11	ScanAgent	nuclei_run	MEDIUM	{"target": "192.168.56.10", "severity": "medium", "templates": null}	REJECTED	Admin User	\N	2026-05-20 21:36:48.159535	2026-05-21 01:19:24.258203
56	11	ScanAgent	nmap_scan	MEDIUM	{"target": "172.16.0.5", "ports": "1-1024", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-20 21:31:42.886562	2026-05-21 01:19:24.593576
55	11	ScanAgent	nmap_scan	MEDIUM	{"target": "example.com", "ports": "1-1024", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-20 21:26:42.350128	2026-05-21 01:19:24.962584
54	11	ScanAgent	nmap_scan	MEDIUM	{"target": "192.168.56.10", "ports": "1-1024", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-20 21:21:41.838193	2026-05-21 01:19:25.335432
53	11	ScanAgent	nmap_scan	MEDIUM	{"target": "172.16.0.5", "ports": "1-1024", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-20 21:16:18.862394	2026-05-21 01:19:25.679546
52	11	ScanAgent	nmap_scan	MEDIUM	{"target": "172.16.0.5", "ports": "1-1024", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-20 21:14:04.589626	2026-05-21 01:19:26.021579
51	11	ScanAgent	nmap_scan	MEDIUM	{"target": "example.com", "ports": "1-1024", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-20 21:11:18.271767	2026-05-21 01:19:26.382713
50	11	ScanAgent	nmap_scan	MEDIUM	{"target": "example.com", "ports": "1-1024", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-20 21:09:03.974353	2026-05-21 01:19:26.763312
49	11	ScanAgent	nmap_scan	MEDIUM	{"target": "192.168.56.10", "ports": "1-1024", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-20 21:06:17.678299	2026-05-21 01:19:27.085416
48	11	ScanAgent	nmap_scan	MEDIUM	{"target": "192.168.56.10", "ports": "1-1024", "timing": 3, "scripts": null}	REJECTED	Admin User	\N	2026-05-20 21:04:03.364861	2026-05-21 01:19:27.395216
59	14	ReconAgent	dns_enum	LOW	{"target": "scanme.nmap.org", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-26 02:29:52.523806	2026-05-26 02:29:52.523814
60	14	ReconAgent	whois_lookup	LOW	{"target": "scanme.nmap.org"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-26 02:29:53.771293	2026-05-26 02:29:53.771302
61	14	ReconAgent	theharvester_run	LOW	{"target": "scanme.nmap.org", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-26 02:29:56.226002	2026-05-26 02:29:56.226012
62	14	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	e2e-tester	Authorized nmap scan against scanme.nmap.org (Nmap Project authorized target)	2026-05-26 02:30:56.072014	2026-05-26 02:32:12.598805
63	15	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "1-1024", "timing": 3, "scripts": null}	EXPIRED	SYSTEM:MANUAL_EXPIRE	Expirado manualmente vía /expire-pending (2026-05-26T02:42:02.827690Z). PENDING anterior a 2026-05-26T02:42:02.827670Z.	2026-05-26 02:40:55.072632	2026-05-26 02:42:02.828229
64	16	ScanAgent	nmap_scan	MEDIUM	{"target": "scanme.nmap.org", "ports": "1-1024", "timing": 3, "scripts": null}	EXPIRED	SYSTEM:MANUAL_EXPIRE	Expirado manualmente vía /expire-pending (2026-05-26T02:43:42.145896Z). PENDING anterior a 2026-05-26T02:43:42.144591Z.	2026-05-26 02:42:31.158918	2026-05-26 02:43:42.18006
65	18	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.10", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	e2e-script	E2E lab — auditoria 2026-05-26	2026-05-26 22:28:48.175505	2026-05-26 22:29:29.114295
66	18	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.20", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	e2e-script	E2E lab - target dvwa	2026-05-26 22:30:35.700449	2026-05-26 22:34:44.675037
67	18	ScanAgent	nuclei_run	MEDIUM	{"target": "10.42.0.10", "severity": "medium", "templates": null}	EXPIRED	SYSTEM:MANUAL_EXPIRE	Expirado manualmente vía /expire-pending (2026-05-26T22:35:40.349776Z). PENDING anterior a 2026-05-26T22:35:40.349740Z.	2026-05-26 22:34:54.66069	2026-05-26 22:35:40.350629
68	18	ScanAgent	nikto_scan	MEDIUM	{"target": "10.42.0.10", "port": 80}	EXPIRED	SYSTEM:MANUAL_EXPIRE	Expirado manualmente vía /expire-pending (2026-05-26T22:36:50.069683Z). PENDING anterior a 2026-05-26T22:36:50.069670Z.	2026-05-26 22:35:44.771655	2026-05-26 22:36:50.070182
69	18	ScanAgent	gobuster_run	MEDIUM	{"target": "10.42.0.10", "mode": "dir", "wordlist": "/app/diccionario.txt"}	EXPIRED	SYSTEM:MANUAL_EXPIRE	Expirado manualmente vía /expire-pending (2026-05-26T22:37:01.198914Z). PENDING anterior a 2026-05-26T22:37:01.198904Z.	2026-05-26 22:36:52.710357	2026-05-26 22:37:01.199083
70	18	ScanAgent	nuclei_run	MEDIUM	{"target": "10.42.0.20", "severity": "medium", "templates": null}	EXPIRED	SYSTEM:MANUAL_EXPIRE	Expirado manualmente vía /expire-pending (2026-05-26T22:37:09.850854Z). PENDING anterior a 2026-05-26T22:37:09.850845Z.	2026-05-26 22:37:03.239379	2026-05-26 22:37:09.851005
71	18	ScanAgent	nikto_scan	MEDIUM	{"target": "10.42.0.20", "port": 80}	EXPIRED	SYSTEM:MANUAL_EXPIRE	Expirado manualmente vía /expire-pending (2026-05-26T22:37:18.391844Z). PENDING anterior a 2026-05-26T22:37:18.391834Z.	2026-05-26 22:37:13.761818	2026-05-26 22:37:18.392007
72	18	ScanAgent	gobuster_run	MEDIUM	{"target": "10.42.0.20", "mode": "dir", "wordlist": "/app/diccionario.txt"}	EXPIRED	SYSTEM:MANUAL_EXPIRE	Expirado manualmente vía /expire-pending (2026-05-26T22:37:26.953942Z). PENDING anterior a 2026-05-26T22:37:26.953932Z.	2026-05-26 22:37:21.495174	2026-05-26 22:37:26.954138
73	19	ReconAgent	dns_enum	LOW	{"target": "10.42.0.0/24", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-27 22:17:30.895643	2026-05-27 22:17:30.895652
74	19	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.0/24"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-27 22:17:31.12993	2026-05-27 22:17:31.129936
75	19	ReconAgent	theharvester_run	LOW	{"target": "10.42.0.0/24", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-05-27 22:17:31.240502	2026-05-27 22:17:31.24051
76	19	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.0/24", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	e2e-v2-auto	E2E v2 post lab-fixes	2026-05-27 22:18:19.880154	2026-05-27 22:19:23.451981
77	19	ScanAgent	nuclei_run	MEDIUM	{"target": "10.42.0.1", "severity": "medium", "templates": null}	APPROVED	e2e-v2-auto	E2E v2 post lab-fixes	2026-05-27 22:20:48.665867	2026-05-27 22:20:52.287517
78	20	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.10", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	e2e-v2-auto	E2E v2 IPs explicitas	2026-05-27 22:23:17.273045	2026-05-27 22:23:36.542602
79	20	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.20", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	e2e-v2-auto	E2E v2 IPs explicitas	2026-05-27 22:24:44.324378	2026-05-27 22:24:54.321379
80	20	ScanAgent	nuclei_run	MEDIUM	{"target": "http://10.42.0.10:80", "severity": "medium", "templates": null}	APPROVED	e2e-v2-auto	E2E v2 IPs explicitas	2026-05-27 22:25:06.280695	2026-05-27 22:25:16.920454
81	20	ScanAgent	nikto_scan	MEDIUM	{"target": "10.42.0.10", "port": 80}	APPROVED	e2e-v2-auto	E2E v2 IPs explicitas	2026-05-27 22:28:20.179808	2026-05-27 22:28:24.887558
82	20	ScanAgent	gobuster_run	MEDIUM	{"target": "http://10.42.0.10:80", "mode": "dir", "wordlist": "/app/diccionario.txt"}	APPROVED	e2e-v2-auto	E2E v2 IPs explicitas	2026-05-27 22:30:27.858486	2026-05-27 22:30:37.788697
83	20	ScanAgent	nuclei_run	MEDIUM	{"target": "http://10.42.0.20:80", "severity": "medium", "templates": null}	EXPIRED	SYSTEM:STARTUP_CLEANUP	Expirado por startup cleanup (2026-05-27T22:35:51.245558Z). PENDING anterior a 2026-05-27T22:34:51.245548Z → proceso huérfano de reload.	2026-05-27 22:30:42.540121	2026-05-27 22:35:51.251223
84	20	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.10"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-02 22:18:55.544685	2026-06-02 22:18:55.544691
85	20	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.20"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-02 22:18:56.219786	2026-06-02 22:18:56.219792
86	20	ReconAgent	dns_enum	LOW	{"target": "10.42.0.10", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-02 22:18:58.85358	2026-06-02 22:18:58.853587
87	20	ReconAgent	dns_enum	LOW	{"target": "10.42.0.20", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-02 22:19:00.026034	2026-06-02 22:19:00.02604
88	21	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.10", "ports": "1-1024", "timing": 2, "scripts": null}	EXPIRED	SYSTEM:STARTUP_CLEANUP	Expirado por startup cleanup (2026-06-02T22:24:18.110095Z). PENDING anterior a 2026-06-02T22:23:18.110078Z → proceso huérfano de reload.	2026-06-02 22:21:47.146544	2026-06-02 22:24:18.126701
89	22	ScanAgent	nmap_scan	HIGH	{"target": "10.42.0.10", "ports": "1-65535", "timing": 4, "scripts": null}	EXPIRED	SYSTEM:STARTUP_CLEANUP	Expirado por startup cleanup (2026-06-02T22:24:18.110095Z). PENDING anterior a 2026-06-02T22:23:18.110078Z → proceso huérfano de reload.	2026-06-02 22:21:47.159107	2026-06-02 22:24:18.126701
90	21	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.10", "ports": "1-1024", "timing": 2, "scripts": null}	APPROVED	e2e-blockd	resume test	2026-06-02 22:25:08.43259	2026-06-02 22:25:18.512726
91	21	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.10", "ports": "1-1024", "timing": 2, "scripts": null}	EXPIRED	SYSTEM:STARTUP_CLEANUP	Expirado por startup cleanup (2026-06-02T23:38:21.734576Z). PENDING anterior a 2026-06-02T23:37:21.734561Z → proceso huérfano de reload.	2026-06-02 22:25:47.758789	2026-06-02 23:38:21.744539
92	21	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.10", "ports": "21,22,23,25,53,80,110,143,443,445,465,587,993,995,3306,3389,5432,5900,8080,8443", "timing": 3, "scripts": null}	EXPIRED	SYSTEM:STARTUP_CLEANUP	Expirado por startup cleanup (2026-06-02T23:38:21.734576Z). PENDING anterior a 2026-06-02T23:37:21.734561Z → proceso huérfano de reload.	2026-06-02 22:30:24.320711	2026-06-02 23:38:21.744539
93	24	ReconAgent	whois_lookup	LOW	{"target": "192.168.56.1"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-10 04:13:15.552639	2026-06-10 04:13:15.552646
94	24	ReconAgent	dns_enum	LOW	{"target": "192.168.56.1", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-10 04:13:18.025157	2026-06-10 04:13:18.025166
95	24	ScanAgent	nmap_scan	HIGH	{"target": "192.168.56.1", "ports": "1-65535", "timing": 4, "scripts": null}	APPROVED	Admin User	\N	2026-06-10 04:13:26.523836	2026-06-10 04:13:50.295608
96	24	ScanAgent	nmap_scan	HIGH	{"target": "192.168.56.1", "ports": "1-10000", "timing": 4, "scripts": null}	APPROVED	Admin User	\N	2026-06-10 04:18:53.490716	2026-06-10 04:19:04.1435
97	24	ScanAgent	nuclei_run	HIGH	{"target": "http://192.168.56.1", "severity": "critical", "templates": null}	APPROVED	Admin User	\N	2026-06-10 04:22:24.753074	2026-06-10 04:22:38.564205
98	24	ScanAgent	nikto_scan	MEDIUM	{"target": "192.168.56.1", "port": 80}	APPROVED	Admin User	\N	2026-06-10 04:26:41.345624	2026-06-10 04:30:28.975597
99	24	ScanAgent	gobuster_run	MEDIUM	{"target": "http://192.168.56.1", "mode": "dir", "wordlist": "/app/diccionario.txt"}	APPROVED	Admin User	\N	2026-06-10 04:31:01.154538	2026-06-10 04:31:08.754642
100	24	ScanAgent	nikto_scan	MEDIUM	{"target": "192.168.56.1", "port": 8000}	APPROVED	Admin User	\N	2026-06-10 04:31:12.321815	2026-06-10 04:31:19.417579
101	24	ScanAgent	nuclei_run	HIGH	{"target": "http://192.168.56.1:8000", "severity": "critical", "templates": null}	APPROVED	Admin User	\N	2026-06-10 04:36:05.203813	2026-06-10 04:48:58.61444
102	25	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.10"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-16 02:14:23.490917	2026-06-16 02:14:23.490927
103	25	ReconAgent	dns_enum	LOW	{"target": "10.42.0.10", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-16 02:14:23.617768	2026-06-16 02:14:23.617778
104	25	ReconAgent	theharvester_run	LOW	{"target": "10.42.0.10", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-16 02:14:24.833398	2026-06-16 02:14:24.833409
105	26	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.10"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-18 01:44:47.74405	2026-06-18 01:44:47.744056
106	26	ReconAgent	dns_enum	LOW	{"target": "10.42.0.10", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-18 01:44:47.791219	2026-06-18 01:44:47.791225
107	26	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.10", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	S0-auto	auto-approve nmap_scan target=10.42.0.10	2026-06-18 01:44:55.841545	2026-06-18 01:44:59.760541
108	26	ScanAgent	nikto_scan	MEDIUM	{"target": "10.42.0.10", "port": 80}	APPROVED	S0-auto	auto-approve nikto_scan target=10.42.0.10	2026-06-18 01:46:10.440262	2026-06-18 01:46:10.509286
109	26	ScanAgent	nuclei_run	HIGH	{"target": "http://10.42.0.10", "severity": "high", "templates": null}	APPROVED	S0-auto	auto-approve nuclei_run target=http://10.42.0.10	2026-06-18 01:51:28.107547	2026-06-18 01:51:28.659222
110	26	ScanAgent	gobuster_run	MEDIUM	{"target": "http://10.42.0.10", "mode": "dir", "wordlist": "/app/diccionario.txt"}	APPROVED	S0-auto	auto-approve gobuster_run target=http://10.42.0.10	2026-06-18 01:54:55.812808	2026-06-18 01:55:00.788973
111	27	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.20"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-18 03:50:16.163955	2026-06-18 03:50:16.163965
112	27	ReconAgent	dns_enum	LOW	{"target": "10.42.0.20", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-18 03:50:16.391945	2026-06-18 03:50:16.391953
113	27	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.20", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	S5-auto	auto-approve nmap_scan	2026-06-18 03:50:26.112751	2026-06-18 03:50:30.609008
114	27	ScanAgent	nikto_scan	MEDIUM	{"target": "10.42.0.20", "port": 80}	APPROVED	S5-auto	auto-approve nikto_scan	2026-06-18 03:50:42.370908	2026-06-18 03:50:46.249438
115	27	ScanAgent	nuclei_run	HIGH	{"target": "10.42.0.20", "severity": "high", "templates": null}	APPROVED	S5-auto	auto-approve nuclei_run	2026-06-18 03:56:11.187541	2026-06-18 03:56:16.184441
116	27	ScanAgent	gobuster_run	MEDIUM	{"target": "http://10.42.0.20", "mode": "dir", "wordlist": "/app/diccionario.txt"}	APPROVED	S5-auto	auto-approve gobuster_run	2026-06-18 03:59:56.969241	2026-06-18 04:00:03.390099
117	27	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.20", "ports": "1025-65535", "timing": 3, "scripts": null}	APPROVED	S5-auto	auto-approve nmap_scan	2026-06-18 04:00:08.914967	2026-06-18 04:00:13.633446
118	28	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.10"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 01:52:47.245415	2026-06-23 01:52:47.245422
119	28	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.20"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 01:52:47.314049	2026-06-23 01:52:47.314059
120	28	ReconAgent	dns_enum	LOW	{"target": "10.42.0.10", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 01:52:47.330553	2026-06-23 01:52:47.33056
121	28	ReconAgent	dns_enum	LOW	{"target": "10.42.0.20", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 01:52:48.169556	2026-06-23 01:52:48.169562
122	28	ReconAgent	theharvester_run	LOW	{"target": "10.42.0.10", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 01:52:48.964478	2026-06-23 01:52:48.964484
123	28	ReconAgent	theharvester_run	LOW	{"target": "10.42.0.20", "sources": "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget", "timeout": 60}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 01:52:48.97617	2026-06-23 01:52:48.976176
124	28	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.10"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 02:26:41.896808	2026-06-23 02:26:41.896816
125	28	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.20"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 02:26:41.957563	2026-06-23 02:26:41.957569
126	28	ReconAgent	dns_enum	LOW	{"target": "10.42.0.10", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 02:26:44.398998	2026-06-23 02:26:44.399013
127	28	ReconAgent	dns_enum	LOW	{"target": "10.42.0.20", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-23 02:26:45.287022	2026-06-23 02:26:45.287029
128	37	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.10"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-26 15:55:13.372332	2026-06-26 15:55:13.372343
129	37	ReconAgent	dns_enum	LOW	{"target": "10.42.0.10", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-26 15:55:13.447881	2026-06-26 15:55:13.447888
130	37	ScanAgent	nmap_scan	MEDIUM	{"target": "10.42.0.10", "ports": "1-1024", "timing": 3, "scripts": null}	APPROVED	Admin User	\N	2026-06-26 15:55:30.628798	2026-06-26 15:57:59.63073
131	37	ScanAgent	nuclei_run	HIGH	{"target": "10.42.0.10", "severity": "high", "templates": "cve,exposed-panels,misconfig"}	APPROVED	Admin User	Aprobado: lab autorizado y aislado (host-only). Riesgo HIGH revisado para la defensa Capstone.	2026-06-26 15:59:13.89103	2026-06-26 16:00:57.66151
132	37	ScanAgent	nikto_scan	MEDIUM	{"target": "10.42.0.10", "port": 80}	APPROVED	Admin User	\N	2026-06-26 16:04:37.524925	2026-06-26 16:05:11.606346
133	37	ScanAgent	gobuster_run	MEDIUM	{"target": "http://10.42.0.10", "mode": "dir", "wordlist": "/app/diccionario.txt"}	APPROVED	Admin User	\N	2026-06-26 16:10:35.315375	2026-06-26 16:11:04.429868
134	37	ReconAgent	whois_lookup	LOW	{"target": "10.42.0.10"}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-26 20:40:44.126264	2026-06-26 20:40:44.126272
135	37	ReconAgent	dns_enum	LOW	{"target": "10.42.0.10", "timeout": 30}	AUTO-APPROVED	Sistema	risk_level LOW — aprobación automática (pasivo OSINT)	2026-06-26 20:40:44.247028	2026-06-26 20:40:44.247037
136	37	ScanAgent	nuclei_run	HIGH	{"target": "10.42.0.10", "severity": "high", "templates": null}	APPROVED	Admin User	\N	2026-06-26 20:41:00.655516	2026-06-26 20:42:08.510204
\.


--
-- Data for Name: scope_targets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scope_targets (id, engagement_id, target_value, target_type, created_at) FROM stdin;
2	2	45.33.32.156	IP	2026-05-15 20:56:02.053185
3	3	45.33.32.156	IP	2026-05-15 20:58:50.431898
4	4	scanme.nmap.org	DOMAIN	2026-05-15 20:59:50.447125
5	4	45.33.32.156	IP	2026-05-15 20:59:50.447128
6	5	172.19.0.2	IP	2026-05-15 20:59:50.466409
7	5	172.19.0.3	IP	2026-05-15 20:59:50.466413
8	7	192.168.56.1	IP	2026-05-18 19:44:44.161112
9	8	scanme.nmap.org	DOMAIN	2026-05-18 22:57:06.13385
10	9	scanme.nmap.org	DOMAIN	2026-05-18 23:44:03.776032
11	10	scanme.nmap.org	DOMAIN	2026-05-19 00:02:57.912662
12	11	192.168.56.10	IP	2026-05-20 21:02:28.299262
13	11	10.0.0.0/24	CIDR	2026-05-20 21:02:28.299272
14	11	example.com	DOMAIN	2026-05-20 21:02:28.299276
15	11	172.16.0.5	IP	2026-05-20 21:02:59.067247
16	12	10.0.0.1	IP	2026-05-20 21:03:21.517098
18	14	scanme.nmap.org	DOMAIN	2026-05-26 02:29:23.953071
19	15	scanme.nmap.org	DOMAIN	2026-05-26 02:40:40.652069
21	17	10.42.0.0/24	CIDR	2026-05-26 22:26:17.267782
22	18	10.42.0.10	IP	2026-05-26 22:28:36.391792
23	18	10.42.0.20	IP	2026-05-26 22:28:36.391805
24	19	10.42.0.0/24	CIDR	2026-05-27 22:17:08.799237
25	20	10.42.0.10	IP	2026-05-27 22:23:01.626105
26	20	10.42.0.20	IP	2026-05-27 22:23:01.626113
27	21	10.42.0.10	IP	2026-06-02 22:21:21.949478
28	22	10.42.0.10	IP	2026-06-02 22:21:22.473152
29	23	10.42.0.10	IP	2026-06-10 00:52:10.327928
30	24	192.168.56.1	IP	2026-06-10 04:12:16.742715
31	25	10.42.0.10	IP	2026-06-16 02:14:14.52484
32	26	10.42.0.10	IP	2026-06-18 01:44:44.150871
33	27	10.42.0.20	IP	2026-06-18 03:50:06.430919
34	28	10.42.0.10	IP	2026-06-23 01:51:51.058608
35	28	10.42.0.20	IP	2026-06-23 01:51:51.058617
36	29	10.42.0.10	IP	2026-06-23 02:28:32.831013
37	30	10.42.0.10	IP	2026-06-26 15:24:25.450041
38	31	10.42.0.10	IP	2026-06-26 15:25:53.195602
39	32	10.42.0.10	IP	2026-06-26 15:41:50.137985
40	33	10.42.0.10	IP	2026-06-26 15:41:50.364859
41	34	10.42.0.10	IP	2026-06-26 15:42:33.93976
42	35	10.42.0.10	IP	2026-06-26 15:42:34.094561
43	36	10.42.0.10	IP	2026-06-26 15:43:56.250484
44	37	10.42.0.10	IP	2026-06-26 15:49:00.109686
\.


--
-- Name: engagements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.engagements_id_seq', 37, true);


--
-- Name: hitl_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hitl_actions_id_seq', 136, true);


--
-- Name: scope_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scope_targets_id_seq', 44, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: engagements engagements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.engagements
    ADD CONSTRAINT engagements_pkey PRIMARY KEY (id);


--
-- Name: hitl_actions hitl_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hitl_actions
    ADD CONSTRAINT hitl_actions_pkey PRIMARY KEY (id);


--
-- Name: scope_targets scope_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scope_targets
    ADD CONSTRAINT scope_targets_pkey PRIMARY KEY (id);


--
-- Name: ix_engagements_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_engagements_id ON public.engagements USING btree (id);


--
-- Name: ix_hitl_actions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_hitl_actions_id ON public.hitl_actions USING btree (id);


--
-- Name: ix_scope_targets_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_scope_targets_id ON public.scope_targets USING btree (id);


--
-- Name: uq_hitl_pending_dedup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_hitl_pending_dedup ON public.hitl_actions USING btree (engagement_id, agent, tool, md5((params)::text)) WHERE ((decision)::text = 'PENDING'::text);


--
-- Name: hitl_actions hitl_actions_engagement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hitl_actions
    ADD CONSTRAINT hitl_actions_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES public.engagements(id);


--
-- Name: scope_targets scope_targets_engagement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scope_targets
    ADD CONSTRAINT scope_targets_engagement_id_fkey FOREIGN KEY (engagement_id) REFERENCES public.engagements(id);


--
-- PostgreSQL database dump complete
--

\unrestrict TJ2q8Mk3dGQE0YvdDck9Vz2amRWH9HHbVCUD2gLaQxbAMI2jEnShMPnjCHmF00E

