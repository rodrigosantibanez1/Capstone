# Resumen Ejecutivo — Rediseño Agéntico (ADR-005)

**Proyecto:** ETH-MAS — Ethical Hacking Multi-Agent System (prototipo académico Capstone)
**Fecha:** 3 de junio de 2026
**Alcance:** Orquestador conversacional, ejecutor seguro y cuatro agentes especializados (Recon, Scan, Análisis, Reporte), más el rediseño de la interfaz.
**Estado:** Implementado y verificado en ramas de característica; pendiente de integración a la rama principal (excepto el Bloque 0, ya integrado).
**Verificación:** 107+ pruebas unitarias en verde (Docker); compilación del frontend correcta.

---

## 1. Contexto

El proyecto ETH-MAS evoluciona desde un flujo determinista hacia una arquitectura multi-agente conforme a la decisión de arquitectura ADR-005. El nuevo modelo combina un orquestador conversacional gobernado por un modelo de lenguaje, un ejecutor seguro y cuatro agentes especializados que cooperan sobre un estado compartido.

Las garantías de identidad del sistema permanecen como **control en código** y no delegado al modelo: validación de alcance (*scope*) programática y aprobación humana (*HITL*) antes de toda acción de riesgo. El orquestador planifica y delega, pero no aprueba acciones de riesgo por conversación.

---

## 2. Estado de integración

La línea de trabajo se encuentra apilada sobre la rama principal en el siguiente orden. Únicamente el Bloque 0 (contratos compartidos) está ya integrado en la rama principal.

| Rama | Contenido | Integración |
|------|-----------|-------------|
| `main` | Base consolidada + Bloque 0 (contratos ADR-005) | **Integrada** |
| `feature/block-e-executor` | Ejecutor seguro *contract-aware* | Pendiente |
| `feature/block-b-analysis` | AnalysisAgent + MCP de análisis (NVD) | Pendiente |
| `feature/block-c-reporter` | ReporterAgent (PDF técnico/ejecutivo) | Pendiente |
| `feature/block-d-recon-scan` | Recon y Scan orientados a objetivo | Pendiente |
| `feature/block-a-orchestrator` | Orquestador conversacional + chat | Pendiente |
| `feature/frontend-ia-redesign` | Rediseño de arquitectura de información | Pendiente |

---

## 3. Entregables por bloque

| Bloque | Entrega |
|--------|---------|
| **0 · Contratos** | Contratos compartidos de los agentes (`BaseAgent`, `AgentContext`, `AgentResult`). Constituyen la base común que estandariza la ejecución de los cuatro agentes. |
| **E · Ejecutor** | Ejecutor seguro y consciente del contrato. Coordina la ejecución de las etapas, mantiene la trazabilidad de las corridas y registra el razonamiento de cada agente desde una fuente única. |
| **B · Análisis** | AnalysisAgent y servicio MCP de análisis. Enriquece los hallazgos con CVE reales (base NVD), puntaje CVSS y técnicas MITRE ATT&CK validadas, evitando datos inventados. Cubre HU-12 y HU-13. |
| **C · Reporte** | ReporterAgent. Genera los informes técnico y ejecutivo en PDF combinando narrativa por modelo de lenguaje y composición determinística. Cubre HU-14. |
| **D · Recon/Scan** | Agentes de reconocimiento y escaneo orientados a objetivo. La intensidad del escaneo se deriva de las reglas de compromiso (ROE); incorpora continuidad tras la aprobación humana y un conteo de hallazgos consistente con la interfaz y el informe. |
| **A · Orquestador** | Orquestador conversacional con modos de planificación (vista previa) y ejecución (delegación real). Expone una conversación persistente y transmisión en vivo de eventos. Incluye el chat del operador en la interfaz. |
| **Frontend** | Rediseño de la arquitectura de información: nueva sección de Análisis, indicadores reales en el inicio, flujo de *pipeline* de cuatro etapas, accesos rápidos en el chat y unificación del idioma a un registro neutro. |

---

## 4. Cómo validar

### Puesta en marcha
- Posicionarse en la rama `feature/frontend-ia-redesign`, que incorpora toda la pila A–E junto con el rediseño de la interfaz.
- Levantar el entorno completo con el laboratorio de objetivos vulnerables y el servidor de desarrollo del frontend.
- Ejecutar la batería de pruebas unitarias en el contenedor del backend (107+ pruebas).

### Recorrido funcional sugerido
- Crear un compromiso (*engagement*) definiendo el alcance por dirección IP explícita.
- Iniciar el flujo desde el Orquestador o desde el *pipeline* de cuatro etapas.
- Aprobar la acción de riesgo en la consola HITL cuando el sistema la solicite.
- Revisar los hallazgos, ejecutar el análisis y descargar los informes en PDF.

---

## 5. Funcionalidad disponible

- Flujo de extremo a extremo: reconocimiento, escaneo, análisis y reporte coordinados por el ejecutor seguro.
- Orquestador conversacional con previsualización de plan y ejecución delegada.
- Enriquecimiento de hallazgos con CVE, CVSS y técnicas ATT&CK validadas contra fuentes oficiales.
- Generación de informes técnico y ejecutivo en PDF con cifras consistentes.
- Control de intensidad de escaneo según las reglas de compromiso, con aprobación humana bloqueante y limpieza de acciones huérfanas.
- Cobertura de pruebas: más de 107 pruebas unitarias en verde sobre el entorno Docker.

---

## 6. Pendientes y puntos de atención

- **Integración a la rama principal:** solo el Bloque 0 está integrado. Se recomienda coordinar las incorporaciones en el orden E, B, C, D, A y frontend, o bien mediante una incorporación consolidada.
- **Reanudación tras aprobación humana:** la continuación correcta consiste en aprobar la acción pendiente, no en relanzar el escaneo; relanzar genera corridas concurrentes y un estado ambiguo.
- **Cierre del compromiso:** al finalizar el *pipeline* el compromiso permanece en estado "en ejecución"; su cierre es una acción explícita del operador.
- **Modo sigiloso:** por diseño es lento; conviene no interpretarlo como un bloqueo del sistema.
- **Modelo de lenguaje:** el entorno actual opera con un modelo de menor costo, mientras que la documentación declara un modelo superior; corresponde reconciliar la configuración con el escalonamiento definido en el ADR.
- **Validación de tiempos de espera** de ciertas herramientas de escaneo a través del *pipeline*, aún pendiente de una corrida extendida.
- **Verificación del frontend en navegador:** validados la compilación y el análisis estático; resta una prueba funcional manual contra el laboratorio.
- **Documentación:** actualizar la base de conocimiento del proyecto para reflejar el estado vigente de integración y el rediseño de la interfaz.

---

## 7. Recomendaciones

1. Acordar la estrategia de incorporación a la rama principal y abrir las revisiones de código en el orden de dependencias.
2. Ejecutar una demostración de extremo a extremo contra el laboratorio para validar el encadenamiento completo y preparar el guion de la defensa académica.
3. Reconciliar la configuración del modelo de lenguaje y actualizar la documentación del proyecto.

---

*Documento interno del equipo ETH-MAS. La información técnica detallada (commits, endpoints y servicios) reside en el repositorio del proyecto.*
