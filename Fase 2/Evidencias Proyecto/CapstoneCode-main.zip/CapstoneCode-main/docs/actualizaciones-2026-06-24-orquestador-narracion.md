# Actualizaciones — Orquestador conversacional, narración en vivo y fixes de configuración

**Fecha:** 2026-06-24 · **Rama:** `release/v0.3` · **Estado:** verificado en vivo (stack Docker) + tests verdes.

Esta sesión cerró tres frentes: (1) arreglar los *gotchas* de arranque del stack que impedían correr el orquestador, (2) hacer del orquestador un verdadero agente conversacional con evaluación de factibilidad *grounded* en el scope real, y (3) agregar una capa de narración legible del pipeline + un cuadro de actividad en vivo en la UI.

---

## 1. Fixes de configuración (gotchas de arranque)

### 1.1 Diagnóstico inicial
El orquestador "no funcionaba" porque **el stack core estaba caído** (postgres, mongo, backend, frontend en `Exited (255)`); sólo el lab seguía arriba por su `restart: unless-stopped`. No era un bug del orquestador. Arranque correcto desde `CapstoneCode/`:

```bash
docker compose up -d db mongo backend      # core
docker compose --profile lab up -d         # targets del lab (ms2/dvwa)
# verificar: GET http://localhost:8000/health/services  → overall=up
```

> El health real vive en `/health/services` y `/`, no en `/health`.

### 1.2 Bug de nombre de variable de entorno (modelos)
`agent_config.py` lee `ANALYSIS_MODEL` (sin `_AGENT_`), pero el `.env` y el `.env.example` definían `ANALYSIS_AGENT_MODEL` → **el AnalysisAgent corría en Haiku silenciosamente** aunque el `.env` "intentara" ponerle Opus. Además `ORCHESTRATOR_MODEL` no existía.

**Convención correcta de nombres:**

| Variable | La lee |
|---|---|
| `RECON_AGENT_MODEL`, `SCAN_AGENT_MODEL` | con `_AGENT_` |
| `ORCHESTRATOR_MODEL`, `ANALYSIS_MODEL`, `REPORTER_MODEL` | **sin** `_AGENT_` |

**Aplicado:** orquestador y análisis ahora en **`claude-opus-4-8`** (el cerebro del sistema, ADR-005 §3.5); recon/scan siguen en Haiku (tareas mecánicas). Corregido en `.env`, `eth-mas-backend/.env` y `.env.example`.

> Los cambios de modelo requieren **recrear** el contenedor (no basta `--reload`):
> `docker compose up -d --force-recreate backend`.

### 1.3 Precedencia de los dos `.env`
En Docker el backend carga **`CapstoneCode/.env`** (raíz, vía `env_file:` del compose) — es la fuente autoritativa. `eth-mas-backend/.env` sólo aplica a `uvicorn` corrido en el host y como relleno (`load_dotenv` sin override) de los MCP servers. Se agregó un **encabezado de precedencia** en ambos archivos y se sincronizaron los modelos para evitar divergencias.

### 1.4 Gotcha de cliente (no es bug del producto)
Llamar la API a mano desde **PowerShell** con JSON con tildes da `400 "error parsing the body"` (PowerShell codifica en Latin-1; el frontend manda UTF-8 bien). Helper para pruebas manuales:

```powershell
function Invoke-EthMas($Path, $Obj, $Method="Post") {
  $bytes = [Text.Encoding]::UTF8.GetBytes(($Obj | ConvertTo-Json -Depth 6))
  Invoke-RestMethod -Uri "http://localhost:8000$Path" -Method $Method `
    -Body $bytes -ContentType "application/json; charset=utf-8"
}
```

---

## 2. Orquestador conversacional con factibilidad *grounded*

El orquestador ya derivaba parámetros del lenguaje natural (worker, goal, intensidad STEALTH/MODERATE/AGGRESSIVE). El gap era que la evaluación de "¿es posible?" se **inferia de la conversación**, no del scope autoritativo: en un engagement nuevo sin historial no conocía los targets ni la ROE.

**Cambio:** `OrchestratorAgent._scope_summary()` lee scope + ROE del engagement desde PostgreSQL y los inyecta en el system prompt (`_build_system_prompt(..., scope_block)`), con una sección explícita de **FACTIBILIDAD**.

**Verificado** (engagement nuevo, sin historial de chat, scope = sólo `10.42.0.10`):
- Pedido "escaneá `10.42.0.20` y `1.1.1.1`" → rechazó ambos como **NO AUTORIZADOS** (`10.42.0.20` no está listado, `1.1.1.1` es externo) y ofreció la alternativa legítima.
- El scope sigue siendo **control en código**: el orquestador no lo amplía por chat.

Archivo: `eth-mas-backend/services/orchestrator_agent.py`.

---

## 3. Narración legible del pipeline (backend)

Capa de frases simples que el operador entiende de un vistazo, **generadas en el backend** para reutilizarlas idénticas en UI, reportes y modo replay.

- **Nuevo módulo** `eth-mas-backend/services/narration.py` (puro/testeable):
  - `narrate_run_start(agent, targets)` → `"🔍 Reconocimiento iniciado sobre 2 objetivos"`.
  - `narrate_tool_start(tool, target, params)` → `"Recon usando OSINT para consultar WHOIS de 10.42.0.10"`, `"Scan usando Nmap para mapear puertos y servicios de 10.42.0.10"`, etc.
  - El "skill" = MCP/categoría (OSINT, Nmap, Nuclei, NVD…); la "tool" = la función; el complemento = target/producto/query.
- **Schemas** (`mongo_schemas.py`): campo `narration` en `ToolCallEntry` y `AgentRunDoc`.
- **Cableado** (`agent_runs_service.py`): `start_run` y `begin_tool_call` ahora persisten la narración. Se expone por los endpoints existentes `GET /engagements/{id}/agent-runs` (+ SSE `/agent-runs/stream`).

**Verificado en vivo** (recon sobre engagement #28): run y cada tool call con su frase poblada.

---

## 4. Cuadro de actividad en vivo (frontend)

**Nuevo componente** `eth-mas-frontend/src/components/ActivityConsole.jsx`:
- Cuadro lateral dedicado que hace *poll* de `GET /engagements/{id}/agent-runs` (cada 2s) y aplana los runs en un **feed cronológico** de las frases de narración.
- Cada línea con ícono de estado (corriendo / ✓ completado / ✗ error), duración, y aviso destacado cuando una tool espera **aprobación HITL**.
- *(Se eligió poll del listado en vez del SSE de agent-runs porque éste emite sólo el run más reciente y cierra al terminar — incómodo para un ticker continuo de los 4 agentes.)*

**Montaje:** `OrchestratorChatView.jsx` pasó a un layout de 2 columnas (chat + cuadro lateral *sticky* en desktop; apilado en mobile).

---

## Archivos tocados

**Backend**
- `services/narration.py` *(nuevo)*
- `services/orchestrator_agent.py` *(scope grounding)*
- `services/agent_runs_service.py` *(cableado narración)*
- `mongo_schemas.py` *(campo `narration`)*
- `tests/test_narration.py` *(nuevo, 10 tests)*

**Frontend**
- `src/components/ActivityConsole.jsx` *(nuevo)*
- `src/views/OrchestratorChatView.jsx` *(montaje cuadro lateral)*

**Config**
- `.env`, `eth-mas-backend/.env` *(no versionados — fix de modelos + precedencia)*
- `.env.example` *(fix de nombres + Opus 4.8, versionado)*

---

## Verificación

- **Tests:** `192 + 10` verdes (`docker exec eth_mas_backend uv run pytest tests/ -q`).
- **Build frontend:** Vite build OK (sin errores de sintaxis/imports).
- **E2E orquestador:** modo PLAN y EXECUTE funcionando (engagements #28/#29); delegación real en ReconAgent; rechazo de targets fuera de scope.

**Cómo probar la UI:** abrir `http://localhost` → pestaña **Orquestador** (hard-refresh `Ctrl+Shift+R`). El cuadro de actividad aparece a la derecha del chat y se puebla en vivo al lanzar recon/scan/análisis/reporte.

---

## Pendiente (no incluido en esta entrega)

- **Modo replay para la demo** (exhibición separada que reproduce un engagement ya corrido sin re-ejecutar herramientas). La narración generada en backend ya deja todo el texto listo para reproducir.
- **Variante A (scan-worker on-prem):** se mantiene en su propia rama, fuera de este commit.
