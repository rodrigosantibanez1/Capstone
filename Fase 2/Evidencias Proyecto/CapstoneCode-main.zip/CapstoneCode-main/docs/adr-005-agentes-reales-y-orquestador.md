# ADR-005 — Agentes reales + Orquestador conversacional

> **Estado:** Propuesto · 2026-05-29
> **Contexto académico:** crítica del profesor guía — *"el proyecto es determinista;
> los agentes no funcionan como agentes"*.
> **Decisión transversal** (afecta los 4 agentes + la capa de orquestación).
> Reemplaza conceptualmente al `PipelineController` secuencial y redefine
> ReconAgent / ScanAgent / AnalysisAgent / ReporterAgent.

---

## 1. Contexto y problema

El análisis del código (2026-05-29) confirmó la crítica:

| Capa | Estado real | Evidencia |
|------|-------------|-----------|
| **ReconAgent** | Checklist puro | `_build_system_prompt`: *"Para CADA target ejecuta en orden: a) dns_enum b) whois_lookup c) theharvester_run"*. Cero ramificación. |
| **ScanAgent** | Playbook rígido + 1 rama | Prompt con orden fijo nmap→(si web)nuclei/nikto/gobuster; reglas duras "una tool por turno", dedup por firma, `max_iters` dimensionado para agotar la matriz. Comentario en código: *"sin el playbook detallado Haiku se salta tools"* → se le quitó agencia a propósito. |
| **AnalysisAgent** | **No existe** | `services/analysis_agent.py` ausente. |
| **ReporterAgent** | **No existe** | `services/reporter_agent.py` ausente. |
| **Orquestación** | Secuencia hardcodeada de 2 | `PipelineController.DEFAULT_STAGES = ["ReconAgent","ScanAgent"]`; sin LLM, sin reacción al estado. No coordina 4, secuencia 2. |
| **Interfaz operador** | Botones REST | `POST /recon`, `POST /scan`. No hay punto conversacional. |

**Consecuencia formal:** mismo scope ⇒ mismas tools, mismo orden, mismos params.
El sistema es reproducible por un `for` loop; el LLM agrega costo y latencia
sin aportar decisión. Además 2 de 4 agentes no existen y el "coordinador" es
una constante.

Causa de fondo del determinismo: el modelo elegido (`claude-haiku-4-5`) es
demasiado chico para razonamiento abierto, así que se compensó scripteando el
comportamiento. La determinación quedó **estructural**: al reanudar tras un
HITL, el agente reconstruye los `messages` de cero (no tiene memoria), y eso
*solo* funciona porque el plan determinista siempre da lo mismo.

## 2. Fuerzas / requisitos

- **Agencia real y amplia** (decisión del equipo): el modelo decide qué/cómo/
  cuándo/sobre-qué, reaccionando al estado — no ejecuta un checklist.
- **Pilares intocables** (hallazgos C1/C2 ya cerrados): scope enforcement
  **programático** y HITL para risk ≥ MEDIUM **en código**. No vuelven al prompt.
- **Auditabilidad y defensa académica:** hay que poder mostrar *por qué* el
  agente hizo lo que hizo.
- **Deadline 9-jun:** el rediseño debe poder partirse en bloques asignables y
  correlativos para trabajo paralelo sin divergencia.

## 3. Decisión

Adoptar el patrón **Orquestador (cerebro) + Ejecutor seguro (manos) + 4 workers
goal-driven**, sobre una **capa de estado compartida (blackboard)**.

```
            ┌───────────────────────────────────────────────┐
   operador │  ORCHESTRATOR AGENT (LLM, Opus)                │
  ⇄ chat ⇄  │  intención NL → plan → delega → reacciona → narra│
            └───────────────┬───────────────────────────────┘
                            │ agent-as-tool
        ┌───────────────────┼───────────────────────┬───────────────┐
        ▼                   ▼                       ▼               ▼
   ReconAgent          ScanAgent              AnalysisAgent     ReporterAgent
   (Haiku)             (Sonnet/Opus)          (Opus)            (Sonnet+render)
        └──── cada tool activa ─────────────────────────────────────┘
                            ▼
   GUARDARRAÍLES EN CÓDIGO:  scope check  +  HITL (risk ≥ MEDIUM)
                            ▼
   PipelineController  →  degradado a EJECUTOR SEGURO + bookkeeping
   (pipeline_runs, stages, anti-zombi, gating HITL) — se conserva
```

**Principio rector:** separar *decisión* de *ejecución segura*. El Orquestador
planifica con libertad amplia; los guardarraíles acotan **la ejecución, no la
estrategia**. Así "agencia amplia" es segura y defendible: el agente puede
planear cualquier cosa, pero no puede salirse de scope ni disparar algo
riesgoso sin aprobación humana. **Estrategia libre, ejecución blindada.**

### 3.1 Contrato de agente (lo comparten los 4)

| Elemento | Definición |
|----------|------------|
| **Entrada** | `goal` (objetivo en NL) + `context` (engagement, scope, **ROE**, estado/findings previos del blackboard) + `tools` (su MCP) + `budget` (máx pasos/tokens) |
| **Comportamiento** | plan → actuar (tool_use) → **observar → adaptar** → decidir seguir/parar |
| **Parámetros** | los elige el modelo (ports/timing/tags/mode) dentro de scope/ROE |
| **Terminación** | por **criterio** ("cobertura suficiente") o presupuesto agotado |
| **Salida** | `AgentResult`: findings/artefactos + **`rationale`** (NL, por qué actuó así) + status + budget usado |
| **Memoria** | **estado persistido en el blackboard**, sobrevive pausas HITL |
| **Guardarraíles** | scope+HITL en la capa MCP/código, independientes del prompt |

Los dos elementos que más mueven la aguja para la crítica: **`rationale`**
(explica la decisión → auditable) y **estado persistido** (da continuidad real;
hoy el agente re-planifica de cero tras cada HITL).

### 3.2 Los 4 workers, goal-driven

- **ReconAgent** (Haiku): objetivo "mapear superficie pasiva". El que menos
  gana con agencia; decisión mínima por tipo de target (dominio→subdominios).
- **ScanAgent** (Sonnet/Opus): objetivo "enumerar y caracterizar". Lee
  `ROE.scan_intensity` (hoy ignorada) para elegir timing; profundiza donde nmap
  encontró versiones jugosas; decide cuándo basta.
- **AnalysisAgent** (Opus, **nuevo**): objetivo "del set de findings producir un
  cuadro de riesgo priorizado y con evidencia". Correlaciona servicio+versión →
  CVEs reales (NVD) → técnicas ATT&CK → cadenas de ataque → prioriza por
  explotabilidad. Núcleo de razonamiento del sistema.
- **ReporterAgent** (Sonnet + render determinista, **nuevo**): narrativa por LLM,
  PDF por Jinja2/WeasyPrint. Servicio puro (no MCP).

### 3.3 Orquestador

Agente LLM (Opus) cuyas tools son los 4 workers (**agent-as-tool**) + tools de
lectura de estado (engagement, findings, HITL status). Conversa con el operador
(intención NL → plan → delegación → narración), reacciona a los rationales de
los workers y a las decisiones HITL. Punto de comunicación: endpoint
conversacional montado sobre la **espina SSE existente**. Las aprobaciones HITL
siguen siendo un control explícito (no texto libre) por seguridad/auditoría.

### 3.4 Blackboard (estado compartido)

Working-memory por engagement en Mongo: `surface_map`, `findings`, `analysis`,
**`agent_rationales`**, `orchestrator_conversation`. Cada agente lee lo
relevante y escribe su salida; el orquestador lee el blackboard para decidir.
Resuelve el "sin memoria entre pausas HITL" y habilita razonamiento cross-fase.

### 3.5 Tiering de modelos

| Componente | Modelo | Razón |
|------------|--------|-------|
| Orquestador | Opus | planificación + diálogo |
| AnalysisAgent | Opus | razonamiento de explotabilidad / kill chains |
| ScanAgent | Sonnet (Opus si hace falta) | decisión adaptativa de scan |
| ReconAgent | Haiku | tarea mecánica |
| ReporterAgent | Sonnet | redacción de narrativa |

Reconciliar con CLAUDE.md §4.1 (declara Opus 4.7 pero el `.env` corre Haiku).

## 4. Consecuencias

**Positivas:** agentes que efectivamente deciden; coordinador real + interfaz
conversacional; los 4 agentes existen; comportamiento explicable (rationales);
los pilares de seguridad se mantienen.

**Costos (honestos) y mitigaciones:**

| Riesgo | Mitigación |
|--------|------------|
| Menos reproducibilidad | Loguear plan+rationale por run; modo **plan-preview** (operador ve el plan antes de ejecutar) |
| Más costo/latencia | Tiering de modelos (Opus solo donde razona) |
| El resume-tras-HITL dependía del determinismo | Capa de **blackboard** lo reemplaza |
| Defensa académica | Guardarraíles + plan-preview + auditoría de rationales = evidencia de control |
| Alcance vs deadline | Ver `plan-bloques-sprint3-agentes.md`: bloques con MVP demostrable |

## 5. Alternativas descartadas

- **Mantener Haiku + más prompting:** no resuelve la causa (modelo chico);
  agencia frágil.
- **Agencia acotada solo por ROE:** más segura pero el equipo eligió agencia
  amplia; se compensa el riesgo con guardarraíles + plan-preview.
- **Tirar el PipelineController:** perdería el bookkeeping y el anti-zombi de
  Fase 1. Se degrada a ejecutor seguro, no se elimina.

## 6. Referencias

- Desglose en bloques asignables: [`plan-bloques-sprint3-agentes.md`](plan-bloques-sprint3-agentes.md)
- CLAUDE.md §4.1 (modelo), §4.3 (pipeline), §4.4 (catálogo HITL), §4.5 (ROE)
- Código analizado: `services/recon_agent.py`, `services/scan_agent.py`,
  `services/pipeline_controller.py`
