# ETH-MAS — Arquitectura del sistema y diagramas (2026-06-11)

> Documento base para construir la documentación y los diagramas del sistema,
> derivado del **grafo de conocimiento del código** (graphify, 1325 nodos / 2162
> aristas / 98 comunidades) y de la estructura real del repo `CapstoneCode/`.
>
> Los diagramas están en **Mermaid** (se renderizan en GitHub, VS Code con
> extensión, Obsidian, etc.). Acompaña a:
> - [`grafo-sistema-2026-06-11.html`](grafo-sistema-2026-06-11.html) — grafo interactivo.
> - [`grafo-reporte-traducido-2026-06-11.md`](grafo-reporte-traducido-2026-06-11.md) — reporte del grafo explicado.

---

## 1. Vista de capas (arquitectura general)

```mermaid
flowchart TB
    subgraph FE["Frontend — React 19 + Vite + Tailwind v4 + shadcn/ui"]
        UI["Vistas (Engagements, Pipeline, HITL,<br/>Hallazgos, Análisis, Reportes, Orquestador)"]
        API_CLIENT["@/lib/api — authedFetch (X-API-Key)"]
    end

    subgraph BE["Backend — FastAPI (Python 3.11)"]
        ROUTERS["routers/ por dominio<br/>(engagements, scope, pipeline, hitl,<br/>reports, orchestrator, observability, health)"]
        AUTH["auth.py — verify_api_key (opt-in)"]
        AGENTS["services/ — Agentes goal-driven<br/>Recon · Scan · Analysis · Reporter"]
        ORCH["Orquestador conversacional + Ejecutor seguro<br/>+ PipelineController"]
        SCOPE["scope_validator — is_target_in_scope (HU-02)"]
    end

    subgraph MCP["MCP Servers (subprocess stdio)"]
        OSINT["OSINT MCP<br/>dns_enum · whois · theharvester"]
        SEC["Security MCP<br/>nmap · nuclei · nikto · gobuster + sonda soft-200"]
        ANA["Analysis MCP<br/>cve_lookup (CPE→NVD) · attack_technique_lookup"]
    end

    subgraph DATA["Persistencia"]
        PG[("PostgreSQL<br/>engagements · scope_targets<br/>hitl_actions · users")]
        MG[("MongoDB<br/>findings · surface_map · agent_runs<br/>pipeline_runs · analysis · reports(GridFS)")]
    end

    EXT["NVD API · Anthropic API"]

    UI --> API_CLIENT --> ROUTERS
    ROUTERS --> AUTH
    ROUTERS --> ORCH --> AGENTS
    AGENTS --> SCOPE
    AGENTS --> MCP
    SEC --> SCOPE
    ANA --> EXT
    AGENTS --> EXT
    ROUTERS --> DATA
    AGENTS --> DATA
    MCP --> PG
```

---

## 2. Pipeline de pentesting (orden canónico + HITL transversal)

```mermaid
flowchart LR
    OP([Operador define<br/>engagement + scope]) --> V{scope<br/>no vacío?}
    V -->|sí| R[ReconAgent<br/>OSINT pasivo]
    R --> SM[(surface_map)]
    SM --> S[ScanAgent<br/>tools activas]
    S --> F[(findings<br/>MongoDB)]
    F --> A["AnalysisAgent<br/>CVE + ATT&CK + gate confianza"]
    A --> RP[ReporterAgent<br/>PDF técnico + ejecutivo]
    RP --> DL([Operador descarga<br/>reportes])

    HITL{{HITL transversal<br/>risk_level ≥ medium}}
    R -.cada tool call.-> HITL
    S -.cada tool call.-> HITL
    HITL -.aprobado/rechazado.-> S

    classDef gate fill:#fde,stroke:#c39
    class HITL gate
```

**Reglas duras (en código, no en prompt):**
- **Scope enforcement** — `is_target_in_scope()` antes de cada tool call activo.
- **HITL** — `risk_level ≥ medium` bloquea hasta decisión humana (o timeout 300s).
- Estrategia del agente libre; ejecución blindada (ADR-005).

---

## 3. Contrato de agentes (Bloque 0, ADR-005)

Los 4 agentes comparten el mismo contrato — por eso `BaseAgent`/`AgentContext`/
`AgentResult` son god nodes del grafo (§2 del reporte).

```mermaid
classDiagram
    class BaseAgent {
        <<abstract>>
        +engagement_id
        +db
        +pipeline_run_id
        +run(ctx: AgentContext) AgentResult
    }
    class AgentContext {
        +targets()
        +scope
        +roe: ROE
        +prior_state
        +operator_directive
    }
    class AgentResult {
        +agent
        +status
        +rationale
        +findings_count
        +artifacts
        +error
    }
    BaseAgent <|-- ReconAgent
    BaseAgent <|-- ScanAgent
    BaseAgent <|-- AnalysisAgent
    BaseAgent <|-- ReporterAgent
    BaseAgent ..> AgentContext : recibe
    BaseAgent ..> AgentResult : devuelve
```

| Agente | MCP / tools | Modo |
|--------|-------------|------|
| ReconAgent | OSINT MCP (dns_enum, whois, theharvester) | pasivo (risk LOW, auto-approve) |
| ScanAgent | Security MCP (nmap, nuclei, nikto, gobuster) | activo (HITL MEDIUM/HIGH) |
| AnalysisAgent | Analysis MCP (cve_lookup, attack_technique_lookup) | pasivo (sin tocar target) |
| ReporterAgent | — (Jinja2 + WeasyPrint) | sin tools |

---

## 4. Modelo de datos (dual-store)

```mermaid
erDiagram
    ENGAGEMENT ||--o{ SCOPE_TARGET : tiene
    ENGAGEMENT ||--o{ HITL_ACTION : registra
    ENGAGEMENT ||--o{ FINDING : produce
    ENGAGEMENT ||--|| SURFACE_MAP : consolida
    ENGAGEMENT ||--o{ AGENT_RUN : ejecuta
    ENGAGEMENT ||--o{ PIPELINE_RUN : orquesta
    ENGAGEMENT ||--|| ANALYSIS : analiza

    ENGAGEMENT {
        int id PK
        string name
        string status
        json roe
        json att_tactics
    }
    SCOPE_TARGET {
        string target_value
        enum target_type "IP|CIDR|DOMAIN"
    }
    HITL_ACTION {
        int id PK
        string tool
        string risk_level
        string decision "PENDING|APPROVED|REJECTED|AUTO-APPROVED|EXPIRED"
    }
    FINDING {
        string dedup_key
        string tool
        string severity
        string confidence "high|low"
        list cve_details "por-CVE: confidence"
        float cvss_score "solo de CVE confirmed"
        string status "open|confirmed|false_positive|fixed"
    }
```

- **PostgreSQL** (relacional): `engagements`, `scope_targets`, `hitl_actions`, `users`.
- **MongoDB** (documental): `findings`, `surface_map`, `agent_runs`, `pipeline_runs`,
  `analysis`, `reports` (GridFS para los PDF).

---

## 5. Flujo de un request (router → servicio → MCP → tool)

```mermaid
sequenceDiagram
    actor Op as Operador (UI)
    participant API as routers/pipeline.py
    participant PC as PipelineController
    participant SA as ScanAgent
    participant SEC as Security MCP
    participant SV as scope_validator
    participant DB as Postgres/Mongo

    Op->>API: POST /engagements/{id}/scan
    API->>PC: run stage (BackgroundTask)
    PC->>SA: run(AgentContext)
    SA->>SEC: nmap_scan(target, engagement_id)
    SEC->>SV: is_target_in_scope(target)?
    alt fuera de scope
        SV-->>SEC: False
        SEC-->>SA: status=blocked (SCOPE_VIOLATION)
    else en scope
        SEC->>DB: HitlAction PENDING
        Note over SEC: bloquea hasta decisión (≤300s)
        Op->>API: PATCH /hitl-actions/{id}/decision (APPROVED)
        SEC->>SEC: ejecuta nmap → normaliza
        SEC->>DB: findings (upsert por dedup_key)
        SEC-->>SA: findings + raw_output
    end
    SA-->>PC: AgentResult
    PC->>DB: agent_runs / pipeline_runs
```

---

## 6. Gate de confianza CVE (hardening 2026-06-11)

La pieza nueva que separa CVEs aplicables de falsos positivos del LLM.
Determinístico, en código (Community 12 + 4 del grafo).

```mermaid
flowchart TD
    F[Finding con servicio] --> HASCPE{¿evidence.cpe?}
    HASCPE -->|sí| CPE["cve_lookup(cpe)<br/>NVD virtualMatchString"]
    HASCPE -->|no| KW["cve_lookup(product, version)<br/>keyword fallback"]
    CPE --> MM{match_mode}
    KW --> MM
    MM -->|cpe_versioned| C1[confirmed]
    MM -->|cpe_product| C2[version-unknown]
    MM -->|keyword| C3[keyword-only]

    C1 --> GATE
    C2 --> GATE
    C3 --> GATE
    GATE{{"Gate determinístico<br/>(_gate_cve_confidence)"}}
    GATE -->|sin versión: confirmed→version-unknown| OUT
    OUT[cve_details por-CVE]

    OUT --> CVSS["cvss_score headline<br/>= SOLO de CVEs confirmed"]
    OUT --> REP{Reporte}
    REP -->|confirmed| SHOW[se muestra + CVSS]
    REP -->|version-unknown| SHOWNC[se muestra · 'no confirmado']
    REP -->|keyword-only| EXCL[excluido del PDF]

    classDef new fill:#dfe,stroke:#3a3
    class GATE,OUT,CVSS new
```

**Reglas duras:** sin versión concreta del servicio, ningún CVE queda `confirmed`;
el CVSS principal del finding sale solo de CVEs `confirmed`; el gate corre sobre
**todos** los findings con CVE (no solo los que re-procesa el LLM).

---

## 7. Máquina de estados HITL

```mermaid
stateDiagram-v2
    [*] --> PENDING: tool activo (risk ≥ medium)
    [*] --> AUTO_APPROVED: tool pasivo (risk LOW)
    PENDING --> APPROVED: operador aprueba
    PENDING --> REJECTED: operador rechaza
    PENDING --> EXPIRED: timeout / cleanup anti-zombi
    APPROVED --> [*]: ejecuta tool
    REJECTED --> [*]: status=rejected
    EXPIRED --> [*]: no revive
    AUTO_APPROVED --> [*]: ejecuta tool
```

`EXPIRED` es interno del sistema (Fase 1 anti-zombi): limpia PENDINGs huérfanos de
subprocess MCP que murieron en un reload. Índice único parcial `uq_hitl_pending_dedup`
+ dedup app-level evitan duplicados concurrentes.

---

## 8. Mapa de módulos (del grafo → carpetas reales)

```mermaid
flowchart LR
    subgraph routers["routers/ (E1–E9)"]
        r_eng[engagements] & r_scope[scope] & r_pipe[pipeline]
        r_hitl[hitl] & r_rep[reports] & r_orch[orchestrator]
        r_obs[observability] & r_health[health]
    end
    subgraph services["services/"]
        s_base[agent_base] --> s_recon[recon_agent] & s_scan[scan_agent]
        s_base --> s_ana[analysis_agent] & s_rep[reporter_agent]
        s_pc[pipeline_controller] & s_orch[orchestrator_agent]
        s_sv[scope_validator] & s_pol[scan_policy]
        s_find[findings_service] & s_nmap[nmap_service]
        s_render[report_renderer] & s_cfg[agent_config]
    end
    subgraph mcp["mcp_servers/"]
        m_osint[osint_server] & m_sec[security_server] & m_ana[analysis_server]
    end
    subgraph data["persistencia"]
        d_models[models.py · Postgres] & d_mongo[mongo_client + mongo_schemas]
        d_alembic[alembic]
    end

    r_pipe --> s_pc --> s_scan --> m_sec
    s_recon --> m_osint
    s_ana --> m_ana
    s_scan --> s_find & s_sv & s_pol
    s_ana --> s_find
    s_rep --> s_render
    r_orch --> s_orch --> s_pc
    services --> data
```

---

## 9. Cómo mantener estos diagramas

- **Regenerar el grafo** tras cambios grandes: borrar `graphify-out/` y correr
  `graphify update CapstoneCode` + `graphify cluster-only CapstoneCode --no-label`
  (la nota de uso está en la memoria del proyecto, `graphify-tool`).
- **Consultas puntuales** sobre el grafo: `graphify query`, `graphify path A B`,
  `graphify explain <nodo>`, `graphify affected <archivo>`.
- Los diagramas Mermaid de este doc son **curados a mano** sobre el grafo — no se
  autogeneran. Al cambiar la arquitectura, actualizar la sección correspondiente.
- Para diagramas oficiales del anteproyecto (JPG), este doc es la **fuente de
  verdad textual**; exportar desde Mermaid Live (mermaid.live) o el preview del IDE.

---

## 10. Resumen ejecutivo (qué dice el grafo de la salud del sistema)

1. **Los god nodes son los correctos**: contrato de agentes (`BaseAgent`,
   `AgentContext`, `AgentResult`) + scope check (`is_target_in_scope`) +
   orquestador (`PipelineController`). Acoplamiento por diseño, no accidental.
2. **Sin ciclos de import reales** (solo auto-ciclos benignos) — el refactor
   `main.py → routers/` quedó limpio.
3. **El hardening de esta semana quedó bien encapsulado**: el gate de confianza
   formó su propia comunidad (C12) y los helpers CPE cayeron en el Analysis MCP (C4).
4. **Frontend desacoplado** del backend vía `@/lib/api`; su único "god node" es
   `cn()` (normal en shadcn/ui).
5. **El sistema es coherente con ADR-005**: 4 workers goal-driven + orquestador +
   ejecutor seguro + blackboard, con scope/HITL como guardarraíles intocables.
