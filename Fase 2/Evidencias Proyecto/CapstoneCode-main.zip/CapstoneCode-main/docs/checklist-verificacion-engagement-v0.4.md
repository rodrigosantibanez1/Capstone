# Checklist de verificación — Engagement vía orquestador (v0.4)

> **Para:** correr en la notebook local (HP Pavilion) antes de la defensa, para confirmar que
> **todo está conectado y funcional** end-to-end: stack → orquestador conversacional → workers →
> persistencia → SSE en el chat. Marcar cada casilla. Si algo falla, anotar el error y pegármelo
> para iterar el fix en `release/v0.4`.

---

## 0. Pre-requisitos (una vez)

- [ ] `cp .env.example .env` y completar **`ANTHROPIC_API_KEY`** (real).
- [ ] **(Recomendado para la demo)** en `.env`, activar el tiering Opus/Sonnet descomentando el
      bloque "RECOMENDADO" y poniendo IDs de modelo vigentes:
      `ORCHESTRATOR_MODEL=<opus>`, `ANALYSIS_MODEL=<opus>`, `SCAN_AGENT_MODEL=<sonnet>`,
      `REPORTER_MODEL=<sonnet>`. (Si se dejan en Haiku, el sistema igual funciona, con razonamiento
      más pobre en el chat — ver `agent_config.py`.)
- [ ] `ETH_MAS_API_KEY` definido (el mismo que consume el frontend vía `VITE_API_KEY`).

## 1. Levantar el stack + lab

```bash
docker compose --profile lab up -d
docker compose ps      # esperar 6 contenedores Up
```

- [ ] 6 contenedores **Up**: `backend`, `frontend`, `mongo`, `postgres`,
      `eth_mas_lab_ms2`, `eth_mas_lab_dvwa`.
- [ ] Lab alcanzable desde el backend:
      `docker exec eth_mas_backend nmap -Pn -p 22,80,3306 10.42.0.10` → puertos open.
- [ ] DVWA responde: `docker exec eth_mas_backend curl -sS -o /dev/null -w "%{http_code}\n" http://10.42.0.20/` → `302`.

## 2. Salud del backend

```bash
curl -s http://localhost:8000/health/services | jq .
```

- [ ] `overall: up` (postgres, mongo, osint_mcp, security_mcp, **Anthropic key validada**).

## 3. Smoke test automatizado (cableado, sin scans activos)

```bash
ETH_MAS_API_KEY=<tu-key> SCOPE_TARGET=10.42.0.10 ./scripts/smoke_engagement.sh
```

- [ ] **6/6 PASS** (health, crear engagement, scope autorizado, scope denegado,
      orquestador modo plan responde, conversación persistida).
- [ ] Si el paso 5 falla → revisar `ANTHROPIC_API_KEY` / `ORCHESTRATOR_MODEL`.

## 4. Verificación manual en la UI — chat del orquestador

> Vista: `EngagementWorkspaceView.jsx` → tab **Orquestador** (`OrchestratorChatView.jsx`).
> Endpoint: `POST /engagements/{id}/orchestrator` · SSE `GET .../orchestrator/stream`.

- [ ] Abrir `http://localhost/` (o `:5173` en dev), loguear, abrir/crear el engagement con scope `10.42.0.10`.
- [ ] Tab **Orquestador** → escribir un mensaje y enviar en modo **Planificar** (plan):
      el orquestador responde un **plan numerado** sin ejecutar nada.
- [ ] Cambiar a **Ejecutar** (execute) → la respuesta vuelve 202 "queued" y el **stream SSE**
      empieza a pintar turnos: delegaciones en los workers (Recon → Scan…).
- [ ] **HITL bloqueante:** cuando el ScanAgent pide aprobación (nmap, risk ≥ MEDIUM), el chat lo
      narra y deriva a la **consola HITL** (`/hitl`). Aprobar ahí → el pipeline **resume**.
- [ ] Al terminar, el orquestador **narra** hallazgos y próximos pasos en el chat.

## 5. Persistencia (confirmar que quedó todo guardado)

```bash
ENG=<id>
curl -s -H "X-API-Key: $ETH_MAS_API_KEY" "http://localhost:8000/engagements/$ENG/findings?limit=200" | jq '.total'
curl -s -H "X-API-Key: $ETH_MAS_API_KEY" "http://localhost:8000/engagements/$ENG/orchestrator/conversation" | jq '.total'
```

- [ ] `findings.total` coherente con el scan (Metasploitable2 → `≥ 20`).
- [ ] Conversación del orquestador persistida (varios turnos: operator/orchestrator/delegation).
- [ ] (Si se corrió Analysis + Report) PDFs descargables desde la tab **Reportes**.

## 6. Cierre

- [ ] Volcar los números reales en la **Parte B** de
      [`contraste-lab-vs-engagement-v0.4.md`](contraste-lab-vs-engagement-v0.4.md).
- [ ] Pegarme cualquier traceback/log de fallo para iterar en `release/v0.4`.

---

## Notas de estabilidad para el día de la demo
- **Backend sin `--reload`** para evitar el `OSError` del watcher si se toca un archivo
  (ver `guion-demo-viernes-2026-06-19.md` §0). O simplemente **no editar archivos durante la demo**.
- La corrida completa Recon→Scan→Analysis→Report sobre Metasploitable2 tarda **~8–11 min**; no
  esperar la corrida entera en vivo — usar el engagement **persistido** como evidencia primaria
  (ver el guion de defensa).

---

**Documento:** `docs/checklist-verificacion-engagement-v0.4.md` · rama `release/v0.4`.
