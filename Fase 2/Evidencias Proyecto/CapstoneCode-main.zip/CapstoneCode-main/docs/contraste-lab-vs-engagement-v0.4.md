# Contraste — Línea base del lab vs. resultados del engagement del sistema (v0.4)

> **Propósito.** Confrontar de forma objetiva lo que el laboratorio "debería" revelar
> (línea base documentada en [`reporte-laboratorio-vulnerabilidades-v0.4.md`](reporte-laboratorio-vulnerabilidades-v0.4.md))
> contra lo que **ETH-MAS efectivamente produjo** en un engagement. Sirve como
> instrumento de evaluación (cobertura, falsos positivos, falsos negativos) para la defensa.
>
> Se compone de dos partes:
> - **Parte A — Contraste contra corridas documentadas** (#26 Metasploitable2, #27 DVWA,
>   y la auditoría de falsos positivos de #24). Disponible ahora, sin re-ejecutar.
> - **Parte B — Template para la corrida fresca** que se ejecutará en vivo el día de la defensa,
>   para completar con datos reales del momento.

---

## Parte A — Contraste contra corridas documentadas

### A.1 Metasploitable2 (`10.42.0.10`) — engagement #26

Fuente de resultados: [`guion-demo-viernes-2026-06-19.md`](guion-demo-viernes-2026-06-19.md)
(#26 = 38 findings, status `completed`, herramientas nmap+nuclei+nikto+gobuster).
Línea base esperada: §1 del reporte técnico.

| Vuln esperada (línea base) | CVE | ¿Detectable por el sistema? | Vía esperada | Estado en #26 |
|----------------------------|-----|------------------------------|--------------|----------------|
| Superficie ~24 puertos | — | ✅ Sí | nmap | **Confirmado** (38 findings totales incluyen mapa de puertos) |
| vsftpd 2.3.4 backdoor | CVE-2011-2523 | ⚠️ Parcial | nmap (banner+versión) → AnalysisAgent CVE por CPE | _Completar con detalle de #26_ |
| Samba 3.0.20 RCE | CVE-2007-2447 | ⚠️ Parcial | nmap (smb-version) → AnalysisAgent | _Completar_ |
| distccd RCE | CVE-2004-2687 | ⚠️ Parcial | nmap (3632 + NSE) → AnalysisAgent | _Completar_ |
| UnrealIRCd backdoor | CVE-2010-2075 | ⚠️ Parcial | nmap (6667 banner) → AnalysisAgent | _Completar_ |
| ingreslock root backdoor (1524) | — | ✅ Sí (exposición) | nmap puerto abierto | _Completar_ |
| MySQL root sin password (3306) | — | ⚠️ Parcial | nmap servicio; explotación fuera de alcance | _Completar_ |
| VNC `password` (5900) | — | ⚠️ Parcial | nmap servicio | _Completar_ |
| Tomcat `tomcat:tomcat` (8180) | — | ⚠️ Parcial | gobuster `/manager` + nmap | _Completar_ |
| Servicios obsoletos (ssh/telnet/…) | — | ✅ Sí (superficie) | nmap versión | _Completar_ |

**Métricas a calcular** (con los findings reales de #26):
- **Cobertura de superficie:** `puertos_detectados / ~24` esperados.
- **Cobertura CVE-ancla:** de las 4 CVE del lab, cuántas correlacionó el AnalysisAgent (recordar el
  gate por CPE+versión: una CVE ausente puede ser correcta si la versión no se confirmó).
- **Falsos positivos:** findings con CVE que no aplica al producto/versión real (metodología de la
  auditoría #24).

### A.2 DVWA (`10.42.0.20`) — engagement #27

Fuente: #27 = 12 findings web (nikto + gobuster), status `completed`.
Línea base esperada: §2 del reporte técnico.

| Esperado (línea base) | ¿Detectable por el sistema? | Vía | Estado en #27 |
|------------------------|------------------------------|-----|----------------|
| Rutas DVWA (`/login.php`, `/setup.php`, `/security.php`, `/vulnerabilities/*`) | ✅ Sí | gobuster | _Completar_ |
| Headers de seguridad faltantes | ✅ Sí | nikto | _Completar_ |
| Stack PHP 5.x EOL / Apache | ⚠️ Parcial | nikto banner | _Completar_ |
| SQLi / XSS / CmdInj por payload | ❌ Fuera de alcance MVP | (requiere drivers específicos) | N/A — documentar como límite |
| Nivel `impossible` por defecto | — | — | **Verificar** que se bajó a `low/medium` antes de la corrida |

**Lectura clave para la defensa:** #27 demuestra que el pipeline corre también sobre una **app web**
(no solo servicios de red). La explotación profunda de SQLi/XSS es un límite **consciente** del MVP
(el sistema descubre y reporta superficie + clases, no explota cada payload).

### A.3 Disciplina de falsos positivos (de #24, transversal)

La auditoría [`verificacion-hallazgos-mypc-2026-06-10.md`](verificacion-hallazgos-mypc-2026-06-10.md)
y el hardening [`hardening-falsos-positivos-2026-06-11.md`](hardening-falsos-positivos-2026-06-11.md)
establecen que el sistema:
- **No emite CVE sin versión** (gate por CPE — fix Bug #5/#6).
- **Degrada hallazgos nikto** ante comportamiento catch-all (soft-200).
- **Traza CVSS por-CVE** (no pega el máximo sin procedencia).

→ En el contraste, **un CVE histórico ausente NO es automáticamente un falso negativo**: si el
escáner no confirmó la versión, omitir la CVE es el comportamiento **correcto** y deseado. Este matiz
es central para defender la **calidad** del sistema frente a un evaluador.

---

## Parte B — Template para la corrida fresca (completar en vivo)

> Ejecutar el engagement vía el **chat del orquestador** sobre `10.42.0.10` (y opcional `10.42.0.20`),
> siguiendo [`checklist-verificacion-engagement-v0.4.md`](checklist-verificacion-engagement-v0.4.md).
> Luego volcar aquí los datos reales con:
> ```bash
> curl -s -H "X-API-Key: $ETH_MAS_API_KEY" \
>   "http://localhost:8000/engagements/<ID>/findings?limit=200" | jq '{total, by_tool: [.findings[].tool] | group_by(.) | map({tool: .[0], n: length})}'
> ```

### B.1 Metadatos de la corrida fresca

| Campo | Valor |
|-------|-------|
| Engagement ID | **#37** |
| Fecha/hora (UTC) | 2026-06-26 ~15:49 (creación) · pipeline 15:55–16:42 |
| Scope | `10.42.0.10` (Metasploitable2) |
| Lanzado vía | Orquestador (chat) — modo `plan` y luego `execute` |
| Modelo orquestador / análisis | `claude-opus-4-8` (tiering recomendado activo) |
| Intensidad (ROE) | MODERATE → nmap `1-1024`, timing 3, nuclei hasta `high` |
| Estado final | **completed** — pipeline_run limpio **4/4 stages** (Recon → Scan → Analysis → Report) |
| Findings totales | **38** (nmap 11 · nikto 23 · nuclei 3 · gobuster 1) |
| Enriquecidos (CVE/ATT&CK) | 38 con técnica ATT&CK · ~19 CVE únicas · **5 vectores de ataque** |

> **Nota de método.** La corrida se condujo de punta a punta desde el **chat del orquestador**
> (modo Planificar → Ejecutar), con el stream SSE pintando turnos en vivo y los HITL de scan
> aprobados **en la consola HITL**. El pipeline_run representativo de #37 quedó **4/4 completed**
> (la pestaña Pipeline en verde). Las métricas exactas de enriquecimiento varían levemente entre
> corridas del LLM (es esperable); lo estable es el conjunto de findings y los vectores principales.
> Detalle de incidencias y fixes en **B.5**.

### B.2 Cobertura vs. línea base

| Vuln esperada | CVE | ¿Detectada? | Evidencia en #37 | Notas |
|---------------|-----|-------------|------------------|-------|
| Superficie ~24 puertos | — | **Parcial** | 11 puertos abiertos: 21,22,23,25,80,111,139,445,512,513,514 | MODERATE escanea `1-1024`; los servicios de ms2 en puertos altos (>1024) quedan fuera de rango por diseño de la intensidad |
| vsftpd 2.3.4 | CVE-2011-2523 | **Sí — confirmed** | nmap 21/tcp + AnalysisAgent CVE confianza `confirmed`; vector "RCE inmediato vía backdoor vsftpd 2.3.4" (high) | **Headline.** Versión confirmada → CVE afirmada (CVSS 9.8) |
| Samba 3.0.20 | CVE-2007-2447 | **No — retenida (correcto)** | Puertos 139/445 detectados por nmap; vector "Compromiso de Samba (**requiere confirmar versión**)" (medium) | FN **justificado**: nmap no confirmó la versión exacta → el gate por CPE retiene la CVE. Disciplina anti-FP funcionando |
| distccd 2.x | CVE-2004-2687 | **Parcial — keyword-only** | CVE correlacionada con confianza `keyword-only`; vector "RCE vía distccd (validado por nuclei)" (high) | Puerto 3632 fuera de `1-1024`; correlación de **baja confianza**, NO afirmada como confirmada |
| UnrealIRCd 3.2.8.1 | CVE-2010-2075 | **No** | — | FN **justificado por scope**: puerto 6667 fuera del rango `1-1024` |
| ingreslock (1524) | — | No | — | Puerto 1524 > 1024 — fuera del scan MODERATE |
| MySQL sin password | — | No | — | Puerto 3306 > 1024 — fuera del scan MODERATE |
| VNC `password` (5900) | — | No | — | Puerto 5900 > 1024 — fuera del scan MODERATE |
| Tomcat default creds (8180) | — | No | — | Puerto 8180 > 1024 — fuera del scan MODERATE |

**Hallazgos adicionales correlacionados** (más allá de las anclas): **CVE-2012-1823** (PHP-CGI RCE,
validado por nuclei → vector high), cadena de CVEs de **Apache 2.2.8** confianza `confirmed`
(CVE-2008-2939, CVE-2009-1955, CVE-2010-4478, CVE-2014-1692, CVE-2015-1419, CVE-2021-3618…), exposición
de **r-services/telnet en texto plano** (vector high) y reconocimiento web (paths/headers vía
nikto+gobuster, vector medium).

### B.3 Métricas finales

| Métrica | Valor | Lectura |
|---------|-------|---------|
| Superficie detectada | **11 puertos** en `1-1024` | La base ~24 incluye servicios en puertos altos fuera del scan MODERATE; dentro del rango, la cobertura es completa |
| Cobertura CVE-ancla | **1/4 confirmada** (vsftpd) + 1/4 baja confianza (distccd) | 2/4 ausencias son **justificadas** (ver abajo), no fallos de detección |
| Falsos positivos (CVE `confirmed` inaplicable) | **0** | Las 9 CVE `confirmed` corresponden a productos+versión reales (vsftpd 2.3.4, Apache 2.2.8) |
| Falsos negativos **justificados** | Samba (versión no confirmada) · UnrealIRCd/distccd/MySQL/VNC/Tomcat/ingreslock (puertos >1024 fuera de MODERATE) | Comportamiento **correcto**: el sistema no inventa ni escanea fuera del perfil de intensidad pactado |
| CVE por confianza | 9 `confirmed` · 4 `keyword-only` · 3 `version-unknown` | El sistema **etiqueta** la confianza en vez de afirmar todo como cierto |
| Tiempo de la corrida | Recon 16 s · Scan ~15,8 min (incluye esperas HITL manuales) · Analysis 2,6 min · Report 19 s | El grueso del tiempo es nuclei/nikto + las aprobaciones HITL |

### B.4 Conclusión del contraste

Dentro del rango efectivamente escaneado (MODERATE = `1-1024`), **ETH-MAS reprodujo la línea base con
alta fidelidad**: detectó la vulnerabilidad insignia del lab —el backdoor de **vsftpd 2.3.4
(CVE-2011-2523, CVSS 9.8)**— con confianza `confirmed` y la articuló como un vector de RCE inmediato,
sumando además un RCE web real (PHP-CGI, CVE-2012-1823) y la cadena de CVEs de Apache 2.2.8. Lo más
valioso para defender la **calidad** del sistema es lo que **no** afirmó: Samba quedó como vector
"requiere confirmar versión" y su CVE fue **retenida** por el gate de CPE, y las CVE de baja evidencia
se marcaron `keyword-only`/`version-unknown` en lugar de venderse como ciertas → **0 falsos positivos
de alta confianza**. Las ausencias de UnrealIRCd, distccd, MySQL, VNC y Tomcat **no son falsos
negativos del detector** sino consecuencia directa de la intensidad **MODERATE** (puertos `1-1024`):
una corrida **AGGRESSIVE** o full-port los alcanzaría. En síntesis, el contraste muestra un sistema que
**prioriza precisión sobre exhaustividad** y es **honesto sobre su propia confianza** — exactamente la
identidad técnica que el proyecto defiende.

### B.5 Incidencias y fixes durante la corrida

La corrida fresca se usó también como prueba de estrés y destapó **dos bugs reales**, ambos
diagnosticados y corregidos en `release/v0.4` con test de regresión:

| # | Síntoma | Causa raíz | Fix | Commit |
|---|---------|-----------|-----|--------|
| 1 | AnalysisAgent fallaba (`status=failed`, "unhandled errors in a TaskGroup") tras un scan exitoso | `messages.create(..., temperature=0)` con **Opus 4.8**, que **deprecó** el parámetro → API 400 enmascarado por el `ExceptionGroup` de anyio | `agent_config.supports_temperature()` (degradación segura) + `analysis_agent` pasa `temperature` solo si el modelo lo acepta | `79f837d` |
| 2 | Descarga de PDF con nombre personalizado → **500** | `Content-Disposition` con el separador em-dash (`—`, U+2014) no es latin-1 → `UnicodeEncodeError` | header RFC 6266 (`filename` ASCII + `filename*=UTF-8''`) | `5f53036` |

Adicional (estabilidad de demo): el backend se pasó a correr **sin `uvicorn --reload`** (override local,
gitignored) para evitar el cuelgue del watcher al editar archivos durante una corrida. Suite completa:
**200 tests verdes** tras los fixes.

**Re-validación limpia (post-fix).** Con los bugs ya corregidos, se re-ejecutó el pipeline **completo
vía el orquestador** sobre #37: resultó un pipeline_run **4/4 stages, todas `completed`**
(Recon → Scan → Analysis → Report, ~497 s), que es el run **representativo** de #37 → la pestaña
Pipeline muestra el flujo en verde. El run original `partial_failed` (con el análisis caído por el bug
de Opus 4.8) queda en el historial pero no se muestra. **El seed de demo (`demo-seed/`) refleja este
estado limpio 4/4.**

---

**Documento:** `docs/contraste-lab-vs-engagement-v0.4.md` · rama `release/v0.4`.
