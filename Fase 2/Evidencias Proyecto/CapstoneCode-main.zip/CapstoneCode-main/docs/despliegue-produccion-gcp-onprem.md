# ETH-MAS — Arquitectura de despliegue productivo (GCP + on-prem) · "to-be"

> Decisión de arquitectura de despliegue para la entrega final del Capstone
> (el profesor pidió **arquitectura productiva**, no el entorno de desarrollo).
> Acompaña al diagrama [`despliegue-produccion-gcp-onprem.drawio`](despliegue-produccion-gcp-onprem.drawio)
> y complementa la vista de despliegue de desarrollo del C4
> ([`arquitectura-eth-mas-c4.drawio`](arquitectura-eth-mas-c4.drawio) · pág. "Despliegue · Docker").
>
> **Fecha:** 2026-06-13 · **Estado:** propuesta (to-be), no implementada.

---

## 1. Contexto y por qué esta forma

Se evaluaron varias alternativas de despliegue productivo (platform.claude /
Managed Agents, GCP gestionado, self-host single-node, híbrido on-prem/cloud). Un
**constraint duro** ordena todas: el **laboratorio (Metasploitable2 + DVWA) es
deliberadamente vulnerable** y las tools de escaneo generan **tráfico activo** —
ambos deben vivir en un **segmento de red aislado y controlado por el equipo**, no
en una nube compartida ni en serverless público. Por eso toda arquitectura
realista de ETH-MAS es **híbrida de dos planos**.

**Decisiones tomadas:**
- **Plano de aplicación + datos → GCP.** Frontend, Backend, PostgreSQL, MongoDB.
- **Plano de escaneo + lab → on-prem** (máquina del operador), lab aislado (host-only).
- **Ruta al LLM → API 1st-party de Anthropic** (egress HTTPS).
- **Conectividad on-prem ↔ GCP → job-pull** (el worker on-prem hace polling
  saliente; NAT-friendly, no se abre la red de casa).
- **Partición del plano de escaneo → se documentan las dos variantes** (A y B, §4).

---

## 2. Arquitectura objetivo — dos planos

```
   Operador ──HTTPS──► [ GCP: app + datos ] ──egress──► Anthropic API · NVD API
                              │  ▲
                   job-pull   │  │  findings (HTTPS, conexión iniciada on-prem)
                              ▼  │
                       [ on-prem: scan worker ] ──scan activo──► [ lab aislado ]
                              └──egress──► Anthropic API (razonamiento ScanAgent)
```

### Plano GCP (aplicación / orquestación / datos)

| Componente | Servicio GCP | Rol |
|------------|--------------|-----|
| **Frontend SPA** | Cloud Run (contenedor nginx) **o** Cloud Storage + CDN | React 19 estático; UI de engagements, pipeline, HITL, hallazgos, reportes |
| **Backend API** | **GCE VM** (o GKE) — FastAPI/uvicorn | Orquestador, PipelineController, **AnalysisAgent** (egress NVD), **ReporterAgent** (PDF), estado HITL, auth, routers, **dispatcher de jobs de scan** |
| **PostgreSQL** | **Cloud SQL** | engagements, scope_targets, hitl_actions, users |
| **MongoDB** | **MongoDB Atlas** (VPC peering a GCP) | findings, surface_map, agent_runs, pipeline_runs, analysis, reports (GridFS) |
| **Cola / endpoint de jobs** | **Pub/Sub** o endpoint REST long-poll del backend | Entrega de scans aprobados al worker on-prem |
| Red | VPC + firewall | Egress a Anthropic/NVD; Cloud SQL/Atlas en subred privada |

> **Por qué GCE y no Cloud Run para el backend:** los escaneos largos, el **HITL
> bloqueante** y el **SSE** chocan con el modelo stateless y el timeout de request
> de Cloud Run. El backend necesita **compute persistente** → GCE VM (simple) o GKE
> (sobredimensionado para el caso). Cloud Run sí es buena opción para el **frontend
> estático**.

### Plano on-prem (escaneo + lab aislado) — máquina del operador

| Componente | Forma | Rol |
|------------|-------|-----|
| **Scan worker** | Docker | **ScanAgent + Security MCP + OSINT MCP + nmap/nuclei/nikto/gobuster + sonda soft-200**. Hace **polling saliente** a GCP por scans aprobados, corre `scope_validator` + scan activo, postea findings a la API del backend |
| **Lab aislado** | Docker, red `eth_mas_lab` host-only (`10.42.0.0/24`, sin `ports:` al host) | Metasploitable2 (`10.42.0.10`) + DVWA (`10.42.0.20`), expose-only |

**Egress del worker on-prem (solo saliente, NAT-friendly):**
- → **Backend GCP** (HTTPS): poll de jobs + POST de findings (no toca las DBs directo).
- → **Anthropic API** (HTTPS): razonamiento del ScanAgent (es un agente LLM).
- → **lab** (red interna aislada): tráfico de scan nmap/nuclei/etc. **sin salida a internet**.

---

## 3. Conectividad: patrón job-pull (NAT-friendly)

La máquina on-prem está detrás de NAT (sin IP pública estática), así que **GCP no
puede iniciar la conexión**. El worker **dial-out**:

1. El operador lanza/aprueba un scan en la UI (GCP). El backend persiste un
   `HitlAction` y, al aprobarse, **encola un job de scan** (Pub/Sub o tabla de jobs).
2. El **worker on-prem** hace polling saliente (HTTPS) y **toma el job aprobado**.
3. El worker corre `is_target_in_scope` + el scan activo contra el lab.
4. El worker **postea los findings** a la API del backend (HTTPS), que los persiste
   en Mongo Atlas y emite los eventos SSE al frontend.

> Es el mismo *shape* que el **self-hosted sandbox worker** de Managed Agents: el
> cerebro/estado en la nube, la ejecución sensible (tráfico activo + lab) en infra
> propia, conexión siempre **iniciada desde on-prem**.

**Alternativa de conectividad (documentada, no elegida):** túnel inverso saliente
(WireGuard/SSH a un gateway en GCP) si se quisiera enlace bidireccional de baja
latencia — a costa de mantener el gateway/túnel.

---

## 4. Las dos particiones del plano de escaneo (ambas documentadas)

### Variante A — Scan worker on-prem (coincide con el modelo objetivo)

- **GCP:** frontend + backend (orquestador, **Analysis**, **Reporter**, HITL, datos).
- **On-prem:** **solo el plano de escaneo** (ScanAgent + Security/OSINT MCP + tools) + lab.
- **Refactor (acotado):** hoy el Security MCP es subprocess del backend monolítico.
  Hay que **extraer el ScanAgent + los MCP de escaneo como un worker independiente**
  que (a) consume jobs por la cola, (b) postea findings por la API. El resto del
  backend (orquestador/Analysis/Reporter) queda en GCP intacto.
- **Pro:** el backend "vive" en GCP como se pidió; separa limpio el tráfico activo.
- **Contra:** requiere el worker + la cola + el contrato job/findings.

### Variante B — Backend completo on-prem, GCP solo front + DBs (fallback)

- **GCP:** **solo** frontend + Cloud SQL + Atlas.
- **On-prem:** **todo el backend** (orquestador + 4 agentes + MCP) + lab.
- **Refactor:** **nulo** — es el monolito actual, pero apuntando a DBs gestionadas en
  GCP (Cloud SQL/Atlas) y sirviendo el frontend desde GCP.
- **Pro:** cero reescritura; el más rápido de levantar.
- **Contra:** el backend **no** queda en GCP (contradice el target); el backend
  on-prem debe alcanzar Cloud SQL/Atlas (egress saliente, OK) y exponer su API al
  frontend GCP (requiere túnel/endpoint público o que el frontend hable a un backend
  on-prem expuesto — menos limpio).

| | Variante A (scan worker) | Variante B (backend on-prem) |
|---|---|---|
| Backend en GCP | ✅ | ❌ (on-prem) |
| Reescritura | Media (extraer worker) | Nula |
| Tráfico activo aislado | ✅ | ✅ |
| Complejidad de red | Media (cola + job-pull) | Baja-media (frontend→backend on-prem) |
| Pureza del target | Alta | Baja |

**Recomendación:** **A como arquitectura final ("to-be")**, **B como camino de
implementación rápido / fallback** para una demo sin reescritura.

---

## 5. Ruta al LLM

**API 1st-party de Anthropic** (`api.anthropic.com`, HTTPS). Sin cambios de código.
Tanto el backend GCP (orquestador/Analysis/Reporter) como el worker on-prem
(ScanAgent) hacen egress a Anthropic. *Knob futuro:* si se fuera full-GCP, Claude en
Vertex AI mantiene la llamada dentro de GCP (pierde Skills/Managed Agents).

---

## 6. Aislamiento del lab (clave de la defensa)

- Lab **on-prem**, red Docker **host-only** `eth_mas_lab` (`10.42.0.0/24`),
  **sin `ports:` al host** y **sin egress a internet** (solo alcanzable por el scan
  worker en la red interna).
- Imágenes pinneadas por digest (ya en `docker-compose.yml`, profile `lab`).
- Es la ubicación más defendible para el relato "laboratorio controlado y aislado":
  físicamente bajo control del equipo, nunca expuesto.

---

## 7. Costo (orden de magnitud, mensual)

| Ítem | Aprox. |
|------|--------|
| GCE VM backend (e2-small/medium) | bajo |
| Cloud SQL (db-f1-micro/g1-small Postgres) | bajo |
| MongoDB Atlas (M0 free / M10) | free–bajo |
| Cloud Run/Storage frontend | mínimo |
| Pub/Sub | mínimo |
| Anthropic API (Haiku/Opus por uso) | variable (lo dominante) |
| Lab on-prem | $0 (máquina propia) |

Para un Capstone, las capas free/micro de GCP + Atlas M0 cubren casi todo; el costo
real lo marca el uso de tokens del LLM.

---

## 8. Checklist de construcción (para Variante A)

- [ ] Extraer `ScanAgent` + `mcp_servers/{security,osint}_server.py` + tools a un
      paquete/worker desplegable por separado (Docker).
- [ ] Definir el **contrato de job**: `GET /scan-jobs/next` (poll) + `POST /engagements/{id}/findings` (resultados) — o Pub/Sub equivalente.
- [ ] Worker: loop de poll saliente + `is_target_in_scope` local + ejecución de scan + post de findings.
- [ ] Backend GCP: dispatcher que encola un job al aprobarse el HITL; deja de spawnear el Security MCP localmente.
- [ ] Infra GCP: GCE VM (backend), Cloud SQL (Postgres), Atlas (Mongo + peering), Cloud Run/Storage (frontend), Pub/Sub (cola).
- [ ] Secrets: `ANTHROPIC_API_KEY`, `ETH_MAS_API_KEY`, credenciales DB — Secret Manager (GCP) y `.env` en el worker on-prem.
- [ ] Red lab on-prem host-only + verificación de no-egress.

---

## 9. Riesgos / puntos abiertos

- **HITL a través de la cola:** el bloqueo del ScanAgent on-prem debe esperar la
  aprobación que vive en GCP. Patrón: el worker solo recibe jobs **ya aprobados**
  (el HITL se resuelve en GCP antes de encolar) → evita polling de estado HITL
  cross-network. Confirmar que el UX de aprobación encaja.
- **Latencia/cola:** el job-pull agrega latencia (intervalo de poll). Aceptable para
  scans (minutos), no para interactividad fina.
- **Variante B y el frontend:** si el backend queda on-prem, el frontend en GCP debe
  alcanzarlo → requiere exponer el backend on-prem (túnel/endpoint) o servir el
  frontend también on-prem.

---

## 10. Relación con el resto de la documentación

- Vista de **desarrollo** (Docker single-host): C4 `arquitectura-eth-mas-c4.drawio` pág. "Despliegue · Docker".
- Vista de **producción** (este doc): `despliegue-produccion-gcp-onprem.drawio`.
- Evaluación de **platform.claude / Managed Agents**: queda como **anexo de evolución
  futura** (rewrite del orquestador a la API de agentes gestionados; datos persistidos
  en Anthropic, no-ZDR) — no es el target de esta entrega.
