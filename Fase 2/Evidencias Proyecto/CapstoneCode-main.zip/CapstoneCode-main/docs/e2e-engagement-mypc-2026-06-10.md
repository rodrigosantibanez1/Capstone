# Evidencia E2E — Engagement #24 "MyPC"

> **Prueba de ejecución end-to-end del pipeline ETH-MAS** sobre un target real
> (host del operador). Recon → Scan → HITL → Analysis → Report, con engagement
> cerrado y 2 PDFs generados.
>
> **Fecha:** 2026-06-10 · **Branch:** `feature/frontend-ia-redesign` ·
> **Modelo agentes:** `claude-haiku-4-5-20251001` · **Operador:** Admin User (`admin@eth-mas.cl`)

> ⏱️ **Nota sobre las horas:** el backend persiste timestamps en **UTC naive**
> (`utils.utc_now()`). Las horas de este documento están en **UTC**. Hora local
> del operador = UTC−4 (Chile, junio). Ej.: `04:13 UTC` = `00:13` local. Existe
> un desfase cosmético conocido en el frontend que interpreta esos timestamps
> como hora local (pendiente de fix — helper `parseUTC`).

---

## 1. Configuración del engagement

| Campo | Valor |
|-------|-------|
| ID | `24` |
| Nombre | `MyPC` |
| Cliente | `owner` |
| Descripción | `p1` |
| **Scope** | `192.168.56.1` (tipo `ip`) — adaptador host-only de VirtualBox = PC del operador |
| Intensidad ROE | `AGGRESSIVE` |
| Ventana ROE | 00:00–12:00, todos los días |
| `max_requests_per_second` | 50 |
| `auto_approve_hitl_below` | `MEDIUM` (LOW se auto-aprueba; MEDIUM/HIGH requieren humano) |
| Tácticas ATT&CK declaradas | 14 (TA0043, TA0042, TA0001…TA0040) |
| Estado final | `completed` (engagement cerrado) |

---

## 2. Timeline del pipeline run `6a28e454…`

| Hora (UTC) | Evento |
|------------|--------|
| 04:12:16 | Engagement #24 creado con scope `192.168.56.1` |
| 04:13:08 | Pipeline run lanzado (`triggered_by: operator`) |
| 04:13:08 → 04:13:23 | **ReconAgent** completa (whois + dns_enum, ambos vacíos — esperado para IP privada) |
| 04:13:23 | **ScanAgent** arranca |
| 04:42:23 | **ReporterAgent** genera los 2 PDFs |
| — | Pipeline `completed`, los 4 stages OK |

### Stages

| Stage | Estado | Resumen |
|-------|--------|---------|
| ReconAgent | ✅ completed | 0 hosts · 0 emails OSINT |
| ScanAgent | ✅ completed | 20 findings |
| AnalysisAgent | ✅ completed | enriquecimiento ATT&CK + CVE + CVSS |
| ReporterAgent | ✅ completed | 2 PDFs |

---

## 3. Controles de seguridad ejercitados

### 3.1 Scope enforcement (HU-02)

El scope quedó acotado a una sola IP. Recon/Scan operaron exclusivamente sobre
`192.168.56.1`. No hubo `scope_violation` en esta corrida.

### 3.2 HITL — registro de decisiones (HU-09)

| HITL | Tool | risk_level | Decisión | Solicitado (UTC) | Decidido (UTC) |
|------|------|-----------|----------|------------------|----------------|
| 93 | whois_lookup | LOW | AUTO-APPROVED | 04:13:15 | 04:13:15 |
| 94 | dns_enum | LOW | AUTO-APPROVED | 04:13:18 | 04:13:18 |
| 95 | nmap_scan | HIGH | APPROVED | 04:13:26 | 04:13:50 |
| 96 | nmap_scan | HIGH | APPROVED | 04:18:53 | 04:19:04 |
| 97 | nuclei_run | HIGH | APPROVED | 04:22:24 | 04:22:38 |
| 98 | nikto_scan | MEDIUM | APPROVED | 04:26:41 | 04:30:28 |
| 99 | gobuster_run | MEDIUM | APPROVED | 04:31:01 | 04:31:08 |
| 100 | nikto_scan | MEDIUM | APPROVED | 04:31:12 | 04:31:19 |
| 101 | nuclei_run | HIGH | APPROVED (tarde) | 04:36:05 | 04:48:58 |

- Las acciones LOW se auto-aprobaron por ROE; las MEDIUM/HIGH requirieron al
  operador → **el control humano funcionó como diseñado**.

### 3.3 ⚠️ Caso HITL #101 — aprobación fuera de ventana (no es bug)

El HITL #101 (`nuclei_run` sobre `http://192.168.56.1:8000`) se solicitó a las
**04:36:05**. El agente espera aprobación con **timeout de 300s** → a las ~04:41
se rindió y marcó ese tool call como `hitl_timeout`. El operador aprobó a las
**04:48:58**, ~7 min después de expirar la ventana, cuando el pipeline ya había
generado los PDFs (04:42).

**Consecuencia:** ese escaneo nuclei sobre el puerto 8000 **nunca se ejecutó**.
La fila figura `APPROVED` en Postgres pero el tool call quedó en `hitl_timeout`.
Es el modelo HITL bloqueante funcionando correctamente — aprobar tras el timeout
no revive la acción.

**Recomendación operativa:** para la demo académica, aprobar los HITL HIGH
dentro de la ventana de ~5 min.

---

## 4. Ejecución de herramientas (ScanAgent)

| # HITL | Tool | Target | Estado | Duración | Nota |
|--------|------|--------|--------|----------|------|
| 95 | nmap_scan | `192.168.56.1` (ports 1-65535, T4) | `tool_error` | 324.8 s | **Timeout 300s** (límite H-1 conocido). 0 findings |
| 96 | nmap_scan | `192.168.56.1` (ports 1-10000, T4) | `completed` | 206.7 s | Agente **se recuperó** acotando el rango → findings |
| 97 | nuclei_run | `http://192.168.56.1` (sev critical) | `completed` | 254.8 s | |
| 98 | nikto_scan | `192.168.56.1` | `completed` | 256.6 s | |
| 99 | gobuster_run | `http://192.168.56.1` | `completed` | 9.1 s | |
| 100 | nikto_scan | `192.168.56.1` | `completed` | 290.8 s | |
| 101 | nuclei_run | `http://192.168.56.1:8000` | `hitl_timeout` | 300.9 s | No ejecutado (ver §3.3) |

> **Comportamiento agéntico destacable:** tras el timeout del barrido de 65 535
> puertos (#95), el ScanAgent re-lanzó nmap acotado a 1-10000 (#96) por decisión
> propia y obtuvo el mapa de puertos. Es el patrón goal-driven esperado del
> rediseño ADR-005, no un playbook rígido.

---

## 5. Findings persistidos en MongoDB (20)

Distribución: **6 high · 3 medium · 8 low · 3 info**. Enriquecimiento del
AnalysisAgent: **16/20 con MITRE ATT&CK**, **4/20 con CVE**, **4/20 con CVSS (fuente NVD)**.

### 5.1 NMAP — superficie de puertos (host Windows)

| Puerto | Servicio | Sev | MITRE | CVSS | CVEs |
|--------|----------|-----|-------|------|------|
| 80/tcp | http — **nginx 1.31.1** | medium | T1046 | — | — |
| 135/tcp | msrpc — Microsoft Windows RPC | high | T1021 | 7.5 | CVE-2003-0352, CVE-2003-0003 |
| 139/tcp | netbios-ssn | high | T1040 | — | — |
| 445/tcp | microsoft-ds (SMB) | high | T1021 | 7.5 | CVE-2003-0352 |
| 808/tcp | mc-nmf (.NET Message Framing) | medium | — | — | — |
| 5040/tcp | unknown | info | — | — | — |
| 7680/tcp | pando-pub (Windows Delivery Optimization) | info | — | — | — |
| 8000/tcp | http-alt — **uvicorn (el propio backend ETH-MAS)** | medium | T1190 | 8.6 | CVE-2020-7695, CVE-2026-2652 |
| 8834/tcp | nessus-xmlrpc (Nessus en el host) | info | — | — | — |

### 5.2 NIKTO — análisis HTTP sobre puerto 80

| Sev | MITRE | CVSS | CVE | Hallazgo |
|-----|-------|------|-----|----------|
| high | T1592 | — | — | Posible home dir = web root, shell history recuperado |
| high | T1592 | — | — | (idem — segundo match) |
| high | T1190 | 4.3 | CVE-2013-6235 | JAMon Admin interface (XSS ≤ v2.7) |
| low | T1040 | — | — | Header faltante: `strict-transport-security` |
| low | T1190 | — | — | Header faltante: `content-security-policy` |
| low | T1190 | — | — | Header faltante: `permissions-policy` |
| low | T1190 | — | — | Header faltante: `referrer-policy` |
| low | T1190 | — | — | Header faltante: `x-content-type-options` |
| low | T1190 | — | — | `OPTIONS`: métodos permitidos GET |
| low | T1190 | — | — | `X-Frame-Options` deprecado (usar CSP frame-ancestors) |
| low | T1190 | — | — | `X-Content-Type-Options` no seteado |

---

## 6. Reportes generados (ReporterAgent · HU-14)

Persistidos en MongoDB GridFS, descargables desde la vista Reportes:

| Archivo | Tipo | Tamaño | Generado (UTC) |
|---------|------|--------|----------------|
| `eng_24_technical.pdf` | technical | 34 145 B | 04:42:23 |
| `eng_24_executive.pdf` | executive | 22 556 B | 04:42:23 |

---

## 7. ⚠️ Observaciones para verificación (la corrida funcionó, los datos hay que auditarlos)

El **pipeline funcionó técnicamente de punta a punta**, pero el enriquecimiento
del AnalysisAgent (LLM) produjo correlaciones CVE que **deben verificarse antes
de darlas por válidas**. Esto es justamente lo que el sistema debe permitir
auditar:

1. **CVEs de 2003 sobre un Windows moderno (findings 135/445):** `CVE-2003-0352`
   (Blaster / MS03-026, RPC DCOM) y `CVE-2003-0003` mapeados a `msrpc` y SMB de
   un host de 2026. **Altamente sospechoso de falso positivo** — correlación
   ingenua por nombre de servicio sin versión (`version: null` en la evidencia).

2. **CVE de 2026 sobre uvicorn (finding 8000):** `CVE-2026-2652` con CVSS 8.6
   sobre el **propio backend ETH-MAS**. Un CVE con año futuro merece verificación
   directa en NVD — posible alucinación o ID mal formado.

3. **Banner `nginx 1.31.1` (puerto 80):** esa versión **no existe** en el
   release público de nginx (mainline va por ~1.27). Posible banner
   custom/spoofeado, build interno o servicio que se hace pasar por nginx.
   Verificar qué corre realmente en `:80`.

4. **El target se escaneó a sí mismo:** el puerto 8000 es el `uvicorn` del propio
   backend ETH-MAS y el 8834 es un Nessus en el host. En scope y válido, pero
   conviene tenerlo presente al interpretar los findings.

5. **Findings nikto "home dir = web root / shell history" (high):** revisar si
   son reales o falsos positivos típicos de nikto contra rutas genéricas.

---

## 8. Veredicto

| Dimensión | Estado |
|-----------|--------|
| Pipeline E2E (4 stages) | ✅ completado |
| Scope enforcement | ✅ activo |
| HITL bloqueante + auto-approve por ROE | ✅ funcionando (incl. timeout #101) |
| Recuperación agéntica ante timeout nmap | ✅ demostrada |
| Persistencia findings (Mongo) | ✅ 20 findings |
| Enriquecimiento ATT&CK/CVE/CVSS | ✅ ejecutado · ⚠️ **calidad de CVEs por auditar** (§7) |
| Generación de reportes PDF | ✅ 2 PDFs |
| Cierre de engagement | ✅ `completed` |

**Conclusión:** la maquinaria del prototipo está **operativa de extremo a
extremo** sobre un target real. El siguiente paso es una **sesión de verificación
de hallazgos** (§7) que separe los findings reales de los falsos positivos del
LLM y produzca un plan de corrección/hardening.
