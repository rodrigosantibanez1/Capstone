# Grafo de conocimiento del código — Reporte traducido y explicado (2026-06-11)

> Traducción + interpretación en español del `GRAPH_REPORT.md` que genera
> **graphify** (grafo de conocimiento del código construido por AST, sin LLM).
> Acompaña a la visualización interactiva [`grafo-sistema-2026-06-11.html`](grafo-sistema-2026-06-11.html)
> (abrir en el navegador) y al `graphify-out/graph.json` (datos crudos D3).
>
> **Repo analizado:** `CapstoneCode/` completo (backend Python + frontend React + docs).
> **Generado con:** `graphify update` + `graphify cluster-only --no-label` (regenerado desde cero).

---

## 0. Cómo leer este grafo (qué es cada cosa)

- **Nodo** = una pieza de código (función, clase, componente React, módulo) o
  una sección de un `.md`. graphify indexó **también la documentación**, por eso
  varias "comunidades" son en realidad capítulos de docs (`lab-setup`, ADR-005,
  este informe, etc.).
- **Arista (edge)** = una relación: una función llama a otra, una clase usa a
  otra, un módulo importa a otro. `EXTRACTED` = leída del AST (segura);
  `INFERRED` = deducida por heurística (confianza ~0.68, **verificar antes de
  confiar**).
- **Comunidad** = grupo de nodos muy conectados entre sí (clustering Leiden).
  En la práctica, cada comunidad ≈ un **módulo o responsabilidad** del sistema.
- **God node** = nodo con muchísimas conexiones. Puede ser una buena abstracción
  central… o un punto único de acoplamiento a vigilar.
- **Betweenness (centralidad de intermediación)** = qué tan "puente" es un nodo
  entre comunidades. Alta = si lo tocás, el impacto se propaga lejos.

---

## 1. Resumen (traducido)

- **1325 nodos · 2162 aristas · 98 comunidades** (86 mostradas, 12 "delgadas" omitidas).
- Extracción: **84% EXTRACTED · 16% INFERRED · 0% AMBIGUOUS**. 342 aristas inferidas
  (confianza media 0.68).
- Costo en tokens: **0** (construcción por AST puro, sin LLM).

**Lectura:** el grafo es mayormente confiable (84% leído directo del código). El
16% inferido se concentra en utilidades muy usadas (`cn()`, `utc_now()`) y en el
contrato de agentes — son las relaciones que conviene mirar con ojo crítico (§5).

---

## 2. God nodes (los más conectados = tus abstracciones centrales)

| # | Nodo | Aristas | Qué es | Lectura |
|---|------|---------|--------|---------|
| 1 | `cn()` | 94 | Util del frontend (clsx + tailwind-merge) que arma classNames | Sano: es el helper que TODO componente shadcn/ui usa. Acoplamiento esperado, no es deuda. |
| 2 | `utc_now()` | 37 | Helper de timestamp UTC (reemplaza `datetime.utcnow()` deprecado) | Puente transversal del backend. Sano pero crítico: lo usan agentes, HITL, persistencia. |
| 3 | `BaseAgent` | 29 | Contrato común de los 4 agentes (ADR-005, Bloque 0) | **Núcleo de diseño correcto:** que sea god node confirma que los 4 workers comparten contrato. |
| 4 | `AgentContext` | 27 | Entrada estándar de cada agente (scope + ROE + estado previo) | Idem — la pieza que homogeniza el pipeline. |
| 5 | `AgentResult` | 27 | Salida estándar de cada agente (status + rationale + artifacts) | Idem. |
| 6 | `PipelineController` | 27 | Orquesta los 4 stages end-to-end | Puente esperado: conecta routers, agentes y observabilidad. |
| 7 | `is_target_in_scope()` | 24 | **Scope enforcement programático (HU-02)** | Que sea god node es **bueno**: confirma que el control de scope toca todas las tools activas. |
| 8 | `AnalysisAgent` | 22 | Agente de análisis (CVE/ATT&CK) | Subió de importancia con el hardening de esta semana. |
| 9 | `ScanAgent` | 22 | Agente de escaneo goal-driven | Núcleo del pipeline. |
| 10 | `normalize_nikto_findings()` | 21 | Normalizador de salida nikto | Alto grado por los tests + el fix catch-all reciente. |

> **Conclusión:** los god nodes del backend son los **correctos por diseño**
> (contrato de agentes + scope check + orquestador), no acoplamiento accidental.
> El único god node "de plomería" es `cn()` en el frontend, que es normal en
> proyectos shadcn/ui.

---

## 3. Conexiones sorprendentes (las que probablemente no sabías)

Todas son **INFERRED** (heurísticas, confianza ~0.68) — útiles como pistas, no como verdad:

| Relación inferida | Archivos | ¿Real? |
|---|---|---|
| `ScopeCreate --usa--> EngagementStatus` | routers/scope.py → models.py | Plausible (el scope vive dentro del ciclo de vida del engagement). |
| `test_agent_context… --llama--> ROE` | tests → schemas.py | Real (el test construye un ROE). |
| `Session --usa--> PipelineController` | orchestrator_agent.py → pipeline_controller.py | Real (el orquestador dispara el pipeline). |
| `AppShell() --llama--> cn()` | App.jsx → lib/utils.js | Real (todo componente usa `cn`). |
| `EngagementSelector() --llama--> cn()` | components → lib/utils.js | Real. |

**Lectura:** ninguna es una sorpresa preocupante; son acoplamientos legítimos que
el AST no vio directo pero la heurística acertó.

---

## 4. Ciclos de import

```
main.py -> main.py
utils.py -> utils.py
routers/__init__.py -> routers/__init__.py
```

**Traducción:** son **auto-ciclos de 1 archivo** (un archivo que se referencia a
sí mismo en el grafo). **No son ciclos de dependencia reales** — son un artefacto
de cómo graphify cuenta referencias internas (p.ej. `routers/__init__.py`
re-exporta sus propios símbolos). **No hay ciclos multi-archivo**, que serían los
problemáticos. ✅ El refactor de `main.py → routers/` (Sesión D) dejó el grafo
limpio de import cycles reales.

---

## 5. Brechas de conocimiento (Knowledge Gaps)

- **247 nodos aislados** (≤1 conexión): `TargetType`, `AsyncIOMotorClient`,
  `HitlDecision`, `Request`, `Engine`, etc.
  - **Traducción:** son en su mayoría **tipos importados de librerías** (Motor,
    FastAPI, SQLAlchemy) y enums que se usan en un solo lugar. No es deuda — el
    AST no les ve "salida" porque solo se instancian/anotan. Algunos sí podrían
    indicar componentes poco integrados, pero el grueso es ruido esperable.
- **12 comunidades delgadas (<3 nodos) omitidas** del reporte.

---

## 6. Preguntas que este grafo está en posición única de responder

graphify sugiere preguntas basadas en centralidad. Traducidas e interpretadas:

1. **¿Por qué `utc_now()` conecta 12 comunidades?** (betweenness 0.079, el puente
   #1). → Porque el timestamp UTC se usa en agentes, HITL, persistencia, runs,
   reportes. **Riesgo:** cambiar su semántica (p.ej. pasar a TZ-aware) impacta
   ancho. **Mitigación:** ya está centralizado en un único helper — correcto.
2. **¿Por qué `PipelineController` conecta 9 comunidades?** (betweenness 0.053). →
   Es el orquestador; toca routers, los 4 agentes, observabilidad y el ejecutor
   seguro. Acoplamiento **por diseño**.
3. **¿Por qué `AnalysisAgent` conecta 9 comunidades?** (betweenness 0.032). →
   Tras el hardening de esta semana, el AnalysisAgent toca: schemas, mongo,
   utils, el **gate de confianza (Community 12)**, el ejecutor, el reporter y
   findings. Subió su centralidad — esperado.
4. **¿Las 93 aristas inferidas de `cn()` son correctas?** → Casi todas sí
   (cualquier componente usa `cn`); es ruido de alto volumen, no deuda.
5. **¿Las 34 inferidas de `utc_now()` son correctas?** → Sí en su mayoría; verificar
   las pocas hacia funciones que no manejan tiempo.

---

## 7. Mapa comunidad → módulo del sistema (lo más útil)

graphify numera las comunidades sin nombre; aquí las traduzco a **responsabilidades
reales** del ETH-MAS (solo las de código relevantes; las de docs se omiten):

| Comunidad | Cohesión | Módulo del sistema | Archivos clave |
|-----------|----------|--------------------|----------------|
| C0 | 0.05 | **Schemas Pydantic** (API) | `schemas.py`, `mongo_schemas.py` (AnalysisDoc, EngagementCreate…) |
| C1 | 0.06 | **Frontend — primitivas UI** (shadcn) | `cn()`, `Card*`, `ApiKeyModal` |
| C2 | 0.09 | **OSINT MCP** (ReconAgent tools) | `dns_enum`, `whois_lookup`, `theharvester_run` |
| C3 | 0.08 | **ScanAgent + política de intensidad** | `ScanAgent`, `ScanPolicy` (deriva flags del ROE) |
| **C4** | 0.08 | **Analysis MCP** (NVD + ATT&CK) ⭐ | `cve_lookup`, `_parse_cpe`, `_build_virtual_match`, `attack_technique_lookup` |
| C5 | 0.09 | **Router pipeline** | `routers/pipeline.py` (recon/scan/analysis) |
| C7 | 0.10 | **Security MCP** (tools activas) | `nmap_scan`, `nuclei_run`, `nikto_scan`, `gobuster_run` |
| **C8** | 0.10 | **Normalizadores de findings** ⭐ | `normalize_gobuster_findings`, `normalize_nikto_findings` |
| C11 | 0.13 | **PipelineController** (orquestación 4 stages) | `pipeline_controller.py` |
| **C12** | 0.11 | **Gate de confianza CVE** (nuevo, 2026-06-11) ⭐ | `_gate_cve_confidence`, `_build_cve_details`, `_finding_has_version`, `_ag_parse_cpe_version` |
| C14 | 0.16 | **Cliente Mongo** | `mongo_client.py` (cols + `ensure_indexes`) |
| C17 | 0.10 | **Bootstrap FastAPI** (lifespan) | `main.py` (`lifespan`, `_expire_orphan_pending_hitl`) |
| C18 | 0.17 | **AnalysisDoc / contrato análisis** | blackboard + AnalysisDoc |
| **C20** | 0.15 | **ReporterAgent** ⭐ | `_applicable_cves`, `_compose_context`, `_is_reportable`, `_fallback_narrative` |
| C21 | 0.12 | **Auth + Health routers** | `auth.py` (verify_api_key), `routers/health.py` |
| C23 | 0.16 | **Persistencia de findings** | `FindingDoc`, `_compute_dedup_key`, `_parse_nikto_csv`, `persist_finding` |
| C28 | 0.18 | **Tiering de modelos** | `agent_config.py` (qué modelo va en cada agente) |
| C33 | 0.19 | **Router orquestador** (chat SSE) | `routers/orchestrator.py` |
| C36 | 0.24 | **Router engagements** | `routers/engagements.py`, `EngagementStatus` |
| C39 | 0.24 | **Contrato de agentes** (Bloque 0) | `agent_base.py` (BaseAgent, AgentContext, build_agent_context) |
| C42 | 0.17 | **Schemas Mongo de runs** | `AgentRunDoc`, `PipelineRunDoc`, `StageEntry` |
| C43 | 0.21 | **Router HITL** | `routers/hitl.py` (decide/expire/list) |
| C44 | 0.24 | **Ejecutor seguro** | `WaitingHitlError`, `ReporterAgent`, `_run_stage` |
| **C47** | 0.20 | **Router findings + compat CVE** ⭐ | `get_findings`, `_derive_compat_cve_fields`, refinamiento scanner |
| C58 | 0.25 | **Router reports** (GridFS) | `routers/reports.py` (launch/list/download) |
| C59 | 0.31 | **Router scope** (HU-01/02) | `routers/scope.py`, `validate_target` |
| C63 | 0.36 | **Render de reportes** | `report_renderer.py` (Jinja2 + WeasyPrint) |
| C66 | 0.38 | **Modelos SQLAlchemy** (Postgres) | `Engagement`, `HitlAction`, `ScopeTarget`, `TargetType` |
| C67 | 0.33 | **Migraciones Alembic** | `alembic/env.py` |
| C69 | 0.40 | **Bootstrap Alembic** | `alembic_bootstrap.py` |

⭐ = comunidades que tocó el hardening anti-falsos-positivos de esta semana.
**Dato bonito:** el código nuevo del gate de confianza formó su **propia comunidad
cohesiva (C12)** y los helpers CPE cayeron en la comunidad del Analysis MCP (C4) —
señal de que el cambio quedó bien encapsulado, no disperso.

---

## 8. Veredicto de salud del grafo

| Señal | Estado | Lectura |
|-------|--------|---------|
| God nodes | 🟢 | Son contrato de agentes + scope check (diseño correcto), no acoplamiento accidental. |
| Ciclos de import | 🟢 | Solo auto-ciclos benignos; cero ciclos multi-archivo. |
| Cohesión por comunidad | 🟡 | Las comunidades de routers/servicios tienen cohesión media-alta (0.2-0.5); las de schemas son bajas (0.05) por ser "bolsas" de tipos — esperable. |
| Encapsulamiento del cambio nuevo | 🟢 | El gate de confianza quedó en su propia comunidad (C12); los helpers CPE en el Analysis MCP (C4). |
| Nodos aislados | 🟡 | 247, casi todos tipos de librería; revisar puntualmente si alguno es un componente huérfano real. |

---

## 9. Artefactos relacionados

- **Visualización interactiva:** [`grafo-sistema-2026-06-11.html`](grafo-sistema-2026-06-11.html) (1.1 MB, abrir en navegador).
- **Datos crudos:** `CapstoneCode/graphify-out/graph.json` (formato D3: nodos + `links`).
- **Reporte original (inglés):** `CapstoneCode/graphify-out/GRAPH_REPORT.md`.
- **Documentación + diagramas del sistema:** [`arquitectura-sistema-diagramas-2026-06-11.md`](arquitectura-sistema-diagramas-2026-06-11.md).

> `graphify-out/` está en `.gitignore` (artefactos regenerables). Para regenerar:
> borrar `graphify-out/` y correr `graphify update CapstoneCode` +
> `graphify cluster-only CapstoneCode --no-label`.
