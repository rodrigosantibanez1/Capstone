# Guía de pruebas — Fixes de reportes/análisis/orquestador (B1–B8)

> Para el **operador**. Cómo verificar, sin tocar código, los 8 arreglos de la
> rama `fix/report-orchestrator-bugs-b1-b8`. Tiempo estimado: ~20 min.

**Rama:** `fix/report-orchestrator-bugs-b1-b8` (commit `c674528`)
**Targets del lab:** `10.42.0.10` (Metasploitable2) · `10.42.0.20` (DVWA)

---

## 0. Preparar el entorno

```bash
cd CapstoneCode
git checkout fix/report-orchestrator-bugs-b1-b8
docker compose --profile lab up -d
```

Verificar que todo está arriba:

```bash
docker ps --format "table {{.Names}}\t{{.Status}}"
```

Debe listar `eth_mas_backend`, `eth_mas_postgres`, `eth_mas_mongo`,
`eth_mas_frontend`, `eth_mas_lab_ms2`, `eth_mas_lab_dvwa`.

- **UI:** http://localhost:5173 (o el puerto que muestre el frontend)
- **API:** http://localhost:8000

> ⚠️ **Importante:** el scope se define **por IP explícita** (`10.42.0.10`,
> `10.42.0.20`), nunca por CIDR (`10.42.0.0/24`).

---

## 1. Crear un engagement y correr el pipeline completo

Desde la UI (vista **Engagements → Nuevo**) o por API:

```bash
curl -s -X POST http://localhost:8000/engagements \
  -H "Content-Type: application/json" \
  -d '{"name":"Prueba fixes B1-B8","client_name":"QA",
       "scope_targets":[{"target_value":"10.42.0.10","target_type":"ip"}]}'
```

Anotá el `id` que devuelve (lo llamamos `<ID>`).

Lanzá el **pipeline completo** desde la vista **Pipeline** (botón Ejecutar) o:

```bash
curl -s -X POST http://localhost:8000/engagements/<ID>/pipeline
```

El ScanAgent va a **pausar pidiendo aprobación HITL** (tráfico activo, risk ≥
medium). Ve a la **consola HITL** y **aprueba** las acciones pendientes. El
pipeline sigue: Scan → Analysis → Reporte.

> Si el scan queda bloqueado por HITL viejos: en la consola HITL usa
> **"Limpiar pendientes"** (o `POST /engagements/<ID>/hitl-actions/expire-pending`).

Cuando termine, sigue con las verificaciones de abajo.

---

## 2. Qué verificar (uno por fix)

### ✅ B1 — El PDF ya no dice "running"
**Antes:** el PDF mostraba *Estado: running* aunque la UI decía *completed*.

1. En la lista de engagements, el engagement debe quedar en **`completed`** solo
   (sin cerrarlo a mano).
2. Descargá el reporte (vista **Reportes** → técnico y ejecutivo).
3. En la primera tabla del PDF, **`Estado` debe decir `completed`** en ambos.

✔️ Pasa si UI y PDF coinciden en `completed`.

---

### ✅ B2 — Severidad coherente con el CVSS
**Antes:** un hallazgo con CVSS 9.8 podía figurar como *Medium*.

1. Vista **Hallazgos** del engagement.
2. Buscá un hallazgo con un **CVE confirmado** y CVSS alto (≥ 9.0).
3. Su **severidad debe ser `critical`** (no medium/high).

✔️ Pasa si ningún hallazgo con CVSS ≥9 confirmado queda por debajo de critical.

> Nota: si el CVE quedó **"sin confirmar"** (no se validó la versión), el sistema
> **no** le muestra CVSS ni sube la severidad — eso es correcto (ver B4).

---

### ✅ B3 — Vectores "CRITICAL" aclarados
**Antes:** el reporte hablaba de vectores CRITICAL aunque el conteo decía 0 críticos.

1. En el **PDF técnico**, sección **"Vectores de ataque"**.
2. Debe aparecer la nota: *"La severidad de cada vector indica el impacto
   potencial de la cadena… no la severidad observada de un hallazgo individual"*.
3. Cada vector muestra el badge **"{severidad} potencial"** (ej. `critical potencial`).

✔️ Pasa si la distinción impacto-potencial vs severidad-observada está explícita.

---

### ✅ B4 — Confianza de cada CVE visible
**Antes:** no se distinguía un CVE confirmado de uno sin confirmar.

1. Vista **Hallazgos**: junto a cada CVE hay una marca **✓** (confirmado) o
   **?** (sin confirmar). Pasá el mouse para ver el detalle.
2. En el **PDF técnico**, la columna CVE muestra **`confirmado`** o
   **`sin confirmar`** por cada CVE.

✔️ Pasa si se ve el estado de confianza por CVE en UI y PDF.

---

### ✅ B5 — Mapeo MITRE estable entre corridas
**Antes:** el mismo hallazgo alternaba de técnica (p. ej. T1190 ↔ T1210).

1. Ejecuta el análisis dos veces sobre el mismo engagement:
   ```bash
   curl -s -X POST http://localhost:8000/engagements/<ID>/analysis >/dev/null
   curl -s "http://localhost:8000/engagements/<ID>/findings?limit=50" \
     | python -c "import sys,json;print({ (f.get('evidence') or {}).get('port'): f.get('mitre_technique') for f in json.load(sys.stdin)['findings']})"
   # repetir las dos líneas y comparar la salida
   ```
2. Las dos salidas deben ser **idénticas**.

✔️ Pasa si la técnica ATT&CK por puerto no cambia entre corridas.

---

### ✅ B6 — Sin viñetas vacías en el PDF
**Antes:** aparecían bullets vacíos en Recomendaciones / pasos de vectores.

1. En ambos PDFs, revisa **Recomendaciones** y los pasos de los vectores.
2. **No debe haber viñetas en blanco**.

✔️ Pasa si todas las viñetas tienen texto.

---

### ✅ B7 — Reporte ejecutivo sin jerga técnica
**Antes:** el ejecutivo repetía la misma narrativa técnica del reporte técnico.

1. Abre el **PDF ejecutivo** y el **técnico**.
2. El párrafo de análisis del **ejecutivo** debe hablar de **riesgo de negocio /
   exposición / prioridad**, sin nombrar CVEs, puertos ni herramientas.
3. Debe ser **distinto** del párrafo técnico.

✔️ Pasa si la narrativa ejecutiva es de alto nivel y diferente a la técnica.

---

### ✅ B8 — El orquestador ejecuta de verdad
**Antes:** el orquestador respondía en el chat pero el engagement quedaba en
`pending` sin acciones.

1. Vista **Orquestador (chat)** del engagement.
2. Escribe una instrucción (ej. *"haz reconocimiento del scope"*).
3. **En modo Plan:** muestra un preview y aparece el botón **"Ejecutar este plan"**.
4. Haz clic en **"Ejecutar este plan"** (o cambia el toggle a **Ejecutar** y envía).
5. Verifica:
   - El engagement pasa a **`running`** (lista de engagements).
   - En el chat aparecen turnos de **delegación** (ej. *"Delegué en ReconAgent…"*).

✔️ Pasa si en modo Ejecutar el estado pasa a `running` y se ven delegaciones reales.

> Recuerda: el orquestador **no** aprueba HITL por chat. Si un worker queda
> esperando aprobación, ve a la **consola HITL**.

---

## 3. Resumen rápido

| Fix | Dónde mirar | Resultado esperado |
|-----|-------------|--------------------|
| B1 | PDF (técnico/ejecutivo) → Estado | `completed`, no `running` |
| B2 | Hallazgos | CVSS ≥9 confirmado ⇒ severidad `critical` |
| B3 | PDF técnico → Vectores | nota "impacto potencial" + badge "{sev} potencial" |
| B4 | Hallazgos + PDF técnico | marca ✓/? · `confirmado`/`sin confirmar` |
| B5 | Análisis ×2 | técnica MITRE idéntica entre corridas |
| B6 | PDF (ambos) | sin viñetas vacías |
| B7 | PDF ejecutivo vs técnico | narrativa ejecutiva sin jerga y distinta |
| B8 | Chat orquestador | "Ejecutar" ⇒ `running` + delegaciones |

Si algo no se comporta como aquí, anota el `id` del engagement y el paso, y
avisa al equipo para revisarlo.
