# Guion de defensa Capstone — 20 min (v0.4)

> **Formato:** 20 minutos · **10 min presentación** + **10 min demo en vivo**.
> **Demo:** ETH-MAS corriendo un engagement sobre el laboratorio (Metasploitable2 `10.42.0.10` +
> DVWA `10.42.0.20`) **a través del orquestador conversacional**, en tiempo real, con un engagement
> **ya persistido** como evidencia primaria y red de seguridad.
> **Regla de oro:** la demo NO depende de una corrida en vivo exitosa. La corrida en vivo es para
> mostrar el **chat del orquestador + SSE + HITL**; los **datos persistidos** son la evidencia.
> Evoluciona [`guion-demo-viernes-2026-06-19.md`](guion-demo-viernes-2026-06-19.md).

---

## 0. Pre-demo (5–10 min antes) — checklist rápido

```bash
cd CapstoneCode
docker compose --profile lab up -d
ETH_MAS_API_KEY=<tu-key> ./scripts/smoke_engagement.sh   # debe dar 6/6 PASS
```

- [ ] 6 contenedores Up · `GET /health/services` → `overall: up`.
- [ ] `.env` con tiering **Opus/Sonnet** activado (mejor razonamiento del orquestador en vivo).
- [ ] Engagement **persistido** del lab visible en el selector, status `completed`.
- [ ] **Backend sin `--reload`** (estabilidad) y **no editar archivos** durante la demo.
- [ ] 2 PDFs (técnico + ejecutivo) a mano como fallback.
- [ ] Abierta la línea base: [`reporte-laboratorio-vulnerabilidades-v0.4.md`](reporte-laboratorio-vulnerabilidades-v0.4.md)
      y el contraste [`contraste-lab-vs-engagement-v0.4.md`](contraste-lab-vs-engagement-v0.4.md).

---

## Parte 1 — Presentación (10 min)

### 1.1 Problema y propuesta (2 min)
- El pentesting manual no escala; las herramientas sueltas generan ruido y falsos positivos.
- **ETH-MAS:** pipeline de pentesting **asistido por IA con control humano** — 4 agentes LLM
  (Recon → Scan → Analysis → Reporter) coordinados por un **orquestador conversacional** sobre un
  blackboard compartido.

### 1.2 Las 3 garantías de identidad técnica (3 min) — *el corazón del proyecto*
1. **Scope enforcement programático** — la autorización del target se valida **en código Python**
   (`scope_validator.py`), no en el prompt. El LLM **no puede** saltárselo.
2. **HITL (Human-in-the-Loop)** — toda acción de riesgo medio+ **bloquea** esperando aprobación
   humana explícita por consola. El orquestador **no aprueba por chat**.
3. **MITRE ATT&CK** — cada finding se mapea a táctica/técnica de forma **determinística**.

### 1.3 Arquitectura (3 min)
- Orquestador (LLM) → delega en workers vía **ejecutor seguro** (`PipelineController`).
- Persistencia dual: **PostgreSQL** (engagements, scope, HITL) + **MongoDB** (findings, analysis,
  conversación, reportes en GridFS).
- Mostrar el diagrama productivo (`docs/despliegue-produccion-gcp-onprem.drawio`): el lab vulnerable
  **nunca** se expone — vive aislado on-prem (`10.42.0.0/24`).

### 1.4 Rigor y calidad (2 min)
- **Línea base verificable** del lab con fuentes públicas (NVD/CVE, Samba, Rapid7, OWASP) —
  [`reporte-laboratorio-vulnerabilidades-v0.4.md`](reporte-laboratorio-vulnerabilidades-v0.4.md).
- **Disciplina anti-falsos-positivos**: gate de CVE por CPE+versión, degradado de hallazgos nikto
  ante catch-all (hardening documentado). Tests verdes + CI en el repo.

---

## Parte 2 — Demo en vivo (10 min)

### 2.1 Crear engagement + scope por el **chat del orquestador** (2 min)
- UI → tab **Orquestador** del engagement con scope `10.42.0.10`.
- Escribir en lenguaje natural: *"Quiero auditar el host 10.42.0.10 del laboratorio."*
- Modo **Planificar** → el orquestador devuelve un **plan numerado** (qué worker, qué objetivo).
  *Punto a destacar:* el LLM **planifica con libertad**, pero la ejecución está blindada.

### 2.2 Scope enforcement en vivo (1 min)
- Mostrar validación: `1.1.1.1` → **DENEGADO**, `10.42.0.10` → **AUTORIZADO**.
- Mensaje clave: la validación es **programática**; el LLM no la sortea.

### 2.3 Ejecutar + SSE + HITL (3 min)
- Cambiar a modo **Ejecutar** → el chat empieza a **stream-ear turnos** (SSE):
  ReconAgent completa, ScanAgent arranca y **delega**.
- Cuando el ScanAgent pide **HITL** (nmap), mostrar la cola de aprobaciones y **aprobar en vivo**
  → el pipeline **resume** (HITL bloqueante real).
- *No esperar los ~8–11 min completos.* Cortar aquí y pasar a la evidencia persistida.

### 2.4 Resultados sobre el engagement **persistido** (3 min) — *la pestaña estelar*
- Cambiar el selector al engagement **completed** del lab.
- **Findings:** filtros por severidad/herramienta (nmap + nuclei + nikto + gobuster).
- **Analysis:** riesgo priorizado con CVE/CVSS; **popover MITRE** (hover sobre T1190 → nombre,
  táctica, link a `attack.mitre.org`); **heatmap** de cobertura + **kill chains**.
- **Reports:** descargar **PDF técnico** y **PDF ejecutivo** (lenguaje de negocio, sin jerga).

### 2.5 Contraste con la línea base (1 min) — *cierre potente*
- Abrir [`contraste-lab-vs-engagement-v0.4.md`](contraste-lab-vs-engagement-v0.4.md):
  "esto es lo que el lab **debía** revelar (fuentes públicas) y esto es lo que el sistema
  **encontró**". Mostrar cobertura y cómo la **disciplina anti-falsos-positivos** explica las
  diferencias (un CVE ausente por versión no confirmada es comportamiento **correcto**).
- Mencionar el segundo target: **DVWA** (`10.42.0.20`) demuestra que el pipeline corre también
  sobre una **app web**, no solo servicios de red.

---

## Plan de respaldo (si algo falla en vivo)

| Falla | Respaldo |
|-------|----------|
| Docker/stack no levanta | Mostrar los 2 PDFs + capturas de la UI + la línea base documentada. |
| Chat/orquestador se cuelga o el LLM no responde | Saltar directo al engagement **persistido** (`completed`). |
| HITL no resume | Mostrarlo como **feature** (bloqueo real) y pasar a datos persistidos. |
| Descarga de PDF falla | PDFs locales pre-descargados a mano. |
| Backend crashea (watcher) | `docker compose up -d backend` lo revive en ~10s; los datos persistidos intactos. |

---

## Mensajes de cierre (para la comisión)
- **Lo demostrado:** un sistema que **planifica con IA, ejecuta con guardarraíles en código y deja a
  la persona al mando** de toda acción sensible.
- **Lo medible:** resultados contrastados contra una línea base con fuentes públicas — no contra la
  opinión del modelo.
- **Lo honesto:** límites conscientes del MVP (explotación profunda de payloads web fuera de
  alcance; OSINT no aplica a IPs privadas) declarados explícitamente.

---

**Documento:** `docs/guion-defensa-capstone-v0.4.md` · rama `release/v0.4`.
