# ETH-MAS — Guión de demo (presentación evaluada · vie 2026-06-19)

> Script paso a paso para la demo en vivo + plan de respaldo. Pensado para ~10-12
> min de demo. Los engagements **#26 (Metasploitable2)** y **#27 (DVWA)** quedan
> **pre-corridos y persistidos** como evidencia y fallback: si algo falla en vivo,
> se muestran ellos sin re-ejecutar.

---

## 0. Pre-demo (5-10 min antes) — checklist

```bash
cd CapstoneCode
docker compose --profile lab up -d
```

- [ ] **6 contenedores up:** `docker compose ps` → backend, frontend, mongo, postgres, lab_ms2, lab_dvwa.
- [ ] **Health verde:** `curl http://localhost:8000/health/services` → `overall: up`
      (postgres, mongo, osint_mcp, security_mcp, anthropic key validada).
- [ ] **Frontend:** abrir `http://localhost/` y loguear (admin simulado).
- [ ] **Evidencia lista:** confirmar que #26 y #27 aparecen en el selector de engagements, ambos `completed`.
- [ ] **(Recomendado) backend sin `--reload`** para estabilidad en vivo — evita el
      `OSError` del watcher si se toca un archivo. Override temporal: en
      `docker-compose.yml`, comando del backend sin `--reload`, o levantar con un
      `docker-compose.override.yml`. Si no se hace, **no editar archivos durante la demo**.
- [ ] Tener a mano los 2 PDFs (técnico + ejecutivo) de #26 por si falla la descarga en vivo.

---

## 1. Contexto (1 min)

- **ETH-MAS** = pipeline de pentesting asistido por IA con control humano.
- 4 agentes LLM (Recon → Scan → Analysis → Reporter) orquestados sobre un blackboard.
- **3 garantías de identidad técnica:**
  1. **Scope enforcement programático** (en código Python, no en el prompt).
  2. **HITL** (aprobación humana antes de acciones de riesgo).
  3. **MITRE ATT&CK** (todo finding mapeado a táctica/técnica).
- Mostrar el diagrama de arquitectura productiva (`docs/despliegue-produccion-gcp-onprem.drawio`).

## 2. Crear engagement + scope + ROE (2 min)

- UI → **Nuevo engagement**.
- **Scope:** `10.42.0.10` (IP explícita — lab Metasploitable2).
- **ROE:** mostrar intensidad de escaneo, paths excluidos, rate limit.
  *Punto a destacar:* ya **no hay "ventanas de tiempo"** — la ejecución ocurre cuando
  el operador inicia el pipeline (simplificación pedida por el equipo).
- **Tácticas ATT&CK:** seleccionar Reconnaissance + Discovery + Initial Access.
- Crear.

## 3. Scope enforcement (1 min)

- Mostrar `GET /engagements/{id}/validate` o la UI de validación:
  - `1.1.1.1` → **DENEGADO** (fuera de scope).
  - `10.42.0.10` → **AUTORIZADO**.
- Mensaje clave: la validación es **programática**, el LLM no puede saltársela.

## 4. Pipeline + HITL en vivo (2 min)

- Tab **Pipeline** → seleccionar los 4 stages → **Lanzar Pipeline**.
- Mostrar el **stepper en vivo (SSE):** ReconAgent completa, ScanAgent arranca.
- Cuando el ScanAgent pide **HITL** (nmap), mostrar la cola de aprobaciones embebida
  y **aprobar en vivo** → el pipeline **resume** (HITL bloqueante real).
- *No esperar los ~11 min completos.* Cortar aquí y pasar a los resultados pre-corridos (#26).

## 5. Resultados sobre #26 (pre-corrido) (3-4 min)

Cambiar el selector a **#26 — corrida 4/4 .10**. (Header muestra `completed`.)

- **Findings (38):** filtros por severidad/herramienta; nmap + nuclei + nikto + gobuster.
- **Analysis** (la pestaña estelar):
  - Riesgo priorizado con CVE/CVSS.
  - **Popover MITRE:** *hover sobre una técnica (ej. T1190)* → ventana con nombre,
    táctica, explicación y **link a attack.mitre.org**. (Feature nuevo.)
  - **Heatmap** de cobertura ATT&CK + **kill chains** expandibles.
  - Punto a destacar: el mapeo MITRE es **determinístico** (re-analizar da el mismo
    resultado — estabilidad validada).
- **Reports:**
  - Descargar **PDF técnico** (detalle: puertos, servicios, CVEs, evidencia, ATT&CK).
  - Descargar **PDF ejecutivo** — mostrar que está **en lenguaje de negocio, sin jerga**
    (sin tags de herramienta, sin CVE-IDs crudos, riesgos traducidos).

## 6. (Opcional) DVWA #27 (1 min)

- Cambiar a **#27 — DVWA**: segundo target del lab, 12 findings web (nikto/gobuster).
- Demuestra que el pipeline funciona sobre una app web, no solo sobre servicios de red.

## 7. Cierre (1 min)

- **Calidad:** 179 tests verdes, CI en el repo, métricas en `docs/metricas-calidad-hu21.md`.
- **Arquitectura productiva:** repasar el doc GCP/on-prem (híbrido de dos planos; el
  lab vulnerable **nunca** se expone — vive aislado on-prem). Es la entrega "to-be"
  hacia la defensa Capstone.
- **Estado:** v0.3 en `release/v0.3`, PR a `main` abierto.

---

## Plan de respaldo (si algo falla en vivo)

| Falla | Respaldo |
|-------|----------|
| Docker/stack no levanta | Mostrar los 2 PDFs de #26 + capturas de la UI. |
| Pipeline en vivo se cuelga | Saltar directo a #26/#27 (ya persistidos, `completed`). |
| Descarga de PDF falla | PDFs locales pre-descargados a mano. |
| Backend crashea (watcher) | `docker compose up -d backend` lo revive en ~10s; #26/#27 intactos. |

**Regla de oro:** la demo NO depende de una corrida en vivo exitosa — #26 y #27
están pre-corridos y son la evidencia primaria. La corrida en vivo es solo para
mostrar el HITL y el SSE.
