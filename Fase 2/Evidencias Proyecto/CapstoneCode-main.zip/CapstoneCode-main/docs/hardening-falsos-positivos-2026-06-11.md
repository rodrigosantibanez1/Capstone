# Hardening anti-falsos-positivos — pasada de calidad (2026-06-11)

> Sesión de calidad sobre el pipeline Scan→Analysis→Report tras la verificación
> del engagement #24 ([`verificacion-hallazgos-mypc-2026-06-10.md`](verificacion-hallazgos-mypc-2026-06-10.md)).
> Objetivo: endurecer las defensas contra los falsos positivos del LLM de forma
> **determinística** (validación en código, no en prompt) y re-validar contra los
> datos reales de #24 sin re-escanear.
>
> **Rama:** `fix/cve-applicability-fp-hardening` · **Tests:** 150 verdes
> (128 previos + 22 nuevos) · **Re-validación:** runtime sobre engagement #24.

---

## 1. Resumen

Se cerraron 8 bugs del camino crítico (con `archivo:línea`) y se agregaron dos
capas de robustez: **gate de confianza CVE** (determinístico) y **degradación
catch-all** (soft-200) para scanners web. El re-run del AnalysisAgent sobre #24
**eliminó el CVSS inflado de todos los falsos positivos** y conservó el riesgo
real (SMB/RPC/NetBIOS expuestos).

| Capa | Antes | Después |
|------|-------|---------|
| Correlación CVE | keyword-soup, sin versión, CVSS de otro CVE | match por CPE en NVD + gate de confianza en código; CVSS headline solo de CVE `confirmed` |
| Scanners web (nikto/gobuster) | todo 200 = hallazgo (cascada de FP) | sonda soft-200 activa → degradación a info/low_confidence |
| Reporter | propagaba cualquier CVE al PDF | excluye `keyword-only` y `false_positive`; marca `version-unknown` como no confirmado |

---

## 2. Bugs corregidos

| # | Bug | Archivo:línea | Fix |
|---|-----|---------------|-----|
| 1 | `parse_nmap_xml` descartaba el `<cpe>` | [nmap_service.py](../eth-mas-backend/services/nmap_service.py) | Captura `cpe`/`cpes` del `<service>` → `evidence.cpe` |
| 2a | nikto no capturaba el puerto (`port=null`) | [findings_service.py](../eth-mas-backend/services/findings_service.py) `_parse_nikto_csv` | Lee `row[2]` → `evidence.port` + `FindingDoc.port` |
| 2b | dedup_key nikto sin puerto → colisión :80/:8000 | `_compute_dedup_key` | Incluye puerto: `nikto\|target\|port\|id\|url` |
| 3 | `"shell"` desnudo en high-keywords → `shell history` = high | `_NIKTO_HIGH_KEYWORDS` | Reemplazado por `web shell`/`reverse shell`/`shellshock` |
| 4 | gobuster aceptaba todo `status<400` sin detección catch-all | `normalize_gobuster_findings` | Param `catchall` → degrada a info/low |
| 5 | `cve_lookup` usaba `keywordSearch`; caché por keyword | [analysis_server.py](../eth-mas-backend/mcp_servers/analysis_server.py) | Match por CPE (`virtualMatchString`); caché por CPE; devuelve `match_mode` |
| 6 | `_persist` sin gate de versión; un solo CVSS no trazado | [analysis_agent.py](../eth-mas-backend/services/analysis_agent.py) | Gate determinístico + `cve_details` por-CVE + CVSS confirmed-only |
| 7 | nmap timeout 300s hardcodeado | nmap_service.py | `NMAP_TIMEOUT_SECS` env (default 600) |
| 8 | ReporterAgent propagaba CVEs no aplicables | [reporter_agent.py](../eth-mas-backend/services/reporter_agent.py) | `_applicable_cves` + `_is_reportable` filtran el PDF |

---

## 3. Capas de robustez nuevas

### 3.1 Gate de confianza CVE (determinístico)

`cve_lookup` ahora consulta NVD con el **CPE** de nmap (`virtualMatchString`
con vendor comodín, producto+versión acotando) y devuelve `match_mode`:
`cpe_versioned` / `cpe_product` / `keyword`. El AnalysisAgent traduce eso a una
confianza por CVE, **decidida en código** (`services/analysis_agent.py`):

| confidence | significado | en el reporte |
|------------|-------------|---------------|
| `confirmed` | versión del servicio cae en el rango vulnerable (CPE match) | se muestra, aporta CVSS headline |
| `version-unknown` | producto coincide, sin versión para confirmar | se muestra **marcado "no confirmado"**, NO aporta CVSS headline |
| `keyword-only` | solo coincidió por texto → no aplicable | **excluido del reporte** |

**Reglas duras (no las puede sobreescribir el LLM):**
- Sin versión concreta del servicio, ningún CVE queda `confirmed` (se baja a `version-unknown`).
- El `cvss_score` headline del finding sale **solo de CVEs `confirmed`**; si no hay ninguno, queda `null`.
- El gate corre sobre **todos** los findings con CVE, no solo los que el LLM re-procesa
  (un CVE stale de un run anterior también se re-gatea).

### 3.2 Sonda soft-200 (catch-all) — `services` Security MCP

`nikto_scan` y `gobuster_run` (dir) emiten **una** request a una ruta aleatoria
inexistente antes de confiar en hallazgos por "200 = existe". Si responde 200, el
host es catch-all (SPA `try_files`/proxy) → el normalizador degrada esos findings
a `info` + `confidence=low`. La sonda:
- es **scope-validada** (`scope_validator`) explícitamente;
- corre **bajo la aprobación HITL del scan web padre** (mismo target/puerto,
  riesgo estrictamente menor: una GET benigna) — NO abre un segundo HITL para no
  doble-promptear al operador en cada scan web.

> **Interpretación de la decisión "sonda activa con HITL":** se honra
> `scope_validator` al pie de la letra y la sonda es tráfico activo gobernado por
> el HITL del nikto/gobuster que la dispara. Si se prefiere un HITL separado por
> sonda, es un cambio de una línea (registrar su propio `HitlAction`).

### 3.3 Refinamiento determinístico de scanners web

Independiente del LLM y de la sonda, el AnalysisAgent degrada a
`info`/`false_positive`/`low` los findings nikto/gobuster que:
- tienen `evidence.catchall == True` (sonda), **o**
- matchean una firma de FP fuerte (`home directory may be set to the web root`,
  `shell history`, `.bash_history`, `.sh_history`) — cubre findings **legacy**
  escaneados antes de que existiera la sonda (caso #24).

---

## 4. Re-validación runtime sobre engagement #24

Re-corrido **`POST /engagements/24/analysis`** sobre los 20 findings ya
persistidos (sin re-escanear). Nota: los findings de #24 fueron escaneados antes
del fix de captura de CPE, por lo que **no** tienen `evidence.cpe` → el re-run
ejercita el camino sin-CPE + el gate de versión + el refinamiento determinístico.

### 4.1 Antes / Después (findings sospechosos)

| Finding | Antes | Después |
|---------|-------|---------|
| nmap 135 (msrpc) | CVE-2003-0352/0003 · **CVSS 7.5** · high | CVEs → `version-unknown` · **CVSS null** · high (exposición real, sin CVE confirmado) |
| nmap 445 (SMB) | CVE-2003-0352 · **CVSS 7.5** · high | CVE → `keyword-only` · **CVSS null** · high (re-gateado aunque el LLM no lo tocó) |
| nmap 8000 (uvicorn) | CVE-2026-2652 · **CVSS 8.6** · medium | CVEs → `version-unknown` · **CVSS null** (el 8.6 de mlflow ya no pinta el finding) |
| nikto `.bash_history` | **high** · sin CVE | **info · false_positive · low** |
| nikto `.sh_history` | **high** · sin CVE | **info · false_positive · low** |
| nikto JAMon | CVE-2013-6235 · **CVSS 4.3** · high | CVE → `keyword-only` (**excluido del reporte**) · **CVSS null** |

**Resultado clave:** la columna CVSS de **todos** los falsos positivos quedó en
`null`; ningún FP se presenta ya como riesgo confirmado. El **riesgo real** se
conserva: SMB/RPC/NetBIOS (135/139/445) siguen `high` por exposición (sin CVE
inventado), y los headers HTTP faltantes siguen `low`.

### 4.2 Reporte regenerado

`POST /engagements/24/report` → **completed**, 2 PDFs (técnico 31.5 KB + ejecutivo
21.6 KB). `findings_count = 18` (20 − 2 `false_positive` excluidos por el reporter). ✅

### 4.3 Residuales honestos (limitaciones del re-run analysis-only)

1. **nikto JAMon sigue `severity=high`** (su CVE ya es `keyword-only`/excluido y
   CVSS null, pero la severidad se fijó en la fase Scan por la keyword "xss"). En
   un **re-escaneo real** la sonda soft-200 lo marcaría catch-all → `info/low`.
   No se sobre-ajustó el refinamiento a JAMon para no introducir heurística frágil.
2. **CVE-2026-2652 (mlflow) quedó `version-unknown`**, no `keyword-only`, porque
   #24 no tiene CPE almacenado. Con CPE (re-escaneo) la `virtualMatchString` de
   uvicorn **no devolvería** el CVE de mlflow → desaparecería del todo. Mientras
   tanto está marcado no-confirmado y con CVSS null.
3. **La narrativa del LLM del reporter** aún tiende a dramatizar (describe FPs
   como reales). Se acotó el system prompt del narrador (no llamar "crítico" a lo
   que no es severidad critical; CVEs como posibles, no confirmados), pero la
   prosa del LLM no es determinística — la **data estructurada** del reporte sí
   quedó limpia.

> Estas tres son inherentes a re-correr **solo** el AnalysisAgent sobre findings
> escaneados con código viejo. Un engagement nuevo (escaneado con este código:
> CPE capturado + sonda soft-200) las cierra de raíz.

---

## 5. Tests

`docker exec eth_mas_backend uv run pytest tests/ -v` → **150 passed**
(128 previos sin regresión + 22 nuevos en
[`tests/test_fp_hardening_2026_06.py`](../eth-mas-backend/tests/test_fp_hardening_2026_06.py)):

- normalizadores: captura de puerto nikto, dedup_key con puerto, degradación
  catch-all (nikto + gobuster), `shell history` ya no es high.
- gate de confianza: downgrade `confirmed`→`version-unknown` sin versión,
  `version-unknown` desde CPE, legacy keyword-only, CVSS headline confirmed-only.
- CPE: parsing 2.2/2.3, `virtualMatchString` (vendor comodín, versión acotada).

---

## 6. Archivos tocados

```
eth-mas-backend/
  mongo_schemas.py                       (+ cve_details, confidence en FindingDoc)
  services/nmap_service.py               (CPE + NMAP_TIMEOUT_SECS)
  services/findings_service.py           (puerto nikto, dedup, catchall, severidad)
  services/analysis_agent.py             (gate determinístico + cve_details + refinamiento)
  services/reporter_agent.py             (filtro keyword-only/false_positive + prompt rigor)
  mcp_servers/analysis_server.py         (cve_lookup por CPE + match_mode + caché CPE)
  mcp_servers/security_server.py         (sonda soft-200 scope-validada)
  tests/test_fp_hardening_2026_06.py     (nuevo — 22 tests)
```

Config nueva (env, opcional): `NMAP_TIMEOUT_SECS` (default 600),
`SOFT200_TIMEOUT_SECS` (default 8).

---

## 7. Pendiente / siguiente

- Re-escanear #24 (o un engagement nuevo) con este código para cerrar los
  residuales §4.3 de raíz (CPE real + sonda soft-200 en acción).
- Alinear `HITL_TIMEOUT_SECS` (300s) con `NMAP_TIMEOUT_SECS` (600s): un scan full
  aprobado tarde aún puede quedar `hitl_timeout` (caso #101 de #24).
- (Opcional) Plantillas del reporte: usar `f.cves[].confirmed` para renderizar el
  badge "no confirmado" en los `version-unknown` (hoy se muestran como CVE normal).
