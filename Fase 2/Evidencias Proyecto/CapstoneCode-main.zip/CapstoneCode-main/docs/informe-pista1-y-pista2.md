# ETH-MAS — Informe de cierre Pista 1 + plan Pista 2

> **Para el equipo.** Detalle de todo lo que se hizo en la Pista 1 (qué se
> encontró, la causa raíz y cómo se resolvió), más el plan de la Pista 2.
>
> **Fecha:** 2026-06-18 · **Release:** `v0.3` en `main` (merge `ea6d826`).

---

## 0. Resumen ejecutivo

Antes de la presentación evaluada del viernes se ejecutó la **Pista 1**: una pasada
de validación + arreglos sobre el código, partiendo del reporte de bugs del operador
(B1–B8) y de pendientes del release plan. Resultado:

- **Pipeline 4/4 real validado** en runtime sobre los dos targets del lab
  (Metasploitable2 #26 = 38 findings, DVWA #27 = 12 findings).
- **Bugs de reportes/análisis cerrados** (B5 estabilidad MITRE, B7 jerga ejecutiva,
  B6 viñetas; B1/B8 resultaron ser código stale, ya correctos).
- **Features nuevas**: popover MITRE con link, ROE sin ventanas de tiempo, nombre de
  reporte personalizable, tab Pipeline que muestra el assessment completo.
- **Calidad**: 179 tests verdes, CI (INFRA-02), doc de métricas (HU-21).
- Todo **mergeado a `main` y etiquetado `v0.3`**. On-prem (Variante B) validado y sano.

La **Pista 2** (construir la Variante A productiva en GCP) arranca después del viernes,
hacia la defensa Capstone. La on-prem queda como red de seguridad.

---

## 1. Estrategia: dos pistas

Se trabajó con una regla simple para no arriesgar la presentación:

> **La demo on-prem es la red de seguridad garantizada; la Variante A (GCP) es la meta
> real, pero se construye encima de la red de seguridad, no en su lugar.**

- **Pista 1** (esta entrega): dejar la demo on-prem validada + la arquitectura
  defendible. Es lo que se presenta el viernes.
- **Pista 2** (post-viernes): Variante A / GCP real. No empieza hasta que Pista 1 esté
  cerrada.

---

## 2. Punto de partida — reporte de bugs del operador (B1–B8)

El operador reportó 8 problemas en reportes/orquestador tras las pruebas cruzadas en el
lab. La Pista 1 los tomó como entrada. Estado consolidado:

| ID | Síntoma reportado | Veredicto Pista 1 |
|----|-------------------|-------------------|
| B1 | PDF dice "completed" pero el header de la UI muestra "pending" | Dato/PDF ya correcto (era stale); header UI arreglado |
| B2 | CVSS 9.8 con severidad Medium | Ya resuelto (reconciliación severidad↔CVSS) |
| B3 | Vectores "CRITICAL" vs 0 findings críticos | Ya resuelto (etiqueta "impacto potencial") |
| B4 | Confianza del CVE no se mostraba | Ya resuelto (badge confirmado/sin confirmar) |
| B5 | Re-analizar cambia las técnicas MITRE | **REAL — arreglado esta pista** |
| B6 | Viñetas vacías en el reporte | Limpio (verificado técnicamente) |
| B7 | Ejecutivo con jerga técnica | **REAL — arreglado esta pista** |
| B8 | Observabilidad: solo ScanAgent 1/1 | Stale en `/pipeline`; matiz orquestador documentado |

**Aprendizaje clave (Sesión 0):** la mitad del reporte era **código stale** — el
operador probó una versión sin los fixes desplegados. Por eso lo PRIMERO fue una
corrida limpia para separar lo stale de lo real.

---

## 3. Lo que se hizo, sesión por sesión

### Sesión 0 — Corrida 4/4 real + verdad de terreno
- Se levantó el stack on-prem y se corrió el **pipeline 4/4 completo sobre #26**
  (Metasploitable2), auto-aprobando los HITL. Resultado: 4 stages `completed`,
  **38 findings reales** (las 4 tools aportaron), 2 PDFs.
- Con eso se separó lo stale de lo real: **B1 y B8 ya estaban correctos** con el código
  fresco; **B5 y B7 fallaban de verdad**.

### Sesión 1 — Reportes: B7 (jerga) + B6 (viñetas)
**B7 — qué se encontró:** la *narrativa* del ejecutivo estaba limpia, pero la tabla
"Principales riesgos" arrastraba los títulos crudos de los findings (`[Nuclei] PHP CGI
… RCE`, `Netbios-ssn`, la URL `http://10.42.0.10`), y la nota al pie citaba "CVEs y
MITRE".
**Causa raíz:** `_strip_exec_jargon` saneaba la prosa del LLM, pero la tabla de riesgos
usaba `finding.title`/`summary` sin sanear.
**Cómo se resolvió** (`reporter_agent.py`): se reescribió `_exec_risk_label` para
(1) quitar tags de herramienta `[Nuclei]`/`[Nikto]`, (2) mapear nombres de servicio a
lenguaje de negocio (`Netbios-ssn` → "Servicio de archivos compartidos expuesto"),
(3) traducir frases de riesgo (RCE → "Ejecución remota de código"); se agregó
`_exec_asset` para mostrar el host limpio en vez de la URL, y se reescribió la nota al
pie sin CVE/MITRE.

**B6 — qué se encontró:** el operador veía `•` sueltos en el texto del PDF.
**Causa raíz:** eran los *marcadores* de lista que el extractor de PDF separa del texto
(artefacto de capa de texto), no `<li>` vacíos.
**Cómo se verificó:** render "tortura" de ambos templates con listas que incluían
`""`/`None`/`"  "` → **0 `<li>` vacíos**. Los guards `if r and r|trim` + `_clean_list`
ya filtraban correctamente.

### Sesión 2 — B5 (estabilidad MITRE)
**Qué se encontró:** re-correr el análisis cambiaba la técnica MITRE de **23 de 29**
hallazgos (peor de lo reportado). SSH/22 oscilaba T1110↔T1021. Además el *conjunto* de
findings enriquecidos variaba entre corridas (26/22/20 de 38).
**Causa raíz:** existe una tabla canónica de técnica por puerto/servicio, pero se
aplicaba **solo a los findings en MongoDB**, NO al `AnalysisDoc.enriched_findings`, que
se guardaba con la salida CRUDA del LLM. `GET /analysis` y la pestaña Analysis leen ese
doc → inestable.
**Cómo se resolvió** (`analysis_agent.py`): nuevo `_normalize_enriched_for_doc` que,
antes de persistir el AnalysisDoc, (1) aplica la técnica canónica a cada entrada y
(2) cubre TODOS los findings de origen en orden fijo. El gate de CVE sigue usando el
enriched crudo del LLM (no se pierde nada).
**Evidencia:** 3 corridas de `/analysis` seguidas → **38 refs, 0 inestables**
(antes 23/29). MITRE determinístico.

### Sesión 3 — Features de UI + B1/B8
- **Popover MITRE (pedido del operador):** nuevo `ui/hover-card.jsx` +
  `analysis/MitreBadge.jsx`. Al pasar el mouse sobre una técnica MITRE se abre una
  ventana con nombre, táctica, explicación breve y **link a attack.mitre.org**.
  Cableado en la tabla de riesgo, el heatmap y las kill chains. (Verificado en la UI
  viva.)
- **B1 (header):** `PipelineView` ahora avisa al workspace cuando el pipeline termina,
  así el badge de estado deja de quedar congelado en "pending"/"running".
- **B8 (observabilidad):** el frontend ya estaba bien para el flujo `/pipeline` (4
  stages; confirmado en S0). El "solo ScanAgent 1/1" del operador era el flujo
  **orquestador** mostrando lo que delegó — comportamiento por diseño, no bug de UI.

### Sesión 4 — ROE sin ventanas de tiempo
**Pedido del operador:** las "ventanas de tiempo" del ROE generaban confusión y nunca
se aplicaban; la ejecución debe ser cuando el operador inicia el pipeline.
**Cómo se resolvió:** se removió `time_windows` del schema (`schemas.py`, clase
`TimeWindow` eliminada) y del form (`RoeBuilder.jsx`, sección + handlers). Es
**compatible hacia atrás**: un engagement legacy con `time_windows` parsea bien y el
campo se ignora (sin migración). CLAUDE.md §4.5 actualizado.

### Sesión 5 — DVWA + CI + métricas
- **HU-20 (DVWA):** pipeline 4/4 completo sobre **#27 (DVWA 10.42.0.20)**: `completed`,
  **12 findings web** (nikto 10, gobuster 1, nmap 1), reportes generados. Ahora ambos
  targets del lab tienen E2E pleno.
- **INFRA-02 (CI):** nuevo `.github/workflows/ci.yml` — job backend (pytest, sin
  servicios porque los tests son puros) + job frontend (lint + build). Se activa en
  cada push/PR.
- **HU-21 (métricas):** nuevo `docs/metricas-calidad-hu21.md` con números reales:
  179 tests, cobertura por categoría, estabilidad MITRE, performance, E2E #26/#27.

### Sesión 6 — Commits + respaldo remoto + on-prem
- 2 commits limpios (código + docs); scratch de pruebas dejado sin commitear.
- **Rama de respaldo remota `release/v0.3`** pusheada a origin.
- **On-prem (Variante B) validado:** 6 contenedores sanos, `/health/services`
  `overall: up`, frontend respondiendo.

### Sesión 7 — Verificación en UI viva + guión de demo
- Verificación interactiva en el navegador: **header B1** muestra "completed";
  **popover MITRE** funciona (T1190 → nombre, táctica, descripción, link).
- **Guión de demo** paso a paso (`docs/guion-demo-viernes-2026-06-19.md`) con checklist
  pre-demo, flujo y plan de respaldo (#26/#27 pre-corridos son la evidencia primaria).

### Extras (post-S7, observaciones del operador)
- **Tab Pipeline mostraba la última corrida, no el assessment completo.** #26 tenía 8
  pipeline_runs (la 4/4 + 7 de 1 stage de re-análisis/re-reportes), y la vista tomaba la
  última (1 stage). Fix (`PipelineView.jsx`): elegir la corrida **representativa** (más
  stages) y no dejar que un run de 1 stage tape el assessment en el stream SSE.
- **Mensajes nikto/nuclei en inglés en el ejecutivo.** Provenían del `summary` del
  finding. Se agregó `_WEB_FINDING_MAP` (14 patrones → frase de negocio en español):
  "Cookie … without the httponly flag" → "Cookie de sesión sin protección (httponly)",
  etc. Validado regenerando el PDF de #27.
- **Nombre de reporte personalizable.** Antes los PDFs eran genéricos
  (`eng_{id}_{type}.pdf`). Ahora el operador asigna un nombre en la pestaña Reports y
  ambos PDFs lo toman con su sufijo ("`<nombre> — Técnico.pdf`"). Threading limpio:
  `AgentContext.report_name` ← `PipelineController` ← `POST /report {name}`.

---

## 4. Validación end-to-end (los números para la defensa)

| Métrica | Metasploitable2 (#26) | DVWA (#27) |
|---------|:---------------------:|:----------:|
| Pipeline 4/4 | ✅ completed | ✅ completed |
| Findings persistidos | **38** | **12** |
| Findings con MITRE | 38/38 | 12/12 |
| Reportes (técnico + ejecutivo) | ✅ | ✅ |
| HITL bloqueante | ✅ (suspende→aprueba→reanuda) | ✅ |

**Calidad:** 179 tests verdes (14 archivos) · cobertura núcleo determinístico alta
(scope 92%, scan_policy 94%, config 100%, parser nmap 75%, reporter 70%) · estabilidad
MITRE **0/29** (antes 23/29) · CI activo · reporte ejecutivo en lenguaje de negocio.

---

## 5. Notas operativas / riesgos conocidos

- **Backend con `uvicorn --reload`:** el watcher puede tropezar con un `OSError [Errno 5]`
  sobre el bind-mount de Docker Desktop en Windows si se editan archivos durante una
  corrida. Se resuelve con `docker compose up -d backend`. **Para la demo: correr el
  backend sin `--reload`** (o no tocar archivos durante la corrida).
- **No re-correr `/analysis` o `/report` antes de la demo en el mismo engagement**, o se
  generan pipeline_runs de 1 stage (ya mitigado en la vista, pero conviene saberlo).
- **Scope por IP explícita** en el lab (no CIDR) para evitar el caso H-3 histórico.
- El lab vulnerable **nunca** debe exponerse al host/internet (host-only).

---

## 6. Estado de release (git)

| Ref | Commit | Qué es |
|-----|--------|--------|
| `main` | `ea6d826` | merge `--no-ff` de release/v0.3 (v0.3 Demo Final) |
| tag `v0.3` | `ab41b7c` | release v0.3, alcanzable desde main |
| `release/v0.3` | `ab41b7c` | rama de respaldo remota |

Commits principales de la Pista 1: `4a123ff` (código), `8c2a6dd` (docs),
`b94e0a3` (guión demo), `1907d45` (fix tab Pipeline), `ab41b7c` (nombre de reporte).

---

## 7. Pista 2 — Variante A / GCP real (lo que haremos)

**Objetivo:** construir la arquitectura productiva "to-be" hacia la defensa Capstone.
Spec en [`despliegue-produccion-gcp-onprem.md`](despliegue-produccion-gcp-onprem.md)
+ su `.drawio`.

**Diseño — híbrido de dos planos:**
- **Plano APP + datos → GCP:** Frontend (Cloud Run/Storage), Backend (GCE VM:
  orquestador + AnalysisAgent + ReporterAgent + HITL + dispatcher de jobs), PostgreSQL
  (Cloud SQL), MongoDB (Atlas + VPC peering), cola (Pub/Sub).
- **Plano ESCANEO + lab → on-prem:** ScanAgent + Security/OSINT MCP + tools + lab
  aislado. Hace **job-pull** (polling saliente) a GCP, NAT-friendly.
- **LLM → API Anthropic** (egress HTTPS desde ambos planos).

**Constraint duro:** el lab (Metasploitable2 + DVWA) **NUNCA** se expone a internet —
vive on-prem, red host-only, sin egress.

**Checklist de construcción (§8 del doc):**
1. **A1** — Extraer ScanAgent + `mcp_servers/{security,osint}_server.py` + tools como un
   worker desplegable por separado (Docker).
2. **A2** — Contrato de job: `GET /scan-jobs/next` (poll saliente) +
   `POST /engagements/{id}/findings` (resultados), o Pub/Sub. El backend encola un job
   al aprobarse el HITL y deja de spawnear el Security MCP localmente.
3. **A3** — Worker: loop de poll saliente + `is_target_in_scope` local + ejecución del
   scan + post de findings a la API.
4. **A4** — Infra GCP: GCE VM (backend), Cloud SQL (Postgres), Atlas (Mongo + peering),
   Cloud Run/Storage (frontend), Pub/Sub (cola). Secrets en Secret Manager + `.env` del
   worker. Verificar lab host-only sin egress.

**Estrategia (de-risk):** hacer **A1–A3 localmente primero** (separar el worker y que el
backend hable con él vía el contrato de job, validado on-prem) y RECIÉN ahí mover el
plano de app a GCP (A4). Así se prueba la arquitectura sin pagar GCP de entrada y sin
romper el camino on-prem (Variante B = fallback).

**Decisiones del equipo a definir antes de arrancar:**
- ¿Cuenta/proyecto GCP con billing? ¿Región?
- ¿Cuenta MongoDB Atlas (M0 free alcanza para el Capstone)?
- ¿Presupuesto? (free/micro tiers cubren casi todo; el costo dominante son los tokens LLM.)
- ¿Dominio/DNS para el frontend, o basta la URL de Cloud Run?

**Riesgos abiertos (del doc §9):**
- HITL a través de la cola: el worker solo recibe jobs **ya aprobados** (el HITL se
  resuelve en GCP antes de encolar) → evita polling de estado HITL cross-network.
- Latencia del job-pull (intervalo de poll) — aceptable para scans (minutos).

---

## 8. Referencias (en `docs/`)

- `despliegue-produccion-gcp-onprem.md` (+ `.drawio`) — arquitectura productiva.
- `metricas-calidad-hu21.md` — métricas de calidad (HU-21).
- `guion-demo-viernes-2026-06-19.md` — guión de demo + plan de respaldo.
- `release-planning.md` — cruce HU × progreso.
- `plan-cierre-viernes-2026-06-19.md` — plan de las dos pistas.
- `prompt-pista2-variante-a.md` — prompt para arrancar la Pista 2.
- `prompt-presentacion-capstone.md` — prompt para construir la presentación.
