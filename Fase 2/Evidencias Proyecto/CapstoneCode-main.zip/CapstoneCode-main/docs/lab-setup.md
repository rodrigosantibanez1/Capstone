# Lab Setup — Metasploitable2 + DVWA

> Documento operativo del laboratorio de targets vulnerables del proyecto
> ETH-MAS. Cubre cómo levantar el lab integrado al stack Docker, qué scope
> usar al crear engagements, los puertos esperados de cada target, y las
> advertencias de seguridad obligatorias.
>
> **Branch que introdujo este lab:** `feature/lab-metasploitable-dvwa`
> **Auditoría asociada:** `auditoria_eth_mas_2026-05-26_lab-setup.md` (raíz del repo)

---

## 1. ⚠️ Advertencia de seguridad — leer antes de levantar el lab

Metasploitable2 es una distribución **intencionalmente vulnerable**. Tiene
backdoors plantados (`vsftpd 2.3.4`, `ingreslock`, `distccd`,
`UnrealIRCd 3.2.8.1`), credenciales por defecto, servicios obsoletos
(`OpenSSH 4.7p1`, `Samba 3.0.20`) y configuraciones de daemons sin
autenticación. **NO debe quedar accesible desde fuera del host bajo ninguna
circunstancia.**

DVWA expone vulnerabilidades web clásicas (SQLi, XSS, CSRF, file inclusion,
command injection) y `vulnerables/web-dvwa:1.9` corre con PHP 5.x EOL.

Garantías que ya están en `docker-compose.yml`:

- Los servicios `metasploitable` y `dvwa` no declaran `ports:` — sólo
  `expose:`, que únicamente publica entre contenedores conectados a la misma
  red Docker. **El host nunca abre puertos del lab.**
- Ambos viven en una red dedicada `eth_mas_lab` (`10.42.0.0/24`), aislada
  del resto del compose por defecto.
- El backend se une a `eth_mas_lab` como **red secundaria** para que pueda
  resolver/atacar los targets — sigue exponiendo sólo `:8000` al host como
  antes.
- Ambos servicios viven bajo `profiles: ["lab"]`, así que un `docker
  compose up` clásico **no los levanta**. Hay que pedirlo explícitamente con
  `--profile lab`.

**Recomendación adicional:** si por algún motivo el equipo decidiera mover
este lab a una máquina compartida, agregar reglas de firewall del host que
bloqueen explícitamente cualquier tráfico hacia `10.42.0.0/24` desde redes
externas.

---

## 2. Imágenes utilizadas (pineadas por digest)

| Servicio | Imagen | Tag | Digest (sha256) | Origen / notas |
|----------|--------|-----|-----------------|----------------|
| `metasploitable` | `tleemcjr/metasploitable2` | `latest` | `e559450b37dccc1909eafa2df5b20bb052e1bd801246f4539a3ef183d5f7288a` | Imagen comunitaria estable desde 2018 — la base Metasploitable2 oficial de Rapid7 no se distribuye como contenedor. |
| `dvwa` | `vulnerables/web-dvwa` | `1.9` | `14c929ec1a99edb77326201f7f0fb431d1b3dd099c09ddeaf46312ab0ff53cfe` | Imagen oficial DVWA v1.9. Apache + PHP 5 + MySQL en un único contenedor. |

`:latest` está prohibido por reproducibilidad (CLAUDE.md §4.8). Si una
imagen rolea en el futuro, el digest garantiza que reconstruir el lab
levante exactamente el mismo binario y los mismos puertos.

### 2.1 Alternativas si la imagen oficial falla

Si en algún build futuro `tleemcjr/metasploitable2` deja de funcionar (las
imágenes viejas a veces rompen con kernels nuevos), las alternativas
documentadas son:

- **`vulhub/metasploitable2`** — fork mantenido por Vulhub. Cambia el
  digest, mismos servicios.
- **`cytopia/dvwa:latest-php-8.1`** — DVWA reempaquetada con PHP moderno
  (rompe algunos retos antiguos pero deja DVWA arrancable en hosts donde
  PHP 5 ya no compila).

No están activadas en el compose: pegar el bloque del servicio cambiando
`image:` y `digest`, levantar `--profile lab` y validar puertos.

---

## 3. Cómo levantar el lab

### 3.1 Levantar todo el stack + lab

```bash
docker compose --profile lab up -d
```

Con esto arrancan: `db`, `mongo`, `backend`, `frontend`, `metasploitable`,
`dvwa`. El backend queda doble-homed (`eth_mas_network` + `eth_mas_lab`).

### 3.2 Levantar sólo el lab (asume stack base ya corriendo)

```bash
docker compose --profile lab up -d metasploitable dvwa
```

### 3.3 Bajar el lab (deja el stack en pie)

```bash
docker compose --profile lab stop metasploitable dvwa
docker compose --profile lab rm -f metasploitable dvwa
```

### 3.4 Limpiar el lab al terminar (recomendado al cerrar el sprint)

```bash
docker compose --profile lab down -v
```

Esto remueve volúmenes anónimos y la red `eth_mas_lab`. Si quieres bajar
**todo** y empezar de cero:

```bash
docker compose --profile lab down -v --remove-orphans
```

### 3.5 Verificar que el lab arrancó bien

```bash
docker ps --format "table {{.Names}}\t{{.Status}}" | grep eth_mas_lab
# eth_mas_lab_ms2    Up X seconds
# eth_mas_lab_dvwa   Up X seconds

# Smoke test desde el backend (debe responder LAN <1ms latency):
docker exec eth_mas_backend nmap -Pn -p 22,80,3306 10.42.0.10
docker exec eth_mas_backend curl -sS -o /dev/null -w "http=%{http_code}\n" http://10.42.0.20/
```

`curl` contra DVWA debe devolver `http=302` (redirige a `/login.php`).

---

## 4. Scope sugerido para un engagement contra el lab

El validador de scope ([`services/scope_validator.py`](../eth-mas-backend/services/scope_validator.py))
acepta tres tipos: `IP`, `CIDR`, `DOMAIN`. El regex de dominio
([`schemas.py:13`](../eth-mas-backend/schemas.py)) exige al menos un punto,
así que **`metasploitable` como hostname plano no valida** — por eso el lab
usa **IPs fijas + CIDR**.

### Opción A — scope CIDR (recomendado)

Un solo target cubre los dos hosts del lab. Más simple para demos:

```json
POST /engagements
{
  "name": "Lab Capstone — Metasploitable + DVWA",
  "client_name": "DUOC UC (lab interno)",
  "scope_targets": [
    {"target_value": "10.42.0.0/24", "target_type": "cidr"}
  ]
}
```

### Opción B — scope por IP (granular)

Útil si quieres ejercitar a propósito el rechazo a uno de los dos targets:

```json
POST /engagements
{
  "name": "Lab Capstone — sólo Metasploitable2",
  "scope_targets": [
    {"target_value": "10.42.0.10", "target_type": "ip"}
  ]
}
```

### Probar `@enforce_scope` con un target fuera de scope

```bash
curl -H "X-API-Key: $ETH_MAS_API_KEY" \
     "http://localhost:8000/engagements/<id>/validate?target=1.1.1.1"
# → {"status":"DENEGADO","in_scope":false}
```

---

## 5. Puertos esperados por target

### 5.1 Metasploitable2 (`10.42.0.10`)

Servicios expuestos por la imagen — exactamente los que el lab oficial de
Rapid7 documenta. Un nmap full-ports debería ver ~24 puertos abiertos.

| Puerto | Servicio | Versión vulnerable conocida |
|--------|----------|------------------------------|
| 21 | ftp | `vsftpd 2.3.4` (backdoor smiley) |
| 22 | ssh | `OpenSSH 4.7p1` |
| 23 | telnet | sin autenticación |
| 25 | smtp | `Postfix smtpd` |
| 53 | domain | `ISC BIND 9.4.2` |
| 80 | http | `Apache 2.2.8` |
| 111 | rpcbind | |
| 139, 445 | netbios / smb | `Samba 3.0.20` (CVE-2007-2447) |
| 512, 513, 514 | exec / login / shell | rsh/rlogin sin auth |
| 1099 | rmiregistry | Java RMI exploit |
| 1524 | ingreslock | **root shell backdoor** |
| 2049 | nfs | exportaciones sin chequeo |
| 2121 | ccproxy-ftp | |
| 3306 | mysql | `MySQL 5.0.51a` (root sin password) |
| 3632 | distccd | CVE-2004-2687 |
| 5432 | postgres | `PostgreSQL 8.3.0` |
| 5900 | vnc | password `password` |
| 6000 | x11 | X server abierto |
| 6667, 6697 | irc | `UnrealIRCd 3.2.8.1` (backdoor) |
| 8009 | ajp13 | Apache Tomcat |
| 8180 | http (tomcat) | Tomcat 5.5 admin `tomcat:tomcat` |
| 8787 | drb | Distributed Ruby RCE |

### 5.2 DVWA (`10.42.0.20`)

| Puerto | Servicio | Notas |
|--------|----------|-------|
| 80 | http | Apache 2.4 + PHP 5.x + DVWA web UI. MySQL embebido, sin exponer. |

DVWA no expone MySQL fuera del contenedor — vive en `localhost:3306`
internamente.

---

## 6. Configuración de DVWA — security levels

Por defecto DVWA arranca con security level `impossible` (sin
vulnerabilidades activas, útil para validar que el servidor responde).
Para que los scanners encuentren algo hay que **bajar el nivel** desde la
UI.

### 6.1 Setup inicial (una vez)

1. Levantar el lab (`docker compose --profile lab up -d`).
2. Desde el host abrir un túnel HTTP al DVWA o usar el navegador del lab.
   Como no exponemos puerto, lo más simple es:
   ```bash
   # túnel temporal (sólo para configurar — apagar al terminar)
   docker run --rm --network eth_mas_lab -p 8081:80 \
     alpine/socat tcp-listen:80,fork,reuseaddr tcp-connect:10.42.0.20:80
   ```
   Luego http://localhost:8081/ en el navegador.
3. Login: `admin / password`.
4. **Setup / Reset Database** → "Create / Reset Database". Esto inicializa
   MySQL embebido.
5. **DVWA Security** → elegir el nivel para esta corrida:
   - `low` → vulns triviales (XSS reflected sin escape, SQLi por
     concatenación). Para validar que los scanners detectan algo.
   - `medium` → vulns con filtros débiles. Más realista.
   - `high` → vulns con tokens CSRF mal usados, escaping incompleto.
   - `impossible` → sin vulnerabilidades — útil para confirmar falsos
     positivos.
6. (Importante) Apagar el túnel del paso 2 cuando termines:
   `docker stop` al contenedor `alpine/socat`.

### 6.2 Cambio rápido vía cookie (para los scanners)

DVWA guarda el security level en la cookie `security`. Si el ScanAgent
acepta cookies custom (Sprint 3+), se puede setear `security=low` sin
tocar la UI.

---

## 7. Limitaciones conocidas

### 7.1 Recon (OSINT) no aplica al lab

El ReconAgent usa `dns_enum`, `whois_lookup`, `theharvester_run` sobre
dominios públicos. Los targets del lab son IPs RFC1918 sin DNS público ni
WHOIS, así que las tools OSINT devuelven resultados vacíos o errores
benignos. Esto **no es un bug** — el lab está pensado para ejercitar el
ScanAgent (puerto, servicio, versión, vulns) que es lo que va a ver una
auditoría real contra una intranet.

### 7.2 AnalysisAgent y ReporterAgent no existen aún

CLAUDE.md §9 los marca como pendientes de Sprint 3. El pipeline
end-to-end completo (HU-19 plena) requiere implementarlos primero. El lab
queda listo para que cuando esos agentes existan se enchufen y la demo
final corra contra `10.42.0.0/24` sin más cambios de infra.

### 7.3 Metasploitable2 imagen no se actualiza desde 2018

La imagen `tleemcjr/metasploitable2:latest` está congelada. Si en algún
host moderno deja de arrancar (problemas conocidos: cgroups v2,
inits viejos), seguir el procedimiento de §2.1.

---

## 8. Troubleshooting

| Síntoma | Diagnóstico | Solución |
|---------|-------------|----------|
| `docker compose --profile lab up -d` no crea los contenedores | Probablemente no se pasó `--profile lab`. | Re-ejecutar con el flag exacto. |
| Backend devuelve `SCOPE_VIOLATION` para `10.42.0.10` | El scope del engagement no incluye esa IP. | Revisar `GET /engagements/<id>` y agregar el target. |
| `nmap` desde el backend no resuelve ni `10.42.0.10` ni `metasploitable` | El backend no está en la red `eth_mas_lab`. | `docker compose down && docker compose --profile lab up -d` para que tome la config nueva del compose. |
| El smoke test ve 0 puertos abiertos | Metasploitable2 puede tardar 10–15s en arrancar todos los daemons. | Esperar o `docker logs eth_mas_lab_ms2` para ver el progreso. |
| DVWA devuelve HTTP 500 desde el navegador | MySQL embebido no terminó de iniciar o `Create Database` no se corrió. | Setup / Reset Database desde la UI (§6.1). |
| Quiero exponer DVWA en `localhost:8081` temporalmente | El lab está sin `ports:` por seguridad. | Usar el túnel `alpine/socat` del §6.1 sólo para el setup, y bajarlo después. |

---

## 9. Cómo validar end-to-end (parcial — Recon + Scan)

> Este flujo es exactamente el que ejecuta la auditoría
> `auditoria_eth_mas_2026-05-26_lab-setup.md`. Pegarlo paso a paso permite
> reproducir la validación.

```bash
# 1. Salud del stack
curl -s http://localhost:8000/health/services | jq .

# 2. Crear engagement con scope = todo el lab
ENG_ID=$(curl -s -X POST http://localhost:8000/engagements \
  -H "X-API-Key: $ETH_MAS_API_KEY" -H "Content-Type: application/json" \
  -d '{
    "name":"Lab Metasploitable+DVWA E2E",
    "client_name":"DUOC UC",
    "scope_targets":[{"target_value":"10.42.0.0/24","target_type":"cidr"}]
  }' | jq -r .id)
echo "Engagement: $ENG_ID"

# 3. Probar @enforce_scope (debe rechazar 1.1.1.1)
curl -s -H "X-API-Key: $ETH_MAS_API_KEY" \
  "http://localhost:8000/engagements/$ENG_ID/validate?target=1.1.1.1"
curl -s -H "X-API-Key: $ETH_MAS_API_KEY" \
  "http://localhost:8000/engagements/$ENG_ID/validate?target=10.42.0.10"

# 4. Recon (no aporta mucho contra RFC1918 — esperado)
curl -s -X POST -H "X-API-Key: $ETH_MAS_API_KEY" \
  "http://localhost:8000/engagements/$ENG_ID/recon" | jq .

# 5. Scan (background) — devuelve 202 + queda PENDING en HITL
curl -s -X POST -H "X-API-Key: $ETH_MAS_API_KEY" \
  "http://localhost:8000/engagements/$ENG_ID/scan" | jq .

# 6. Listar HITLs pendientes
HITL_ID=$(curl -s -H "X-API-Key: $ETH_MAS_API_KEY" \
  "http://localhost:8000/engagements/$ENG_ID/hitl-actions?pending_only=true" \
  | jq -r '.[0].id')
echo "HITL pending: $HITL_ID"

# 7. Aprobar
curl -s -X PATCH -H "X-API-Key: $ETH_MAS_API_KEY" \
  -H "Content-Type: application/json" \
  "http://localhost:8000/hitl-actions/$HITL_ID/decision" \
  -d '{"decision":"APPROVED","operator":"e2e-script","notes":"E2E lab"}'

# 8. Esperar a que el scan termine (~30-60s contra LAN) y leer findings
sleep 60
curl -s -H "X-API-Key: $ETH_MAS_API_KEY" \
  "http://localhost:8000/engagements/$ENG_ID/findings?limit=200" | jq '.total'
```

Resultado esperado: `total >= 20` (Metasploitable2 expone ~24 puertos en
nmap top-1024).

---

**Documento mantenido por:** Scrum Master del sprint activo (CLAUDE.md §10).
**Última actualización:** 2026-05-26 — creación inicial junto con
`feature/lab-metasploitable-dvwa`.
