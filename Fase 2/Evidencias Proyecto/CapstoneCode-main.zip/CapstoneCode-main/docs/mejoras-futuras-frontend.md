# Mejoras futuras — Frontend

> Ideas evaluadas y conscientemente diferidas. No son deuda técnica urgente:
> son opciones que decidimos **no** aplicar ahora para no arriesgar estabilidad
> antes de la defensa, pero que valen la pena más adelante.

---

## 1. Gráfico de métricas con librería especializada (Recharts)

**Contexto.** En el rediseño de la pantalla de Inicio (2026-07), los números
dejaron de ser el protagonista y pasaron a una franja secundaria con un
**gráfico interactivo de hallazgos por severidad**. Ese gráfico hoy está
**dibujado a mano** (una "dona" en SVG dentro de `HomeView.jsx`, componente
`SeverityDonut`), sin agregar ninguna pieza nueva al proyecto.

**Por qué se hizo así (decisión actual).**
- Cero dependencias nuevas → menos cosas que puedan fallar el día de la defensa.
- Más liviano y fácil de mantener por el equipo.
- Cubre de sobra lo que se necesita: segmentos por severidad, resaltado al pasar
  el mouse o con el teclado, total al centro y leyenda interactiva.

**La mejora futura.** Si en algún momento se quiere una capa de visualización
más rica (varios tipos de gráfico, tooltips animados, ejes, series temporales
de la evolución de hallazgos, comparativas entre engagements), conviene adoptar
una **librería de gráficos ya hecha**. La recomendada para este stack
(React + Tailwind + shadcn/ui) es **Recharts**, porque shadcn/ui ya ofrece un
envoltorio oficial de `Chart` construido sobre Recharts.

**Qué implicaría (a alto nivel).**
1. Sumar la dependencia `recharts` al frontend.
2. Incorporar el componente `chart` de shadcn/ui (envoltorio con theming).
3. Reemplazar `SeverityDonut` de `HomeView.jsx` por un gráfico de Recharts,
   **manteniendo los mismos colores** ya definidos en el proyecto
   (`--sev-critical`, `--sev-high`, `--sev-medium`, `--sev-low`, `--sev-info`
   en `src/index.css`) para no perder coherencia visual.
4. Aprovechar la ocasión para agregar vistas que hoy no existen: evolución de
   hallazgos en el tiempo, o severidad comparada entre varios engagements.

**Costo / riesgo.** Suma peso al paquete y una dependencia más que mantener.
Por eso se dejó para después: el gráfico propio actual ya cumple el objetivo
sin ese costo.

---

_Última actualización: 2026-07-01 · rama `release/v0.4`._
