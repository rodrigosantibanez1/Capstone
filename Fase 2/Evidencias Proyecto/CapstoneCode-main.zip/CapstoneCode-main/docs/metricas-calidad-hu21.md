# ETH-MAS — Métricas de calidad (HU-21)

> **Qué es esto:** consolidado de métricas de calidad del sistema, medidas sobre
> el código y el laboratorio reales (no estimaciones). Cierra **HU-21** (E8 ·
> Validación).
>
> **Fecha:** 2026-06-18 · **Rama:** `fix/report-orchestrator-bugs-b1-b8`
> **Targets de validación:** Metasploitable2 (`10.42.0.10`) + DVWA (`10.42.0.20`),
> red aislada `eth_mas_lab`.

---

## 1. Pruebas automatizadas

Suite ejecutada con `uv run pytest tests/` dentro del contenedor backend.

| Métrica | Valor |
|---------|-------|
| Tests totales | **179 passed** (0 fallos) |
| Archivos de test | 14 |
| Tiempo de corrida | ~2 s |

**Distribución por módulo bajo prueba:**

| Archivo | Tests | Foco |
|---------|:-----:|------|
| `test_fp_hardening_2026_06.py` | 22 | Gate de confianza CVE, sonda soft-200 anti-FP |
| `test_report_bugs_fixes.py` | 21 | B1–B8 + B5 (estabilidad MITRE) + B7 (jerga/traducción ejecutiva) |
| `test_findings_normalizers.py` | 20 | Normalizadores nmap/nuclei/nikto/gobuster |
| `test_scope_validator.py` | 18 | Scope IP/CIDR/dominio/URL/host:port/IPv6 |
| `test_analysis_agent.py` | 16 | Severidad↔CVSS, técnica canónica |
| `test_agent_contracts.py` | 13 | Contrato BaseAgent (Recon/Scan goal-driven) |
| `test_scan_policy.py` | 11 | Política de riesgo/HITL por tool |
| `test_orchestrator_agent.py` | 10 | Orquestador conversacional |
| `test_analysis_mcp.py` | 10 | Analysis MCP (cve_lookup, attack_technique_lookup) |
| `test_nmap_service.py` | 8 | Parser XML de nmap (puertos/CPE, fixes M-1/M-2) |
| `test_reporter_agent.py` | 8 | Render de reportes, narrativa |
| `test_scan_agent_decision.py` | 5 | Decisión goal-driven del ScanAgent |
| `test_block_e_executor.py` | 4 | Ejecutor seguro |
| `test_block_a_executor_threading.py` | 2 | Threading del ejecutor |

### Cobertura (pytest-cov sobre `services/`)

La cobertura se reporta en **dos categorías**, porque el sistema mezcla lógica
determinística (testeable en unidad) con loops de agentes LLM (que se validan
end-to-end, §2). Mockear el LLM inflaría la cobertura sin probar nada real.

**A · Núcleo determinístico** (parsing, scope, política, normalización, helpers de
reporte/análisis) — lo que puede romperse en silencio y por eso SÍ se cubre en unidad:

| Módulo | Cobertura |
|--------|:---------:|
| `agent_config.py` | **100 %** |
| `scan_policy.py` | **94 %** |
| `scope_validator.py` | **92 %** |
| `agent_base.py` | 84 % |
| `nmap_service.py` | 75 % (0 % → 75 % en S6) |
| `reporter_agent.py` | 70 % |
| `findings_service.py` | 67 % |
| `report_renderer.py` | 54 % |
| `analysis_agent.py` (helpers) | 50 % |

**B · Runtime de agentes** (loops LLM, orquestación, persistencia Mongo, MCP) —
cubierto por los **E2E reales** del §2, no por unit tests: `recon_agent` 12 %,
`scan_agent` 20 %, `pipeline_controller` 26 %, `orchestrator_agent` 44 %,
`blackboard` 51 %, `agent_runs_service`/`pipeline_runs_service` 25–32 %.

**Total `services/` = 44 %.** El número global es bajo *por diseño*: el ~56 % no
cubierto en unidad es código de integración con el LLM y Mongo que se ejercita en
las corridas 4/4 reales (engagements #26 y #27), no con mocks.

---

## 2. Validación end-to-end (pipeline 4/4 real)

Pipeline completo Recon → Scan (+HITL) → Analysis → Reporter sobre el lab aislado.

| Métrica | Metasploitable2 (#26) | DVWA (#27) |
|---------|:---------------------:|:----------:|
| Stages completados | **4/4** | **4/4** |
| Estado final del engagement | completed | completed |
| Findings persistidos (Mongo) | **38** | **12** |
| Findings por tool | nmap+nuclei+nikto+gobuster | nikto 10 · gobuster 1 · nmap 1 |
| Findings enriquecidos (analysis) | 38/38 | 12/12 |
| Attack vectors | (varios) | 4 |
| Reportes generados | técnico + ejecutivo | técnico + ejecutivo |
| HITL aprobados | nmap/nuclei/nikto/gobuster | nmap/nuclei/nikto/gobuster |

> Cierra **HU-19** (Metasploitable2) y **HU-20** (DVWA): ambos targets del lab
> ejercitan el pipeline completo con findings reales persistidos y PDFs generados.
> **HU-07** queda cerrado en runtime: las 4 tools de scan aportan evidencia
> (antes nuclei/nikto daban 0 por timeout). **HU-09** validado: HITL bloqueante
> con aprobación y resume.

---

## 3. Calidad del análisis (AnalysisAgent)

| Métrica | Antes del fix | Después del fix (S2) |
|---------|:-------------:|:--------------------:|
| Estabilidad MITRE (refs que cambian de técnica en 3 corridas) | **23/29 inestables** | **0/29 — 100 % estable** |
| Cobertura de enriquecimiento (findings con técnica) | subconjunto variable (26/22/20 de 38) | **set completo y fijo (38/38)** |

- **Determinismo ATT&CK:** `temperature=0` + tabla canónica por puerto/servicio
  web + normalización del `enriched_findings` antes de persistir → el mapeo MITRE
  es reproducible corrida a corrida (verificado: 3 corridas idénticas sobre #26).
- **Anti–falsos positivos (hardening 2026-06-11):** gate de confianza CVE
  determinístico (confirmed / version-unknown / keyword-only), CVSS headline solo
  de CVEs *confirmed*, sonda soft-200 scope-validada. Sobre el engagement #24
  (target real), 0/4 CVE de alto CVSS aplicables tras el gate → se evitó reportar
  4 falsos positivos.

---

## 4. Calidad de los reportes

| Métrica | Resultado |
|---------|-----------|
| Viñetas vacías en HTML renderizado (B6) | **0** (`<li>` vacíos, torture-test con listas con None/"") |
| Jerga técnica en reporte ejecutivo (B7) | **0 tags de tool / URLs crudas / CVE-IDs / nombres de servicio** en la tabla de riesgos (validado en #26 y #27) |
| Consistencia de estado en PDF (B1) | PDF y engagement coinciden en `completed` (no más "running" congelado) |
| Conteo de findings | autoritativo desde Mongo (excluye false_positive), consistente entre técnico/ejecutivo/UI |

---

## 5. Performance (pipeline 4/4)

| Stage | Tiempo aprox. |
|-------|:-------------:|
| ReconAgent | 10–20 s (OSINT vacío contra RFC1918, esperado) |
| ScanAgent (4 tools + HITL) | 8–10 min (nuclei es el dominante) |
| AnalysisAgent (Opus 4.7 + NVD) | ~3 min |
| ReporterAgent (Jinja2 + WeasyPrint) | ~20 s |
| **Total E2E** | **~11–14 min** |

---

## 6. CI (INFRA-02)

`.github/workflows/ci.yml` — 2 jobs en cada push/PR:
- **backend-tests:** `uv sync` + `uv run pytest` (suite pura, sin servicios).
- **frontend-build:** `npm ci` + lint (no bloqueante) + `npm run build`.

---

## 7. Limitaciones honestas

- **Cobertura por diseño dividida (§1):** el núcleo determinístico está bien cubierto
  (90 %+ en scope/política/config, 70–75 % en parser/reporter); el runtime de agentes
  LLM se valida E2E, no en unidad. El 44 % global refleja esa mezcla, no una falta de
  pruebas del comportamiento real (que sí se ejercita en #26/#27).
- La traducción de mensajes de findings web (nikto/nuclei) al ejecutivo cubre los
  patrones que emiten las tools del lab; un mensaje no contemplado caería al texto
  original (legible) — se amplía sumando reglas a `_WEB_FINDING_MAP`.
- nuclei aporta 0 findings sobre DVWA en security-level por defecto; subir el nivel
  o ajustar templates aumentaría la superficie (fuera del alcance de esta entrega).
