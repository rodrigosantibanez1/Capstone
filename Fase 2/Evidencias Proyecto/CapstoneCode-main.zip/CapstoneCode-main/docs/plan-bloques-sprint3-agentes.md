# Plan de bloques — Rediseño agéntico (Sprint 3)

> Acompaña a [`adr-005-agentes-reales-y-orquestador.md`](adr-005-agentes-reales-y-orquestador.md).
> Objetivo: trabajo **autónomo pero correlativo**, asignable por persona, sin
> divergencia. La técnica anti-divergencia: **Bloque 0 congela los contratos**
> (interfaces + esquema del blackboard); todos codean contra eso y se integran
> por el blackboard, no por llamadas directas entre módulos en construcción.

---

## 0. Mapa de dependencias

```
                 ┌─────────────────────────────┐
                 │  BLOQUE 0 — CONTRATOS        │  (keystone, primero)
                 │  AgentResult/Context, base,  │
                 │  blackboard schema,          │
                 │  agent-as-tool, model tiering│
                 └──────────────┬──────────────┘
        ┌──────────────┬────────┼────────┬──────────────┐
        ▼              ▼        ▼        ▼              ▼
   BLOQUE A       BLOQUE B   BLOQUE C  BLOQUE D     BLOQUE E
  Orquestador   Analysis    Reporter  Refactor     Controller
  + chat op.    +NVD MCP    (render)  Recon/Scan   → ejecutor
                                                   seguro
```

Una vez **congelado el Bloque 0**, A/B/C/D/E avanzan en paralelo. Integran por
el blackboard (Mongo) y por la interfaz agent-as-tool, ambos definidos en B0.

**Regla de oro:** ningún bloque cambia los contratos del Bloque 0 por su cuenta.
Cualquier cambio de contrato pasa por acuerdo del equipo (PR al Bloque 0).

---

## BLOQUE 0 — Contratos compartidos · 🔑 keystone

**Owner sugerido:** Rodrigo (backend core) — pero se **revisa entre los 3** antes de congelar.
**Bloquea a:** A, B, C, D, E. **No puede empezar nada serio sin esto.**

### Deliverables
1. `services/agent_base.py` — contrato común:
   ```python
   class AgentContext(BaseModel):
       engagement_id: int
       goal: str
       scope: list[ScopeTarget]
       roe: ROE
       prior_state: dict          # lectura del blackboard
       budget_steps: int = 12
       budget_tokens: int = 200_000

   class AgentResult(BaseModel):
       agent: str
       status: Literal["completed","waiting_hitl","partial","failed","aborted"]
       rationale: str             # NL — POR QUÉ actuó así (obligatorio)
       findings_count: int = 0
       artifacts: dict = {}       # surface_map / analysis / report_path / etc.
       pending_hitl_ids: list[int] = []
       budget_used: dict = {}     # {"steps": n, "tokens": n}

   class BaseAgent(ABC):
       async def run(self, ctx: AgentContext) -> AgentResult: ...
   ```
2. `services/blackboard.py` — acceso al estado compartido (Mongo). Colecciones/docs:
   - `surface_map`     (ya existe) — salida de Recon
   - `findings`        (ya existe) — salida de Scan
   - `analysis`        (**nuevo**) — salida de Analysis (CVEs, ATT&CK, vectores, prioridad)
   - `agent_rationales`(**nuevo**) — `{engagement_id, agent, run_id, rationale, ts}`
   - `orchestrator_conversation` (**nuevo**) — turnos operador↔orquestador
   API: `read(engagement_id, keys) -> dict`, `write(engagement_id, key, payload)`.
3. **Interfaz agent-as-tool** — JSON schema con el que el Orquestador invoca un worker:
   ```json
   {"name":"run_scan_agent",
    "input_schema":{"engagement_id":"int","goal":"str","intensity":"str?"}}
   ```
   y el `AgentResult` serializado como retorno. Documentar en este archivo (§contratos).
4. `config/models.py` (o env): `ORCHESTRATOR_MODEL`, `ANALYSIS_MODEL`,
   `SCAN_AGENT_MODEL`, `RECON_AGENT_MODEL`, `REPORTER_MODEL` con defaults del tiering (ADR §3.5).

### Aceptación
- [ ] Los Pydantic models compilan y tienen tests de (de)serialización.
- [ ] `blackboard.read/write` con test contra Mongo de dev.
- [ ] Documento de contratos (este archivo, §"Contratos congelados") revisado por los 3.
- [ ] Stubs de `BaseAgent` para que A/B/C/D puedan importar sin esperar implementación.

---

## BLOQUE A — Orquestador + chat del operador

**Owner sugerido:** Rodrigo (backend/front, operador-facing). **Depende de:** B0.
**Puede stubbear** los workers como agent-as-tool mientras D/B/C los terminan.

### Deliverables
- `services/orchestrator_agent.py` — agente LLM (Opus) con los 4 workers como
  tools + tools de lectura del blackboard. Loop: intención → plan → delega →
  reacciona → narra. Modo **plan-preview** (devuelve plan antes de ejecutar).
- Endpoint conversacional `POST /engagements/{id}/orchestrator` (mensaje del
  operador) + stream por la **espina SSE existente**.
- Frontend: panel de chat del operador (reusar estilos `theme.js`).
- El orquestador invoca al **Bloque E** (ejecutor seguro) para correr stages,
  no llama a los agentes salteándose el bookkeeping/guardarraíles.

### Aceptación
- [ ] El operador pide en NL ("escaneá esto en modo sigiloso") y el orquestador
  arma un plan coherente (verificable con workers stub).
- [ ] Plan-preview funciona: el operador ve el plan antes de ejecutar.
- [ ] HITL sigue siendo control explícito (no por chat).
- [ ] Conversación persistida en `orchestrator_conversation`.

---

## BLOQUE B — AnalysisAgent + Analysis MCP (NVD)

**Owner sugerido:** David (LLM/análisis). **Depende de:** B0 + `findings` en blackboard.
**Independiente** del orquestador (se puede invocar directo para validar).

### Deliverables
- `mcp_servers/analysis_server.py` — Analysis MCP, tools risk LOW (auto-approve):
  - `cve_lookup(product, version)` → CVEs reales + CVSS (NVD API 2.0; **caché en
    Mongo** por rate-limit 5 req/30s sin API key).
  - `attack_technique_lookup(query)` → valida technique_id contra dataset MITRE
    ATT&CK local (evita IDs alucinados — hallazgo A4).
- `services/analysis_agent.py` (Opus, contrato B0): lee findings → razona →
  correlaciona CVE/ATT&CK → **vectores de ataque (kill chains)** → prioriza por
  explotabilidad. Escribe `analysis` + `rationale` en el blackboard.
- Endpoint `POST /engagements/{id}/analysis` (cierra HU-12, HU-13).

### Aceptación
- [ ] Sobre los findings reales de Metasploitable2, produce CVEs verificados (no
  alucinados) con CVSS desde NVD.
- [ ] Mapea técnicas ATT&CK validadas contra el dataset local.
- [ ] Emite ≥1 vector de ataque con evidencia encadenada.
- [ ] `rationale` explica la priorización.

---

## BLOQUE C — ReporterAgent (servicio puro)

**Owner sugerido:** David (reportería). **Depende de:** B0 + esquema `analysis` (B).
**Independiente:** mockea `analysis` para desarrollar el render en paralelo.

### Deliverables
- `services/reporter_agent.py`: narrativa por LLM (Sonnet) + render determinista
  Jinja2/WeasyPrint (SPIKE-02 ya validó UTF-8).
- `templates/report_technical.html` y `report_executive.html`.
- Endpoint `POST /engagements/{id}/report?type=technical|executive` → PDF (HU-14).
- Frontend `ReportesView.jsx` conectado al endpoint real.

### Aceptación
- [ ] PDF técnico con findings por severidad + evidencia + mapeo ATT&CK.
- [ ] PDF ejecutivo con top-3 riesgos, sin evidencia cruda.
- [ ] UTF-8 español correcto.

---

## BLOQUE D — Refactor Recon/Scan al contrato (goal-driven)

**Owner sugerido:** Yerson (agentes/MCP/scanning). **Depende de:** B0.
**Independiente:** sus salidas (surface_map/findings) ya las consumen otros por blackboard.

### Deliverables
- Reescribir `recon_agent.py` y `scan_agent.py` al contrato B0:
  - prompt de **objetivo**, no checklist.
  - ScanAgent lee `ROE.scan_intensity` y elige timing/ports/tags (dentro de scope).
  - terminación por criterio + presupuesto (no matriz agotada).
  - escribe `rationale` en el blackboard; estado persistido (continuidad tras HITL).
- Mantener `@enforce_scope` + HITL **sin cambios** (guardarraíles).

### Aceptación
- [ ] Con `scan_intensity=STEALTH` vs `AGGRESSIVE`, el agente usa timing distinto
  (decisión observable, no hardcode).
- [ ] Tras un HITL aprobado, retoma sin re-planificar de cero (lee blackboard).
- [ ] `rationale` no vacío y coherente con lo ejecutado.
- [ ] Scope+HITL siguen pasando los tests existentes.

---

## BLOQUE E — PipelineController → ejecutor seguro

**Owner sugerido:** Yerson o Rodrigo. **Depende de:** B0. **Correlativo con A.**

### Deliverables
- Degradar `PipelineController` a **ejecutor seguro**: ya no decide el orden
  (eso lo hace el Orquestador); expone `run_stage(agent_name, ctx)` que:
  conserva pipeline_runs/stages, el gating HITL y el anti-zombi de Fase 1.
- Registrar **los 4 agentes** en `_AGENT_REGISTRY` (hoy solo 2).
- El Orquestador (A) llama a este ejecutor; nunca instancia agentes salteándose
  los guardarraíles.

### Aceptación
- [ ] `_AGENT_REGISTRY` tiene los 4 agentes.
- [ ] Bookkeeping y anti-zombi de Fase 1 intactos (regresión: tests HITL).
- [ ] El orden ya no es una constante; lo decide el caller (orquestador).

---

## Secuenciación realista (deadline 9-jun)

1. **Día 0 (juntos):** congelar Bloque 0. Sin esto no arranca nada en paralelo.
2. **Paralelo:** D (Yerson), B (David), A+E (Rodrigo). C (David) tras B.
3. **MVP demostrable** si el tiempo aprieta — prioridad para la defensa:
   - B (AnalysisAgent) + C (Reporter) cierran HU-12/13/14 → reporte real end-to-end.
   - A (Orquestador+chat) es el cambio cualitativo más visible frente a la crítica.
   - Si D no llega completo: dejar Recon/Scan actuales detrás del ejecutor seguro
     (E) y del orquestador (A) — el sistema ya se ve agéntico desde arriba aunque
     los workers de scan sigan siendo conservadores.

## Contratos congelados ✅ (Bloque 0 cerrado — 2026-05-29)

> Referencia única. Cualquier cambio = PR revisado por los 3.
> Verificado: **62 tests verdes** (incluye 13 de contratos) + blackboard probado
> contra Mongo vivo + `ensure_indexes()` sin errores + backend sano tras reload.

### Archivos entregados
| Archivo | Qué expone |
|---------|------------|
| `services/agent_base.py` | `ScopeItem`, `AgentContext`, `AgentResult`, `BaseAgent` (ABC), `AGENT_NAMES`, `AGENT_TOOL_SCHEMAS`, `TOOL_NAME_TO_AGENT`, `build_agent_context()` |
| `services/blackboard.py` | `read_state`, `write_analysis`, `record_rationale`, `read_rationales`, `append_conversation`, `read_conversation` |
| `services/agent_config.py` | `orchestrator_model/analysis_model/scan_agent_model/recon_agent_model/reporter_model`, `model_for()`, `RECOMMENDED_TIERING`, `FAST_MODEL_DEFAULT` |
| `mongo_schemas.py` (+) | `AnalysisDoc`, `AgentRationaleDoc`, `ConversationTurnDoc` |
| `mongo_client.py` (+) | shortcuts `analysis_col/agent_rationales_col/orchestrator_conversation_col` + índices |

### Contratos
- [x] **`AgentContext`**: `engagement_id, goal, scope:[ScopeItem], roe:ROE, prior_state:dict, budget_steps=12, budget_tokens=200k, operator_directive?`. Helper `.targets()`.
- [x] **`AgentResult`**: `agent, status, rationale (obligatorio), findings_count, artifacts, pending_hitl_ids, budget_used, error?`. `extra=forbid`. `status ∈ {completed, waiting_hitl, partial, failed, aborted, skipped}`.
- [x] **`BaseAgent`**: ctor `(engagement_id, db, pipeline_run_id?)`, `async run(ctx) -> AgentResult`, attr `name`.
- [x] **Blackboard** (1 doc/engagement salvo donde se indica): `surface_map`, `findings`, `analysis` (upsert), `agent_rationales` (append), `orchestrator_conversation` (append).
- [x] **agent-as-tool** (nombres ESTABLES): `run_recon_agent`, `run_scan_agent` (+`intensity`), `run_analysis_agent`, `run_reporter_agent` (+`report_type`). Input requerido: `engagement_id, goal`. Retorno: `AgentResult` serializado.
- [x] **Tiering de modelos**: env `ORCHESTRATOR_MODEL/ANALYSIS_MODEL/SCAN_AGENT_MODEL/RECON_AGENT_MODEL/REPORTER_MODEL`. Default seguro = `FAST_MODEL_DEFAULT` (Haiku). Activar Opus/Sonnet por env (pendiente §4.1).

### Cómo lo consume cada bloque
- **A (orquestador)**: `AGENT_TOOL_SCHEMAS` como tools del LLM; `TOOL_NAME_TO_AGENT` para mapear; `append/read_conversation`; invoca workers vía el ejecutor (E).
- **B (analysis)**: `read_state(include=("findings",))` → razona → `write_analysis()` + `record_rationale()`.
- **C (reporter)**: `read_state(include=("analysis","findings"))` → render.
- **D (recon/scan)**: implementan `BaseAgent`; reciben `AgentContext` (leen `roe.scan_intensity`); escriben `record_rationale()`.
- **E (ejecutor)**: `build_agent_context()` + `model_for()` + registra los 4 en `_AGENT_REGISTRY`.
