# ETH-MAS — Plan de cierre para la presentación evaluada (vie 2026-06-19)

> **Qué es esto:** plan de trabajo acordado el 2026-06-17 para llegar a la
> **última presentación evaluada antes de la defensa Capstone** (comisión). El
> viernes 19-jun es un checkpoint calificado, **no** la defensa final — por eso la
> estrategia separa lo que *debe* estar listo el viernes de lo que es la meta real
> y puede cerrarse después.
>
> **Deadline duro:** jueves 18-jun noche (todo lo de Pista 1 validado).
> **Estado:** definición acordada · arranca por la Sesión 0.

---

## Estrategia: dos pistas

> **La demo on-prem es la red de seguridad garantizada para el viernes; la
> Variante A (GCP real) es la meta verdadera, pero se construye *encima* de la red
> de seguridad, no en lugar de ella.**

- **Pista 1 — Red de seguridad (lockear antes del jue noche).** Demo on-prem
  validada + arquitectura defendida. Es lo que se presenta el viernes pase lo que
  pase con la Pista 2.
- **Pista 2 — Variante A / GCP real (arranca SOLO cuando Pista 1 esté lockeada).**
  Es lo realmente esperado para la defensa Capstone; si no llega validada al
  viernes, la on-prem cubre la presentación.

**Reglas de oro:**
1. **R1 manda** (riesgo crítico del release plan): la corrida 4/4 real (Sesión 0)
   es lo **primero** que se ejecuta — puede revelar un bug de integración entre
   agentes y no queremos descubrirlo la víspera.
2. **Recorte si aprieta el tiempo:** nunca se tocan S0 / S1 / S7. Lo primero que se
   sacrifica es S5 (HU-20, INFRA-02, HU-21 son todas *Could*) y construir GCP real.

---

## Pista 1 — Red de seguridad (on-prem + arquitectura)

| # | Sesión | Definition of Done | Cierra |
|---|--------|--------------------|--------|
| **0** | Corrida 4/4 real `.10` + sync de rama | Pipeline Recon→Scan+HITL→Analysis→Reporte corre completo sobre `10.42.0.10` en el código con los fixes B1-B8 desplegados. Se captura el estado real de B1/B5/B6/B7/B8. | HU-07, HU-09, HU-19 |
| **1** | Reportes pulidos | Ejecutivo sin jerga (B7: tags `[Nuclei]`/`[Nikto]`, nombres de servicio, URLs, refs CVE/MITRE residuales). `empty <li>=0` en el HTML renderizado (B6). | B6, B7 |
| **2** | MITRE estable (B5) | *Solo si la Sesión 0 lo muestra inestable.* Análisis 3× seguidas → técnicas MITRE idénticas. | B5 |
| **3** | Features UI | Popover MITRE al pasar sobre la técnica/táctica + link a `attack.mitre.org`. Fix header B1 (refresca a `completed`). Observabilidad B8 (los 4 stages en `PipelineView`, no solo Scan). | B1, B8 + feature |
| **4** | Simplificar ROE | Quitar `time_windows` del schema ROE (§4.5), del form `EngagementSetupView.jsx` y del template. Ejecución = al iniciar el pipeline. | feature |
| **5** | DVWA `.20` + cerrar release plan | E2E sobre `10.42.0.20` (HU-20). CI mínimo en el repo (INFRA-02). Métricas de calidad desde tests/E2E (HU-21). | HU-20, INFRA-02, HU-21 |
| **6** | Merge + on-prem productivo | PR `feature/frontend-ia-redesign` → `main` + tag `v0.3`. Stack docker on-prem vivo (Variante B). Doc + diagrama GCP/on-prem listos para defender. | gobernanza |
| **7** | Ensayo de demo | Script paso a paso ensayado + **corrida de respaldo grabada** (mitiga R4: Docker falla en vivo). | HU-19 demo |

## Pista 2 — Variante A / GCP real (post-lock de Pista 1)

Checklist §8 de [`despliegue-produccion-gcp-onprem.md`](despliegue-produccion-gcp-onprem.md).

| # | Sesión | Definition of Done |
|---|--------|--------------------|
| **A1** | Extraer scan worker | `ScanAgent` + `mcp_servers/{security,osint}_server.py` + tools como paquete Docker desplegable aparte. |
| **A2** | Contrato de jobs | `GET /scan-jobs/next` (poll saliente) + `POST /engagements/{id}/findings` (o Pub/Sub). El backend encola job al aprobar el HITL y deja de spawnear el Security MCP local. |
| **A3** | Infra GCP | GCE VM (backend), Cloud SQL (Postgres), MongoDB Atlas (+ peering), Cloud Run/Storage (frontend), Pub/Sub (cola). Secrets en Secret Manager + `.env` del worker on-prem. |
| **A4** | E2E híbrido + aislamiento | Worker on-prem dial-out a GCP, scan al lab aislado, findings persistidos en Atlas, SSE al front GCP. Verificar lab host-only **sin egress** a internet. |

---

## Contexto que sostiene el plan

- **El proyecto está a "falta validar el todo", no "falta construir".** Según
  `release-planning.md` §5, una sola corrida 4/4 de 8-10 min cierra HU-07, HU-09 y
  HU-19 y valida HU-12/13/14/15 en runtime. De ahí que la Sesión 0 sea la de mayor
  apalancamiento.
- **Reportes del operador (cruzadas .10/.20):** sospecha de **código stale** — los
  fixes B1-B8 ya están aplicados/verificados/pusheados en
  `fix/report-orchestrator-bugs-b1-b8`. La Sesión 0 confirma si B5/B8 "siguen
  fallando" por falta de despliegue. Residuales reales probables: B7 (jerga
  ejecutivo), B6 (`•` suelto en texto), B1 (header UI muestra `pending`).
- **Despliegue productivo:** la arquitectura GCP/on-prem ya está escrita como
  "to-be" (doc + `.drawio`). Variante A = trabajo de varios días; Variante B =
  monolito actual apuntando a DBs gestionadas (fallback rápido para demo).

---

## Calendario

| Día | Foco |
|-----|------|
| mié 17-jun | Sesión 0 (corrida 4/4) → Sesiones 1-4 según resultado |
| jue 18-jun | Cerrar Pista 1 (S5-S7). **Lock de la red de seguridad a la noche.** |
| vie 19-jun | Presentación evaluada (demo on-prem + arquitectura). |
| post-viernes → defensa Capstone | Pista 2 (Variante A / GCP real). |
