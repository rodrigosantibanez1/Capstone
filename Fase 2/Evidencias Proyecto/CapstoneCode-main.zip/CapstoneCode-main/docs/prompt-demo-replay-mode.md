# Prompt — Construir el "Modo Replay" (demo / método de cocina) para ETH-MAS

> Para usar en una sesión nueva (Claude Code) ubicada en la raíz del repo
> `CapstoneCode/`. Asume cero contexto previo. Antes de implementar, carga
> únicamente el contexto necesario leyendo los archivos que se indican en cada
> sección (no explores el repo entero).

---

## Rol y objetivo

Eres un ingeniero full-stack en **ETH-MAS** (Ethical Hacking Multi-Agent System), un prototipo académico de pentesting asistido por IA con control humano. La tarea: construir un **Modo Replay** separado, **solo para la demo de la defensa**, que **reproduzca visualmente un engagement ya ejecutado y cerrado** (la corrida real sobre el lab) **sin volver a ejecutar nada** — sin llamadas a LLM, sin NVD, sin herramientas de scan, sin tocar el target. El replay trae lo ya generado (persistido en PostgreSQL + MongoDB) y lo reproduce con **timing acelerado** ("método de cocina": los tiempos de carga y las esperas largas —HITL, timeouts de nuclei/nikto— se recortan; los resultados ya obtenidos se muestran de inmediato, pero respetando la progresión visual paso a paso).

Debe quedar **completamente aislado** del pipeline real: no crea datos nuevos, no muta el engagement "golden", no cambia el comportamiento del pipeline en vivo.

## Contexto a cargar primero (leer estos archivos, en este orden)

Lee solo lo necesario para entender formas y convenciones; no hace falta abrir todo el repo:

1. `docker-compose.yml` — servicios, perfiles (`lab`), puertos.
2. `eth-mas-backend/models.py` — tablas PostgreSQL: `engagements`, `scope_targets`, `hitl_actions`.
3. `eth-mas-backend/mongo_schemas.py` — documentos Mongo: `AgentRunDoc` (con `tools_called[]` y el campo `narration`), `PipelineRunDoc`, `FindingDoc`, `SurfaceMapDoc`, `AnalysisDoc`, `ConversationTurnDoc`.
4. `eth-mas-backend/services/narration.py` — frases legibles ya generadas en backend (se reutilizan tal cual en el replay).
5. `eth-mas-backend/routers/__init__.py` y un router de lectura (p. ej. `routers/observability.py`) — patrón de registro de routers y de endpoints de lectura/SSE.
6. `eth-mas-frontend/src/views/PipelineView.jsx` y `src/views/OrchestratorChatView.jsx` — estilo, consumo de SSE/REST y componentes reutilizables (`StageCard`, `TurnBubble`).
7. `eth-mas-frontend/src/components/ActivityConsole.jsx` — cuadro de actividad que ya renderiza la narración (base del feed del replay).
8. `eth-mas-frontend/src/lib/api.js` y `src/lib/routes.js` — `authedFetch`, `API_BASE`, `ROUTES`, `NAV_DEFINITION`.

## Orientación al proyecto (lo mínimo)

- **Stack en Docker.** Backend FastAPI (Python 3.11) en `eth-mas-backend/` (puerto 8000); frontend React 19 + Vite + **Tailwind v4 + shadcn/ui** + react-router-dom v7 en `eth-mas-frontend/` (puerto 80); PostgreSQL + MongoDB.
- **Levantar:** `docker compose up -d db mongo backend frontend` y `docker compose --profile lab up -d`. Health: `GET http://localhost:8000/health/services` (overall=up). El backend corre con `--reload` y bind-mount → los `.py` recargan solos.
- **Convenciones frontend:** cliente HTTP `@/lib/api` (`authedFetch`, `API_BASE`); rutas `@/lib/routes` (`ROUTES` + `NAV_DEFINITION`); toasts `sonner`; íconos `lucide-react`; UI `@/components/ui/*`; helper `cn` en `@/lib/utils`.
- **Auth:** en dev la X-API-Key está desactivada; `authedFetch` la inyecta si existe.
- **Rama:** trabaja en una rama nueva a partir de `release/v0.3`, p. ej. `feature/demo-replay-mode`. No commitear a `main` ni a `release/v0.3` directo.

## Qué reproducir (todo ya está persistido — solo lectura)

No agregar campos nuevos al modelo. La forma exacta de cada estructura está en los archivos del punto anterior; en resumen:

- **PostgreSQL:** engagement (id, name, status, roe, att_tactics, fechas), scope (`Engagement.scopes`: target_value, target_type), `hitl_actions` (agent, tool, risk_level, decision, operator, requested_at, decided_at).
- **MongoDB:** `agent_runs` (con `narration` y `tools_called[]`, cada tool con `narration`, status, duration_ms, started_at/finished_at), `pipeline_runs` (`stages[]`), `findings` (severity, cvss, cve_ids, mitre_technique, discovered_at), `analysis` (enriched_findings, attack_vectors, summary), `orchestrator_conversation` (role, content, created_at).
- **Narración (clave):** las frases legibles ya vienen en `agent_runs.narration` y `tools_called[].narration` (ej.: "🔍 Reconocimiento iniciado sobre 2 objetivos", "Recon usando OSINT para consultar WHOIS de 10.42.0.10"). El replay las muestra tal cual.

Endpoints de lectura existentes reutilizables (confirmar paths exactos en `routers/`): `GET /engagements/{id}`, `/engagements/{id}/agent-runs`, `/engagements/{id}/pipeline-runs`, `/engagements/{id}/findings`, `/engagements/{id}/orchestrator/conversation`, `/engagements/{id}/hitl-actions`, y el listado de reportes.

## Arquitectura recomendada

### 1) Backend — endpoint de snapshot read-only
Crear `GET /engagements/{id}/replay-snapshot` (router nuevo `routers/replay.py`, registrado en `routers/__init__.py`). Devuelve en un solo JSON todo lo replayable, leyendo de los servicios/colecciones existentes, **sin mutar nada**:

```jsonc
{
  "engagement": { "id": ..., "name": ..., "status": ..., "scope": [...], "roe": ..., "att_tactics": [...] },
  "conversation": [ /* orchestrator_conversation, asc por created_at */ ],
  "pipeline_run": { /* el representativo: más stages, desempate por reciente */ },
  "agent_runs": [ /* con tools_called */ ],
  "findings": [ ... ],
  "analysis": null,
  "hitl_actions": [ ... ],
  "reports": [ { "type": ..., "file_id": ..., "created_at": ..., "name": ... } ]
}
```

Reglas: read-only, sin efectos secundarios; si falta algo (p. ej. analysis), devolver `null`/`[]` sin error. Mismo patrón de auth que los demás GET de lectura.

### 2) Backend — generador de timeline (módulo puro, testeable)
`services/replay_timeline.py`: función pura `build_replay_timeline(snapshot, mode) -> list[ReplayEvent]` que aplana el snapshot en una lista ordenada de eventos con timestamp real:

- `run_start` (agent, narration) en `agent_run.started_at`.
- `tool_start` (narration, params) en `tool.started_at`; `tool_end` (status, duration_ms, output_preview) en `tool.finished_at`.
- `finding` (severity, summary, cve…) en `finding.discovered_at`.
- `hitl_requested` (risk, tool) en `hitl.requested_at`; `hitl_decided` (decision) en `hitl.decided_at`.
- `chat_turn` (role, content) en `turn.created_at`.
- `stage_change` (agent, status) por transición de `pipeline_run.stages`.
- `analysis_ready` en `analysis.generated_at`; `report_ready` en `report.created_at`.

Después **comprimir el tiempo**: mapear `[t_min, t_max]` real a `[0, DEMO_BUDGET]` con un tope de gap entre eventos consecutivos (el "método de cocina": las esperas largas colapsan). Modos:
- `instant` — todo en t=0 (mostrar el estado final ya).
- `fast` (default) — pipeline completo en ~60–90 s; gaps proporcionales capados a ≤1.5 s.
- `realish` — proporcional, capado a ≤4 s (más natural, sin esperas eternas).

Cada evento lleva `t_offset_ms` (cuándo dispararlo desde el play). Incluir tests (`tests/test_replay_timeline.py`): orden estable, sin offsets negativos, la compresión respeta el budget, `instant` deja todo en 0.

### 3) Frontend — Replay Player (ruta nueva)
Nueva vista `src/views/ReplayView.jsx` + ruta en `@/lib/routes` (p. ej. `ROUTES.replay = '/replay'`) y entrada en `NAV_DEFINITION` (grupo "Demo"). Componentes nuevos en `src/components/replay/`.

UI:
- **Selector de "golden engagement":** lista de engagements `completed` (permitir fijar un id por defecto, p. ej. `?engagement=NN` o `localStorage`). Mostrar nombre/fecha.
- **Controles:** Play / Pause / Reiniciar, selector de velocidad (Instant / Fast / Realish) y una barra de progreso/scrubber.
- **Badge visible "MODO REPLAY · engagement #NN · corrida del <fecha>"** (ver nota de honestidad).
- **Motor de reproducción (cliente):** hacer fetch del snapshot, armar el timeline (reutilizar la lógica del backend si se expone el timeline ya armado, o reconstruirlo en el cliente) y revelar los eventos según `t_offset_ms` con un timer. Pause congela; el scrubber salta a un offset (recalcula qué eventos ya ocurrieron).
- **Render reutilizando lo existente** (no reinventar el look):
  - Cuadro de actividad: reutilizar/adaptar `ActivityConsole.jsx` para que consuma el feed de eventos del replay (mismas frases con ícono de estado/duración).
  - Stepper de pipeline: reutilizar `StageCard` (extraerlo de `PipelineView.jsx` si hace falta) para mostrar Recon → Scan → Analysis → Report avanzando.
  - Chat del orquestador: reutilizar el estilo de `TurnBubble` (de `OrchestratorChatView.jsx`) para mostrar la conversación apareciendo turno a turno.
  - Findings apareciendo progresivamente (lista por severidad), heatmap MITRE (`src/components/analysis/AttackCoverageHeatmap.jsx`) al llegar `analysis_ready`, y un panel de reporte al `report_ready`.
- **HITL en el replay:** al `hitl_requested`, mostrar "⏸ esperando aprobación (HITL #id)"; al `hitl_decided`, "✓ aprobado por {operator}" y continuar. En replay no hay aprobación real: es parte de la reproducción.

## Restricciones (no negociables)

1. **Read-only / sin efectos:** el replay nunca llama a Anthropic/NVD/herramientas, nunca crea `agent_runs`/`findings`/`hitl_actions`/`pipeline_runs`, nunca muta el engagement golden ni ningún dato.
2. **Aislado:** ruta, endpoint y componentes separados. No modificar el flujo del pipeline en vivo ni las vistas existentes, salvo extracción no disruptiva de componentes compartidos (`StageCard`).
3. **Honestidad académica (recomendado, configurable):** mostrar el badge "MODO REPLAY". Es una defensa evaluada; presentar resultados pre-grabados como si fueran en vivo es riesgoso. El badge va visible por defecto; si el equipo decide ocultarlo, que sea un toggle explícito, no el default.
4. **Determinismo:** misma corrida golden → misma reproducción (orden estable, sin aleatoriedad).
5. **Sin datos sensibles ni payloads enormes en el front:** truncar `raw_output`/`output_preview` razonablemente.

## Preparar el "golden engagement" (precondición de la demo)
Antes de usar el replay, ejecutar una vez el pipeline real completo sobre el lab y cerrarlo, para tener datos ricos:
1. `docker compose --profile lab up -d` (ms2 `10.42.0.10`, dvwa `10.42.0.20`).
2. Crear engagement con **scope por IP** (`10.42.0.10`, `10.42.0.20`) — no CIDR (workaround H-3 conocido).
3. Con `ORCHESTRATOR_MODEL`/`ANALYSIS_MODEL` = `claude-opus-4-8`, ejecutar Recon → Scan (aprobar los HITL en la consola) → Analysis → Report, end-to-end.
4. Cerrar el engagement (status → completed). Registrar su id: ese es el golden por defecto del replay.

## Criterios de aceptación
- [ ] `GET /engagements/{id}/replay-snapshot` devuelve el bundle completo, read-only, y maneja faltantes sin romper.
- [ ] `build_replay_timeline` ordena y comprime correctamente; tests verdes.
- [ ] La vista Replay reproduce un engagement completo: chat + stepper + narración en vivo + findings progresivos + heatmap MITRE + reporte, con Play/Pause/velocidad/scrubber.
- [ ] El modo `instant` muestra el estado final inmediato; `fast` reproduce todo en ~60–90 s sin esperas largas.
- [ ] Badge "MODO REPLAY" visible. Cero escrituras a BD durante un replay (verificable: los contadores de `agent_runs`/`findings` no cambian).
- [ ] Build de Vite OK; la suite del backend sigue verde (`docker exec eth_mas_backend uv run pytest tests/ -q`).
- [ ] No se modifica el comportamiento del pipeline en vivo.

## Verificación esperada
- Levantar el stack, preparar (o reutilizar) un golden engagement, abrir la pestaña Replay, seleccionarlo e iniciar la reproducción. Confirmar que se ve la progresión completa sin re-ejecutar herramientas (en los logs del backend no debe haber tool calls MCP ni llamadas a Anthropic durante el replay).
- Probar Pause / Reiniciar / cambio de velocidad y el scrubber.

## Fuera de alcance (no hacer)
- No re-ejecutar herramientas ni "rehidratar" llamando a los agentes.
- No tocar Variante A (scan-worker), que vive en su propia rama.
- No modificar `services/narration.py` ni el pipeline real (solo consumirlos).

## Entregables
- `eth-mas-backend/routers/replay.py` (+ registro), `eth-mas-backend/services/replay_timeline.py`, `eth-mas-backend/tests/test_replay_timeline.py`.
- `eth-mas-frontend/src/views/ReplayView.jsx`, `src/components/replay/*`, ruta + nav.
- Un `.md` corto en `docs/` con cómo preparar el golden engagement y operar el replay en la defensa.
- Todo en la rama `feature/demo-replay-mode` (a partir de `release/v0.3`).
