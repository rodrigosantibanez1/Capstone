# Prompt para nueva sesión — Pista 2 / Variante A (despliegue GCP real)

> Pegá el bloque de abajo como primer mensaje de una sesión nueva. Le da a Claude
> todo el contexto para abordar la Pista 2 desde cero.

---

```
Contexto del proyecto
=====================
ETH-MAS (Ethical Hacking Multi-Agent System) — Capstone DUOC UC 2026. Pipeline de
pentesting asistido por IA con control humano: 4 agentes LLM (ReconAgent → ScanAgent
→ AnalysisAgent → ReporterAgent) orquestados sobre un blackboard, que invocan
herramientas reales de seguridad (nmap/nuclei/nikto/gobuster, OSINT) vía MCP.
Garantías: scope enforcement programático, HITL bloqueante, mapeo MITRE ATT&CK.

Stack: FastAPI/Python 3.11 (gestor uv) · React 19 + Vite + Tailwind v4 + shadcn ·
PostgreSQL 15 · MongoDB 7 · Alembic · MCP · Jinja2/WeasyPrint. Modelos: Recon/Scan =
Haiku, Analysis = Opus 4.7 (ver .env). Repo local: C:\Users\User\Documents\Claude\
Projects\ETH-MAS\CapstoneCode (git remote origin = github.com/rodrigosantibanez1/
CapstoneCode). Hay CLAUDE.md y archivos de memoria con el historial completo.

Estado actual
=============
- Pista 1 (red de seguridad on-prem para la presentación evaluada) está COMPLETA,
  mergeada a `main` y etiquetada `v0.3` en remoto (merge commit ea6d826).
- On-prem "Variante B" (docker-compose monolítico) validado y sano: pipeline 4/4
  real corrido sobre el lab (Metasploitable2 #26 = 38 findings, DVWA #27 = 12
  findings), reportes técnico+ejecutivo, 179 tests verdes.
- Levantar el stack: en PowerShell (NO bash — el daemon Docker no es alcanzable por
  bash), `cd CapstoneCode; docker compose --profile lab up -d`. Health:
  `docker exec eth_mas_backend curl -s localhost:8000/health/services`. Tests:
  `docker exec eth_mas_backend uv run pytest tests/ -q`.

Objetivo de esta sesión: PISTA 2 — Variante A (despliegue productivo GCP + on-prem)
==================================================================================
Construir la arquitectura productiva "to-be" hacia la defensa Capstone (posterior a
la presentación del viernes). Está especificada en:
  - docs/despliegue-produccion-gcp-onprem.md  (arquitectura, §4 variantes, §8 checklist)
  - docs/despliegue-produccion-gcp-onprem.drawio  (diagrama)

Diseño (híbrido de dos planos):
  - Plano de APP + datos → GCP: Frontend (Cloud Run/Storage), Backend
    (GCE VM: orquestador + AnalysisAgent + ReporterAgent + HITL + dispatcher),
    PostgreSQL (Cloud SQL), MongoDB (Atlas + VPC peering), cola (Pub/Sub).
  - Plano de ESCANEO + lab → on-prem (máquina del operador): ScanAgent + Security MCP
    + OSINT MCP + tools + lab aislado. Hace job-pull (polling saliente) a GCP.
  - LLM → API 1st-party de Anthropic (egress HTTPS desde ambos planos).

CONSTRAINT DURO (innegociable): el laboratorio vulnerable (Metasploitable2 + DVWA)
NUNCA se expone a internet. Vive on-prem en red host-only aislada, sin egress.

Checklist de construcción (§8 del doc, Variante A):
  A1. Extraer ScanAgent + mcp_servers/{security,osint}_server.py + tools como un
      worker desplegable por separado (Docker).
  A2. Definir el contrato de job: GET /scan-jobs/next (poll saliente) +
      POST /engagements/{id}/findings (resultados) — o equivalente Pub/Sub. El
      backend encola un job al aprobarse el HITL y deja de spawnear el Security MCP
      localmente.
  A3. Worker: loop de poll saliente + is_target_in_scope local + ejecución de scan +
      post de findings a la API del backend.
  A4. Infra GCP: GCE VM (backend), Cloud SQL (Postgres), Atlas (Mongo + peering),
      Cloud Run/Storage (frontend), Pub/Sub (cola). Secrets en Secret Manager (GCP)
      + .env en el worker on-prem. Verificar lab host-only sin egress.

Estrategia recomendada (de-risk):
  Empezar por A1–A3 LOCALMENTE: separar el scan worker en su propio contenedor y que
  el backend hable con él vía el contrato de job (poll + post findings), validado en
  on-prem PRIMERO. Recién cuando el split de dos planos funcione local, mover el plano
  de app a GCP (A4). Así se prueba la arquitectura sin pagar GCP de entrada y sin
  romper el camino on-prem que ya funciona (Variante B sigue siendo el fallback).

Riesgos/puntos abiertos a resolver (del doc §9):
  - HITL a través de la cola: el worker on-prem solo debe recibir jobs YA aprobados
    (el HITL se resuelve en GCP antes de encolar) para evitar polling de estado HITL
    cross-network. Confirmar que el UX de aprobación encaja.
  - Latencia del job-pull (intervalo de poll) — aceptable para scans (minutos).
  - Si el backend quedara on-prem (Variante B fallback), el frontend GCP debe
    alcanzarlo (túnel/endpoint).

Decisiones que necesito confirmar con el usuario al arrancar:
  - ¿Hay cuenta/proyecto GCP con billing habilitado? ¿Región preferida?
  - ¿Cuenta MongoDB Atlas (M0 free sirve para el Capstone)?
  - ¿Presupuesto? (el doc apunta a free/micro tiers + costo dominante = tokens LLM).
  - ¿Dominio/DNS para el frontend, o IP/URL de Cloud Run basta?

Primeros pasos sugeridos:
  1. Leer docs/despliegue-produccion-gcp-onprem.md completo + revisar los archivos
     de memoria (historial Pista 1).
  2. Confirmar las decisiones GCP de arriba con el usuario.
  3. Crear rama nueva desde `main` (ej. feature/variante-a-scan-worker).
  4. Empezar A1: mapear las dependencias del ScanAgent + Security/OSINT MCP para
     extraerlos a un worker; diseñar el contrato de job (A2) antes de codear.
  NO mergear a main sin PR. NO exponer el lab. Mantener Variante B funcionando.
```

---

*Generado al cerrar la Pista 1 (2026-06-18). El working tree local quedó en `main`
(v0.3). La Pista 2 arranca en rama nueva.*
