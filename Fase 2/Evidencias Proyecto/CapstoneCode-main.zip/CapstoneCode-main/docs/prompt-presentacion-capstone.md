# Prompt para nueva sesión — Construir la presentación (PPTX)

> Pegá el bloque de abajo como primer mensaje de una sesión nueva, y **adjuntá tu
> estructura base + el pptx de ejemplo**. El prompt aporta el contenido/sustancia;
> tu estructura define el orden y el pptx de ejemplo define el estilo/formato.

---

```
Tarea
=====
Construir la presentación (archivo .pptx) del proyecto Capstone ETH-MAS para la
presentación evaluada. Adjunto: (1) mi ESTRUCTURA BASE (el índice/orden de slides que
quiero) y (2) un PPTX DE EJEMPLO (para que copies su estilo: paleta, tipografías,
layouts, densidad). Sigue mi estructura para el ORDEN y el pptx de ejemplo para el
LOOK & FEEL. Usa la skill de PowerPoint (pptx) para generar el archivo.
Importante: la presentación es académica (defensa de Capstone) — clara, honesta, con
evidencia concreta. Nada de humo. Texto conciso por slide (no párrafos largos).

Contexto del proyecto
=====================
ETH-MAS (Ethical Hacking Multi-Agent System) — proyecto Capstone PTY4614, DUOC UC,
2026. Equipo: Rodrigo (backend/auth/frontend), Yerson (agentes/MCP/scanning), David
(LLM/análisis/reportería). Metodología Scrum (Sprint 0 + 5 sprints de 2 semanas,
MoSCoW + story points Fibonacci, DoR/DoD). Repo: github.com/rodrigosantibanez1/
CapstoneCode. Más detalle en CLAUDE.md y docs/ del repo.

Qué es: un pipeline de pentesting asistido por IA con control humano. Cuatro agentes
LLM especializados (ReconAgent → ScanAgent → AnalysisAgent → ReporterAgent) orquestados
sobre un "blackboard" compartido + un orquestador conversacional, que invocan
herramientas reales de seguridad vía MCP (Model Context Protocol).

Tres garantías de identidad técnica (el corazón del relato):
  1. Scope enforcement PROGRAMÁTICO — la validación de alcance está en código Python
     (decorator/validador), NO en el prompt del LLM. El agente no puede salirse del
     scope aunque "quiera".
  2. HITL (Human-In-The-Loop) BLOQUEANTE — antes de toda acción de riesgo (scan
     activo), el agente se suspende y espera aprobación humana real.
  3. MITRE ATT&CK — todo hallazgo se mapea a táctica/técnica como marco común.

La historia (arco honesto para la defensa):
  - El profesor criticó una versión temprana: "el proyecto es determinista; los agentes
    no funcionan como agentes" (eran checklists/playbooks rígidos).
  - Respuesta: ADR-005 — rediseño a Orquestador conversacional (LLM) + 4 workers
    goal-driven sobre blackboard, con AGENCIA AMPLIA pero scope+HITL en código como
    guardarraíles intocables. Lema: "estrategia libre, ejecución blindada".

Arquitectura técnica
====================
- Agentes goal-driven (contrato BaseAgent): reciben un OBJETIVO + contexto y DECIDEN
  qué tools usar; no ejecutan un checklist fijo.
- Tools por agente:
  · ReconAgent (OSINT pasivo): dns_enum, whois_lookup, theharvester_run.
  · ScanAgent (activo): nmap, nuclei, nikto, gobuster (vía Security MCP).
  · AnalysisAgent: cve_lookup (NVD) + mapeo MITRE; enriquece findings con CVE/CVSS.
  · ReporterAgent: narrativa LLM + render determinístico Jinja2/WeasyPrint → PDF
    técnico + ejecutivo.
- Doble almacenamiento: PostgreSQL (engagements, scope, hitl_actions, users) +
  MongoDB (findings, surface_map, agent_runs, pipeline_runs, analysis, reports/GridFS).
- Observabilidad: agent_runs + pipeline_runs + SSE en vivo (stepper del pipeline).
- Stack: FastAPI/Python 3.11 · React 19 + Vite + Tailwind v4 + shadcn · Postgres 15 ·
  Mongo 7 · Alembic · MCP · Jinja2/WeasyPrint · Docker Compose.
- Modelos LLM: Claude (Recon/Scan = Haiku, Analysis/Reporter = Opus) vía API Anthropic.

Laboratorio de validación
=========================
Lab aislado en red Docker host-only (10.42.0.0/24, sin exposición al host):
  · Metasploitable2 (10.42.0.10) — VM deliberadamente vulnerable (vsftpd 2.3.4 backdoor,
    Samba, telnet/rsh/rlogin, MySQL 5.0, Apache 2.2.8, etc.).
  · DVWA (10.42.0.20) — app web vulnerable.
Imágenes pinneadas por digest. El lab NUNCA se expone a internet (principio de
laboratorio controlado para ethical hacking).

Resultados / evidencia concreta (para slides de validación — son números REALES)
================================================================================
Pipeline 4/4 end-to-end (Recon → Scan + HITL → Analysis → Reporte PDF) validado en
runtime sobre ambos targets del lab:
  · Engagement #26 (Metasploitable2): 4/4 stages completed, 38 findings reales
    (nmap+nuclei+nikto+gobuster), 38/38 enriquecidos con MITRE, reportes técnico+ejecutivo.
  · Engagement #27 (DVWA): 4/4 stages completed, 12 findings web, reportes generados.
  · HITL bloqueante validado: el ScanAgent se suspende y reanuda al aprobar.
  · Tiempo E2E: ~11–14 min (nmap+nuclei dominan; Analysis ~3 min con Opus + NVD).

Calidad (HU-21, doc docs/metricas-calidad-hu21.md):
  · 179 tests automatizados (14 archivos), 0 fallos.
  · Cobertura del núcleo determinístico alta: scope_validator 92%, scan_policy 94%,
    agent_config 100%, parser nmap 75%, reporter 70%, findings 67%. El runtime de
    agentes LLM se valida E2E (no con mocks que inflarían la cobertura).
  · Estabilidad del mapeo MITRE: 0/29 hallazgos cambian de técnica entre corridas
    (antes 23/29 inestables) — análisis determinístico y reproducible.
  · Anti-falsos-positivos: gate de confianza CVE (confirmed/version-unknown/keyword-only),
    CVSS headline solo de CVEs confirmados.
  · CI (INFRA-02): GitHub Actions corre pytest + build del frontend en cada push/PR.
  · Reporte ejecutivo en lenguaje de negocio (sin jerga técnica, traducido al español);
    reporte técnico con CVEs/CVSS/MITRE/evidencia.

Arquitectura productiva (slide "to-be" / trabajo a futuro)
=========================================================
El profesor pidió una ARQUITECTURA PRODUCTIVA (no solo el entorno de desarrollo).
Diseño híbrido de dos planos (docs/despliegue-produccion-gcp-onprem.md + .drawio):
  · Plano APP + datos → GCP (Cloud Run/GCE, Cloud SQL, MongoDB Atlas, Pub/Sub).
  · Plano ESCANEO + lab → on-prem aislado (el lab vulnerable NUNCA va a la nube).
  · Conectividad job-pull (el worker on-prem hace polling saliente, NAT-friendly).
Estado: especificada como "to-be" + camino de implementación de-risked (validar el
split on-prem antes de pagar GCP). La entrega actual corre on-prem (Variante B).

Versiones / releases:
  · v0.1 (Sprint 1): Engagement & Scope + Recon.
  · v0.2 (Sprint 2): Recon + Scan + findings + observabilidad.
  · v0.3 (Sprint 3 — Demo Final): HITL + Análisis + Reporte + visualización +
    validación sobre el lab. Mergeado a main, etiquetado v0.3.

Assets de evidencia disponibles para incrustar en slides
=======================================================
(si quieres, pídemelos o toma capturas del stack vivo — ejecuta
`docker compose --profile lab up -d` y abre http://localhost):
  · Diagramas en docs/: despliegue-produccion-gcp-onprem.drawio (arquitectura GCP/on-prem),
    arquitectura-eth-mas-c4.drawio, arquitectura-sistema-diagramas-2026-06-11.md,
    grafos del sistema. En la raíz del repo: Diagrama_de_flujo, BPMN swimlanes,
    eth_mas_architecture, componentes, tools_vs_agents.
  · PDFs de ejemplo: reportes técnico + ejecutivo de #26/#27 (regenerables vía la UI,
    tab Reports → "Generar reportes").
  · UI viva (localhost): tabs Pipeline (stepper 4/4), Findings, Analysis (popover MITRE
    + heatmap + kill chains), Reports. Buen material para capturas.
  · Guión de demo: docs/guion-demo-viernes-2026-06-19.md (flujo paso a paso + fallback).
  · Métricas: docs/metricas-calidad-hu21.md.

Instrucciones de construcción
=============================
1. Lee mi estructura base adjunta y el pptx de ejemplo. Respeta MI orden de slides y
   COPIA el estilo del ejemplo (colores, fuentes, layouts, nivel de detalle).
2. Usa la skill `pptx` para generar el .pptx.
3. Por slide: título claro + 3–5 bullets concisos (o un diagrama/captura). Evita
   párrafos. Usa los NÚMEROS REALES de arriba (38 findings, 179 tests, 0/29 MITRE,
   coberturas, 4/4 stages) — dan credibilidad en una defensa.
4. Si una slide pide diagrama o captura que no tengo a mano, deja un placeholder claro
   indicando qué imagen va ahí (y, si puedo, la genero/capturo del stack vivo).
5. Mantén el tono honesto: separa "hecho y validado" de "diseñado/to-be" (Variante A
   GCP es to-be; la validación E2E sobre el lab es real).
6. Cierra con conclusiones + trabajo futuro (Variante A / GCP real, ampliar lab,
   métricas de calidad continuas).

Primero confirma conmigo: ¿qué slides de mi estructura quieres que priorice, hay límite
de cantidad de slides/tiempo de exposición, y quieres que genere/capture imágenes del
stack vivo para incrustar?
```

---

*Generado al cerrar la Pista 1 (2026-06-18). Adjuntá la estructura base + el pptx de
ejemplo en la sesión nueva; este prompt aporta la sustancia, ellos el formato.*
