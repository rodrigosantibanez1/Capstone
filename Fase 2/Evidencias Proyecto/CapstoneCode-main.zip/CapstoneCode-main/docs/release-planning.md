# ETH-MAS — Release Planning (HU × Progreso)

> **Qué es esto:** el plan de releases anclado en el **backlog Jira** (épicas E0–E9,
> historias HU-01…HU-24), cruzado con el **estado real de avance** del proyecto. Cada HU
> tiene su release, su prioridad MoSCoW y su estado verificado. Los commits aparecen solo
> como *evidencia*, no como estructura.
>
> **Objetivo del proyecto a 100%:** ejecutar el pipeline end-to-end
> (Recon → Scan → HITL → Analysis → Reporte PDF) sobre targets reales — el laboratorio
> interno (Metasploitable2 + DVWA) **y** IPs/dominios que traiga el operador.
>
> **Fecha:** 2026-06-09 · **Deadline académico:** 2026-06-09 (defensa)
> **Supersede:** `eth_mas_release_plan.md` v1.0 (2026-05-29), que quedó stale
> (decía `main` congelado y AnalysisAgent/ReporterAgent inexistentes — ambos ya resueltos).

---

## 1. Versionado y releases

| Versión | Alcance (en términos de HU) | Hito / Demo | Estado |
|---------|------------------------------|-------------|--------|
| `v0.1 · academic prototype` | E1 Engagement & Scope + Recon stub (HU-01..04, HU-22) | Demo 1 — Sprint 1 | ✅ Entregada |
| `v0.2 · academic prototype` | E2 Recon + E3 Scan + findings + observabilidad (HU-05..08, HU-23) | Demo 2 — Sprint 2 | ✅ Entregada |
| `v0.3 · academic prototype` | E4 HITL + E5 Análisis + E6 Reporte + E7 Visualización + E8 Validación | **Demo Final — Sprint 3** | 🟡 **Código completo, falta validación E2E + merge** |

> **Cambio clave vs el plan del 29-may:** en aquel momento `v0.3` estaba "en construcción"
> porque AnalysisAgent y ReporterAgent **no existían**. Hoy **sí existen** (Bloques B y C del
> rediseño ADR-005, ya commiteados). El estado de `v0.3` pasó de *"falta construir"* a
> *"falta validar en runtime y mergear"*. Eso reordena por completo la ruta crítica (§5).

---

## 2. Tablero maestro — HU × Progreso

**Leyenda de estado:**
✅ Done (implementado y verificado) · 🟡 Parcial (implementado, falta validación runtime o es parcial) · ❌ Pendiente · ⬜ No iniciado (diferido)

**MoSCoW:** M=Must · S=Should · C=Could · W=Won't (este release)

### E0 · Setup técnico — Sprint 0
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| INFRA-01 | Repo + branching | M | v0.1 | ✅ | GitHub Flow, convención de ramas activa |
| INFRA-02 | CI básico (lint/tests/type-check) | S | v0.1 | 🟡 | Suite pytest (128 verdes) corre en Docker; **falta confirmar CI automatizado en el repo** |
| INFRA-03 | VMs lab Metasploitable2 + DVWA | M | v0.2 | ✅ | Lab Docker `profiles:["lab"]`, red `10.42.0.0/24` |
| SPIKE-01 | POC MCP + Claude API | M | v0.1 | ✅ | Cerrado |
| SPIKE-02 | POC WeasyPrint UTF-8 español | M | v0.3 | ✅ | Validado; base del ReporterAgent |

### E1 · Engagement & Scope — Sprint 1
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| HU-01 | Configuración de scope | M | v0.1 | ✅ | `POST /engagements`, scope IP/CIDR/dominio + ROE Pydantic |
| HU-02 | Validación targets in-scope | M | v0.1 | ✅ | `@enforce_scope` programático; `scope_validator` acepta IP/CIDR/URL/host:port |
| HU-03 | Gestión del engagement | M | v0.1 | ✅ | State machine `VALID_TRANSITIONS` + cierre manual (BUG-2) + guard terminal 409 |

### E9 · Auth & Gobernanza — Sprint 1 + Backlog
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| HU-22 | Auth básica (X-API-Key) | S | v0.1 | ✅ | Opt-in vía `ETH_MAS_API_KEY`; movida a `auth.py` en refactor routers |
| HU-23 | Observabilidad | S | v0.2 | ✅ | Spine `agent_runs` + `pipeline_runs` + SSE en vivo (adelantada de backlog a Sprint 2) |
| HU-24 | Rate limiting de tokens | W | Backlog | ❌ | `ROE.max_requests_per_second` existe; rate limiting de **tokens LLM** no implementado |

### E2 · Reconocimiento — Sprint 2
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| HU-04 | ReconAgent OSINT | M | v0.1→v0.2 | ✅ | dns/whois/theHarvester; migrado a goal-driven (`BaseAgent`, ADR-005 Bloque D) |
| HU-05 | Surface map | M | v0.2 | ✅ | `SurfaceMapDoc` persiste en Mongo · `GET /surface-map` |

### E3 · Escaneo — Sprint 2-3
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| HU-06 | ScanAgent | M | v0.2 | ✅ | nmap/nuclei/nikto/gobuster vía Security MCP; intensidad por `ROE.scan_intensity` |
| HU-07 | Normalización de findings | M | v0.2 | 🟡 | nmap/gobuster verificados runtime; **nuclei/nikto dan 0 findings vía pipeline** (timeout, §15) |
| HU-08 | Persistencia de findings | M | v0.2 | ✅ | `dedup_key` + upsert + índices Mongo; re-scan no duplica |

### E4 · HITL — Sprint 3 + Backlog
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| HU-09 | Intervención humana (HITL real) | M | v0.3 | 🟡 | Bloqueante real + anti-zombi (EXPIRED, dedup); **falta validación E2E del bloqueo+resume en demo** |
| HU-10 | Auditoría de decisiones | C | v0.3/Backlog | ✅ | `HitlAuditView` + log `GET /hitl-actions` + export CSV |

### E5 · Análisis IA — Sprint 3 (ex Sprint 4)
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| HU-11 | Vectores de ataque (kill chains) | C | v0.3 | ✅ | `attack_vectors` del AnalysisAgent + UI `KillChains.jsx` (ADR-005 Bloque B) |
| HU-12 | Mapeo MITRE ATT&CK | M | v0.3 | ✅ | AnalysisAgent + Analysis MCP; técnica/táctica por finding |
| HU-13 | CVSS scoring | M | v0.3 | ✅ | `cve_lookup` NVD → `cvss_score`/`cvss_source`; badge en UI |

### E6 · Reportería — Sprint 3 (ex Sprint 4)
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| HU-14 | Reporte técnico PDF | M | v0.3 | ✅ | ReporterAgent Jinja2+WeasyPrint (ADR-005 Bloque C); conteo de findings autoritativo |
| HU-15 | Reporte ejecutivo PDF | S | v0.3 | ✅ | El ReporterAgent genera técnico **y** ejecutivo (`type=technical|executive`) |

### E7 · Visualización — Sprint 3 (ex Sprint 5)
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| HU-16 | Dashboard de hallazgos | S | v0.3 | ✅ | Findings UI + KPIs reales en HomeView (rediseño IA) |
| HU-17 | Pipeline progress | S | v0.3 | ✅ | `PipelineView` 4 stages + SSE en vivo |
| HU-18 | Listado de reportes | S | v0.3 | ✅ | `GET /reports` real desde GridFS + descarga por `file_id` (BUG-3) |

### E8 · Validación — Sprint 3 (ex Sprint 5)
| ID | Historia | MoSCoW | Release | Estado | Evidencia / nota |
|----|----------|:------:|:-------:|:------:|------------------|
| HU-19 | Validación sobre Metasploitable2 | M | v0.3 | 🟡 | Recon+Scan validados (12 findings reales, eng #18/#20); **falta correr el pipeline 4/4 completo** |
| HU-20 | Validación sobre DVWA | C | v0.3/Backlog | 🟡 | DVWA en lab, 1 finding (puerto 80); sin validación E2E plena |
| HU-21 | Métricas de calidad | C | Backlog | ❌ | No iniciada |

---

## 3. Lectura del cruce — ¿dónde está parado el proyecto?

| Categoría | HUs | Conclusión |
|-----------|-----|------------|
| **Must completados** | HU-01..06, 08, 12, 13, 14 | ✅ El grueso del valor está construido y verificado |
| **Must con validación pendiente** | HU-07, HU-09, HU-19 | 🟡 **Aquí está el gap real al 100%** — no es código, es runtime |
| **Should completados** | HU-15, 16, 17, 18, 22, 23 | ✅ |
| **Could entregados de regalo** | HU-10, HU-11 | ✅ Salieron del rediseño ADR-005 sin estar en el plan original |
| **Diferidos (no bloquean demo)** | HU-20, HU-21, HU-24, INFRA-02 | ⬜ Backlog / nice-to-have |

**Titular honesto:** de las 13 HU "Must" del proyecto, **10 están terminadas y verificadas**.
Las 3 restantes (HU-07 nuclei/nikto, HU-09 HITL, HU-19 Metasploitable2) **están implementadas
en código** — lo que falta es **una corrida end-to-end real que las encadene y las valide en
runtime**. El proyecto no está a "falta construir features", está a "falta probar el todo".

---

## 4. Criterios de cada release (HU como checklist)

### Demo 1 · v0.1 — ✅ ENTREGADA (Sprint 1)
- [x] HU-01 `POST /engagements` con scope + ROE validado
- [x] HU-02 `@enforce_scope` deniega fuera de scope antes de toda tool
- [x] HU-03 state machine de engagement operativa
- [x] HU-04 ReconAgent corre (3 tools)
- [x] HU-22 auth X-API-Key

### Demo 2 · v0.2 — ✅ ENTREGADA (Sprint 2)
- [x] HU-06 ScanAgent → nmap real
- [x] HU-05 surface_map persiste
- [x] HU-08 findings con dedup + índices
- [x] HU-23 observabilidad (agent_runs/pipeline_runs/SSE)
- [🟡] HU-07 normalización — nmap/gobuster OK, nuclei/nikto pendientes de runtime

### Demo Final · v0.3 — 🟡 CÓDIGO COMPLETO, FALTA VALIDAR (Sprint 3)
- [x] HU-12 AnalysisAgent mapea ATT&CK *(construido — falta verlo correr en el pipeline 4/4)*
- [x] HU-13 CVSS via NVD *(idem)*
- [x] HU-14 + HU-15 ReporterAgent PDF técnico + ejecutivo *(idem)*
- [x] HU-16/17/18 visualización (findings, pipeline, reportes)
- [ ] **HU-09 HITL bloqueante validado en demo** (suspende→aprueba→resume en vivo)
- [ ] **HU-19 Metasploitable2 end-to-end** — pipeline 4/4 completo con CVEs conocidos en el PDF
- [ ] Script de demo paso a paso ensayado

---

## 5. Ruta crítica al 100% (reordenada)

```
[1] Correr el pipeline 4/4 REAL sobre el lab        ← cierra HU-07, HU-09, HU-19 de una
        (Recon → Scan+HITL → Analysis → Reporte PDF)   y valida HU-12/13/14/15 en runtime
        ↓
[2] Confirmar nuclei/nikto producen findings        ← cierra HU-07
        ↓
[3] PR feature/frontend-ia-redesign → main          ← gobernanza: 13 commits, todo v0.3
        + tag v0.3 + actualizar CLAUDE.md (§9 stale)
        ↓
[4] Script de demo + ensayo                          ← cierra HU-19 para la defensa
        ↓
[5] (Post-demo) Targets del operador: nmap timeout
    internet, OSINT público, HU-24 rate limiting     ← robustez para uso real
```

> El cambio respecto al plan del 29-may: antes el paso #1 era *"construir AnalysisAgent y
> ReporterAgent"* (no existían). Ahora ya existen, así que la ruta crítica es **validación,
> no construcción**. Una sola corrida de 8–10 min cierra el grueso de lo pendiente.

---

## 6. Pendiente para "100% con targets del operador"

El lab valida el flujo; para que el operador traiga **cualquier IP/dominio** faltan ajustes
de robustez (no bloquean la demo académica, sí el uso real):

| HU / ítem | Acción | Origen |
|-----------|--------|--------|
| HU-19 (extender) | nmap subprocess timeout 300→600s para targets de internet | auditoría §14 H-1 |
| HU-04 (extender) | Validar OSINT real contra dominio público (vacío contra RFC1918 es esperado) | §14 |
| HU-02 (validar) | Confirmar runtime `scope=CIDR` que defina el operador (fix ya aplicado) | §15 H-3 |
| HU-24 | Rate limiting de tokens LLM (hoy solo `max_requests_per_second` de red) | backlog |
| — | Guard de estado terminal en el path del **orquestador** (hoy solo `POST /pipeline`) | caveat ADR-005 |
| — | Reconciliar modelo LLM: doc dice Opus 4.7, `.env` corre Haiku (tiering ADR §3.5) | §4.12 |

---

## 7. Riesgos al release final

| # | Riesgo | Prob. | Impacto | Mitigación |
|---|--------|:-----:|:-------:|------------|
| R1 | La corrida 4/4 real revela un bug de integración entre agentes | Media | Crítico | Correrla YA, no la víspera; tener eng #18/#20 pre-corridos como fallback grabado |
| R2 | nuclei/nikto siguen dando 0 findings vía pipeline | Media | Medio | nmap como evidencia de respaldo; documentar la causa si persiste |
| R3 | Merge de 13 commits a `main` genera conflicto | Baja | Alto | La rama está lineal sobre main; PR cuanto antes |
| R4 | Demo en vivo falla por entorno (Docker Desktop) | Media | Alto | Ensayar script; engagement pre-corrido como respaldo |
| R5 | HU-19 sin tiempo para ensayo | Media | Alto | Priorizar paso #1 de la ruta crítica sobre todo lo demás |

---

## 8. Definition of Done de un release
- [ ] HUs Core (Must) del release en "Done" en Jira con link a evidencia
- [ ] Rama mergeada a `main` con reviewer + tests verdes
- [ ] Tag de versión en `main`
- [ ] Demo realizada ante la audiencia objetivo
- [ ] CLAUDE.md sincronizado (§4.6 estado, §8 artefactos, §9 estado de merge)

---

## 9. Nota de mantenimiento
Este documento reemplaza a `eth_mas_release_plan.md` (raíz, v1.0). Para evitar dos fuentes en
conflicto, conviene **retirar o redirigir** el de la raíz hacia este. La fuente de verdad de
fechas/capacity sigue siendo CLAUDE.md §4.6/§4.7; este doc consolida el cruce HU↔progreso.
