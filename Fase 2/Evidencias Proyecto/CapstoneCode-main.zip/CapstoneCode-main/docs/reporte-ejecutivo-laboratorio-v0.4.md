# Reporte ejecutivo — Laboratorio de evaluación ETH-MAS (v0.4)

> **Para:** comisión evaluadora / dirección de proyecto.
> **Qué es esto:** una lectura **de negocio** del estado de riesgo del entorno de prueba sobre el
> que el sistema ETH-MAS demuestra su capacidad de auditoría asistida por IA. Sin tecnicismos: el
> detalle técnico y las referencias están en
> [`reporte-laboratorio-vulnerabilidades-v0.4.md`](reporte-laboratorio-vulnerabilidades-v0.4.md).

---

## 1. Contexto en una frase

El laboratorio reproduce, de forma **controlada y aislada**, dos sistemas deliberadamente inseguros
—un servidor con servicios de red anticuados y una aplicación web vulnerable— para medir, con
evidencia, si la plataforma ETH-MAS **descubre, prioriza y reporta** los riesgos como lo haría un
equipo de seguridad humano.

## 2. Los dos sistemas evaluados

| Sistema | Rol | Estado de riesgo |
|---------|-----|------------------|
| **Servidor heredado** (Metasploitable2) | Simula una intranet con software sin mantenimiento | **Crítico** — múltiples puertas traseras y accesos sin contraseña |
| **Aplicación web** (DVWA) | Simula un portal web con defensas mal implementadas | **Alto** — vulnerable a las fallas web más comunes de la industria |

## 3. Hallazgos clave (traducidos a impacto de negocio)

1. **Acceso total no autorizado.** El servidor heredado tiene al menos **cinco vías** por las que un
   atacante toma el control completo sin credenciales válidas: tres "puertas traseras" plantadas en
   el software, un acceso administrativo a la base de datos **sin contraseña**, y un servicio de
   administración con la contraseña de fábrica. Cualquiera de ellas equivale a una **fuga total** de
   la información alojada.

2. **Riesgos validados por la industria.** Cuatro de esos hallazgos están catalogados públicamente
   con identificadores oficiales de severidad reconocidos mundialmente (escala estándar CVSS), tres
   de ellos en el rango **crítico/alto (7.5 a 10 sobre 10)**. No son hipótesis del sistema: son
   riesgos documentados por el NIST de EE.UU. y por proveedores como Samba y Rapid7.

3. **La aplicación web reproduce las fallas más frecuentes del mercado.** Inyección de datos, robo de
   sesión y ejecución de comandos no autorizados — exactamente las categorías que la referencia
   internacional **OWASP Top 10** señala como las de mayor prevalencia.

4. **No todo "hallazgo" es un riesgo real.** Una parte central del valor del sistema es **distinguir
   el ruido del riesgo**: en auditorías previas, la plataforma fue endurecida para **descartar
   falsos positivos** (alarmas que no aplican al equipo real). Esto eleva la confianza en cada
   informe emitido y evita el costo de perseguir riesgos inexistentes.

## 4. Por qué esto importa para la evaluación

- **Medible.** Existe una lista cerrada y verificable de lo que el entorno "debería" revelar; el
  desempeño del sistema se puede puntuar objetivamente (cobertura, aciertos, falsas alarmas).
- **Trazable.** Cada riesgo del informe se enlaza a una **fuente pública de confianza**, no a una
  opinión del modelo de IA. Esto es auditable por terceros.
- **Con control humano.** Ninguna acción intrusiva se ejecuta sin **aprobación humana explícita**
  (control HITL), y el alcance autorizado se valida **en código**, no por conversación. La IA
  propone; la persona aprueba.

## 5. Conclusión

El laboratorio es un **banco de pruebas riguroso y reproducible**. La línea base de riesgo está
documentada y respaldada por fuentes oficiales, lo que permite **contrastar de forma objetiva** los
resultados que produce ETH-MAS. El sistema no solo enumera puertos: **prioriza por riesgo real,
respalda cada conclusión con evidencia pública y mantiene a la persona al mando** de toda acción
sensible — que es, precisamente, lo que se espera de una herramienta de seguridad profesional.

---

**Documento:** `docs/reporte-ejecutivo-laboratorio-v0.4.md` · rama `release/v0.4`.
**Detalle técnico y fuentes:** [`reporte-laboratorio-vulnerabilidades-v0.4.md`](reporte-laboratorio-vulnerabilidades-v0.4.md).
