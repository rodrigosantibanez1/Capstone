# Reporte al equipo — ETH-MAS · 2026-06-01

> **Para:** Rodrigo, Yerson, David
> **Sprint 3** (26 may – 9 jun) · deadline académico **9 jun**
> **Autor de la sesión:** asistente Claude (Opus) + operador
> **TL;DR:** se cerró el bug de Nikto (causa raíz real, no era timeout), se respondió a
> la crítica del profesor con un rediseño agéntico documentado (ADR-005), y se
> implementaron y verificaron los **Bloques 0 (contratos)** y **E (ejecutor seguro)**.
> `main` quedó consolidado y verificable con `docker compose up --build`.

---

## 1. Estado general

| Frente | Estado |
|--------|--------|
| Fix Nikto (reporte del operador, 4 mejoras) | ✅ **en `main`** |
| Crítica "proyecto determinista / agentes no agénticos" | ✅ diagnosticada + ADR-005 + plan de bloques |
| Bloque 0 — contratos compartidos | ✅ **en `main`** |
| Bloque E — ejecutor seguro | ✅ listo, en rama `feature/block-e-executor` (**PR a `main` pendiente**) |
| Bloques A / B / C / D | ⏳ pendientes (listos para arrancar en paralelo) |
| Stack `docker compose up --build` | ✅ verificado (front + backend + BDs healthy) |

---

## 2. Lo hecho esta sesión

### 2.1 Fix de Nikto (cierra el reporte del operador)
**Causa raíz real (aislada midiendo, no era timeout):** el reporter `-Format json` de
**nikto 2.6.0 crashea** al serializar (`nikto_report_json.plugin` → archivo de 0 bytes)
aunque encuentre hallazgos. Diagnóstico contra `10.42.0.10:80`: `csv/xml/txt` funcionan, `json` no.

- `security_server.nikto_scan`: `-Format json` → **`-Format csv`**; `-maxtime` (autodetención
  con salida completa) + `NIKTO_TIMEOUT_SECS` como red de seguridad; status explícito
  (`completed/completed_empty/timeout/error`) + `notes`; nunca borra el archivo antes de
  leerlo; finding `info` que preserva el raw si no hay parse.
- `findings_service.normalize_nikto_findings`: detecta formato (CSV nuevo / JSON legacy) +
  `_parse_nikto_csv`.
- **Runtime real: 0 → 27 findings.** Cubre las 4 mejoras del operador.
- Commit `a24cd45` (en `main`).

### 2.2 Respuesta a la crítica del profesor → ADR-005
Se confirmó con evidencia de código: **ReconAgent = checklist**, **ScanAgent = playbook
rígido**, **AnalysisAgent/ReporterAgent no existen**, **PipelineController = secuencia
hardcodeada de 2 stages** (no coordina 4), operador = botones REST. Mismo scope ⇒ mismo
resultado: reproducible por un `for` loop.

**Decisión (ADR-005):** Orquestador conversacional (Opus) + **ejecutor seguro** + 4 workers
*goal-driven* sobre un **blackboard** compartido. **Agencia amplia** pero **scope + HITL en
código** como guardarraíles intocables. *Estrategia libre, ejecución blindada.*

- `docs/adr-005-agentes-reales-y-orquestador.md`
- `docs/plan-bloques-sprint3-agentes.md` (desglose asignable)

### 2.3 Bloque 0 — Contratos compartidos *(en `main`, commit `cc8e856`)*
Base anti-divergencia sobre la que codean todos los bloques:
- `services/agent_base.py`: `AgentContext`, `AgentResult` (con `rationale` obligatorio),
  `BaseAgent` (ABC), `AGENT_TOOL_SCHEMAS` (agent-as-tool), `build_agent_context()`.
- `services/blackboard.py`: estado compartido en Mongo (`read_state`, `write_analysis`,
  `record_rationale`, `append/read_conversation`).
- `services/agent_config.py`: tiering de modelos por env.
- `mongo_schemas.py`/`mongo_client.py`: 3 colecciones nuevas + índices.
- 13 tests de contrato.

### 2.4 Bloque E — Ejecutor seguro *(rama `feature/block-e-executor`, commit `dc7716b`)*
`PipelineController` degradado de "decisor del orden" a **ejecutor seguro**:
- `_AGENT_REGISTRY` con **los 4 agentes**.
- `_run_stage` **contract-aware**: legacy (`run()→dict`, Recon/Scan) + nuevo
  (`BaseAgent.run(ctx)→AgentResult`).
- **Pre-check anti-zombi y bookkeeping `pipeline_runs` intactos.** Orden por `stages=[...]`.
- Stubs `analysis_agent.py` / `reporter_agent.py` (los rellenan B/C).

### 2.5 Fix de entorno (Windows / Docker)
Postgres no podía bindear el host `5432` (rango excluido por WinNAT, bloque `5264-5863`).
`docker-compose.yml` ahora usa `${POSTGRES_HOST_PORT:-5432}` (default intacto para el equipo);
override local en `.env` con `POSTGRES_HOST_PORT=15432`. El backend conecta por la red Docker,
así que solo afecta el acceso a Postgres **desde el host**.

---

## 3. Verificación

- **Tests:** 68/68 verdes (44 normalizers/scope + 13 contratos B0 + 6 ejecutor E + 5 nikto CSV).
- **Nikto:** corrida real CSV → normalizador → 27 findings (antes 0).
- **Blackboard:** read/write probado contra Mongo vivo.
- **Ejecutor (E):** integración en vivo — corrió `AnalysisAgent` (contrato nuevo) sobre
  engagement #20, rationale persistido en el blackboard.
- **Stack:** `docker compose up --build` → postgres+mongo healthy, backend online (v0.3.0,
  `/docs` 200), frontend 200.

---

## 4. Estado de git

| Rama | Contenido | Acción |
|------|-----------|--------|
| **`main`** (`bcdd9ab`) | phase-1 + lab + **fix nikto** + **Bloque 0** + docs ADR/plan | base sincronizada |
| **`feature/block-e-executor`** (`dc7716b`) | `main` + **Bloque E** (1 commit adelante, sin divergencia) | **PR a `main` pendiente** |
| `feature/block0-agent-contracts` | subsumida por `main` | se puede borrar |
| `feature/lab-metasploitable-dvwa` | subsumida por `main` | se puede borrar |

> Nota: `CLAUDE.md` §9 estaba desactualizado — `origin/main` **no** estaba congelado;
> ya tenía observability-spine mergeado. Ahora `main` está al día con todo lo anterior.

---

## 5. Política de trabajo acordada (sincronizado + incremental)

**Ramas de bloque cortas → PR → merge a `main` apenas verdes.** Cada bloque **nace de `main`
actualizado** y vuelve por PR. Evitar ramas largas/apiladas (driftean y rompen la sincronía).

```
git checkout main && git pull
git checkout -b feature/block-X
# build + tests verdes
PR → review/CI → merge a main
# el siguiente bloque nace de main ya actualizado
```

---

## 6. Plan de bloques (asignación sugerida)

| Bloque | Qué | Owner sug. | Estado |
|--------|-----|-----------|--------|
| **0** Contratos | `agent_base` + `blackboard` + `agent_config` | Rodrigo (revisado x3) | ✅ en `main` |
| **E** Ejecutor seguro | `PipelineController` contract-aware + registry 4 | Yerson/Rodrigo | ✅ PR pendiente |
| **A** Orquestador + chat operador | LLM supervisor + endpoint conversacional + SSE | Rodrigo | ⏳ |
| **B** AnalysisAgent + Analysis MCP | `cve_lookup` (NVD) + ATT&CK + vectores | David | ⏳ (siguiente) |
| **C** ReporterAgent | Jinja2/WeasyPrint técnico+ejecutivo | David | ⏳ |
| **D** Refactor Recon/Scan | al contrato (goal-driven, lee ROE) | Yerson | ⏳ |

Detalle de contratos congelados y "cómo lo consume cada bloque" en
`docs/plan-bloques-sprint3-agentes.md`.

---

## 7. Decisiones abiertas / pendientes

1. **Merge del PR de E a `main`** (gh no está instalado en el entorno → abrir por web:
   `compare/main...feature/block-e-executor`). Tras esto, B arranca de `main`.
2. **Reconciliar modelo (§4.1):** el doc dice Opus 4.7 pero el `.env` corre Haiku. El tiering
   del ADR §3.5 está cableado por env (`ANALYSIS_MODEL`, etc.) con default seguro; falta
   confirmar los IDs reales disponibles y activarlos en `.env`. **El Bloque B (razonamiento)
   se beneficia de un modelo Opus/Sonnet.**
3. **Quirk menor del ejecutor:** un stage `skipped` se cuenta `completed` a nivel pipeline
   (el loop solo distingue `waiting_hitl`); el rationale guarda el status real. Pulir al
   definir semántica `skipped`/`partial`. No bloqueante.
4. **Limpieza:** borrar ramas `block0-agent-contracts` y `lab-metasploitable-dvwa` (ya en main).

---

## 8. Cómo levantar el entorno

```bash
docker compose up --build -d          # db, mongo, backend, frontend
# backend: http://localhost:8000  (/docs para la API)
# frontend: http://localhost:80
docker compose --profile lab up -d    # + Metasploitable2 (10.42.0.10) y DVWA (10.42.0.20)
```
> Windows: si Postgres no bindea el `5432`, setear `POSTGRES_HOST_PORT=15432` en `.env`
> (ver §2.5). Tests: `docker exec eth_mas_backend uv run pytest tests/ -q` (68 verdes).
