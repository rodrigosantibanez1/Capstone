# Reporte técnico — Vulnerabilidades del laboratorio ETH-MAS (v0.4)

> **Propósito.** Documentar, con trazabilidad a fuentes de confianza de la comunidad
> (NVD/CVE, vendor advisories, Rapid7, ExploitDB, OWASP, Nmap NSE), el conjunto de
> vulnerabilidades **esperadas** en los dos targets que componen el laboratorio del
> proyecto. Este documento es la **línea base ("ground truth")** contra la que se
> contrasta el resultado de un engagement real ejecutado por el sistema ETH-MAS
> (ver [`contraste-lab-vs-engagement-v0.4.md`](contraste-lab-vs-engagement-v0.4.md)).
>
> **Alcance del lab.** Dos targets aislados en la red Docker `eth_mas_lab`
> (`10.42.0.0/24`), sin exposición al host (ver [`lab-setup.md`](lab-setup.md) §1):
> - **Target 1 — Metasploitable2** · `10.42.0.10` · contenedor `eth_mas_lab_ms2`.
> - **Target 2 — DVWA 1.9** · `10.42.0.20` · contenedor `eth_mas_lab_dvwa`.
>
> **Advertencia.** Ambas imágenes son **intencionalmente vulnerables** y nunca deben
> exponerse fuera del host. El digest de cada imagen está pineado por reproducibilidad
> ([`lab-setup.md`](lab-setup.md) §2).

---

## 0. Resumen ejecutivo técnico

| Target | Imagen (digest) | Naturaleza | Vulns esperadas |
|--------|-----------------|-----------|------------------|
| Metasploitable2 `10.42.0.10` | `tleemcjr/metasploitable2` `@sha256:e559450b…` | Distro Linux vulnerable (servicios de red) | ~24 puertos; ≥5 RCE críticas con CVE/backdoor; credenciales por defecto; daemons sin auth |
| DVWA 1.9 `10.42.0.20` | `vulnerables/web-dvwa:1.9` `@sha256:14c929ec…` | App web PHP 5.x EOL | OWASP Top 10 clásicas (SQLi, XSS, CSRF, File Inclusion, Command Injection) — activables por nivel |

**Cinco vulnerabilidades "ancla"** (las que un engagement competente debería detectar y
correlacionar con CVE), todas con fuente verificada en NVD:

| # | Servicio / versión | CVE | CVSS (NVD) | Tipo |
|---|--------------------|-----|------------|------|
| 1 | vsftpd 2.3.4 (FTP) | [CVE-2011-2523](https://nvd.nist.gov/vuln/detail/CVE-2011-2523) | v2 **10.0** / v3.1 **9.8** | Backdoor RCE (shell en 6200/tcp) |
| 2 | UnrealIRCd 3.2.8.1 (IRC) | [CVE-2010-2075](https://nvd.nist.gov/vuln/detail/CVE-2010-2075) | v2 **7.5** | Backdoor RCE (supply-chain) |
| 3 | distccd 2.x | [CVE-2004-2687](https://nvd.nist.gov/vuln/detail/CVE-2004-2687) | v2 **9.3** | RCE distribuido sin auth |
| 4 | Samba 3.0.20 (SMB) | [CVE-2007-2447](https://nvd.nist.gov/vuln/detail/CVE-2007-2447) | v2 **6.0** | RCE `username map script` |
| 5 | DVWA (multi) | — (clases OWASP) | — | SQLi / XSS / CmdInj / File Inclusion |

---

## 1. Target 1 — Metasploitable2 (`10.42.0.10`)

Superficie esperada (de [`lab-setup.md`](lab-setup.md) §5.1): ~24 puertos abiertos, los que
documenta el lab oficial de Rapid7. Un `nmap` top-1024 debería ver `total ≥ 20`.

### 1.1 Vulnerabilidades con CVE confirmada

#### 1.1.1 vsftpd 2.3.4 — backdoor "smiley" · puerto 21/tcp
- **CVE:** [CVE-2011-2523](https://nvd.nist.gov/vuln/detail/CVE-2011-2523)
- **CVSS:** v2 base **10.0** (AV:N/AC:L/Au:N/C:C/I:C/A:C); v3.1 **9.8 Critical**.
- **Descripción.** La build de `vsftpd 2.3.4` distribuida con un backdoor: un usuario
  cuyo nombre contiene `:)` dispara la apertura de un shell de comandos en **6200/tcp**.
- **Detección.** Banner `220 (vsFTPd 2.3.4)` en 21/tcp; confirmación activa abriendo 6200/tcp.
- **Fuentes:** [NVD](https://nvd.nist.gov/vuln/detail/CVE-2011-2523) ·
  [Red Hat](https://access.redhat.com/security/cve/cve-2011-2523) ·
  [Rapid7 module `vsftpd_234_backdoor`](https://www.rapid7.com/db/modules/exploit/unix/ftp/vsftpd_234_backdoor/) ·
  template [Nuclei CVE-2011-2523](https://github.com/projectdiscovery/nuclei-templates/blob/main/network/cves/2011/CVE-2011-2523.yaml).

#### 1.1.2 UnrealIRCd 3.2.8.1 — backdoor · puertos 6667, 6697/tcp
- **CVE:** [CVE-2010-2075](https://nvd.nist.gov/vuln/detail/CVE-2010-2075)
- **CVSS:** v2 base **7.5** (impact 6.4 / exploitability 10.0).
- **Descripción.** Ataque de cadena de suministro: el tarball oficial de UnrealIRCd
  3.2.8.1 (nov-2009 a jun-2010) fue troyanizado en el macro `DEBUG3_DOLOG_SYSTEM`,
  permitiendo ejecución remota de comandos.
- **Fuentes:** [NVD](https://nvd.nist.gov/vuln/detail/CVE-2010-2075) ·
  [Rapid7 module `unreal_ircd_3281_backdoor`](https://www.rapid7.com/db/modules/exploit/unix/irc/unreal_ircd_3281_backdoor/) ·
  [CVE.org](https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2010-2075).

#### 1.1.3 distccd 2.x — RCE distribuido · puerto 3632/tcp
- **CVE:** [CVE-2004-2687](https://nvd.nist.gov/vuln/detail/CVE-2004-2687)
- **CVSS:** v2 base **9.3** (AV:N/AC:M/Au:N/C:C/I:C/A:C).
- **Descripción.** `distccd` sin restricción de acceso ejecuta trabajos de compilación
  arbitrarios → ejecución remota de comandos sin autenticación.
- **Fuentes:** [NVD](https://nvd.nist.gov/vuln/detail/CVE-2004-2687) ·
  [Nmap NSE `distcc-cve2004-2687`](https://nmap.org/nsedoc/scripts/distcc-cve2004-2687.html) ·
  [CVE.org](https://www.cve.org/CVERecord?id=CVE-2004-2687).

#### 1.1.4 Samba 3.0.20 — `username map script` · puertos 139, 445/tcp
- **CVE:** [CVE-2007-2447](https://nvd.nist.gov/vuln/detail/CVE-2007-2447)
- **CVSS:** v2 base **6.0** (AV:N/AC:M/Au:S/C:P/I:P/A:P).
- **Descripción.** `smbd` 3.0.0–3.0.25rc3 ejecuta comandos vía metacaracteres de shell
  (función `SamrChangePassword`) cuando `username map script` está habilitado en `smb.conf`.
- **Fuentes:** [NVD](https://nvd.nist.gov/vuln/detail/CVE-2007-2447) ·
  [Advisory oficial Samba](https://www.samba.org/samba/security/CVE-2007-2447.html) ·
  [Rapid7 module `usermap_script`](https://www.rapid7.com/db/modules/exploit/multi/samba/usermap_script/) ·
  [ExploitDB 16320](https://www.exploit-db.com/exploits/16320).

### 1.2 Vulnerabilidades por backdoor / mala configuración (sin CVE — el "riesgo" es la exposición)

> Nota metodológica: igual que se demostró en
> [`verificacion-hallazgos-mypc-2026-06-10.md`](verificacion-hallazgos-mypc-2026-06-10.md),
> **la ausencia de CVE no implica ausencia de riesgo**. Estos hallazgos son críticos por
> configuración, no por una vulnerabilidad de software con identificador.

| Puerto | Servicio | Hallazgo | Severidad | Fuente de referencia |
|--------|----------|----------|-----------|----------------------|
| 1524 | ingreslock | **Root shell backdoor** (bind shell directo a root) | Crítica | [Rapid7 Metasploitable2 guide](https://docs.rapid7.com/metasploit/metasploitable-2/) |
| 3306 | MySQL 5.0.51a | `root` **sin contraseña** | Crítica | [Rapid7 Metasploitable2 guide](https://docs.rapid7.com/metasploit/metasploitable-2/) |
| 5900 | VNC | contraseña por defecto `password` | Alta | [Rapid7 Metasploitable2 guide](https://docs.rapid7.com/metasploit/metasploitable-2/) |
| 8180 | Tomcat 5.5 | credenciales por defecto `tomcat:tomcat` | Alta | [Rapid7 Metasploitable2 guide](https://docs.rapid7.com/metasploit/metasploitable-2/) |
| 2049 | NFS | exportaciones sin chequeo (`no_root_squash`) | Alta | [Rapid7 Metasploitable2 guide](https://docs.rapid7.com/metasploit/metasploitable-2/) |
| 23 | telnet | sin autenticación / texto plano | Alta | Servicio obsoleto |
| 512/513/514 | rexec/rlogin/rsh | r-services sin autenticación | Alta | Servicios obsoletos |
| 1099 | Java RMI | `rmiregistry` cargando clases remotas | Alta | [Rapid7 module `java_rmi_server`](https://www.rapid7.com/db/modules/exploit/multi/misc/java_rmi_server/) |
| 8787 | distributed Ruby (drb) | RCE en objetos Ruby distribuidos | Alta | [Rapid7 module `drb_remote_codeexec`](https://www.rapid7.com/db/modules/exploit/linux/misc/drb_remote_codeexec/) |
| 6000 | X11 | servidor X sin control de acceso | Media | Configuración insegura |

### 1.3 Servicios obsoletos (superficie, sin explotación trivial garantizada)

| Puerto | Servicio | Versión | Nota |
|--------|----------|---------|------|
| 22 | ssh | OpenSSH 4.7p1 (2007) | Múltiples CVEs históricos; versión obsoleta |
| 25 | smtp | Postfix smtpd | Servicio de correo expuesto |
| 53 | domain | ISC BIND 9.4.2 | DNS obsoleto |
| 80 | http | Apache 2.2.8 | Servidor web obsoleto (apps: Mutillidae, DVWA local, phpMyAdmin, etc.) |
| 5432 | postgres | PostgreSQL 8.3.0 | DB obsoleta |
| 111 | rpcbind | — | Exposición RPC |
| 8009 | ajp13 | Tomcat AJP | Protocolo Tomcat (potencial Ghostcat-like en versiones afectadas) |

---

## 2. Target 2 — DVWA 1.9 (`10.42.0.20`)

DVWA es una **aplicación de entrenamiento OWASP**: las vulnerabilidades **no** tienen CVE propio
(la app *es* el laboratorio), sino que materializan clases del OWASP Top 10. Por defecto arranca en
nivel `impossible` (sin vulns); hay que bajar a `low/medium/high` (`admin/password`) para activarlas
([`lab-setup.md`](lab-setup.md) §6).

| Puerto | Servicio | Versión |
|--------|----------|---------|
| 80 | http | Apache 2.4 + **PHP 5.x (EOL)** + DVWA web UI; MySQL embebido interno (no expuesto) |

### 2.1 Clases de vulnerabilidad (activables por security level)

| Clase DVWA | OWASP Top 10 (2021) | Referencia comunidad |
|------------|---------------------|----------------------|
| SQL Injection (+ blind) | [A03:2021 — Injection](https://owasp.org/Top10/A03_2021-Injection/) | [OWASP SQLi](https://owasp.org/www-community/attacks/SQL_Injection) |
| Cross-Site Scripting (Reflected/Stored/DOM) | [A03:2021 — Injection](https://owasp.org/Top10/A03_2021-Injection/) | [OWASP XSS](https://owasp.org/www-community/attacks/xss/) |
| Command Injection | [A03:2021 — Injection](https://owasp.org/Top10/A03_2021-Injection/) | [OWASP Command Injection](https://owasp.org/www-community/attacks/Command_Injection) |
| CSRF | [A01:2021 — Broken Access Control](https://owasp.org/Top10/A01_2021-Broken_Access_Control/) | [OWASP CSRF](https://owasp.org/www-community/attacks/csrf) |
| File Inclusion (LFI/RFI) | [A03 / A05](https://owasp.org/Top10/A05_2021-Security_Misconfiguration/) | [OWASP Path Traversal](https://owasp.org/www-community/attacks/Path_Traversal) |
| File Upload | [A04:2021 — Insecure Design](https://owasp.org/Top10/A04_2021-Insecure_Design/) | [OWASP Unrestricted File Upload](https://owasp.org/www-community/vulnerabilities/Unrestricted_File_Upload) |
| Brute Force / Weak session IDs | [A07:2021 — Identification & Auth Failures](https://owasp.org/Top10/A07_2021-Identification_and_Authentication_Failures/) | DVWA login |
| Stack EOL (PHP 5.x) | [A06:2021 — Vulnerable & Outdated Components](https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components/) | [PHP EOL](https://www.php.net/eol.php) |

- **Proyecto DVWA:** [github.com/digininja/DVWA](https://github.com/digininja/DVWA).

### 2.2 Qué espera detectar el sistema sobre DVWA
El ScanAgent ataca DVWA con herramientas **web** (nikto + gobuster); el descubrimiento de rutas
(`/login.php`, `/setup.php`, `/security.php`, `/vulnerabilities/*`) y de headers de seguridad
faltantes es lo esperado. La explotación profunda de SQLi/XSS por payload requiere drivers
específicos que están fuera del alcance del MVP (ver §4).

---

## 3. Matriz consolidada CVE → CVSS → fuente

| CVE | Producto / versión | CVSS v2 | CVSS v3 | Fuente primaria | Fuente comunidad |
|-----|--------------------|---------|---------|-----------------|------------------|
| CVE-2011-2523 | vsftpd 2.3.4 | 10.0 | 9.8 | [NVD](https://nvd.nist.gov/vuln/detail/CVE-2011-2523) | [Rapid7](https://www.rapid7.com/db/modules/exploit/unix/ftp/vsftpd_234_backdoor/) |
| CVE-2010-2075 | UnrealIRCd 3.2.8.1 | 7.5 | — | [NVD](https://nvd.nist.gov/vuln/detail/CVE-2010-2075) | [Rapid7](https://www.rapid7.com/db/modules/exploit/unix/irc/unreal_ircd_3281_backdoor/) |
| CVE-2004-2687 | distccd 2.x | 9.3 | — | [NVD](https://nvd.nist.gov/vuln/detail/CVE-2004-2687) | [Nmap NSE](https://nmap.org/nsedoc/scripts/distcc-cve2004-2687.html) |
| CVE-2007-2447 | Samba 3.0.20 | 6.0 | — | [NVD](https://nvd.nist.gov/vuln/detail/CVE-2007-2447) | [Samba advisory](https://www.samba.org/samba/security/CVE-2007-2447.html) · [ExploitDB 16320](https://www.exploit-db.com/exploits/16320) |

> CVSS de NVD verificados mediante consulta directa el 2026-06-26.

---

## 4. Brechas conocidas y notas de exactitud (para el contraste)

1. **OSINT no aplica al lab.** Los targets son IPs RFC1918 sin DNS/WHOIS público; el ReconAgent
   (`dns_enum`, `whois_lookup`, `theharvester_run`) devuelve vacío. No es un bug
   ([`lab-setup.md`](lab-setup.md) §7.1).
2. **`nuclei_run` está implementado, pero su cabecera tiene un comentario obsoleto `[stub Sprint 3]`.**
   En `mcp_servers/security_server.py` la tool nuclei **sí ejecuta** nuclei real (tags, severidad,
   salida JSONL, timeout escalado 240/600s, default acotado a `-tags cve`). El síntoma de "0 findings"
   reportado en `release-planning.md` es por **cobertura/timeout en runtime** (severidad mínima
   `medium`, default `cve`, target en LAN), **no** porque sea un stub. El motor de correlación CVE
   "de fondo" del sistema es el **AnalysisAgent** vía NVD (`cve_lookup` por CPE+versión). Acción de
   refinamiento sugerida: corregir el comentario y validar la cobertura nuclei en la corrida local.
3. **DVWA en `impossible` por defecto.** Si no se baja el nivel, los scanners web no encuentran las
   clases OWASP — solo la superficie HTTP. Confirmar nivel `low`/`medium` antes de la corrida.
4. **Disciplina anti-falsos-positivos.** El sistema gatea CVE por CPE+versión y degrada hallazgos
   nikto ante catch-all (hardening 2026-06-11). Esto implica que **no** todo CVE histórico del
   servicio aparece: solo los que matcheen producto+versión observados. El contraste debe leerse a
   la luz de esto (un CVE esperado ausente puede ser correcto si la versión no se confirmó).

---

## 5. Fuentes

- NVD (NIST) — `https://nvd.nist.gov/vuln/detail/<CVE>`
- CVE.org / MITRE — `https://www.cve.org/CVERecord?id=<CVE>`
- Samba security advisories — `https://www.samba.org/samba/security/`
- Rapid7 vuln & exploit DB — `https://www.rapid7.com/db/`
- Rapid7 Metasploitable2 guide — `https://docs.rapid7.com/metasploit/metasploitable-2/`
- ExploitDB — `https://www.exploit-db.com/`
- Nmap NSE docs — `https://nmap.org/nsedoc/`
- OWASP Top 10 (2021) — `https://owasp.org/Top10/`
- Project DVWA — `https://github.com/digininja/DVWA`
- ProjectDiscovery Nuclei templates — `https://github.com/projectdiscovery/nuclei-templates`

---

**Documento:** `docs/reporte-laboratorio-vulnerabilidades-v0.4.md` · rama `release/v0.4`.
**Insumos del repo:** `docs/lab-setup.md` §5–6, `docs/verificacion-hallazgos-mypc-2026-06-10.md`,
`docs/hardening-falsos-positivos-2026-06-11.md`.
