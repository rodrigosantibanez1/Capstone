# Reporte de sesión — release/v0.4 (2026-06-26)

> **Para el equipo.** Qué se hizo en la sesión local sobre `release/v0.4`, cómo levantar
> el sistema, cómo **ver el engagement de demo ya persistido** sin re-correr el pipeline,
> y cómo conducir la demo de la defensa. Todo el trabajo está **commiteado y pusheado** a
> `release/v0.4`.

---

## 0. TL;DR

- Se **reconcilió** `release/v0.4` (el paquete de defensa que ya estaba en el remoto) con
  la narración en vivo del orquestador de `release/v0.3`.
- Se **validó el pipeline completo end-to-end vía el chat del orquestador** sobre
  Metasploitable2 → engagement **#37**, persistido: **38 findings · 18 enriquecidos ·
  6 vectores · 2 PDFs**.
- Se encontraron y **corrigieron 3 bugs reales** (con tests): análisis con Opus 4.8,
  descarga de PDF, y el smoke en Windows. **Suite: 200 tests verdes.**
- El backend ahora corre **sin `--reload`** para estabilidad de demo.
- El orquestador responde en **español neutro** (sin voseo).
- **El engagement #37 se distribuye como seed** (`demo-seed/`): el equipo lo restaura y lo
  ve igual, sin esperar los ~15 min de corrida.

---

## 1. Estado de la rama `release/v0.4`

`release/v0.4` se creó desde `release/v0.3`, pero **el remoto ya tenía** una `release/v0.4`
con el paquete de defensa (`fb8b6de`). Se reconcilió así:

```
… fb8b6de  release/v0.4: paquete de defensa Capstone   (base remota)
   9f77360  Merge release/v0.3 → narración en vivo del orquestador
   824a8c6  restaura tooling PS1 + docs cierre Pista 1
   8d9c309  fix(smoke): body por archivo — UTF-8 en Windows
   79f837d  fix(analysis): no enviar temperature a Opus 4.8
   5f53036  fix(reports): descarga PDF con nombre no-ASCII
   cb6dfdd  docs(contraste): Parte B con datos reales de #37
   279f5e3  style(orchestrator): español neutro (sin voseo)
   db8c505  chore(demo): seed de #37 + scripts restore/dump
```

> **Variante A / Pista 2** (scan worker job-pull) **NO** entró en v0.4: quedó parqueada en
> `git stash` (foco de v0.4 = defensa). No interfiere con la demo.

---

## 2. Bugs encontrados y corregidos

| # | Síntoma | Causa raíz | Fix | Commit |
|---|---------|-----------|-----|--------|
| 1 | AnalysisAgent fallaba tras un scan OK ("unhandled errors in a TaskGroup") | **Opus 4.8 deprecó `temperature`** → API 400, enmascarado por el ExceptionGroup de anyio | `agent_config.supports_temperature()` omite el parámetro en modelos que lo deprecaron | `79f837d` |
| 2 | Descarga de PDF con nombre personalizado → **500** | `Content-Disposition` con em-dash (`—`) no es latin-1 → `UnicodeEncodeError` | header RFC 6266 (`filename` ASCII + `filename*=UTF-8''`) | `5f53036` |
| 3 | `smoke_engagement.sh` fallaba al crear engagement | `curl -d "$body"` corrompe UTF-8 en Git Bash/Windows (argv) | body por archivo temporal (`--data-binary @`) | `8d9c309` |

**Estabilidad de demo:** el backend corre **sin `uvicorn --reload`** vía
`docker-compose.override.yml` (gitignored). El watcher con `--reload` colgaba el worker al
editar archivos durante una corrida. **Costo:** editar código backend ya no recarga en
caliente → hay que `docker compose restart backend`.

---

## 3. Cómo levantar el sistema (paso a paso)

> Requisitos: Docker Desktop corriendo, `.env` con `ANTHROPIC_API_KEY` real (el tiering
> recomendado —Opus en orquestador/análisis— ya está activo en `.env`).

```bash
git fetch origin && git checkout release/v0.4 && git pull origin release/v0.4

# 1. Levantar stack + lab (6 contenedores)
docker compose --profile lab up -d
docker compose ps                      # esperar 6 Up

# 2. Salud
curl -s http://localhost:8000/health/services | jq .   # overall: up

# 3. Smoke de cableado (necesita jq instalado)
SCOPE_TARGET=10.42.0.10 ./scripts/smoke_engagement.sh  # 6/6 PASS
```

- **Frontend:** http://localhost/ (login ya activo como Admin; auth X-API-Key está OFF
  porque `ETH_MAS_API_KEY` está vacío en `.env`).
- **Lab alcanzable:** `docker exec eth_mas_backend nmap -Pn -p 22,80,3306 10.42.0.10`.
- Si el frontend no muestra la consola de narración, reconstruir:
  `docker compose build frontend && docker compose up -d frontend`.

> **Nota Windows:** `jq` se instala con `winget install jqlang.jq` (reabrir la terminal
> para que tome el PATH). El smoke aborta limpio si falta `jq`.

---

## 4. ⭐ Ver el engagement de demo ya persistido (#37)

**Importante:** el engagement #37 que se corrió esta sesión vive en los **volúmenes Docker
locales** de quien lo ejecutó, **no en git**. Al clonar la rama y hacer `docker compose up`,
las BD arrancan **vacías**. Para ver la **misma corrida**, restaurar el seed:

```bash
# Con el stack ARRIBA:
./scripts/restore_demo_seed.sh
```

Esto carga (⚠️ **destructivo**, reemplaza las BD locales):
- **Postgres** (`demo-seed/eth_mas_pg.sql`): engagement #37 + scope + HITL.
- **Mongo** (`demo-seed/eth_mas_mongo.archive`): findings, análisis, conversación del
  orquestador, pipeline/agent runs y los **2 PDFs** (GridFS).

**Verificación** (debería dar estos números):

```bash
curl -s "http://localhost:8000/engagements/37/findings?limit=200"        | jq .total      # 38
curl -s "http://localhost:8000/engagements/37/analysis"                  | jq '.attack_vectors|length'  # 5
curl -s "http://localhost:8000/engagements/37/reports"                   | jq .total      # 4
curl -s "http://localhost:8000/engagements/37/orchestrator/conversation" | jq .total      # 17
```

> El **pipeline_run representativo** de #37 es **4/4 completed** (Recon→Scan→Analysis→Report) — la
> pestaña **Pipeline** se ve en verde. (Hay un run previo `partial_failed` en el historial, del bug
> de Opus 4.8 ya corregido; no es el representativo y no se muestra.)

En la UI: **Engagement → #37 "Defensa Capstone - Metasploitable2"** → tabs **Findings**,
**Analysis** (popover MITRE, heatmap, kill chains) y **Reports** (descargar los 2 PDFs).

> Para **regenerar** el seed tras una corrida nueva: `./scripts/dump_demo_seed.sh`.

---

## 5. Cómo correr la demo (flujo conversacional)

Guión completo: [`guion-defensa-capstone-v0.4.md`](guion-defensa-capstone-v0.4.md).
Flujo en vivo desde el **chat del orquestador** (tab **Orquestador** del engagement):

1. **Crear engagement** con scope `10.42.0.10` (preset ATT&CK "Standard pentest").
2. Tab **Orquestador** → modo **Planificar**: el orquestador devuelve un **plan numerado**
   grounded en scope, sin ejecutar (la "Actividad en vivo" queda vacía).
3. Modo **Ejecutar** con una instrucción explícita ("ejecuta el plan completo…"):
   el **stream SSE** pinta turnos en vivo (Recon → Scan…).
4. **HITL bloqueante:** cuando el ScanAgent pide nmap/nuclei/nikto/gobuster, aprobar en
   **Control HITL** → el pipeline **reanuda** solo.
5. El orquestador **narra** los hallazgos al terminar.

> **Para la defensa (20 min):** mostrar el flujo en vivo (chat + SSE + 1er HITL) **sin
> esperar los ~15 min completos**, y luego **saltar al engagement #37 persistido** (seed)
> como evidencia: findings, Analysis y los 2 PDFs. El #37 es la **red de seguridad**.

**Estabilidad el día de la demo:**
- Backend **sin `--reload`** (ya configurado) y **no editar archivos** durante la corrida.
- Tener los **2 PDFs descargados** a mano como fallback.
- **Scope por IP** (no CIDR). **No re-correr** `/analysis` ni `/report` sobre el mismo
  engagement justo antes (genera pipeline_runs de 1 stage).

---

## 6. Resultados del contraste vs. línea base

Detalle completo: [`contraste-lab-vs-engagement-v0.4.md`](contraste-lab-vs-engagement-v0.4.md)
(Parte B). Resumen de #37:

| Aspecto | Resultado |
|---------|-----------|
| Findings | 38 (nmap 11 · nikto 23 · nuclei 3 · gobuster 1) |
| Enriquecidos CVE/ATT&CK | 38 con técnica ATT&CK · ~19 CVE únicas · 5 vectores |
| Pipeline | run representativo **4/4 completed** (Recon→Scan→Analysis→Report) |
| **vsftpd 2.3.4** (CVE-2011-2523, CVSS 9.8) | ✅ `confirmed` → vector RCE insignia |
| **Samba** (CVE-2007-2447) | ⚠️ **retenida** por versión no confirmada (anti-FP correcto) |
| distccd / UnrealIRCd / MySQL / VNC / Tomcat | ausentes por scope **MODERATE (1-1024)** — FN justificados |
| Falsos positivos de alta confianza | **0** |

**Lectura para la defensa:** el sistema **prioriza precisión sobre exhaustividad** y es
**honesto sobre su confianza** (etiqueta `confirmed` / `keyword-only` / `version-unknown`).
Las ausencias de los servicios en puertos >1024 son consecuencia de la intensidad MODERATE,
no fallos del detector: una corrida AGGRESSIVE los alcanzaría.

---

## 7. Notas y pendientes

- **Variante A / Pista 2** queda parqueada en `git stash` (`stash@{0}` sobre `release/v0.4`)
  + respaldo en la rama local `backup/v0.4-local-init`. Retomar ahí, no en v0.4.
- **`CLAUDE.md`** (vive fuera del repo, en la carpeta padre) quedó **pendiente de refinar**
  para reflejar esta sesión. Acordado dejarlo para después.
- **Orquestador en español neutro:** se ajustó el system prompt (sin voseo). `narration.py`
  ya estaba neutro.
- La tabla `scan_jobs` (artefacto de la migración de Variante A) se **eliminó** de la BD
  local; el `alembic_version` quedó en el head de v0.4 (`e4f7b2a9c5d6`). Una instalación
  fresca queda consistente sin pasos extra.

---

## 8. Checklist de verificación (lo que quedó probado)

- [x] 6 contenedores Up · `/health/services` overall: up · Opus 4.8 disponible.
- [x] Lab alcanzable desde el backend (nmap 22/80/3306, DVWA 302).
- [x] Smoke 6/6 PASS (incluye orquestador modo plan + persistencia de conversación).
- [x] Engagement #37 vía chat: plan, ejecutar, SSE en vivo, HITL aprobado en consola,
      narración final.
- [x] Pipeline **4/4 completed** persistido (run representativo): Recon → Scan (38) →
      Analysis (5 vectores) → Report. La pestaña Pipeline en verde.
- [x] Descarga de PDFs (http 200).
- [x] 200 tests verdes tras los fixes.
- [x] Seed de #37 restaurable y verificado (round-trip OK).

---

**Documento:** `docs/reporte-sesion-2026-06-26-v0.4.md` · rama `release/v0.4`.
