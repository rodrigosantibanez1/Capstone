# Run-sheet de la demo en vivo — ETH-MAS (release/v0.4)

> Hoja operativa para conducir la demo: **clic exacto** + **qué decir**. Para imprimir.
> Tiempo objetivo: ~10 min de demo. Notación: **[CLIC]** acción · **[DECIR]** guion · **[MOSTRAR]** a qué mirar.

---

## 0. Antes de empezar (con público o 5 min antes)

- [ ] Stack arriba: `docker compose --profile lab up -d` → 6 contenedores Up.
- [ ] `curl -s http://localhost:8000/health/services | jq .overall` → `up`.
- [ ] Engagement de respaldo restaurado: `./scripts/restore_demo_seed.sh`.
- [ ] Navegador en `http://localhost/`. Backend **sin `--reload`**. **No editar archivos** durante la demo.
- [ ] Los 2 PDFs descargados a mano (carpeta `reportes-demo/`) por si falla la red.

---

## 1. Apertura (1 min) — sin tocar nada

**[DECIR]** "ETH-MAS es un sistema de pentesting ético multi-agente con control humano. Un orquestador conversacional (LLM) coordina cuatro agentes —Recon, Scan, Análisis y Reporte— sobre herramientas reales. Tres garantías están en código, no en el prompt: el scope, el HITL (aprobación humana) y el mapeo MITRE ATT&CK. Lo voy a mostrar en vivo y después sobre una corrida ya completa."

**[MOSTRAR]** La pantalla de Inicio: las luces verdes de salud arriba (postgres, mongo, MCP, claude).

---

## 2. Demo en vivo con el orquestador (4–5 min)

> Objetivo: mostrar el chat + el stream en vivo + una aprobación HITL. **No esperar a que termine.**

1. **[CLIC]** **Nuevo** (arriba a la derecha de la pantalla de Inicio).
2. **[CLIC]** Campo "Nombre" → escribir **`Demo en vivo`**.
3. **[CLIC]** Campo de scope → escribir **`10.42.0.10`** → **Enter** (aparece el chip con el target).
4. **[CLIC]** Preset **"Standard pentest"** (en Tácticas ATT&CK).
5. **[CLIC]** **Crear Engagement**.
   - **[MOSTRAR]** El sistema abre solo el **orquestador de ese engagement** en la pantalla de Inicio (ya no hay que buscarlo ni entrar a ninguna pestaña).

7. **Modo Planificar** (botón **Plan** activo):
   - **[CLIC]** Caja de texto → escribir: *"Quiero auditar el host 10.42.0.10. Arma un plan, sin ejecutar nada todavía."*
   - **[CLIC]** **Planificar**.
   - **[DECIR]** "Devuelve un plan numerado y confirma que el target está dentro del scope autorizado. Fíjense que la 'Actividad en vivo' sigue vacía: en modo plan no ejecuta nada."

8. **Modo Ejecutar**:
   - **[CLIC]** Toggle **Ejecutar**.
   - **[CLIC]** Caja de texto → escribir: *"Ejecuta el plan: Recon y Scan sobre 10.42.0.10."*
   - **[CLIC]** **Ejecutar**.
   - **[MOSTRAR]** Panel **"Actividad en vivo"**: se pinta en vivo (SSE) — Reconocimiento, luego Escaneo.
   - **[DECIR]** "Esto es el stream en tiempo real: el orquestador delegó en Recon y ahora en Scan."

9. **HITL bloqueante** (el momento clave):
   - **[MOSTRAR]** El sidebar **Control HITL** muestra un badge (1) cuando el Scan pide aprobación.
   - **[CLIC]** **Control HITL**.
   - **[DECIR]** "El agente quiere lanzar una herramienta activa (nmap/nuclei). Como es riesgo medio o alto, queda en pausa esperando aprobación humana. Esto es control en código: no se sortea por chat."
   - **[CLIC]** **Aprobar**.
   - **[DECIR]** "Aprobado: el pipeline reanuda solo. Si rechazara, no correría."

> **NO esperar a que termine la corrida** (~15 min). Pasar al engagement persistido.

---

## 3. Salto a la corrida completa persistida — #37 (3–4 min)

**[DECIR]** "Para ver el resultado completo end-to-end, paso a una corrida que ya dejé persistida sobre el mismo lab."

1. **[CLIC]** En la pantalla de **Inicio**, en la lista de engagements, fila **#37 "Defensa Capstone - Metasploitable2"** → botón **Abrir** (espacio de trabajo completo).

2. **Pestaña Pipeline:**
   - **[MOSTRAR]** **4/4 en verde · completed**: Recon → Scan → Analysis → Report.
   - **[DECIR]** "Las cuatro etapas completas, conducidas por el orquestador."

3. **Pestaña Findings:**
   - **[MOSTRAR]** 38 hallazgos (nmap, nikto, nuclei, gobuster).
   - **[DECIR]** "38 hallazgos reales de cuatro herramientas distintas."

4. **Pestaña Analysis:**
   - **[MOSTRAR]** Vectores / kill chains. **Pasar el mouse** sobre una técnica MITRE → se abre el **popover** (nombre, táctica, link a attack.mitre.org). Mostrar el heatmap.
   - **[DECIR]** "El análisis enriquece los hallazgos con CVE y MITRE ATT&CK. Lo importante para la calidad: el backdoor de vsftpd 2.3.4 (CVE-2011-2523, CVSS 9.8) sale **confirmado**, pero Samba queda marcado como 'requiere confirmar versión' y su CVE se retiene. El sistema prioriza precisión: no inventa CVEs sin versión."

5. **Pestaña Reports:**
   - **[CLIC]** Descargar **Técnico** y **Ejecutivo**.
   - **[MOSTRAR]** El ejecutivo en lenguaje de negocio (sin jerga); el técnico con evidencia y mapeo ATT&CK.

---

## 4. Cierre (30 s)

**[DECIR]** "En resumen: un orquestador conversacional que planifica y delega, con scope y HITL como controles en código intocables, herramientas reales, y reportes con mapeo MITRE. Precisión sobre exhaustividad y honestidad sobre la confianza de cada hallazgo."

---

## Plan de respaldo (si algo falla)

| Falla | Qué hacer |
|-------|-----------|
| La corrida en vivo se cuelga / tarda | Saltar ya a **#37 persistido** (Parte 3). Es la evidencia primaria. |
| Falla la API key (orquestador no responde) | #37 **no usa la API**: se ve completo igual. Mostrar Pipeline/Analysis/Reports. |
| Falla Docker / el front | Abrir los **2 PDFs descargados** desde `reportes-demo/` y narrar con ellos. |

> Guion narrativo extendido: [`guion-defensa-capstone-v0.4.md`](guion-defensa-capstone-v0.4.md).
> Cómo levantar y restaurar desde cero: [`reporte-sesion-2026-06-26-v0.4.md`](reporte-sesion-2026-06-26-v0.4.md) §3–4.

---

**Documento:** `docs/runsheet-demo-en-vivo-v0.4.md` · rama `release/v0.4`.
