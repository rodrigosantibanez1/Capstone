# Slide 14 — Contraste: línea base del lab vs. ETH-MAS

> Para insertar **después de la slide 13 (intro demo)**. Contenido acotado, listo para una
> sola slide. Fuente: [`contraste-lab-vs-engagement-v0.4.md`](contraste-lab-vs-engagement-v0.4.md).

---

## TÍTULO
**¿Qué debería encontrar el lab… y qué encontró el sistema?**

### Subtítulo
Engagement #37 · Metasploitable2 (10.42.0.10) · conducido por el orquestador · pipeline 4/4

---

## CUERPO (tabla central — 4 CVE "ancla" del lab)

| Vulnerabilidad esperada | Resultado de ETH-MAS |
|-------------------------|----------------------|
| **vsftpd 2.3.4** — backdoor (CVE-2011-2523, CVSS 9.8) | ✅ **Detectada y confirmada** → vector de RCE insignia |
| **Samba** (CVE-2007-2447) | ⚠️ Detectada, **CVE retenida**: versión no confirmada |
| **distccd / UnrealIRCd** (puertos > 1024) | ⛔ Fuera del scan **MODERATE** (1–1024) — por diseño |

---

## CIFRAS (banda inferior, 3 KPIs)

**38** hallazgos reales   ·   **5** vectores de ataque   ·   **0** falsos positivos de alta confianza

---

## MENSAJE CLAVE (caja destacada)

> **Precisión sobre exhaustividad.** El sistema **no inventa CVEs sin versión confirmada**:
> etiqueta cada hallazgo por su nivel de confianza. Las ausencias son **decisiones de scope**,
> no fallos de detección.

---

### Notas para el orador (no van en la slide)
- "vsftpd confirmado" = el agente verificó producto + versión → afirma la CVE (CVSS 9.8).
- "Samba retenida" = se detectó el servicio pero no la versión exacta → el gate por CPE **no**
  afirma la CVE. Esto es lo que defiende la **calidad** del sistema ante un evaluador.
- "Fuera de rango" = la intensidad MODERATE escanea 1–1024; una corrida AGGRESSIVE alcanzaría
  distccd (3632) y UnrealIRCd (6667).
- Esta slide **prepara** la demo: muestra el criterio con el que hay que mirar lo que viene.

---

## Sugerencia de layout (PowerPoint)
- Título arriba (1 línea) + subtítulo gris pequeño.
- Tabla 2 columnas al centro (3 filas), con íconos ✅ / ⚠️ / ⛔ a color.
- Banda inferior con los 3 KPIs en grande (38 · 5 · 0).
- Caja de mensaje clave abajo, fondo de acento.
- **Sin** texto adicional: que entre de un vistazo.
