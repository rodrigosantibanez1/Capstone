# Verificación de hallazgos — Engagement #24 "MyPC"

> **Sesión de auditoría sobre datos persistidos** (no se re-escaneó). Contrasta
> cada finding del engagement #24 contra la NVD real y el `raw_output` guardado,
> dictamina CONFIRMADO / FALSO POSITIVO / REQUIERE-PRUEBA-MANUAL, y produce un
> plan de hardening priorizado por **riesgo real** + fixes al AnalysisAgent.
>
> **Fecha:** 2026-06-10 · **Target:** `192.168.56.1` (host Windows del operador,
> adaptador host-only de VirtualBox) · **Fuente:** `GET /engagements/24/findings`
> (20 findings) + raw_output de cada FindingDoc + consultas directas a NVD API 2.0.
>
> Acompaña a [`e2e-engagement-mypc-2026-06-10.md`](e2e-engagement-mypc-2026-06-10.md) §7.

---

## 0. TL;DR

- **La superficie de puertos es real** — nmap no alucina: los 9 puertos abiertos
  están confirmados por evidencia `syn-ack`.
- **Todas las correlaciones CVE "graves" son falsos positivos.** Los 3 hallazgos
  de mayor CVSS del reporte (7.5 en RPC/SMB, 8.6 en uvicorn) **no aplican a este
  host**. El CVSS del LLM apuntó al riesgo en la dirección equivocada.
- **El ítem que sí merece atención (SMB/NetBIOS expuesto) no llevaba ningún CVE.**
  Esa inversión es exactamente lo que esta sesión expone.
- **Causa raíz técnica de los falsos positivos, identificada en código:**
  1. `cve_lookup` usa `keywordSearch` (texto libre) de NVD y el agente lo invoca
     aunque `version=null` → correlación por nombre de servicio / palabra suelta.
  2. El `:80` es el **propio frontend del ETH-MAS**; su `nginx.conf` hace
     `try_files … /index.html`, devolviendo **200 para toda ruta** → cascada de
     falsos positivos de nikto (`.bash_history`, `JAMonAdmin.jsp`, etc.).
- **Una sospecha del E2E §7 quedó descartada:** `CVE-2026-2652` **sí existe** en
  NVD (no es alucinación ni ID mal formado) — pero es de **mlflow**, no de
  uvicorn. El heurístico propuesto de "descartar CVE con año futuro" sería
  **incorrecto**: descartaría un CVE válido. El fix correcto es filtrar por
  producto/versión, no por año.

---

## 1. Tabla de veredictos por finding

Leyenda: ✅ CONFIRMADO · ❌ FALSO POSITIVO · 🔬 REQUIERE-PRUEBA-MANUAL

### 1.1 NMAP — puertos (la existencia del puerto es siempre ✅; el juicio es sobre la correlación CVE/severidad)

| Puerto / servicio | CVE asignado | CVSS guardado | Veredicto correlación | Justificación |
|---|---|---|---|---|
| 80/tcp — nginx 1.31.1 | — | — | ✅ (servicio real, severidad sobrevalorada) | Es el **frontend del propio ETH-MAS** (`frontend` container, `80:80` en docker-compose). Banner **no spoofeado**: `nginx:alpine` con versión mainline reciente (minor impar = mainline, consistente con 2026). Sin CVE. Severidad `medium` es alta para "puerto http abierto" de tu propia SPA. |
| 135/tcp — msrpc | CVE-2003-0352, CVE-2003-0003 | 7.5 | ❌ FALSO POSITIVO | Ambos CVE **existen en NVD** (verificados) pero son de **2003** y afectan Windows NT/2000/XP/2003. `version=null` → el agente hizo `keywordSearch="Microsoft Windows RPC"` y NVD devolvió los CVE de RPC más famosos por coincidencia de texto. CVE-2003-0003 es además **escalada local** del RPC Locator, ni siquiera remoto. Un Windows de 2026 está parchado contra Blaster. |
| 139/tcp — netbios-ssn | — | — | ✅ (real, sin CVE; ver hardening) | Puerto real y **relevante para hardening** (NetBIOS expuesto). El finding no lleva CVE — correcto, pero la severidad `high` aquí sí está bien puesta. |
| 445/tcp — microsoft-ds (SMB) | CVE-2003-0352 | 7.5 | ❌ FALSO POSITIVO (CVE) / ✅ (exposición SMB real) | El CVE es el mismo de Blaster (2003), no aplica. **Pero el puerto SMB abierto es el hallazgo más importante de toda la corrida** y no tiene CVE que lo respalde. Ver §2 P1. |
| 808/tcp — mc-nmf (.NET Message Framing) | — | — | ✅ (real, benigno) | Servicio .NET legítimo del host. Severidad `medium` sobrevalorada. |
| 5040/tcp — unknown | — | — | ✅ (real, benigno) | Windows Connected Devices Platform Service. Normal en Windows 10/11. |
| 7680/tcp — pando-pub | — | — | ✅ (real, benigno) | Windows Delivery Optimization (descargas P2P de updates). Normal. |
| 8000/tcp — uvicorn | CVE-2020-7695, CVE-2026-2652 | 8.6 | ❌ FALSO POSITIVO (ambos CVE) | Es **el propio backend ETH-MAS**. Detalle abajo. |
| 8834/tcp — nessus-xmlrpc | — | — | ✅ (real, exposición legítima de dev) | Nessus del operador. Esperado. |

#### Detalle puerto 8000 (uvicorn)

- **CVE-2026-2652** — ❌ FALSO POSITIVO. **Existe en NVD** (publicado 2026-05-15,
  CVSS v3.0 = 8.6), así que **no es alucinación**. Pero es una vuln de
  **mlflow ≤ 3.9.0** (acceso no autenticado a rutas FastAPI). La palabra
  "uvicorn" aparece en su descripción sólo porque mlflow se sirve vía uvicorn →
  `keywordSearch=uvicorn` la matcheó. El backend ETH-MAS no es mlflow.
- **CVE-2020-7695** — 🔬 REQUIERE-PRUEBA-MANUAL (casi seguro no aplica). CVE real
  de uvicorn (HTTP response splitting), CVSS v3.1 = **5.3** (medium), afecta
  **uvicorn < 0.11.7**. Con `version=null` no se puede confirmar, pero el backend
  corre uvicorn moderno (>0.30). Comprobar con `docker exec eth_mas_backend uv pip show uvicorn`.
- **Bug de procedencia de CVSS:** el finding guarda `cvss_score=8.6`, que es el
  score de CVE-2026-2652 (mlflow), **no** el de CVE-2020-7695 (5.3). El agente
  pega un único CVSS (el máximo) a un finding con múltiples CVE, sin trazar a cuál
  pertenece. Ver §3 fix B.

### 1.2 NIKTO — HTTP sobre :80 y :8000

> **Causa raíz transversal:** el `nginx.conf` del frontend hace
> `location / { try_files $uri $uri/ /index.html; }`. Cualquier ruta inexistente
> devuelve **HTTP 200 + index.html** (la SPA React). nikto usa el código 200 como
> señal de "el recurso existe" → reporta como hallazgo cada ruta de su diccionario.

| Hallazgo | Sev | CVE | Veredicto | Justificación |
|---|---|---|---|---|
| "home dir = web root, shell history retrieved" (`/.bash_history`) | high | — | ❌ FALSO POSITIVO | El 200 es el `index.html` de la SPA, no un `.bash_history`. Host **Windows**, sin shell bash. Artefacto del catch-all `try_files`. |
| idem (`/.sh_history`) | high | — | ❌ FALSO POSITIVO | Mismo origen. |
| JAMon Admin interface — `/JAMonAdmin.jsp` | high | CVE-2013-6235 | ❌ FALSO POSITIVO | CVE real (XSS en JAMon ≤2.7, CVSS v2 4.3 verificado) **pero no hay JAMon aquí**: nginx no sirve JSP y no hay app Java. El 200 es la SPA. Mismo catch-all. |
| Falta header `content-security-policy` | low | — | ✅ CONFIRMADO | `nginx.conf` no setea CSP. Real, baja prioridad. |
| Falta `strict-transport-security` | low | — | ✅ CONFIRMADO (matiz) | Real, pero HSTS sólo aplica sobre HTTPS; el frontend sirve HTTP plano. |
| Falta `x-content-type-options` | low | — | ✅ CONFIRMADO | Real. `nosniff` ausente. |
| Falta `referrer-policy` | low | — | ✅ CONFIRMADO | Real. |
| Falta `permissions-policy` | low | — | ✅ CONFIRMADO | Real. |
| `X-Frame-Options` deprecado / `X-Content-Type-Options` no seteado | low | — | ✅ CONFIRMADO | Real, informativo. |
| `OPTIONS: Allowed HTTP Methods: GET` | low | — | ✅ CONFIRMADO (info) | Trivial. |

**Nota de calidad de datos:** el `raw_output` muestra que nikto corrió contra
**:80 y :8000** (HITL #98 y #100), pero todos los FindingDoc tienen `port: null`
— el normalizador de nikto no captura el puerto. La tabla de hallazgos no permite
distinguir si un header falta en el frontend (80) o en el backend (8000). Ver §3 fix F.

### 1.3 Resumen cuantitativo

| Veredicto | Cantidad | Detalle |
|---|---|---|
| ❌ Falso positivo (correlación CVE / hallazgo) | 5 | RPC/SMB 2003 (×2 findings), uvicorn 2026-2652, nikto shell-history (×2), JAMon |
| 🔬 Requiere prueba manual | 1 | uvicorn CVE-2020-7695 (versión desconocida; casi seguro no aplica) |
| ✅ Confirmado (servicio/exposición real) | 14 | 9 puertos reales + headers HTTP faltantes |

**Lectura:** 0 de los 4 CVE "de alto CVSS" del reporte son aplicables a este host.

---

## 2. Plan de corrección / hardening — priorizado por riesgo REAL

> Ordenado por exposición real, **no** por el CVSS del LLM. Contexto: es un PC de
> desarrollo Windows; el target era su adaptador host-only de VirtualBox.

### P1 — Exposición que conviene cerrar (riesgo real, sin CVE en el reporte)

1. **SMB / NetBIOS (135 / 139 / 445).** Es el riesgo real más alto de la corrida,
   y ningún CVE válido lo respaldaba.
   - Restringir 139/445/135 en la interfaz host-only con el firewall de Windows
     (regla de entrada que sólo permita lo necesario, o bloqueo total si la VM no
     monta shares del host).
   - Deshabilitar **NetBIOS sobre TCP/IP** (puerto 139) en ese adaptador
     (Propiedades del adaptador → IPv4 → Avanzado → WINS → "Deshabilitar NetBIOS").
   - Verificar que **SMBv1 está deshabilitado** y **SMB signing requerido**
     (`Get-SmbServerConfiguration`).
   - *No* se necesita parchar nada de 2003 — eso era el falso positivo.

2. **5040/tcp.** Servicio de Windows benigno; si no se usa en la VLAN host-only,
   firewallearlo en ese adaptador. Prioridad baja dentro de P1.

### P2 — Higiene HTTP (riesgo bajo en dev; trivial de cerrar)

3. **Headers de seguridad faltantes en `nginx.conf`.** Sólo relevante si el
   frontend se expone más allá de localhost/host-only. Añadir en el bloque
   `server` (o `location /`):
   - `add_header X-Content-Type-Options "nosniff" always;`
   - `add_header Referrer-Policy "strict-origin-when-cross-origin" always;`
   - `add_header Content-Security-Policy "<política de la SPA>" always;`
   - `add_header X-Frame-Options "DENY" always;` (o equivalente vía CSP `frame-ancestors`).
   - HSTS sólo cuando el frontend sirva HTTPS.

### P3 — Exposición legítima de tu entorno de dev: documentar y aceptar (NO "arreglar")

4. Estos puertos son **tu propio tooling** y aparecieron porque el target se
   escaneó a sí mismo:
   - **8000/uvicorn** = backend ETH-MAS.
   - **80/nginx** = frontend ETH-MAS.
   - **8834/nessus** = tu Nessus.
   - **808 (.NET) / 7680 (Delivery Optimization)** = servicios normales de Windows/.NET.
   - Recomendación: bindear los servicios de dev al adaptador host-only o a
     `127.0.0.1` de forma intencional, y dejarlos anotados como exposición
     esperada para que futuras corridas no los vuelvan a marcar como riesgo.

---

## 3. Mejoras al sistema ETH-MAS (lo que esta corrida dejó en evidencia)

### Fix A — AnalysisAgent correlaciona CVE sin versión → "keyword soup" (causa raíz #1)

**Evidencia:** los findings de 135/445/8000 tienen `version=null` y aun así
recibieron CVE. `cve_lookup` ([`mcp_servers/analysis_server.py:76-120`](../eth-mas-backend/mcp_servers/analysis_server.py))
usa `keywordSearch` (texto libre de NVD), que matchea cualquier CVE que mencione
el término en su descripción — de ahí el CVE de mlflow por la palabra "uvicorn".

Propuesta (de menor a mayor esfuerzo):

1. **No emitir CVE cuando `version` es null/vacío.** El system prompt ya dice
   "para cada servicio con producto **+ versión**" pero no se hace cumplir.
   Reforzarlo en código en `AnalysisAgent._persist`
   ([`services/analysis_agent.py:304-320`](../eth-mas-backend/services/analysis_agent.py)):
   si el finding de origen no tiene versión, descartar `cve_ids`/`cvss_score`.
   Barato y elimina de un golpe los 3 falsos positivos de nmap.
2. **Gating por producto y matching por CPE.** En vez de `keywordSearch`, usar el
   parámetro **`virtualMatchString`** de NVD con el CPE
   (`cpe:2.3:a:<vendor>:<product>:<version>`). nmap **ya emite el CPE** en el XML
   (`cpe:/a:igor_sysoev:nginx:1.31.1`, `cpe:/o:microsoft:windows`): capturarlo en
   el normalizador y pasarlo a `cve_lookup`. Así NVD hace el match de rango de
   versión y no devuelve CVE de otros productos. Es el fix de fondo.
3. **No filtrar por año.** El heurístico "descartar CVE con año futuro" propuesto
   en el E2E §7 sería incorrecto: `CVE-2026-2652` es válido y vigente. El criterio
   correcto es aplicabilidad por producto+versión, no por fecha.

### Fix B — Procedencia del CVSS (bug de etiquetado)

**Evidencia:** el finding de :8000 guarda `cvss_score=8.6` (de CVE-2026-2652)
junto a `cve_ids=[CVE-2020-7695 (5.3), CVE-2026-2652 (8.6)]`. El agente pega un
único CVSS (el máximo) sin trazar a qué CVE pertenece.

Propuesta: guardar CVSS **por CVE** (mapa `cve_id → {score, source}`) en el
FindingDoc, o como mínimo registrar de qué `cve_id` proviene `cvss_score`. El
score de un finding nunca debe pertenecer a un CVE distinto de los que lista.

### Fix C — nikto: cascada de falsos positivos por catch-all SPA (causa raíz #2)

**Evidencia:** `nginx.conf:17-19` (`try_files … /index.html`) hace que toda ruta
devuelva 200. nikto marca `.bash_history`, `.sh_history`, `JAMonAdmin.jsp`, etc.

Es un límite inherente de nikto, pero el sistema puede mitigarlo:

1. **Sonda de cordura:** antes de confiar en hallazgos nikto basados en "200 =
   existe", pedir una ruta aleatoria inexistente; si también da 200, marcar los
   hallazgos de detección-por-200 como `low_confidence` / degradar severidad.
2. Como mínimo, **bajar de `high` a `info`** los hallazgos nikto del tipo
   "file retrieved" cuando el servidor exhibe comportamiento catch-all.

### Fix D — nmap timeout 300s insuficiente para 1-65535 (H-1 histórico)

**Evidencia:** HITL #95 (full ports, 1-65535) → `tool_error` a los 324.8s. El
agente se recuperó solo acotando a 1-10000 (#96), pero el barrido completo nunca
terminó.

Propuesta:
1. Hacer el timeout del subprocess nmap **configurable por env** (p.ej.
   `NMAP_TIMEOUT_SECS`, default 600) en el Security MCP.
2. O **chunking** del rango completo en bandas con timeout por banda; o default a
   top-N puertos + barrido dirigido. El patrón de auto-recuperación del agente ya
   apunta a esto — conviene formalizarlo.
3. **Cuidado con la ventana HITL:** el timeout de espera HITL es 300s (caso #101).
   Si el tool puede tardar 600s, el timeout HITL debería ser ≥ al del tool, o el
   HITL debería declarar la duración esperada. Hoy un scan largo aprobado tarde
   queda en `hitl_timeout` (lo que le pasó al nuclei de :8000).

### Fix E — Desfase UTC→local en el frontend (cosmético)

**Evidencia:** backend persiste UTC naive (`utils.utc_now()`); el frontend
interpreta los timestamps como hora local (documentado en E2E §nota de horas).
Añadir un helper `parseUTC(ts)` que normalice a UTC (append `Z` / `Date.UTC`)
antes de formatear. No afecta datos, sólo presentación.

### Fix F — Normalizador nikto pierde el puerto

**Evidencia:** todos los FindingDoc de nikto tienen `port: null` aunque el
`raw_output` distingue :80 y :8000. Capturar el puerto en
`normalize_nikto_findings` para que el operador sepa a qué servicio aplica cada
header faltante.

---

## 4. Apéndice — verificación NVD (consultas directas, 2026-06-10)

| CVE | ¿En NVD? | Publicado | CVSS real | Producto real | Aplica a #24 |
|---|---|---|---|---|---|
| CVE-2026-2652 | ✅ Sí | 2026-05-15 | v3.0 = 8.6 | **mlflow ≤ 3.9.0** | ❌ No (matcheó "uvicorn" en la descripción) |
| CVE-2020-7695 | ✅ Sí | 2020-07-27 | v3.1 = 5.3 | **uvicorn < 0.11.7** | 🔬 Improbable (versión desconocida; backend usa uvicorn moderno) |
| CVE-2003-0352 | ✅ Sí | 2003-08-18 | v2 = 7.5 | Windows NT/2000/XP/2003 (Blaster) | ❌ No (host 2026 parchado) |
| CVE-2003-0003 | ✅ Sí | 2003-02-07 | v2 = 7.5 | Windows NT/2000/XP (RPC Locator, **local**) | ❌ No |
| CVE-2013-6235 | ✅ Sí | 2014-01-31 | v2 = 4.3 | **JAMon ≤ 2.7** (XSS) | ❌ No (no hay JAMon; 200 de la SPA) |

Todos los CVE-ID son reales y bien formados. **El problema nunca fue invención de
IDs, sino correlación sin versión (keyword match) y la cascada de 200 de la SPA.**

---

## 5. Acciones sugeridas (resumen accionable)

| # | Acción | Tipo | Prioridad |
|---|--------|------|-----------|
| 1 | Firewall/disable NetBIOS+SMB (139/445/135) en el adaptador host-only | Hardening host | **P1** |
| 2 | Verificar SMBv1 off + SMB signing | Hardening host | P1 |
| 3 | Documentar 8000/80/8834/808/7680 como exposición de dev esperada | Hardening host | P3 |
| 4 | `cve_lookup`: no emitir CVE si `version=null`; migrar a match por CPE | Fix sistema (A) | **Alta** |
| 5 | Guardar CVSS por-CVE (trazar score↔cve_id) | Fix sistema (B) | Alta |
| 6 | nikto: degradar hallazgos "200=existe" ante catch-all SPA | Fix sistema (C) | Media |
| 7 | nmap timeout configurable / chunking + alinear con ventana HITL | Fix sistema (D) | Media |
| 8 | Helper `parseUTC` en frontend | Fix sistema (E) | Baja |
| 9 | Capturar puerto en normalizador nikto | Fix sistema (F) | Baja |
| 10 | Añadir security headers a `nginx.conf` (si el front se expone) | Hardening web | P2 |

> **Nota:** ningún cambio de código fue aplicado en esta sesión. Este documento es
> sólo el dictamen de verificación + plan. Los fixes 4-9 requieren confirmación
> antes de implementarse.
