"""
alembic/env.py — entorno de migración Alembic.

Cambios (auditoría 2026-05-20, hallazgo D-1):
  - Lee DATABASE_URL del entorno (.env del backend o env del docker-compose).
  - Importa Base.metadata de models.py para que autogenerate funcione.
  - Si no hay DATABASE_URL, cae al sqlalchemy.url del alembic.ini.

Esto permite correr `alembic` indistintamente desde:
  - Container del backend (DATABASE_URL=postgresql+psycopg2://postgres:admin@postgres:5432/...)
  - Host con venv local (DATABASE_URL=...@localhost:5432/...)
  - CI sin .env (cae al default del .ini)
"""

from __future__ import annotations

import os
import sys
from logging.config import fileConfig
from pathlib import Path

from sqlalchemy import engine_from_config
from sqlalchemy import pool

from alembic import context

# Permitir importar el backend (models, database, etc.) desde env.py.
_BACKEND_DIR = Path(__file__).resolve().parent.parent
if str(_BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(_BACKEND_DIR))

# Cargar variables de .env si está disponible (idempotente).
try:
    from dotenv import load_dotenv
    load_dotenv(_BACKEND_DIR / ".env")
except ImportError:
    pass  # dotenv no es obligatorio (Docker inyecta env directo)

# Cargar metadata de los modelos para soportar autogenerate.
try:
    import models  # noqa: F401  (registra los Column en Base.metadata)
    from database import Base
    target_metadata = Base.metadata
except Exception:
    # Si la importación falla (raro), seguimos sin metadata: las migraciones
    # explícitas siguen funcionando, solo se pierde autogenerate.
    target_metadata = None


# Alembic Config object, acceso al alembic.ini.
config = context.config

# Sobrescribir sqlalchemy.url con DATABASE_URL del entorno si está definida
# (fix D-1 auditoría 2026-05-20).
_env_url = os.getenv("DATABASE_URL")
if _env_url:
    config.set_main_option("sqlalchemy.url", _env_url)

# Configurar logging del .ini.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)


def run_migrations_offline() -> None:
    """Modo offline: genera SQL sin conectarse a la BD."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Modo online: conecta y ejecuta migraciones contra la BD real."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
