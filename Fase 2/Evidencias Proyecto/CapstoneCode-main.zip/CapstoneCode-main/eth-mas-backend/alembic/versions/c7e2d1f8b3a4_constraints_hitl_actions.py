"""Constraints en hitl_actions (risk_level + decision) — M-5 auditoría

Revision ID: c7e2d1f8b3a4
Revises: a1b2c3d4e5f6
Create Date: 2026-05-19 14:00:00.000000

Motivación (auditoría 2026-05-19 §M-5):
  hitl_actions.risk_level y hitl_actions.decision son columnas String sin
  validación a nivel DB. Cualquier typo desde un MCP server o un test podía
  escribir valores fuera del catálogo §4.4 del CLAUDE.md sin que nadie se
  enterara.

  Esta migración añade CheckConstraints (no enums) para no romper datos legacy
  y permitir extender el catálogo sin migración pesada.

Valores válidos:
  risk_level: LOW | MEDIUM | HIGH | CRITICAL
  decision:   NULL | PENDING | APPROVED | REJECTED | AUTO-APPROVED
              (NULL = registro legacy del antiguo enforce_scope; PENDING = flujo
               actual desde los MCP servers)
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "c7e2d1f8b3a4"
down_revision: Union[str, Sequence[str], None] = "a1b2c3d4e5f6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


_VALID_RISK     = ("LOW", "MEDIUM", "HIGH", "CRITICAL")
_VALID_DECISION = ("PENDING", "APPROVED", "REJECTED", "AUTO-APPROVED")


def upgrade() -> None:
    # ── 1. Sanitizar datos legacy antes de aplicar el constraint ─────────────
    # Cualquier risk_level fuera del catálogo se normaliza a MEDIUM (más
    # restrictivo entre los seguros).
    valid_risk_sql = ", ".join(f"'{v}'" for v in _VALID_RISK)
    op.execute(
        f"UPDATE hitl_actions "
        f"SET risk_level = 'MEDIUM' "
        f"WHERE risk_level NOT IN ({valid_risk_sql})"
    )

    # B-2: las filas legacy del antiguo enforce_scope quedaban con decision IS
    # NULL para indicar "pendiente". El flujo actual (MCP servers) usa
    # decision='PENDING'. Normalizamos los NULL históricos para tener un único
    # marker de estado pendiente y simplificar el filtro en main.py.
    op.execute(
        "UPDATE hitl_actions SET decision = 'PENDING' WHERE decision IS NULL"
    )

    # Cualquier decision fuera del catálogo (post-normalize) se baja a PENDING.
    valid_decision_sql = ", ".join(f"'{v}'" for v in _VALID_DECISION)
    op.execute(
        f"UPDATE hitl_actions "
        f"SET decision = 'PENDING' "
        f"WHERE decision NOT IN ({valid_decision_sql})"
    )

    # ── 2. Constraints ───────────────────────────────────────────────────────
    op.create_check_constraint(
        "ck_hitl_risk_level_valid",
        "hitl_actions",
        f"risk_level IN ({valid_risk_sql})",
    )
    op.create_check_constraint(
        "ck_hitl_decision_valid",
        "hitl_actions",
        f"decision IS NULL OR decision IN ({valid_decision_sql})",
    )


def downgrade() -> None:
    op.drop_constraint("ck_hitl_decision_valid",  "hitl_actions", type_="check")
    op.drop_constraint("ck_hitl_risk_level_valid", "hitl_actions", type_="check")
