"""Sumar EXPIRED al catálogo de hitl_actions.decision — Fase 1.2 anti-zombi

Revision ID: d3a5b9c1e2f0
Revises: c7e2d1f8b3a4
Create Date: 2026-05-22 16:00:00.000000

Motivación (auditoría 2026-05-22 §Problema #2):
  Cuando uvicorn --reload (Docker bind-mount + flag --reload) mata al worker
  para hot-reload, los subprocess MCP lanzados por ScanAgent/ReconAgent quedan
  huérfanos en el contenedor (no había init: true → no se reapean). Esos
  huérfanos pueden haber registrado HitlAction(decision='PENDING') que ya
  nunca van a poder destrabarse porque su stdio está roto.

  Necesitamos un estado terminal nuevo `EXPIRED` para que:
    a) el lifespan del backend pueda marcar como EXPIRED toda PENDING anterior
       al boot actual (Fix 1.2 cleanup).
    b) el operador pueda forzar EXPIRED desde la UI sin esperar el reinicio
       (Fix 1.3 endpoint POST /expire-pending).

  EXPIRED es estrictamente para uso interno del sistema. El endpoint
  PATCH /hitl-actions/{id}/decision del operador NO acepta EXPIRED — sólo
  APPROVED/REJECTED/AUTO-APPROVED.

Valores válidos post-migración:
  decision: PENDING | APPROVED | REJECTED | AUTO-APPROVED | EXPIRED
"""
from typing import Sequence, Union

from alembic import op


# revision identifiers, used by Alembic.
revision: str = "d3a5b9c1e2f0"
down_revision: Union[str, Sequence[str], None] = "c7e2d1f8b3a4"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


_VALID_DECISION_NEW = ("PENDING", "APPROVED", "REJECTED", "AUTO-APPROVED", "EXPIRED")
_VALID_DECISION_OLD = ("PENDING", "APPROVED", "REJECTED", "AUTO-APPROVED")


def upgrade() -> None:
    # Recrear el CheckConstraint con EXPIRED incluido. PostgreSQL no admite
    # ALTER CHECK en sitio: drop + create.
    op.drop_constraint("ck_hitl_decision_valid", "hitl_actions", type_="check")

    valid_sql = ", ".join(f"'{v}'" for v in _VALID_DECISION_NEW)
    op.create_check_constraint(
        "ck_hitl_decision_valid",
        "hitl_actions",
        f"decision IS NULL OR decision IN ({valid_sql})",
    )


def downgrade() -> None:
    # Antes de bajar la migración, llevar las filas EXPIRED a REJECTED para
    # que cumplan el constraint viejo. EXPIRED es un estado terminal, así que
    # REJECTED es el mapeo semánticamente más cercano.
    op.execute(
        "UPDATE hitl_actions SET decision = 'REJECTED' WHERE decision = 'EXPIRED'"
    )

    op.drop_constraint("ck_hitl_decision_valid", "hitl_actions", type_="check")

    valid_sql = ", ".join(f"'{v}'" for v in _VALID_DECISION_OLD)
    op.create_check_constraint(
        "ck_hitl_decision_valid",
        "hitl_actions",
        f"decision IS NULL OR decision IN ({valid_sql})",
    )
