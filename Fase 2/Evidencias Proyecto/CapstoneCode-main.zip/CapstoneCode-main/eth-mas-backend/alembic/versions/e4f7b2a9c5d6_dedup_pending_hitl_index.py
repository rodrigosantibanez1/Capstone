"""Índice único parcial anti-duplicado en hitl_actions PENDING — Fix 3.2

Revision ID: e4f7b2a9c5d6
Revises: d3a5b9c1e2f0
Create Date: 2026-05-22 17:30:00.000000

Motivación (auditoría 2026-05-22 §Problema #2 + Fix 3):
  Fix 3.1 (security_server.py) hace dedup en aplicación: antes de crear una
  HitlAction PENDING busca si ya existe una idéntica en los últimos N
  segundos. Esa defensa funciona dentro de un proceso, pero NO contra dos
  procesos MCP corriendo en paralelo (escenario típico tras --reload de
  uvicorn con bind-mount, donde el subprocess huérfano sigue vivo y un
  nuevo subprocess legítimo arranca en simultáneo).

  Esta migración agrega un UNIQUE INDEX parcial a nivel BD que actúa como
  segunda barrera: dos INSERT concurrentes con misma firma chocan contra
  el índice, el perdedor recibe IntegrityError y _register_hitl_pending
  (Fix 3.1) lo atrapa y reusa el id del ganador.

Firma del índice:
  (engagement_id, agent, tool, md5(params::text))  WHERE decision = 'PENDING'

  - md5(params::text) garantiza determinismo aunque params sea JSONB —
    PostgreSQL cast lo serializa a una representación textual estable.
  - El filtro WHERE decision='PENDING' significa que sólo aplica a la cola
    activa. Filas EXPIRED/APPROVED/REJECTED no compiten por unicidad —
    se puede tener historial de varios scans del mismo tool sobre el mismo
    target sin colisionar.

Limpieza pre-índice:
  Si la BD actual tiene duplicados PENDING vivos (porque corrió en versión
  anterior sin el dedup), no podemos crear el índice unique sin antes
  resolverlos. Estrategia conservadora: conservar el MÁS NUEVO (id máximo)
  por firma y marcar los restantes como EXPIRED (la migración previa
  d3a5b9c1e2f0 ya habilitó EXPIRED como valor válido).
"""
from typing import Sequence, Union

from alembic import op


# revision identifiers, used by Alembic.
revision: str = "e4f7b2a9c5d6"
down_revision: Union[str, Sequence[str], None] = "d3a5b9c1e2f0"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


_INDEX_NAME = "uq_hitl_pending_dedup"


def upgrade() -> None:
    # ── 1. Limpiar duplicados existentes ANTES de poner el constraint ──────
    # Para cada (engagement_id, agent, tool, md5(params::text)) que tenga
    # >1 fila PENDING, conservamos la más reciente (mayor id) y expiramos
    # las anteriores.
    op.execute(
        """
        WITH ranked AS (
            SELECT
                id,
                row_number() OVER (
                    PARTITION BY engagement_id, agent, tool, md5(params::text)
                    ORDER BY id DESC
                ) AS rn
            FROM hitl_actions
            WHERE decision = 'PENDING'
        )
        UPDATE hitl_actions
        SET    decision   = 'EXPIRED',
               decided_at = NOW(),
               operator   = 'SYSTEM:DEDUP_MIGRATION',
               notes      = 'Duplicado expirado al crear índice único e4f7b2a9c5d6'
        WHERE id IN (SELECT id FROM ranked WHERE rn > 1);
        """
    )

    # ── 2. Crear el UNIQUE INDEX parcial ─────────────────────────────────────
    # No usamos op.create_index() porque la expresión funcional md5(...) y el
    # filtro WHERE requieren SQL directo para que SQLAlchemy no la transforme.
    op.execute(
        f"""
        CREATE UNIQUE INDEX {_INDEX_NAME}
        ON hitl_actions (engagement_id, agent, tool, md5(params::text))
        WHERE decision = 'PENDING';
        """
    )


def downgrade() -> None:
    op.execute(f"DROP INDEX IF EXISTS {_INDEX_NAME};")
