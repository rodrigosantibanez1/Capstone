"""
auth.py — Auth X-API-Key (HU-22)
================================
Política: opt-in. La auth se activa SOLO si ETH_MAS_API_KEY está definida y no
vacía en el entorno. En dev (variable ausente o vacía) verify_api_key es
no-op, lo que evita fricción local y desincronizaciones frontend/backend.
Para la defensa académica basta exportar ETH_MAS_API_KEY=<secreto> y reiniciar
el backend: el mismo código pasa a exigir el header sin más cambios.

Vive en módulo propio (no en main.py) porque los routers lo importan como
dependencia y main.py importa los routers — dejarlo en main crearía un
import circular.
"""

from __future__ import annotations

import logging
import os

from fastapi import HTTPException, Security, status
from fastapi.security.api_key import APIKeyHeader

logger = logging.getLogger("eth_mas.auth")

_API_KEY        = (os.getenv("ETH_MAS_API_KEY") or "").strip()
_AUTH_ENABLED   = bool(_API_KEY)
_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

if _AUTH_ENABLED:
    logger.info("Auth X-API-Key ACTIVA (ETH_MAS_API_KEY seteada)")
else:
    logger.warning(
        "Auth X-API-Key DESACTIVADA (ETH_MAS_API_KEY no definida). "
        "Endpoints protegidos quedan abiertos — solo apto para dev local."
    )


async def verify_api_key(key: str = Security(_api_key_header)):
    """Valida X-API-Key solo si ETH_MAS_API_KEY está seteada. Si no, no-op."""
    if not _AUTH_ENABLED:
        return
    if not key or key != _API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key inválida o ausente. Incluir header X-API-Key.",
        )
