# Gestión de API Keys — ETH-MAS

> Documento de referencia para el manejo de las API keys del proyecto. Cubre lo implementado (**Nivel 1**) y deja documentadas las mejoras futuras (**Nivel 2** y **Nivel 3**) para post-Capstone.

---

## Las dos keys del proyecto — no confundir

| Variable | Quién la usa | Para qué | Endpoint protegido |
|---|---|---|---|
| `ANTHROPIC_API_KEY` | Backend (`ReconAgent`, `ScanAgent`) | Llamadas a Claude API vía Anthropic SDK | — |
| `ETH_MAS_API_KEY` | Frontend → Backend (`X-API-Key` header) | Auth interna entre cliente y FastAPI | `POST /pipeline`, `POST /scan`, `POST /recon`, `PATCH /hitl-actions/*` |

Son **dos secretos distintos**. La documentación de [Anthropic Admin API](https://platform.claude.com/docs/en/api/admin/api_keys/update) gestiona la **primera** (`ANTHROPIC_API_KEY`), no la segunda.

---

## Estado actual — Nivel 1 (implementado)

### Cómo se cargan

Ambas leen de variables de entorno vía `python-dotenv`:

```bash
# .env (no commitear — está en .gitignore)
ANTHROPIC_API_KEY=sk-ant-api03-xxxxx...
ETH_MAS_API_KEY=dev-key-insecure-change-me
```

### Validación de `ANTHROPIC_API_KEY`

Centralizado en [`services/anthropic_health.py`](../services/anthropic_health.py):

| Función | Cuándo se ejecuta | Qué hace |
|---|---|---|
| `validate_anthropic_key_format()` | Startup del backend (`lifespan`) | Chequea prefijo `sk-ant-` y longitud. Síncrono. Solo `warn` si falla — el backend igual arranca para que `/health/services` sea accesible. |
| `check_anthropic_key_live()` | Background al startup + on-demand (`?refresh=true`) | Llama a `client.models.list()` con timeout 5s. Cachea el resultado 10 min. |
| `mark_anthropic_failure(reason)` | Agentes al recibir 401 en runtime | Invalida el cache inmediatamente, refleja en `/health/services` sin esperar al próximo poll. |
| `mark_anthropic_success()` | Agentes al terminar un loop OK | Extiende el TTL del cache sin pegarle a Anthropic. |

### Manejo de errores en agentes

`ReconAgent.run()` y `ScanAgent.run()` envuelven el agentic loop:

```python
try:
    await self._run_agentic_loop(...)
    mark_anthropic_success()
except AuthenticationError as e:           # o APIStatusError status_code=401
    mark_anthropic_failure("401 desde ReconAgent")
    # marca el AgentRunDoc como failed con mensaje claro:
    # "ANTHROPIC_API_KEY inválida o revocada (401). Revisar .env."
```

### Visibilidad en el frontend

- `GET /health/services` reporta el estado real:
  ```json
  "anthropic": {
    "status": "up",
    "key_present": true,
    "key_validated": true,
    "models_sample": ["claude-haiku-4-5-20251001", ...],
    "checked_at": "2026-05-18T13:42:11Z"
  }
  ```
- La barra global del frontend (`HealthBar` en `App.jsx`) muestra punto rojo si `status: down`.
- Para forzar un re-chequeo tras rotar la key: `GET /health/services?refresh=true`.

### Validación de `ETH_MAS_API_KEY`

Sigue siendo el dependency `verify_api_key` de [`main.py`](../main.py):

```python
async def verify_api_key(key: str = Security(_api_key_header)):
    if not key or key != _API_KEY:
        raise HTTPException(status_code=401, detail="API key inválida o ausente.")
```

Aplicado vía `dependencies=[Depends(verify_api_key)]` en endpoints sensibles. El frontend la gestiona desde la UI (modal accesible vía botón ⚙ del top bar, persiste en `localStorage`).

### Garantías de no-leak

- La key se pasa al SDK como `AsyncAnthropic(api_key=key)` — nunca en logs ni stack traces.
- Validado con `grep -ri "api_key\|ANTHROPIC_API"` — no aparece en strings de log/print.
- El campo `detail` de las respuestas de error trunca a 200 chars y nunca incluye la key.

---

## Nivel 2 — Multi-source con prioridad (pendiente · ~1 h)

**Problema que resuelve:** hot-swap de la key sin restart del backend; soporte de Docker secrets para que producción no requiera `.env` plano en el filesystem.

### Diseño propuesto

Crear `services/key_provider.py`:

```python
class KeyProvider:
    """
    Resuelve secretos buscando en este orden:
      1. /run/secrets/{name}            (Docker secrets / Kubernetes)
      2. os.environ[name.upper()]       (.env, env vars)
      3. ~/.eth-mas/secrets/{name}      (file-based dev mode)
      4. raise KeyError
    """
    SOURCES = ["docker_secrets", "env", "user_secrets"]

    @classmethod
    def get(cls, name: str) -> str:
        for source in cls.SOURCES:
            value = getattr(cls, f"_from_{source}")(name)
            if value:
                logger.info("Key '%s' obtenida de fuente '%s'", name, source)
                return value
        raise KeyError(f"Secret '{name}' no encontrado en ninguna fuente")
```

### Cambios necesarios

1. **`services/anthropic_health.py`** — reemplazar `os.getenv("ANTHROPIC_API_KEY")` por `KeyProvider.get("ANTHROPIC_API_KEY")`.
2. **`docker-compose.yml`** — agregar sección `secrets`:
   ```yaml
   services:
     backend:
       secrets:
         - anthropic_api_key
         - eth_mas_api_key
   secrets:
     anthropic_api_key:
       file: ./secrets/anthropic_api_key.txt
     eth_mas_api_key:
       file: ./secrets/eth_mas_api_key.txt
   ```
3. **Watcher con `watchfiles`** — si el archivo de secret cambia, recargar en memoria sin restart. Útil para rotación en caliente.
4. **Endpoint admin** `POST /admin/keys/reload` (con `verify_api_key`) — invalida cache de `anthropic_health` y fuerza re-lectura.

### Estimación

3 archivos nuevos/modificados, ~120 líneas. ~1 h.

---

## Nivel 3 — Anthropic Admin API (pendiente · ~3 h)

**Problema que resuelve:** gestión programática de las keys de la organización Anthropic — listarlas, ver cuál está activa, deshabilitar la vieja al rotar.

**Requiere:** una **Admin API key** separada (`sk-ant-admin-...`), creada en la consola de Anthropic con permisos de admin sobre la organización. Es **otra credencial más** que sumar al `.env`.

### Endpoints útiles

| Método | Endpoint Anthropic | Para qué |
|---|---|---|
| `GET` | `/v1/organizations/api_keys` | Listar todas las keys de la org |
| `GET` | `/v1/organizations/api_keys/{id}` | Detalle de una key |
| `POST` | `/v1/organizations/api_keys/{id}` | Update (renombrar, cambiar `status` a `active`/`inactive`/`archived`) |

> Nota: la **creación** de keys nuevas no está expuesta en el Admin API público a la fecha de este documento. Sigue siendo manual desde console.anthropic.com.

### Diseño propuesto

1. **`services/anthropic_admin.py`** — wrapper async sobre el Admin API:
   ```python
   class AnthropicAdmin:
       def __init__(self):
           self.admin_key = os.getenv("ANTHROPIC_ADMIN_API_KEY")
           if not self.admin_key:
               raise RuntimeError("ANTHROPIC_ADMIN_API_KEY requerida para Admin API")

       async def list_api_keys(self) -> list[dict]: ...
       async def get_api_key(self, key_id: str) -> dict: ...
       async def disable_api_key(self, key_id: str) -> dict: ...
       async def rename_api_key(self, key_id: str, name: str) -> dict: ...
   ```
2. **Endpoints backend** (todos con `verify_api_key` dependency, no exponer al público):
   - `GET /admin/anthropic/keys` — lista keys de la org
   - `POST /admin/anthropic/keys/{id}/disable` — deshabilita
   - `POST /admin/anthropic/keys/{id}/rename` — renombra
3. **Vista frontend** `AdminKeysView.jsx` — tabla con las keys de la org, badge de status, botones de acción. Modal de confirmación antes de deshabilitar.
4. **Variable de entorno** `ANTHROPIC_ADMIN_API_KEY` separada en `.env.example`.

### Estimación

5-6 archivos nuevos, ~400 líneas. ~3 h.

### Cuándo justifica implementarlo

- Si el Capstone debe demostrar gestión de credenciales como feature.
- Si hay rotación periódica obligatoria (compliance).
- Si hay múltiples ambientes (dev/staging/prod) usando keys distintas y se quiere auditar cuál se usó.

Para el alcance académico actual (deadline 9 jun, 1 sprint restante), **no es prioritario**.

---

## Convenciones operativas

- **NUNCA commitear `.env`** — está en `.gitignore` desde Sprint 1.
- **`.env.example`** se mantiene actualizado con todas las variables necesarias (incluyendo defaults seguros para dev).
- **Rotar tras un leak**: deshabilitar key vieja en console.anthropic.com → crear key nueva → actualizar `.env` → `GET /health/services?refresh=true` → verificar `key_validated: true`.
- **Local dev**: usar `ANTHROPIC_API_KEY` personal sin compartir; los costos son bajísimos con Haiku (~$0.10/día de demo).
- **CI/CD futuro**: la key debería venir de GitHub Secrets, no del repo.

---

## Referencias

- [Anthropic API key authentication](https://platform.claude.com/docs/en/api/getting-started)
- [Anthropic Admin API — keys](https://platform.claude.com/docs/en/api/admin/api_keys/update)
- [12-factor app — Config](https://12factor.net/config)
- [Docker secrets](https://docs.docker.com/engine/swarm/secrets/)

---

**Última revisión:** 2026-05-18 · Sprint 2
**Owner:** equipo ETH-MAS
