# Alternativa Gemini para ReconAgent (y futuros agentes)

**Estado:** Documentado, no implementado por defecto.  
**Cuándo usar:** Si se dispone de tokens Gemini gratuitos y se quiere reducir costo a $0 durante desarrollo.  
**Decisión de Sprint 2:** Se usa `claude-haiku-4-5-20251001` por defecto. Ver sección "¿Por qué Haiku por defecto?" al final.

---

## ¿Qué cambia al usar Gemini?

El **MCP server no cambia en absoluto** (`osint_server.py` es agnóstico al LLM cliente).  
Lo único que cambia es el **cliente del agente** — el código que llama al LLM y enruta sus tool calls de vuelta al MCP server.

La arquitectura queda:

```
ReconAgent (recon_agent.py, modo Gemini)
     │  google-genai SDK
     │  FunctionCall → FunctionResponse
     ↓
MCP Bridge (mcp_gemini_bridge.py)
     │  convierte MCP tool schemas → Gemini FunctionDeclaration
     │  enruta Gemini tool calls → MCP session.call_tool()
     ↓
OSINT MCP Server (osint_server.py) — SIN CAMBIOS
     │  scope check + HITL + tools reales
     ↓
dnspython / python-whois / theHarvester
```

---

## Paso 1 — Dependencias adicionales

```
# Agregar a requirements.txt
google-genai>=1.16.0
```

**No reemplaza** `anthropic` en requirements — ambas pueden coexistir.

---

## Paso 2 — Variables de entorno

```bash
# .env — cambiar para modo Gemini
RECON_AGENT_BACKEND=gemini          # "claude" (default) | "gemini"
GEMINI_API_KEY=AIza...              # API key de Google AI Studio / universidad
RECON_AGENT_MODEL=gemini-2.5-flash  # o gemini-2.5-pro para mejor razonamiento
```

---

## Paso 3 — Bridge MCP → Gemini

Crear `agent_core/mcp_gemini_bridge.py`:

```python
"""
mcp_gemini_bridge.py — Adaptador MCP tools → Gemini FunctionDeclaration
========================================================================
Conecta al MCP server vía stdio y expone sus tools en el formato
que espera el SDK google-genai (FunctionDeclaration con JSON Schema).

Uso:
    tools, session = await load_mcp_tools_for_gemini("mcp_servers/osint_server.py")
    # tools  → list[types.FunctionDeclaration] para pasar a Gemini
    # session → ClientSession activa para ejecutar tool calls
"""

from __future__ import annotations

import json
import os
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from google.genai import types


async def load_mcp_tools_for_gemini(
    server_script: str,
) -> tuple[list[types.FunctionDeclaration], ClientSession, Any]:
    """
    Conecta al MCP server y convierte sus tools a FunctionDeclaration de Gemini.

    IMPORTANTE: el contexto (read/write streams) debe mantenerse abierto
    durante toda la sesión del agente. Retorna también los streams para
    que el llamador los maneje con contextlib.AsyncExitStack.

    Returns:
        (gemini_declarations, session, exit_stack)
    """
    import contextlib

    stack = contextlib.AsyncExitStack()

    server_params = StdioServerParameters(
        command="python",
        args=[server_script],
        env={**os.environ},
    )

    read, write = await stack.enter_async_context(stdio_client(server_params))
    session     = await stack.enter_async_context(ClientSession(read, write))
    await session.initialize()

    mcp_tools = await session.list_tools()

    declarations = []
    for tool in mcp_tools.tools:
        # Sanear el JSON Schema para compatibilidad con Gemini
        # Gemini no acepta: $schema, additionalProperties, algunos formats
        schema = _sanitize_schema_for_gemini(tool.inputSchema or {})
        declarations.append(
            types.FunctionDeclaration(
                name        = tool.name,
                description = tool.description or "",
                parameters  = schema,
            )
        )

    return declarations, session, stack


def _sanitize_schema_for_gemini(schema: dict) -> dict:
    """
    Elimina campos del JSON Schema que Gemini rechaza.
    Gemini acepta: type, properties, required, description, enum.
    Rechaza: $schema, additionalProperties, $ref, allOf, anyOf, oneOf.
    """
    BLOCKED = {"$schema", "additionalProperties", "$ref", "$defs", "allOf", "anyOf", "oneOf"}

    def _clean(obj):
        if isinstance(obj, dict):
            return {k: _clean(v) for k, v in obj.items() if k not in BLOCKED}
        if isinstance(obj, list):
            return [_clean(i) for i in obj]
        return obj

    return _clean(schema)


async def call_mcp_tool_from_gemini(
    session: ClientSession,
    function_call,         # google.genai.types.FunctionCall
) -> str:
    """
    Ejecuta un tool call de Gemini en el MCP server.
    Retorna el resultado como string (para FunctionResponse).
    """
    result = await session.call_tool(
        function_call.name,
        arguments=dict(function_call.args),
    )
    return result.content[0].text if result.content else "{}"
```

---

## Paso 4 — ReconAgent en modo Gemini

En `services/recon_agent.py`, el método `_run_agentic_loop` se reemplaza con
esta variante cuando `RECON_AGENT_BACKEND=gemini`:

```python
async def _run_agentic_loop_gemini(self, targets: list[str], scopes: list) -> dict:
    """
    Loop del agente usando Gemini como LLM.
    El MCP server es el mismo — solo cambia el cliente LLM.
    """
    from google import genai
    from google.genai import types
    from agent_core.mcp_gemini_bridge import (
        load_mcp_tools_for_gemini,
        call_mcp_tool_from_gemini,
    )

    gemini_client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

    declarations, session, stack = await load_mcp_tools_for_gemini(
        _OSINT_SERVER_SCRIPT
    )

    raw_results: list[dict] = []

    async with stack:
        messages = [
            types.Content(
                role="user",
                parts=[types.Part(text=(
                    f"Ejecuta reconocimiento OSINT sobre: {targets}. "
                    f"Engagement ID: {self.engagement_id}. "
                    f"Para cada target: dns_enum, whois_lookup, theharvester_run. "
                    f"Incluye siempre engagement_id={self.engagement_id}."
                ))]
            )
        ]

        system_instruction = self._build_system_prompt(targets)
        max_iters = len(targets) * 3 * 2 + 5

        for iteration in range(max_iters):
            response = gemini_client.models.generate_content(
                model    = self.model,    # ej: "gemini-2.5-flash"
                contents = messages,
                config   = types.GenerateContentConfig(
                    system_instruction = system_instruction,
                    tools = [types.Tool(function_declarations=declarations)],
                    temperature = 0.1,
                ),
            )

            candidate = response.candidates[0]
            messages.append(candidate.content)

            # ¿Gemini quiere llamar tools?
            function_calls = [
                p for p in candidate.content.parts
                if hasattr(p, "function_call") and p.function_call
            ]

            if function_calls:
                function_responses = []
                for part in function_calls:
                    fc = part.function_call
                    t_start     = datetime.utcnow()
                    result_text = "{}"
                    call_status = "completed"

                    try:
                        result_text = await call_mcp_tool_from_gemini(session, fc)
                        parsed      = json.loads(result_text)
                        raw_results.append(parsed)

                        if parsed.get("status") == "blocked":
                            call_status = "scope_violation"

                    except Exception as e:
                        result_text = json.dumps({"error": str(e), "status": "error"})
                        call_status = "error"

                    duration_ms = int(
                        (datetime.utcnow() - t_start).total_seconds() * 1000
                    )
                    self._tool_log.append(ToolCallEntry(
                        tool           = fc.name,
                        target         = dict(fc.args).get("target", ""),
                        status         = call_status,
                        hitl_action_id = json.loads(result_text).get("hitl_action_id"),
                        duration_ms    = duration_ms,
                    ))

                    function_responses.append(
                        types.Part(function_response=types.FunctionResponse(
                            name     = fc.name,
                            response = {"result": result_text},
                        ))
                    )

                messages.append(
                    types.Content(role="user", parts=function_responses)
                )

            else:
                # Gemini terminó (sin más tool calls)
                break

    return await self._build_and_persist_surface_map(raw_results, scopes)
```

### Integración en `run()`:

```python
# En ReconAgent._run_agentic_loop(), al inicio:
backend = os.getenv("RECON_AGENT_BACKEND", "claude")
if backend == "gemini":
    return await self._run_agentic_loop_gemini(targets, scopes)
# ... resto del método Claude (ya implementado)
```

---

## Diferencias clave Claude vs Gemini para este agente

| Aspecto | Claude Haiku 4.5 | Gemini 2.5 Flash |
|---|---|---|
| Costo por run ReconAgent | ~$0.02-0.05 | $0 (tokens gratis universidad) |
| Fiabilidad tool calling | Alta (nativo Anthropic) | Alta (Google Function Calling) |
| `stop_reason` para "terminé" | `"end_turn"` | ausencia de `function_call` en parts |
| Schema tools | `input_schema` (JSON Schema) | `FunctionDeclaration` (JSON Schema saneado) |
| Manejo de errores en tool | `tool_result` con `is_error` | `FunctionResponse` con campo error |
| Streaming | `stream=True` en `create()` | `stream=True` en `generate_content()` |
| MCP server | **Sin cambios** | **Sin cambios** |

---

## ¿Por qué Haiku por defecto y no Gemini?

1. **Un solo code path en producción.** Gemini requiere el bridge + sanitización de schemas. Cualquier bug en el bridge afecta al agente. Con Claude, el SDK de Anthropic y el SDK de MCP son del mismo ecosistema.

2. **El costo real es bajo.** ReconAgent con Haiku cuesta ~$0.03/run. Para 60 runs de desarrollo: ~$1.80. No justifica la complejidad de mantener dos backends.

3. **Gemini es una salida de emergencia, no el plan A.** Si los tokens de la universidad cubren el proyecto completo, se puede activar con una variable de entorno. El MCP server ya es agnóstico.

4. **Demo académica.** El tribunal evaluará el stack declarado en el anteproyecto. Usar Claude mantiene coherencia con la documentación existente.

---

*Documento creado: Sprint 2 — 2026-05-13*  
*Actualizar si se implementa el backend Gemini en producción.*
