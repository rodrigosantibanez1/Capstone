"""
main.py — ETH-MAS FastAPI application v0.5.0
=============================================
Entry point (uvicorn main:app). Desde la Sesión D (2026-06-09) main.py solo
contiene bootstrap + lifespan + registro de routers; los endpoints viven en
el paquete `routers/`, organizados por dominio:

  routers/health.py        · GET /  ·  GET /health/services
  routers/engagements.py   · E1 — CRUD + state machine (HU-01, HU-03)
  routers/scope.py         · E1 — scope targets + validate (HU-01, HU-02)
  routers/pipeline.py      · E2/E3/E0 — recon, scan, analysis, surface-map,
                             findings, pipeline + pipeline-runs (HU-04..08, 12/13)
  routers/reports.py       · E6 — PDFs GridFS (HU-14)
  routers/hitl.py          · E4 — cola HITL + expire-pending (HU-09, HU-10)
  routers/orchestrator.py  · Bloque A — chat operador↔orquestador (ADR-005)
  routers/observability.py · agent_runs + SSE (HU-23)

La auth X-API-Key (HU-22) vive en auth.py (verify_api_key, opt-in vía
ETH_MAS_API_KEY). El scope check canónico sigue en services/scope_validator.
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

import models
import routers
from database import engine
from mongo_client import ensure_indexes
from services.alembic_bootstrap import bootstrap_alembic
from services.anthropic_health import (
    check_anthropic_key_live,
    validate_anthropic_key_format,
)
from utils import utc_now

logger_main = __import__("logging").getLogger("eth_mas.main")

# Crea tablas si no existen (dev convenience; idempotente). En producción la
# fuente de verdad es Alembic — bootstrap_alembic() de abajo sincroniza el
# estado de alembic_version con la realidad de la BD (fix D-2 auditoría
# 2026-05-20). Si la BD está virgen, Alembic aplica las migraciones; si fue
# creada por create_all en una versión vieja, hace stamp head sin re-ejecutar.
models.Base.metadata.create_all(bind=engine)
try:
    _bootstrap_result = bootstrap_alembic(engine)
    logger_main.info("Alembic bootstrap: %s", _bootstrap_result)
except Exception as e:
    # No bloquear el arranque por un fallo del bootstrap — los endpoints siguen
    # funcionando, solo no aplicaríamos migraciones futuras automáticamente.
    logger_main.warning("Alembic bootstrap falló (no bloqueante): %s", e)


# ── Lifespan (reemplaza @on_event deprecated) ─────────────────────────────────

# Fix 1.2 — Anti-zombi al startup.
# Cualquier HitlAction con decision='PENDING' creada antes del boot actual
# pertenece a un proceso huérfano del reload anterior (su stdio MCP está
# roto y nadie va a destrabarla). Las marcamos como 'EXPIRED' para que la
# UI deje de mostrarlas como pendientes y para que el pre-check de
# ScanAgent / PipelineController (introducido por Yerson en bb3bf12) no
# bloquee nuevas corridas legítimas.
#
# Grace period: 60s. Toleramos PENDINGs muy recientes para no apagar HITL
# legítimas si el operador reinicia el backend en medio de un scan activo
# (caso raro pero posible). El operador siempre puede forzar la limpieza
# con el endpoint POST /engagements/{id}/hitl-actions/expire-pending
# (Fix 1.3).
_STARTUP_EXPIRE_GRACE_SECS = 60


def _expire_orphan_pending_hitl(grace_period_secs: int = _STARTUP_EXPIRE_GRACE_SECS) -> int:
    """
    Marca como EXPIRED todas las HitlAction PENDING con requested_at anterior
    a (ahora - grace_period_secs). Retorna el número de filas afectadas.

    Se invoca desde el lifespan al arrancar el backend. Síncrono — el caller
    debe envolverlo en asyncio.to_thread() para no bloquear el event loop.
    """
    from sqlalchemy.orm import Session

    cutoff = utc_now() - __import__("datetime").timedelta(seconds=grace_period_secs)
    note = (
        f"Expirado por startup cleanup ({utc_now().isoformat()}Z). "
        f"PENDING anterior a {cutoff.isoformat()}Z → proceso huérfano de reload."
    )

    with Session(engine) as session:
        # SQLAlchemy bulk update: emite un solo UPDATE.
        affected = (
            session.query(models.HitlAction)
            .filter(
                models.HitlAction.decision == "PENDING",
                models.HitlAction.requested_at < cutoff,
            )
            .update(
                {
                    "decision":   "EXPIRED",
                    "decided_at": utc_now(),
                    "operator":   "SYSTEM:STARTUP_CLEANUP",
                    "notes":      note,
                },
                synchronize_session=False,
            )
        )
        session.commit()
        return int(affected or 0)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Inicializa recursos al arrancar y los libera al apagar.
    - Crea índices MongoDB (idempotente)
    - Limpia HITL PENDING huérfanas de procesos anteriores (Fix 1.2)
    - Valida formato de ANTHROPIC_API_KEY (warn-only; NO bloquea startup
      para que el operador pueda revisar /health/services aunque la key
      esté rota)
    - Lanza un live-check de la key en background (no bloquea startup)
    """
    await ensure_indexes()

    # Cleanup anti-zombi (Fix 1.2). Síncrono → to_thread para no bloquear.
    try:
        expired = await asyncio.to_thread(_expire_orphan_pending_hitl)
        if expired > 0:
            logger_main.warning(
                "Startup cleanup: %d HitlAction PENDING huérfanas marcadas como EXPIRED",
                expired,
            )
        else:
            logger_main.info("Startup cleanup: sin HITL huérfanas que limpiar")
    except Exception as e:
        # No bloquear el startup si la BD aún no está lista o falla el UPDATE
        # (ej: migración d3a5b9c1e2f0 no aplicada). El operador puede usar
        # POST /expire-pending manualmente en cuanto la BD esté disponible.
        logger_main.error(
            "Startup cleanup falló (no bloqueante): %s. "
            "Verificar que la migración d3a5b9c1e2f0 esté aplicada.", e,
        )

    # Validación de formato — rápida, síncrona
    ok_fmt, fmt_msg = validate_anthropic_key_format()
    if ok_fmt:
        logger_main.info("ANTHROPIC_API_KEY format OK")
    else:
        logger_main.warning(
            "⚠ ANTHROPIC_API_KEY: %s — los agentes fallarán hasta corregirla. "
            "Ver /health/services en el dashboard.", fmt_msg,
        )

    # Live-check en background. Hace una llamada a /v1/models (free) con
    # timeout 5s. Si falla, /health/services lo reflejará. No bloquea.
    asyncio.create_task(check_anthropic_key_live())

    yield
    # Cleanup opcional al shutdown (Motor cierra conexiones solo)


# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="ETH-MAS API",
    description="Motor de orquestacion de pentesting multi-agente con HITL",
    version="0.5.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for _router in routers.ALL_ROUTERS:
    app.include_router(_router)
