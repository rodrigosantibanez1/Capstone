# mcp_servers — MCP Servers de ETH-MAS
# Cada server corre como proceso independiente (stdio transport).
# FastAPI los lanza como subprocesos via mcp.client.stdio.

# Servers disponibles:
#   osint_server.py   — ReconAgent: dns_enum, whois_lookup, theharvester_run
#   security_server.py — ScanAgent: nmap_scan, nuclei_run, nikto_scan, gobuster_run (Sprint 2b)
