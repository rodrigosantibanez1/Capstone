#!/usr/bin/env python3
"""
analysis_server.py — Analysis MCP Server · ETH-MAS Sprint 3 (Bloque B, ADR-005)
===============================================================================
MCP Server que expone las tools de enriquecimiento del AnalysisAgent. A
diferencia del Security MCP, estas tools son **pasivas** (risk_level LOW): NO
contactan el target — operan sobre findings ya persistidos y bases externas de
conocimiento (NVD, MITRE ATT&CK). Por eso no requieren HITL ni scope check.

Tools:
  cve_lookup(product, version)        → CVEs reales + CVSS desde NVD API 2.0
                                         (caché en Mongo, degradación graceful).
  attack_technique_lookup(query)      → valida/busca técnicas MITRE ATT&CK contra
                                         un dataset local (evita IDs alucinados — A4).

Transporte: stdio — el AnalysisAgent lo lanza como subprocess.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import urllib.parse
import urllib.request
from typing import Optional

# ── Path setup ────────────────────────────────────────────────────────────────
_BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

from dotenv import load_dotenv
load_dotenv(os.path.join(_BACKEND_DIR, ".env"))

from utils import utc_now
from mongo_client import get_mongo_db

from mcp.server.fastmcp import FastMCP

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [analysis_server] %(levelname)s — %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)

# ── Config NVD ────────────────────────────────────────────────────────────────
_NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
_NVD_API_KEY = os.getenv("NVD_API_KEY")  # opcional; sin key NVD limita a 5 req/30s
_NVD_TIMEOUT = float(os.getenv("NVD_TIMEOUT_SECS", "20"))
# TTL de caché (días). CVEs por producto/versión cambian poco.
_CVE_CACHE_TTL_DAYS = int(os.getenv("CVE_CACHE_TTL_DAYS", "30"))

mcp = FastMCP(
    "eth-mas-analysis",
    instructions=(
        "Analysis MCP del pipeline ETH-MAS. Tools pasivas (risk LOW): NO contactan "
        "el target. Enriquecen findings con CVEs reales (NVD) y técnicas MITRE "
        "ATT&CK validadas. Nunca inventes CVE-IDs ni technique_ids: usa estas tools."
    ),
)


def _cve_cache_col():
    return get_mongo_db()["cve_cache"]


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: cve_lookup
# ═══════════════════════════════════════════════════════════════════════════════

# Conversión CPE 2.2 (URI, lo que emite nmap) → componentes 2.3.
# nmap: cpe:/a:igor_sysoev:nginx:1.31.1   →  part=a vendor=igor_sysoev
#       product=nginx version=1.31.1
def _parse_cpe(cpe: str) -> Optional[dict]:
    """Extrae {part, vendor, product, version} de un CPE 2.2 o 2.3. None si no parsea."""
    if not cpe:
        return None
    cpe = cpe.strip()
    if cpe.startswith("cpe:2.3:"):
        c = cpe.split(":")
        # cpe : 2.3 : part : vendor : product : version : ...
        get = lambda i: c[i] if len(c) > i else "*"  # noqa: E731
        return {"part": get(2), "vendor": get(3), "product": get(4), "version": get(5)}
    if cpe.startswith("cpe:/"):
        c = cpe[len("cpe:/"):].split(":")
        get = lambda i: c[i] if len(c) > i else "*"  # noqa: E731
        return {"part": get(0) or "*", "vendor": get(1) or "*",
                "product": get(2) or "*", "version": get(3) or "*"}
    return None


def _has_concrete_version(version: Optional[str]) -> bool:
    return bool(version) and version not in ("*", "-", "")


def _build_virtual_match(parsed: dict) -> str:
    """
    Arma un virtualMatchString CPE 2.3 para NVD. Vendor se comodín-iza (`*`)
    para maximizar recall: nmap a veces reporta un vendor histórico distinto al
    de NVD (ej. nginx = igor_sysoev en nmap vs f5/nginx en NVD). El producto +
    versión siguen acotando → seguimos sin falsos positivos por keyword.
    """
    part = parsed.get("part") or "a"
    product = parsed.get("product") or "*"
    version = parsed.get("version") or "*"
    version = version if _has_concrete_version(version) else "*"
    return f"cpe:2.3:{part}:*:{product}:{version}:*:*:*:*:*:*:*"


def _query_nvd(keyword: str, max_results: int) -> list[dict]:
    """Llamada síncrona a NVD por keyword (se corre en to_thread). CVEs parseados."""
    params = {"keywordSearch": keyword, "resultsPerPage": max_results}
    return _nvd_get(params, max_results)


def _query_nvd_by_cpe(virtual_match: str, max_results: int) -> list[dict]:
    """
    Consulta NVD con virtualMatchString: NVD aplica el match de rango de versión
    contra las `configurations` de cada CVE server-side. Solo devuelve CVEs
    cuya configuración vulnerable cubre el producto+versión dado (fix 2026-06-11).
    """
    params = {"virtualMatchString": virtual_match, "resultsPerPage": max_results}
    return _nvd_get(params, max_results)


def _nvd_get(params: dict, max_results: int) -> list[dict]:
    url = f"{_NVD_URL}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={"User-Agent": "ETH-MAS/analysis"})
    if _NVD_API_KEY:
        req.add_header("apiKey", _NVD_API_KEY)
    with urllib.request.urlopen(req, timeout=_NVD_TIMEOUT) as resp:
        data = json.loads(resp.read().decode("utf-8", errors="replace"))
    return _parse_nvd_response(data, max_results)


def _parse_nvd_response(data: dict, max_results: int) -> list[dict]:
    """Extrae CVE-ID + CVSS + descripción de la respuesta NVD 2.0."""
    out: list[dict] = []
    for item in (data.get("vulnerabilities") or [])[:max_results]:
        cve = item.get("cve") or {}
        cve_id = cve.get("id")
        if not cve_id:
            continue
        # descripción en inglés
        desc = ""
        for d in cve.get("descriptions", []) or []:
            if d.get("lang") == "en":
                desc = d.get("value", "")
                break
        # CVSS: preferir v3.1 > v3.0 > v2
        score = None
        severity = None
        metrics = cve.get("metrics", {}) or {}
        for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
            arr = metrics.get(key) or []
            if arr:
                cdata = arr[0].get("cvssData", {}) or {}
                score = cdata.get("baseScore")
                severity = cdata.get("baseSeverity") or arr[0].get("baseSeverity")
                break
        out.append({
            "cve_id": cve_id,
            "cvss_score": score,
            "cvss_severity": (severity or "").lower() or None,
            "description": desc[:300],
            "source": "NVD",
        })
    return out


@mcp.tool()
async def cve_lookup(
    product: str = "",
    version: str = "",
    cpe: str = "",
    engagement_id: int = 0,
    max_results: int = 8,
) -> str:
    """
    Busca CVEs reales para un servicio en la NVD. PREFERÍ pasar el `cpe` que nmap
    detectó (campo evidence.cpe del finding): NVD aplica el match de rango de
    versión server-side y devuelve solo CVEs que de verdad afectan ese
    producto+versión, evitando los falsos positivos por coincidencia de texto.
    NO contacta el target (risk LOW).

    Args:
        product:       Nombre del producto (ej: "vsftpd"). Usado si no hay cpe.
        version:       Versión detectada (ej: "2.3.4"). Opcional.
        cpe:           CPE de nmap (ej: "cpe:/a:igor_sysoev:nginx:1.31.1"). RECOMENDADO.
        engagement_id: ID del engagement (trazabilidad).
        max_results:   Máximo de CVEs a devolver (default 8).

    Returns:
        JSON {product, version, cpe, match_mode, cves:[...], status, cached}.
        match_mode: "cpe_versioned" (CVE aplica a la versión exacta → confirmado) |
                    "cpe_product"   (match por producto sin versión → no confirmado) |
                    "keyword"       (solo texto, NO aplicable sin validar) |
                    "none".
        status: "completed" | "completed_empty" | "unavailable".
    """
    parsed = _parse_cpe(cpe) if cpe else None
    # Si no vino CPE pero sí product+version concretos, igual usamos keyword.

    # match_mode determina la CONFIANZA río abajo (AnalysisAgent._persist).
    if parsed and _has_concrete_version(parsed.get("version")):
        match_mode = "cpe_versioned"
        cache_key = f"cpe::{_build_virtual_match(parsed)}".lower()
    elif parsed:
        match_mode = "cpe_product"
        cache_key = f"cpe::{_build_virtual_match(parsed)}".lower()
    else:
        match_mode = "keyword"
        cache_key = f"kw::{product} {version}".strip().lower()

    # ── 1. Caché (por CPE o por keyword) ──────────────────────────────────────
    try:
        from datetime import timedelta
        cutoff = utc_now() - timedelta(days=_CVE_CACHE_TTL_DAYS)
        cached = await _cve_cache_col().find_one(
            {"_id": cache_key, "cached_at": {"$gte": cutoff}}
        )
        if cached:
            return json.dumps({
                "tool": "cve_lookup", "product": product, "version": version, "cpe": cpe,
                "match_mode": cached.get("match_mode", match_mode),
                "cves": cached.get("cves", []), "status": "completed", "cached": True,
            })
    except Exception as e:  # noqa: BLE001 — la caché no debe tumbar la tool
        logger.warning("cve_lookup: caché no disponible: %s", e)

    # ── 2. NVD (CPE preferido, keyword como fallback) ─────────────────────────
    try:
        if parsed:
            vm = _build_virtual_match(parsed)
            cves = await asyncio.to_thread(_query_nvd_by_cpe, vm, max_results)
        else:
            keyword = f"{product} {version}".strip()
            cves = await asyncio.to_thread(_query_nvd, keyword, max_results) if keyword else []
        status = "completed" if cves else "completed_empty"
    except Exception as e:  # noqa: BLE001 — sin red / NVD caído → graceful
        logger.warning("cve_lookup: NVD inaccesible (mode=%s): %s", match_mode, e)
        return json.dumps({
            "tool": "cve_lookup", "product": product, "version": version, "cpe": cpe,
            "match_mode": match_mode, "cves": [], "status": "unavailable",
            "error": f"NVD inaccesible: {e}", "cached": False,
        })

    # ── 3. Guardar en caché ───────────────────────────────────────────────────
    try:
        await _cve_cache_col().replace_one(
            {"_id": cache_key},
            {"_id": cache_key, "product": product, "version": version, "cpe": cpe,
             "match_mode": match_mode, "cves": cves, "cached_at": utc_now()},
            upsert=True,
        )
    except Exception as e:  # noqa: BLE001
        logger.warning("cve_lookup: no se pudo cachear %r: %s", cache_key, e)

    logger.info("cve_lookup mode=%s key=%r → %d CVEs (status=%s)",
                match_mode, cache_key, len(cves), status)
    return json.dumps({
        "tool": "cve_lookup", "product": product, "version": version, "cpe": cpe,
        "match_mode": match_mode, "cves": cves, "status": status, "cached": False,
    })


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: attack_technique_lookup
# ═══════════════════════════════════════════════════════════════════════════════
# Dataset MITRE ATT&CK (Enterprise) curado — subconjunto relevante a pentest de
# red/web. Su propósito es VALIDAR los technique_id que propone el LLM (evita IDs
# alucinados, hallazgo A4) y permitir búsqueda por keyword. Ampliable: el dataset
# completo (STIX) se puede cargar a futuro sin cambiar la interfaz de la tool.

_ATTACK_TECHNIQUES: dict[str, dict] = {
    "T1595": {"name": "Active Scanning", "tactic": "Reconnaissance"},
    "T1592": {"name": "Gather Victim Host Information", "tactic": "Reconnaissance"},
    "T1046": {"name": "Network Service Discovery", "tactic": "Discovery"},
    "T1018": {"name": "Remote System Discovery", "tactic": "Discovery"},
    "T1083": {"name": "File and Directory Discovery", "tactic": "Discovery"},
    "T1190": {"name": "Exploit Public-Facing Application", "tactic": "Initial Access"},
    "T1133": {"name": "External Remote Services", "tactic": "Initial Access"},
    "T1078": {"name": "Valid Accounts", "tactic": "Initial Access"},
    "T1110": {"name": "Brute Force", "tactic": "Credential Access"},
    "T1212": {"name": "Exploitation for Credential Access", "tactic": "Credential Access"},
    "T1021": {"name": "Remote Services", "tactic": "Lateral Movement"},
    "T1210": {"name": "Exploitation of Remote Services", "tactic": "Lateral Movement"},
    "T1059": {"name": "Command and Scripting Interpreter", "tactic": "Execution"},
    "T1203": {"name": "Exploitation for Client Execution", "tactic": "Execution"},
    "T1505": {"name": "Server Software Component", "tactic": "Persistence"},
    "T1071": {"name": "Application Layer Protocol", "tactic": "Command and Control"},
    "T1499": {"name": "Endpoint Denial of Service", "tactic": "Impact"},
    "T1098": {"name": "Account Manipulation", "tactic": "Persistence"},
    "T1552": {"name": "Unsecured Credentials", "tactic": "Credential Access"},
    "T1040": {"name": "Network Sniffing", "tactic": "Credential Access"},
}


def _attack_lookup(query: str) -> dict:
    """Lógica pura (testeable) de attack_technique_lookup."""
    import re as _re

    q = (query or "").strip()
    q_upper = q.upper()

    # ── Validación de ID ──────────────────────────────────────────────────────
    if q_upper in _ATTACK_TECHNIQUES:
        t = _ATTACK_TECHNIQUES[q_upper]
        return {
            "query": query,
            "matches": [{"technique_id": q_upper, "name": t["name"], "tactic": t["tactic"]}],
            "status": "validated",
        }

    # Si parece un ID (T####) pero no está en el dataset → not_found explícito.
    if _re.fullmatch(r"T\d{4}(\.\d{3})?", q_upper):
        return {"query": query, "matches": [], "status": "not_found"}

    # ── Búsqueda por keyword ──────────────────────────────────────────────────
    ql = q.lower()
    matches = [
        {"technique_id": tid, "name": t["name"], "tactic": t["tactic"]}
        for tid, t in _ATTACK_TECHNIQUES.items()
        if ql and (ql in t["name"].lower() or ql in t["tactic"].lower())
    ]
    return {
        "query": query,
        "matches": matches,
        "status": "found" if matches else "not_found",
    }


@mcp.tool()
async def attack_technique_lookup(query: str, engagement_id: int = 0) -> str:
    """
    Valida o busca técnicas MITRE ATT&CK contra el dataset local. Usa esto para
    NO inventar technique_ids: si pasas un ID lo valida; si pasas keywords, busca.

    Args:
        query:         Un technique_id (ej "T1046") para validar, o keywords
                       (ej "service discovery") para buscar.
        engagement_id: ID del engagement (solo trazabilidad).

    Returns:
        JSON {query, matches:[{technique_id, name, tactic}], status}.
        status: "validated" (ID existe) | "found" (búsqueda con resultados) |
                "not_found" (ID inexistente o sin matches).
    """
    return json.dumps(_attack_lookup(query))


# ═══════════════════════════════════════════════════════════════════════════════
# Entrypoint
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logger.info("Analysis MCP Server iniciando (stdio transport)...")
    mcp.run(transport="stdio")
