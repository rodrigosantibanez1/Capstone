#!/usr/bin/env python3
"""
osint_server.py — OSINT MCP Server · ETH-MAS Sprint 2
======================================================
MCP Server que expone 3 tools de reconocimiento OSINT pasivo.

Tools registradas:
  dns_enum          → registros A/MX/NS/TXT via dnspython
  whois_lookup      → registro WHOIS via python-whois
  theharvester_run  → emails/hosts/IPs via theHarvester subprocess

Cada tool call ejecuta en orden:
  1. Scope check contra PostgreSQL (scope_targets del engagement)
  2. Registro AUTO-APPROVED en hitl_actions (risk_level LOW, pasivo)
  3. Ejecución de la herramienta real
  4. Retorno de JSON {data, raw_output, hitl_action_id, ...}

Transporte: stdio — FastAPI lanza este script como subprocess.
El proceso se mantiene vivo durante toda la sesión del agente.

Alternativa Gemini: ver docs/gemini_alternative.md
El MCP server es agnóstico al LLM cliente — tanto Claude como Gemini
(con bridge) pueden llamar estas mismas tools sin modificar este archivo.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from datetime import datetime
from typing import Optional

# ── Path setup: permite importar desde eth-mas-backend/ ──────────────────────
_BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

# ── Imports del backend ───────────────────────────────────────────────────────
from dotenv import load_dotenv
load_dotenv(os.path.join(_BACKEND_DIR, ".env"))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

import models
from services.scope_validator import is_target_in_scope
from utils import utc_now

# ── MCP SDK ───────────────────────────────────────────────────────────────────
from mcp.server.fastmcp import FastMCP

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [osint_server] %(levelname)s — %(message)s",
    stream=sys.stderr,   # stdout está reservado para el protocolo MCP
)
logger = logging.getLogger(__name__)

# ── DB connection (autónoma, no depende del engine de FastAPI) ────────────────
_DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:admin@localhost:5432/eth_mas_db")
_engine       = create_engine(_DATABASE_URL)
_SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=_engine)

def _get_db() -> Session:
    return _SessionLocal()

# ── MCP Server ────────────────────────────────────────────────────────────────
mcp = FastMCP(
    "eth-mas-osint",
    instructions=(
        "OSINT MCP Server del pipeline ETH-MAS. "
        "Todas las tools son pasivas (risk_level LOW) y se auto-aprueban. "
        "Siempre incluir engagement_id en cada llamada para el scope check."
    ),
)

AGENT_NAME  = "ReconAgent"
RISK_LEVEL  = "LOW"


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers internos
# ═══════════════════════════════════════════════════════════════════════════════

def _scope_check_and_register(
    target: str,
    engagement_id: int,
    tool: str,
    params: dict,
    db: Session,
) -> int:
    """
    Valida scope y registra HitlAction AUTO-APPROVED.
    Retorna el hitl_action_id creado.
    Lanza ValueError si el target está fuera de scope.
    """
    if not is_target_in_scope(target, engagement_id, db):
        raise ValueError(
            f"SCOPE_VIOLATION: '{target}' no está en el scope del engagement {engagement_id}. "
            f"Acción bloqueada."
        )

    action = models.HitlAction(
        engagement_id = engagement_id,
        agent         = AGENT_NAME,
        tool          = tool,
        risk_level    = RISK_LEVEL,
        params        = params,
        decision      = "AUTO-APPROVED",
        operator      = "Sistema",
        notes         = f"risk_level {RISK_LEVEL} — aprobación automática (pasivo OSINT)",
        requested_at  = utc_now(),
        decided_at    = utc_now(),
    )
    db.add(action)
    db.commit()
    db.refresh(action)
    logger.info("HITL AUTO-APPROVED: id=%d tool=%s target=%s", action.id, tool, target)
    return action.id


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: dns_enum
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def dns_enum(target: str, engagement_id: int, timeout: int = 30) -> str:
    """
    Enumera registros DNS del target: A, MX, NS, TXT.
    Herramienta pasiva — solo consultas DNS, sin contacto directo con el target.
    risk_level: LOW (auto-aprobado).

    Args:
        target:        IP o dominio a consultar.
        engagement_id: ID del engagement activo (para scope check).
        timeout:       Timeout total en segundos (default 30).

    Returns:
        JSON string con records DNS, raw_output y hitl_action_id.
    """
    db = _get_db()
    try:
        hitl_id = _scope_check_and_register(
            target, engagement_id, "dns_enum",
            {"target": target, "timeout": timeout}, db
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "dns_enum", "status": "blocked", "error": str(e)})
    finally:
        if db:
            db.close()

    logger.info("dns_enum → target=%s engagement=%d", target, engagement_id)

    import dns.resolver
    import dns.exception

    resolver = dns.resolver.Resolver()
    resolver.lifetime = timeout

    records: dict[str, list[str]] = {"A": [], "MX": [], "NS": [], "TXT": []}

    for rtype in ("A", "MX", "NS", "TXT"):
        try:
            answers = await asyncio.to_thread(resolver.resolve, target, rtype)
            records[rtype] = [str(r) for r in answers]
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
            records[rtype] = []
        except dns.exception.Timeout:
            records[rtype] = []
            logger.warning("dns_enum timeout en tipo %s para %s", rtype, target)
        except Exception as e:
            records[rtype] = []
            logger.warning("dns_enum error [%s] %s: %s", rtype, target, e)

    result = {
        "tool":           "dns_enum",
        "target":         target,
        "engagement_id":  engagement_id,
        "timestamp":      utc_now().isoformat(),
        "records":        records,
        "status":         "completed",
        "source":         "mcp",
        "hitl_action_id": hitl_id,
    }

    logger.info(
        "dns_enum completado: target=%s A=%s",
        target, records.get("A", [])
    )
    return json.dumps(result)


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: whois_lookup
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def whois_lookup(target: str, engagement_id: int) -> str:
    """
    Consulta WHOIS del target (dominio o IP).
    Para targets en red de laboratorio aislada retorna datos vacíos gracefully.
    risk_level: LOW (auto-aprobado).

    Args:
        target:        Dominio o IP a consultar.
        engagement_id: ID del engagement activo (para scope check).

    Returns:
        JSON string con datos WHOIS y hitl_action_id.
    """
    db = _get_db()
    try:
        hitl_id = _scope_check_and_register(
            target, engagement_id, "whois_lookup",
            {"target": target}, db
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "whois_lookup", "status": "blocked", "error": str(e)})
    finally:
        if db:
            db.close()

    logger.info("whois_lookup → target=%s engagement=%d", target, engagement_id)

    import whois as python_whois

    try:
        w = await asyncio.to_thread(python_whois.whois, target)

        def _safe(val) -> str:
            """Convierte valores WHOIS (que pueden ser listas o None) a string."""
            if val is None:
                return "N/A"
            if isinstance(val, list):
                return str(val[0]) if val else "N/A"
            return str(val)

        data = {
            "registrar":     _safe(w.registrar),
            "creation_date": _safe(w.creation_date),
            "expiry_date":   _safe(w.expiration_date),
            "org":           _safe(w.org),
            "country":       _safe(w.country),
            "name_servers":  [str(ns) for ns in w.name_servers] if w.name_servers else [],
            "status":        _safe(w.status),
        }
        status = "completed"

    except Exception as e:
        logger.info("whois_lookup sin datos para %s: %s", target, e)
        data = {
            "registrar":     "N/A — red de laboratorio aislada",
            "creation_date": "N/A",
            "expiry_date":   "N/A",
            "org":           "N/A",
            "country":       "N/A",
            "name_servers":  [],
            "status":        "N/A",
        }
        status = "completed_empty"

    result = {
        "tool":           "whois_lookup",
        "target":         target,
        "engagement_id":  engagement_id,
        "timestamp":      utc_now().isoformat(),
        "data":           data,
        "status":         status,
        "source":         "mcp",
        "hitl_action_id": hitl_id,
    }

    return json.dumps(result)


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: theharvester_run
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def theharvester_run(
    target: str,
    engagement_id: int,
    timeout: int = 60,
    sources: Optional[str] = "baidu,bing,certspotter,crtsh,dnsdumpster,hackertarget",
) -> str:
    """
    Ejecuta theHarvester para recolectar emails, hosts e IPs desde fuentes OSINT.
    Usa fuentes sin API key por defecto (apropiadas para lab sin internet real).
    Si theHarvester no está instalado, retorna resultado vacío gracefully.
    risk_level: LOW (auto-aprobado).

    Args:
        target:        Dominio objetivo (ej: "example.com"). IPs retornan vacío.
        engagement_id: ID del engagement activo (para scope check).
        timeout:       Timeout en segundos (default 60).
        sources:       Fuentes OSINT separadas por coma.

    Returns:
        JSON string con emails/hosts/IPs encontrados y hitl_action_id.
    """
    db = _get_db()
    try:
        hitl_id = _scope_check_and_register(
            target, engagement_id, "theharvester_run",
            {"target": target, "sources": sources, "timeout": timeout}, db
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "theharvester_run", "status": "blocked", "error": str(e)})
    finally:
        if db:
            db.close()

    logger.info(
        "theharvester_run → target=%s engagement=%d sources=%s",
        target, engagement_id, sources
    )

    cmd = [
        "theHarvester",
        "-d", target,
        "-b", sources or "baidu,bing",
        "-l", "100",
    ]

    raw_output = ""
    data: dict = {"emails": [], "hosts": [], "subdomains": [], "ips": []}
    status = "completed"

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout_bytes, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        raw_output = stdout_bytes.decode("utf-8", errors="replace")
        data = _parse_harvester_output(raw_output)

    except asyncio.TimeoutError:
        raw_output = f"theHarvester timeout después de {timeout}s"
        status = "timeout"
        logger.warning("theharvester_run timeout: target=%s", target)

    except FileNotFoundError:
        raw_output = "theHarvester no encontrado en PATH. Instalar: pip install theHarvester"
        status = "tool_not_found"
        logger.warning("theHarvester no instalado — retornando vacío gracefully")

    except Exception as e:
        raw_output = str(e)
        status = "error"
        logger.error("theharvester_run error: %s", e)

    result = {
        "tool":           "theharvester_run",
        "target":         target,
        "engagement_id":  engagement_id,
        "timestamp":      utc_now().isoformat(),
        "data":           data,
        "raw_output":     raw_output,
        "status":         status,
        "source":         "mcp",
        "hitl_action_id": hitl_id,
    }

    logger.info(
        "theharvester_run completado: target=%s emails=%d hosts=%d",
        target, len(data["emails"]), len(data["hosts"])
    )
    return json.dumps(result)


def _parse_harvester_output(raw: str) -> dict:
    """
    Parser básico del output de theHarvester.
    theHarvester no siempre produce output estructurado,
    por lo que se usan regex sobre el texto plano.
    """
    import re

    emails = list(set(re.findall(
        r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", raw
    )))
    ips = list(set(re.findall(
        r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b",
        raw
    )))
    # Hosts/subdominios: líneas que parecen FQDNs
    hosts = list(set(re.findall(
        r"\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b",
        raw
    )))

    return {
        "emails":    emails,
        "hosts":     hosts,
        "subdomains": hosts,
        "ips":       ips,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Entrypoint
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logger.info("OSINT MCP Server iniciando (stdio transport)...")
    mcp.run(transport="stdio")
