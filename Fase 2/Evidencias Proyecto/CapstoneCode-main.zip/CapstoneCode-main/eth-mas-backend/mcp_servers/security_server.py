#!/usr/bin/env python3
"""
security_server.py — Security MCP Server · ETH-MAS Sprint 2/3
==============================================================
MCP Server que expone tools de escaneo activo con scope check + HITL obligatorio.

Tools registradas:
  nmap_scan     → Port scan + service detection (risk_level MEDIUM/HIGH)
  nuclei_run    → Templates de vulnerabilidades (risk_level MEDIUM/HIGH)
  nikto_scan    → Análisis HTTP (risk_level MEDIUM)
  gobuster_run  → Dir/DNS bruteforce (risk_level MEDIUM)

Cada tool call ejecuta en orden:
  1. Scope check contra PostgreSQL
  2. Registro en hitl_actions con decision="PENDING" (MEDIUM/HIGH requieren aprobación)
  3. BLOQUEO: espera polling hasta que decision != "PENDING" (timeout configurable)
  4. Si rechazado → retorna status="rejected" + hitl_action_id
  5. Si aprobado → ejecuta la herramienta real
  6. Retorna JSON {findings, raw_output, hitl_action_id, ...}

Transporte: stdio — FastAPI/scan_agent lanza este script como subprocess.

Diferencia con osint_server.py:
  OSINT → risk_level LOW → AUTO-APPROVED (sin bloqueo)
  Security → risk_level MEDIUM/HIGH → PENDING → espera decisión humana
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
import sys
from datetime import datetime
from typing import Optional

# ── Path setup ────────────────────────────────────────────────────────────────
_BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

# ── Imports del backend ───────────────────────────────────────────────────────
from dotenv import load_dotenv
load_dotenv(os.path.join(_BACKEND_DIR, ".env"))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

import models
from services.scope_validator import is_target_in_scope
from utils import utc_now

# ── MCP SDK ───────────────────────────────────────────────────────────────────
from mcp.server.fastmcp import FastMCP

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [security_server] %(levelname)s — %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)

# ── DB connection ─────────────────────────────────────────────────────────────
_DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:admin@localhost:5432/eth_mas_db")
_engine       = create_engine(_DATABASE_URL)
_SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=_engine)

def _get_db() -> Session:
    return _SessionLocal()

# ── Config HITL ───────────────────────────────────────────────────────────────
HITL_POLL_INTERVAL_SECS: float = float(os.getenv("HITL_POLL_INTERVAL", "3"))
HITL_TIMEOUT_SECS: float       = float(os.getenv("HITL_TIMEOUT_SECS", "300"))  # 5 min

# Fix 3.1 — Ventana de dedup. Si llega un tool call idéntico a uno ya PENDING
# creado dentro de los últimos N segundos, reusamos su hitl_action_id en lugar
# de registrar un duplicado. Las "viejas" (>30s) las consideramos potencialmente
# zombi del reload anterior y dejamos que el operador las apruebe/expire por
# su cuenta — NO las reusamos porque podríamos quedar esperando una decisión
# para un subprocess que ya murió.
HITL_DEDUP_WINDOW_SECS: float = float(os.getenv("HITL_DEDUP_WINDOW_SECS", "30"))

# ── Timeouts de nikto (configurables vía env) ─────────────────────────────────
# Diagnóstico 2026-05-29: nikto 2.6.0 contra Metasploitable2 supera 330s en scan
# completo. En vez de matarlo por fuera (SIGKILL → salida truncada) lo acotamos
# por dentro con `-maxtime`: nikto se autodetiene y escribe un reporte CSV
# completo y válido. `NIKTO_TIMEOUT_SECS` es solo la red de seguridad del
# subprocess (debe ser > maxtime para no competir con la autodetención).
NIKTO_MAXTIME_SECS: int  = int(os.getenv("NIKTO_MAXTIME_SECS", "280"))
NIKTO_TIMEOUT_SECS: float = float(os.getenv("NIKTO_TIMEOUT_SECS", str(NIKTO_MAXTIME_SECS + 90)))

# ── MCP Server ────────────────────────────────────────────────────────────────
mcp = FastMCP(
    "eth-mas-security",
    instructions=(
        "Security MCP Server del pipeline ETH-MAS. "
        "Todas las tools son activas (risk_level MEDIUM o HIGH). "
        "Cada llamada REQUIERE aprobación HITL explícita del operador antes de ejecutar. "
        "El sistema bloqueará hasta recibir la decisión o cumplirse el timeout."
    ),
)

AGENT_NAME = "ScanAgent"

# ── Rutas a binarios y wordlist ───────────────────────────────────────────────
# Fix 5.3 (auditoría 2026-05-25) — resolución cross-platform.
# Antes el código apuntaba duro a *.exe (Windows). Dentro del contenedor backend
# (debian-slim) eso causaba FileNotFoundError en subprocess.run, que disparaba
# la cadena de bugs 5.1/5.2 en scan_agent (status='error' con hitl_action_id →
# pipeline en waiting_hitl con HitlAction ya APPROVED).
#
# Orden de búsqueda por binario:
#   1. PATH del sistema (instalado vía apt / Go / etc.)
#   2. backend_dir/<name>          (binario Linux bundleado)
#   3. backend_dir/<name>.exe      (legacy Windows local dev)
# Si nada matchea retornamos el nombre desnudo: subprocess.run lo intentará y
# fallará limpio, scan_agent lo logueará como tool_error y seguirá con la
# próxima tool sin wedgear el pipeline.

def _resolve_binary(name: str) -> str:
    in_path = shutil.which(name)
    if in_path:
        return in_path

    bundled_linux = os.path.join(_BACKEND_DIR, name)
    if os.path.isfile(bundled_linux) and os.access(bundled_linux, os.X_OK):
        return bundled_linux

    bundled_win = os.path.join(_BACKEND_DIR, f"{name}.exe")
    if os.path.isfile(bundled_win):
        return bundled_win

    return name


_GOBUSTER_EXE = _resolve_binary("gobuster")
_NUCLEI_EXE   = _resolve_binary("nuclei")
_NIKTO_BIN    = _resolve_binary("nikto")
_WORDLIST     = os.path.join(_BACKEND_DIR, "diccionario.txt")

logger.info(
    "Binarios resueltos: gobuster=%s nuclei=%s nikto=%s",
    _GOBUSTER_EXE, _NUCLEI_EXE, _NIKTO_BIN,
)


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers internos
# ═══════════════════════════════════════════════════════════════════════════════

def _params_signature(params: dict) -> str:
    """
    Firma determinística de los parámetros de un tool call. JSON canónico con
    keys ordenadas → la misma combinación lógica produce el mismo string
    aunque el dict de entrada esté en otro orden o tenga whitespace distinto.

    Fix 3.1 — usada por el dedup en _register_hitl_pending y por el índice
    único parcial definido en la migración e4f7b2a9c5d6 (Fix 3.2).
    """
    return json.dumps(params or {}, sort_keys=True, separators=(",", ":"))


def _find_recent_pending_duplicate(
    engagement_id: int,
    tool: str,
    params: dict,
    db: Session,
) -> Optional[int]:
    """
    Busca un HitlAction PENDING existente con la misma firma de params
    creado dentro de la ventana HITL_DEDUP_WINDOW_SECS. Retorna su id si
    encuentra match, None si no.

    No usa func.md5() en SQL — trae los pocos candidatos del rango temporal
    (típicamente 0-1) y compara firmas en Python. Más simple y portable que
    construir la expresión funcional en el WHERE.
    """
    from datetime import timedelta

    cutoff = utc_now() - timedelta(seconds=HITL_DEDUP_WINDOW_SECS)
    candidates = (
        db.query(models.HitlAction)
        .filter(
            models.HitlAction.engagement_id == engagement_id,
            models.HitlAction.agent == AGENT_NAME,
            models.HitlAction.tool == tool,
            models.HitlAction.decision == "PENDING",
            models.HitlAction.requested_at >= cutoff,
        )
        .order_by(models.HitlAction.id.desc())
        .limit(20)   # red de seguridad — en la práctica devuelve <=2
        .all()
    )

    target_sig = _params_signature(params)
    for c in candidates:
        if _params_signature(c.params or {}) == target_sig:
            return c.id

    return None


def _register_hitl_pending(
    target: str,
    engagement_id: int,
    tool: str,
    risk_level: str,
    params: dict,
    db: Session,
) -> int:
    """
    Valida scope y registra HitlAction con status PENDING. Si ya existe un
    HitlAction PENDING con los mismos (engagement_id, agent, tool, params)
    dentro de HITL_DEDUP_WINDOW_SECS, REUSA su id (Fix 3.1 — defensa contra
    duplicados cross-process: dos subprocess MCP del mismo reload no
    bombardean la cola HITL con la misma request).

    Retorna el hitl_action_id (nuevo o reusado).
    Lanza ValueError si el target está fuera de scope.
    """
    # ── 1. Scope check ───────────────────────────────────────────────────────
    if not is_target_in_scope(target, engagement_id, db):
        raise ValueError(
            f"SCOPE_VIOLATION: '{target}' no está en el scope del engagement {engagement_id}."
        )

    # ── 2. Dedup pre-INSERT: tal vez ya existe ───────────────────────────────
    dup_id = _find_recent_pending_duplicate(engagement_id, tool, params, db)
    if dup_id is not None:
        logger.info(
            "HITL DEDUP (reuso): id=%d tool=%s target=%s risk=%s — "
            "match en ventana %.0fs",
            dup_id, tool, target, risk_level, HITL_DEDUP_WINDOW_SECS,
        )
        return dup_id

    # ── 3. Crear nuevo HitlAction ────────────────────────────────────────────
    # IntegrityError handling: cuando la migración del índice único parcial
    # (e4f7b2a9c5d6, Fix 3.2) está aplicada, dos procesos compitiendo por
    # crear el mismo PENDING a la vez van a chocar contra UNIQUE INDEX. El
    # perdedor recibe IntegrityError, hace rollback y vuelve a consultar el
    # ganador para reusar su id.
    from sqlalchemy.exc import IntegrityError

    action = models.HitlAction(
        engagement_id = engagement_id,
        agent         = AGENT_NAME,
        tool          = tool,
        risk_level    = risk_level,
        params        = params,
        decision      = "PENDING",
        operator      = None,
        notes         = None,
        requested_at  = utc_now(),
        decided_at    = None,
    )
    db.add(action)
    try:
        db.commit()
    except IntegrityError as e:
        db.rollback()
        # Esperamos uq_hitl_pending_dedup (Fix 3.2). Si es otra cosa, re-raise.
        if "uq_hitl_pending_dedup" not in str(e.orig).lower() and \
           "uq_hitl_pending_dedup" not in str(e).lower():
            raise

        winner_id = _find_recent_pending_duplicate(
            engagement_id, tool, params, db,
        )
        if winner_id is not None:
            logger.warning(
                "HITL DEDUP (race resuelto): id=%d tool=%s target=%s — "
                "otro proceso ganó la creación, reusamos su id",
                winner_id, tool, target,
            )
            return winner_id
        # Caso bizarro: el índice rechazó nuestro INSERT pero la búsqueda no
        # encuentra el ganador (¿lo aprobaron en el medio?). Re-raise para no
        # ocultar el problema.
        raise

    db.refresh(action)
    logger.info(
        "HITL PENDING: id=%d tool=%s target=%s risk=%s",
        action.id, tool, target, risk_level,
    )
    return action.id


async def _wait_for_hitl_decision(hitl_action_id: int) -> str:
    """
    Polling de la decisión HITL hasta que sea APPROVED o REJECTED.
    Retorna la decisión final.
    Lanza TimeoutError si se supera HITL_TIMEOUT_SECS.
    """
    elapsed = 0.0
    while elapsed < HITL_TIMEOUT_SECS:
        db = _get_db()
        try:
            action = db.query(models.HitlAction).filter(
                models.HitlAction.id == hitl_action_id
            ).first()
            if action and action.decision not in ("PENDING",):
                logger.info(
                    "HITL decision recibida: id=%d decision=%s",
                    hitl_action_id, action.decision
                )
                return action.decision
        finally:
            db.close()

        await asyncio.sleep(HITL_POLL_INTERVAL_SECS)
        elapsed += HITL_POLL_INTERVAL_SECS

    raise TimeoutError(
        f"HITL timeout después de {HITL_TIMEOUT_SECS}s. "
        f"El operador no respondió para hitl_action_id={hitl_action_id}."
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Sonda soft-200 (catch-all) — fix 2026-06-11
# ═══════════════════════════════════════════════════════════════════════════════
# Servidores que sirven una SPA (nginx try_files → index.html) o que redirigen
# todo a un login devuelven 200 a CUALQUIER ruta. Eso hace que nikto/gobuster
# reporten como "encontrado" cada path de su diccionario (falsos positivos en
# cascada: .bash_history, JAMonAdmin.jsp, etc — engagement #24).
#
# Antes de confiar en hallazgos basados en "200 = existe", pedimos UNA ruta
# aleatoria inexistente. Si responde 200, el host es catch-all → el normalizador
# degrada esos findings a info + confidence=low.
#
# Tráfico activo: es UNA request benigna al mismo target del scan, que YA pasó
# scope_validator + HITL (la sonda corre DESPUÉS de la aprobación del nikto/
# gobuster padre, mismo target/puerto, riesgo estrictamente menor). Re-validamos
# scope explícitamente por las dudas; NO abre un segundo HITL para no
# doble-promptear al operador en cada scan web.

SOFT200_TIMEOUT_SECS: float = float(os.getenv("SOFT200_TIMEOUT_SECS", "8"))


async def _soft200_probe(target: str, port: int, engagement_id: int) -> bool:
    """
    Devuelve True si el servidor responde 200 a una ruta aleatoria inexistente
    (catch-all). False ante 404/otros/errores de red. No lanza nunca.
    """
    import random
    import string
    import urllib.error
    import urllib.request

    rand = "".join(random.choices(string.ascii_lowercase + string.digits, k=24))
    scheme = "https" if int(port) == 443 else "http"
    probe_url = f"{scheme}://{target}:{port}/eth-mas-probe-{rand}"

    # Re-check de scope explícito (defensa en profundidad; el padre ya validó).
    db = _get_db()
    try:
        if not is_target_in_scope(probe_url, engagement_id, db):
            logger.warning("soft200_probe: %s fuera de scope, se omite", probe_url)
            return False
    finally:
        db.close()

    def _do_probe() -> bool:
        req = urllib.request.Request(
            probe_url, method="GET",
            headers={"User-Agent": "ETH-MAS/soft200-probe"},
        )
        try:
            with urllib.request.urlopen(req, timeout=SOFT200_TIMEOUT_SECS) as resp:
                # 200 a una ruta basura → catch-all.
                return getattr(resp, "status", resp.getcode()) == 200
        except urllib.error.HTTPError as e:
            # 404/403/... = el server distingue rutas → NO catch-all.
            return e.code == 200
        except Exception:  # noqa: BLE001 — red caída / TLS / timeout → no concluyente
            return False

    try:
        catchall = await asyncio.to_thread(_do_probe)
    except Exception:  # noqa: BLE001
        catchall = False

    logger.info("soft200_probe %s → catchall=%s", probe_url, catchall)
    return catchall


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: nmap_scan
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def nmap_scan(
    target: str,
    engagement_id: int,
    ports: str = "1-1024",
    timing: int = 3,
    scripts: Optional[str] = None,
) -> str:
    """
    Ejecuta nmap sobre el target con detección de versiones.
    Requiere aprobación HITL antes de ejecutar (risk_level MEDIUM/HIGH).
    Escaneos con timing >= 4 o scripts NSE se registran como risk_level HIGH.

    Args:
        target:        IP o CIDR a escanear. Debe estar en el scope del engagement.
        engagement_id: ID del engagement activo (para scope check y HITL).
        ports:         Rango de puertos (default "1-1024"). Usar "1-65535" para full scan.
        timing:        Timing template nmap T0-T5 (default T3=normal).
        scripts:       Scripts NSE separados por coma (ej: "vuln,default"). None = sin scripts.

    Returns:
        JSON string con findings normalizados, raw_output y hitl_action_id.
    """
    # Determinar risk_level según intensidad
    risk_level = "HIGH" if (timing >= 4 or scripts) else "MEDIUM"

    db = _get_db()
    try:
        hitl_id = _register_hitl_pending(
            target, engagement_id, "nmap_scan", risk_level,
            {"target": target, "ports": ports, "timing": timing, "scripts": scripts},
            db,
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "nmap_scan", "status": "blocked", "error": str(e)})
    finally:
        db.close()

    logger.info(
        "nmap_scan esperando HITL: id=%d target=%s risk=%s",
        hitl_id, target, risk_level
    )

    # ── Esperar decisión HITL ─────────────────────────────────────────────────
    try:
        decision = await _wait_for_hitl_decision(hitl_id)
    except TimeoutError as e:
        return json.dumps({
            "tool": "nmap_scan", "status": "hitl_timeout",
            "error": str(e), "hitl_action_id": hitl_id,
        })

    if decision.upper() != "APPROVED":
        logger.info("nmap_scan RECHAZADO por operador: hitl_id=%d", hitl_id)
        return json.dumps({
            "tool": "nmap_scan", "status": "rejected",
            "error": f"Operador rechazó la acción (decision={decision})",
            "hitl_action_id": hitl_id,
        })

    # ── Ejecutar nmap ─────────────────────────────────────────────────────────
    logger.info("nmap_scan APROBADO, ejecutando: target=%s ports=%s", target, ports)

    from services.nmap_service import run_nmap_scan, parse_nmap_xml
    from services.findings_service import normalize_nmap_findings

    try:
        xml_output = await asyncio.to_thread(
            run_nmap_scan, target, ports=ports, timing=timing, scripts=scripts
        )
        raw_findings = parse_nmap_xml(xml_output)
        normalized = normalize_nmap_findings(engagement_id, raw_findings)

        result = {
            "tool":           "nmap_scan",
            "target":         target,
            "engagement_id":  engagement_id,
            "timestamp":      utc_now().isoformat(),
            "findings":       normalized,
            "findings_count": len(normalized),
            "raw_output":     xml_output[:2000],  # truncar para el contexto del LLM
            "status":         "completed",
            "risk_level":     risk_level,
            "hitl_action_id": hitl_id,
        }

    except Exception as e:
        logger.error("nmap_scan error: %s", e)
        result = {
            "tool":           "nmap_scan",
            "target":         target,
            "engagement_id":  engagement_id,
            "timestamp":      utc_now().isoformat(),
            "findings":       [],
            "findings_count": 0,
            "raw_output":     str(e),
            "status":         "error",
            "hitl_action_id": hitl_id,
        }

    logger.info(
        "nmap_scan completado: target=%s findings=%d",
        target, result["findings_count"]
    )
    return json.dumps(result)


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: nuclei_run
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def nuclei_run(
    target: str,
    engagement_id: int,
    severity: str = "medium",
    templates: Optional[str] = None,
) -> str:
    """
    Ejecuta nuclei con templates de vulnerabilidades sobre el target.
    Requiere aprobación HITL antes de ejecutar.

    Args:
        target:        URL o IP objetivo.
        engagement_id: ID del engagement.
        severity:      Severidad mínima de templates ("low","medium","high","critical").
        templates:     Tags de templates separados por coma. None = "cve,exposed-panels,misconfig".

    Returns:
        JSON con findings normalizados (JSONL de nuclei), raw_output y hitl_action_id.
    """
    risk_level = "HIGH" if severity in ("high", "critical") else "MEDIUM"

    db = _get_db()
    try:
        hitl_id = _register_hitl_pending(
            target, engagement_id, "nuclei_run", risk_level,
            {"target": target, "severity": severity, "templates": templates},
            db,
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "nuclei_run", "status": "blocked", "error": str(e)})
    finally:
        db.close()

    try:
        decision = await _wait_for_hitl_decision(hitl_id)
    except TimeoutError as e:
        return json.dumps({"tool": "nuclei_run", "status": "hitl_timeout", "error": str(e), "hitl_action_id": hitl_id})

    if decision.upper() != "APPROVED":
        return json.dumps({"tool": "nuclei_run", "status": "rejected", "hitl_action_id": hitl_id})

    # ── Ejecutar nuclei ───────────────────────────────────────────────────────
    url_target = target if target.startswith("http") else f"http://{target}"
    # Default acotado a `cve` para evitar el timeout de 1606 templates en 180s.
    # El operador puede pedir tags más amplios pasando `templates="cve,misconfig"`
    # y el wrapper subirá el budget hasta 600s automáticamente.
    tags = templates or "cve"
    # Budget escalado por amplitud del tag: cve solo es típico ~120s para 1 host
    # en LAN; cve+misconfig+exposed-panels puede llegar a 300s.
    timeout_secs = 600 if "," in tags else 240

    logger.info(
        "nuclei_run APROBADO, ejecutando: target=%s tags=%s timeout=%ds",
        url_target, tags, timeout_secs,
    )

    cmd = [
        _NUCLEI_EXE,
        "-u", url_target,
        "-tags", tags,
        "-severity", severity,
        "-silent",
        "-no-color",
        "-j",                     # JSONL output — una línea por hallazgo
        "-disable-update-check",  # fix lab-fixes H-6: no network call al boot
        "-rate-limit", "150",     # acotar carga a 150 req/s para LAN sin ahogar nuclei
    ]

    try:
        proc = await asyncio.to_thread(
            subprocess.run, cmd,
            capture_output=True, text=True, timeout=timeout_secs,
        )
        raw_output = proc.stdout or ""

        from services.findings_service import normalize_nuclei_findings
        normalized = normalize_nuclei_findings(engagement_id, url_target, raw_output)

        result = {
            "tool":           "nuclei_run",
            "target":         target,
            "engagement_id":  engagement_id,
            "timestamp":      utc_now().isoformat(),
            "findings":       normalized,
            "findings_count": len(normalized),
            "raw_output":     raw_output[:2000],
            "status":         "completed",
            "risk_level":     risk_level,
            "hitl_action_id": hitl_id,
        }
    except subprocess.TimeoutExpired:
        result = {
            "tool": "nuclei_run", "status": "error",
            "error": f"Nuclei tardó demasiado y fue cancelado (timeout {timeout_secs}s)",
            "hitl_action_id": hitl_id,
        }
    except FileNotFoundError:
        result = {
            "tool": "nuclei_run", "status": "error",
            "error": f"nuclei.exe no encontrado en {_NUCLEI_EXE}",
            "hitl_action_id": hitl_id,
        }
    except Exception as e:
        result = {
            "tool": "nuclei_run", "status": "error",
            "error": str(e), "hitl_action_id": hitl_id,
        }

    logger.info(
        "nuclei_run completado: target=%s findings=%d",
        target, result.get("findings_count", 0),
    )
    return json.dumps(result)


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: nikto_scan
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def nikto_scan(target: str, engagement_id: int, port: int = 80) -> str:
    """
    Ejecuta nikto para análisis de servidor HTTP (misconfigs, headers, archivos
    por defecto, versiones). Requiere aprobación HITL (risk_level MEDIUM).

    Robustez (diagnóstico 2026-05-29 — reporte operador):
      - Usa `-Format csv`, NO `-Format json`: el reporter JSON de nikto 2.6.0
        crashea al serializar (`nikto_report_json.plugin` → archivo de 0 bytes)
        aunque encuentre hallazgos. El CSV es estructurado y estable (Mejora 1).
      - `-maxtime` acota nikto por dentro: se autodetiene escribiendo un CSV
        completo, en vez de morir por SIGKILL del subprocess (Mejora 2). El
        timeout del subprocess es solo red de seguridad (NIKTO_TIMEOUT_SECS).
      - Maneja explícitamente archivo vacío / reporter caído / timeout (Mejora 3)
        vía `status` (completed / completed_empty / timeout / error) + `notes`.
      - Preserva raw_output como evidencia en toda rama; si no hay findings
        parseables pero sí output, emite un finding `info` con el raw (Mejora 4).

    Args:
        target:        IP o hostname del servidor web. Debe estar en scope.
        engagement_id: ID del engagement.
        port:          Puerto HTTP a analizar (default 80).

    Returns:
        JSON con findings normalizados, raw_output y hitl_action_id.
    """
    db = _get_db()
    try:
        hitl_id = _register_hitl_pending(
            target, engagement_id, "nikto_scan", "MEDIUM",
            {"target": target, "port": port},
            db,
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "nikto_scan", "status": "blocked", "error": str(e)})
    finally:
        db.close()

    try:
        decision = await _wait_for_hitl_decision(hitl_id)
    except TimeoutError as e:
        return json.dumps({"tool": "nikto_scan", "status": "hitl_timeout", "error": str(e), "hitl_action_id": hitl_id})

    if decision.upper() != "APPROVED":
        return json.dumps({"tool": "nikto_scan", "status": "rejected", "hitl_action_id": hitl_id})

    # ── Ejecutar nikto ────────────────────────────────────────────────────────
    import os as _os, tempfile

    logger.info(
        "nikto_scan APROBADO, ejecutando: target=%s port=%d maxtime=%ds safety_timeout=%.0fs",
        target, port, NIKTO_MAXTIME_SECS, NIKTO_TIMEOUT_SECS,
    )

    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w") as _f:
        tmpfile = _f.name

    cmd = [
        _NIKTO_BIN,
        "-h", target,
        "-p", str(port),
        "-Format", "csv",                  # json crashea en nikto 2.6.0 (diag 2026-05-29)
        "-output", tmpfile,
        "-nointeractive",
        "-maxtime", str(NIKTO_MAXTIME_SECS),
    ]

    def _read_and_cleanup() -> str:
        """Lee el CSV de salida (lo que haya quedado) y borra el tmpfile. Nunca lanza."""
        content = ""
        try:
            with open(tmpfile, "r", encoding="utf-8", errors="replace") as _fh:
                content = _fh.read()
        except OSError:
            content = ""
        finally:
            try:
                _os.unlink(tmpfile)
            except OSError:
                pass
        return content

    from services.findings_service import normalize_nikto_findings

    raw_output = ""
    status = "completed"
    error: Optional[str] = None
    notes: list[str] = []

    try:
        proc = await asyncio.to_thread(
            subprocess.run, cmd,
            capture_output=True, text=True, timeout=NIKTO_TIMEOUT_SECS,
        )
        raw_output = _read_and_cleanup()
        if not raw_output.strip():
            # Mejora 3: nikto corrió pero no dejó salida estructurada.
            status = "completed_empty"
            notes.append(
                "nikto no escribió salida CSV (reporter caído o sin hallazgos). "
                "stderr: " + (proc.stderr or "")[:200]
            )
    except subprocess.TimeoutExpired:
        # Red de seguridad: nikto debería haberse autodetenido con -maxtime mucho
        # antes. Si llegamos aquí rescatamos lo parcial en disco (Mejora 4).
        raw_output = _read_and_cleanup()
        status = "timeout"
        error = f"Nikto excedió el timeout de seguridad ({NIKTO_TIMEOUT_SECS:.0f}s)"
        notes.append("Timeout duro del subprocess; se preservó la evidencia parcial en disco.")
    except FileNotFoundError:
        try:
            _os.unlink(tmpfile)
        except OSError:
            pass
        return json.dumps({
            "tool": "nikto_scan", "status": "error",
            "error": "nikto no encontrado en PATH. Instalar con: sudo apt install nikto",
            "raw_output": "",
            "hitl_action_id": hitl_id,
        })
    except Exception as e:  # noqa: BLE001 — degradación controlada
        raw_output = _read_and_cleanup()
        status = "error"
        error = str(e)

    # Sonda soft-200: ¿el server responde 200 a toda ruta? (fix 2026-06-11).
    # Corre bajo la aprobación HITL del nikto padre (mismo target/puerto).
    catchall = await _soft200_probe(target, port, engagement_id)
    if catchall:
        notes.append(
            "Catch-all detectado (200 a ruta aleatoria): hallazgos basados en "
            "existencia degradados a info/low_confidence."
        )

    # Normalización (CSV en operación normal; el normalizer también acepta JSON legacy).
    try:
        normalized = normalize_nikto_findings(engagement_id, target, raw_output, catchall=catchall)
    except Exception as e:  # noqa: BLE001
        logger.error("nikto_scan: fallo normalizando salida: %s", e)
        normalized = []
        notes.append(f"Error de normalización: {e}")

    # Mejora 4: si no hubo findings parseables pero sí evidencia cruda, no la
    # perdemos — la persistimos como un finding info.
    if not normalized and raw_output.strip():
        notes.append("Sin findings estructurados; evidencia cruda preservada como finding info.")
        normalized = [{
            "engagement_id": engagement_id,
            "phase": "scan",
            "tool": "nikto",
            "target": target,
            "title": "[Nikto] escaneo ejecutado — evidencia cruda preservada (sin findings parseables)",
            "severity": "info",
            "status": "open",
            "confidence": "low" if catchall else "high",
            "evidence": {
                "nikto_id": "",
                "method": "GET",
                "url": "/",
                "port": port,
                "catchall": catchall,
                "note": "raw_output preservado por fallback de normalización (Mejora 4)",
            },
            "mitre_technique": "T1190",
            "cve_ids": [],
            "cvss_score": None,
            "cvss_source": None,
            "discovered_at": utc_now().isoformat(),
            "raw_output": raw_output[:2000],
        }]

    result: dict = {
        "tool":           "nikto_scan",
        "target":         target,
        "engagement_id":  engagement_id,
        "timestamp":      utc_now().isoformat(),
        "port":           port,
        "findings":       normalized,
        "findings_count": len(normalized),
        "raw_output":     raw_output[:2000],
        "status":         status,
        "risk_level":     "MEDIUM",
        "hitl_action_id": hitl_id,
    }
    if notes:
        result["notes"] = " ".join(notes)
    if error:
        result["error"] = error

    logger.info(
        "nikto_scan completado: target=%s port=%d status=%s findings=%d",
        target, port, status, result["findings_count"],
    )
    return json.dumps(result)


# ═══════════════════════════════════════════════════════════════════════════════
# Tool: gobuster_run
# ═══════════════════════════════════════════════════════════════════════════════

@mcp.tool()
async def gobuster_run(
    target: str,
    engagement_id: int,
    mode: str = "dir",
) -> str:
    """
    Ejecuta gobuster en modo dir (descubrimiento de rutas HTTP) o dns (brute-force
    de subdominios). Usa el wordlist bundleado en el backend (diccionario.txt).
    Requiere aprobación HITL (risk_level MEDIUM).

    Args:
        target:        URL base (mode=dir) o dominio (mode=dns).
        engagement_id: ID del engagement.
        mode:          "dir" para rutas HTTP, "dns" para subdominios.

    Returns:
        JSON con rutas/subdominios encontrados, findings normalizados y hitl_action_id.
    """
    db = _get_db()
    try:
        hitl_id = _register_hitl_pending(
            target, engagement_id, "gobuster_run", "MEDIUM",
            {"target": target, "mode": mode, "wordlist": _WORDLIST},
            db,
        )
    except ValueError as e:
        db.close()
        return json.dumps({"tool": "gobuster_run", "status": "blocked", "error": str(e)})
    finally:
        db.close()

    try:
        decision = await _wait_for_hitl_decision(hitl_id)
    except TimeoutError as e:
        return json.dumps({"tool": "gobuster_run", "status": "hitl_timeout", "error": str(e), "hitl_action_id": hitl_id})

    if decision.upper() != "APPROVED":
        return json.dumps({"tool": "gobuster_run", "status": "rejected", "hitl_action_id": hitl_id})

    # ── Ejecutar gobuster ─────────────────────────────────────────────────────
    url_target = target if target.startswith("http") else f"http://{target}"

    if mode == "dir":
        scan_target = url_target
        cmd = [
            _GOBUSTER_EXE, "dir",
            "-u", url_target,
            "-w", _WORDLIST,
            "-t", "10",
            "--no-color",
            "-q",
        ]
    else:  # dns
        scan_target = target
        cmd = [
            _GOBUSTER_EXE, "dns",
            "-d", target,
            "-w", _WORDLIST,
            "-t", "10",
            "--no-color",
            "-q",
        ]

    logger.info("gobuster_run APROBADO, ejecutando: mode=%s target=%s", mode, scan_target)

    try:
        proc = await asyncio.to_thread(
            subprocess.run, cmd,
            capture_output=True, text=True, timeout=120,
        )
        raw_output = proc.stdout or ""

        # Sonda soft-200 solo en modo dir (rutas HTTP). En dns no aplica.
        catchall = False
        if mode == "dir":
            from urllib.parse import urlparse as _urlparse
            _p = _urlparse(url_target)
            _host = _p.hostname or target
            _port = _p.port or (443 if _p.scheme == "https" else 80)
            catchall = await _soft200_probe(_host, _port, engagement_id)

        from services.findings_service import normalize_gobuster_findings
        normalized = normalize_gobuster_findings(
            engagement_id, scan_target, raw_output, mode, catchall=catchall,
        )

        result = {
            "tool":           "gobuster_run",
            "target":         target,
            "engagement_id":  engagement_id,
            "timestamp":      utc_now().isoformat(),
            "mode":           mode,
            "findings":       normalized,
            "findings_count": len(normalized),
            "raw_output":     raw_output[:2000],
            "status":         "completed",
            "risk_level":     "MEDIUM",
            "hitl_action_id": hitl_id,
        }
    except subprocess.TimeoutExpired:
        result = {
            "tool": "gobuster_run", "status": "error",
            "error": "Gobuster tardó demasiado y fue cancelado (timeout 120s)",
            "hitl_action_id": hitl_id,
        }
    except FileNotFoundError:
        result = {
            "tool": "gobuster_run", "status": "error",
            "error": f"gobuster.exe no encontrado en {_GOBUSTER_EXE}",
            "hitl_action_id": hitl_id,
        }
    except Exception as e:
        result = {
            "tool": "gobuster_run", "status": "error",
            "error": str(e), "hitl_action_id": hitl_id,
        }

    logger.info(
        "gobuster_run completado: mode=%s target=%s findings=%d",
        mode, target, result.get("findings_count", 0),
    )
    return json.dumps(result)


# ═══════════════════════════════════════════════════════════════════════════════
# Entrypoint
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logger.info("Security MCP Server iniciando (stdio transport)...")
    mcp.run(transport="stdio")
