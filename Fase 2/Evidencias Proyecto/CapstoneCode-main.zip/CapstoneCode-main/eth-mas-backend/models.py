from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Enum, JSON, Text
from sqlalchemy.orm import relationship
import enum

from database import Base
from utils import utc_now


# ── Enums ────────────────────────────────────────────────────────────────────

class TargetType(enum.Enum):
    IP     = "ip"
    CIDR   = "cidr"
    DOMAIN = "domain"


class EngagementStatus(enum.Enum):
    """Estados posibles de un engagement (§4.3 CLAUDE.md)."""
    PENDING   = "pending"    # Creado, sin iniciar pipeline
    RUNNING   = "running"    # Pipeline activo
    PAUSED    = "paused"     # Pausado (fuera de ventana ROE, etc.)
    COMPLETED = "completed"  # Pipeline finalizado con éxito
    ABORTED   = "aborted"    # Detenido manualmente por el operador


# Transiciones válidas — evita saltos de estado ilegales
VALID_TRANSITIONS: dict = {
    EngagementStatus.PENDING:   [EngagementStatus.RUNNING, EngagementStatus.ABORTED],
    EngagementStatus.RUNNING:   [EngagementStatus.PAUSED, EngagementStatus.COMPLETED, EngagementStatus.ABORTED],
    EngagementStatus.PAUSED:    [EngagementStatus.RUNNING, EngagementStatus.ABORTED],
    EngagementStatus.COMPLETED: [],   # estado terminal
    EngagementStatus.ABORTED:   [],   # estado terminal
}


# ── Modelos ───────────────────────────────────────────────────────────────────

class Engagement(Base):
    __tablename__ = "engagements"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String, nullable=False, default="Nuevo Análisis")
    description = Column(Text, nullable=True)
    client_name = Column(String, nullable=True)

    # Estado del pipeline — HU-03
    status      = Column(
        Enum(EngagementStatus, name="engagementstatus"),
        nullable=False,
        default=EngagementStatus.PENDING,
    )

    # Rules of Engagement como JSON (schema §4.5 CLAUDE.md)
    roe         = Column(JSON, nullable=True)

    # Tácticas ATT&CK autorizadas — ej. ["TA0043", "TA0001", "TA0007"]
    att_tactics = Column(JSON, nullable=True)

    created_at  = Column(DateTime, default=utc_now)
    updated_at  = Column(DateTime, default=utc_now, onupdate=utc_now)

    # Relaciones
    scopes       = relationship("ScopeTarget", back_populates="engagement", cascade="all, delete-orphan")
    hitl_actions = relationship("HitlAction",  back_populates="engagement", cascade="all, delete-orphan")


class ScopeTarget(Base):
    __tablename__ = "scope_targets"

    id            = Column(Integer, primary_key=True, index=True)
    engagement_id = Column(Integer, ForeignKey("engagements.id"), nullable=False)
    target_value  = Column(String, nullable=False)
    target_type   = Column(Enum(TargetType, name="targettype"), nullable=False)
    created_at    = Column(DateTime, default=utc_now)

    engagement = relationship("Engagement", back_populates="scopes")


class HitlAction(Base):
    """Registro inmutable de cada decisión HITL (HU-09 y HU-10)."""
    __tablename__ = "hitl_actions"

    id            = Column(Integer, primary_key=True, index=True)
    engagement_id = Column(Integer, ForeignKey("engagements.id"), nullable=False)

    agent         = Column(String, nullable=False)   # ReconAgent, ScanAgent…
    tool          = Column(String, nullable=False)   # dns_enum, nmap_scan…
    risk_level    = Column(String, nullable=False)   # LOW, MEDIUM, HIGH, CRITICAL
    params        = Column(JSON, nullable=True)      # parámetros exactos del tool call

    decision      = Column(String, nullable=True)    # APPROVED | REJECTED | AUTO-APPROVED
    operator      = Column(String, nullable=True)    # admin@eth-mas.cl o "Sistema"
    notes         = Column(Text, nullable=True)      # notas del operador

    requested_at  = Column(DateTime, default=utc_now)
    decided_at    = Column(DateTime, nullable=True)

    engagement = relationship("Engagement", back_populates="hitl_actions")
