"""
mongo_schemas.py — Schemas Pydantic para colecciones MongoDB (Sprint 2)
=======================================================================
Define la forma de cada documento que se persiste en MongoDB.
Pydantic v2 valida antes de insertar; motor serializa con model_dump().

Colecciones:
  SurfaceMapDoc  → surface_map     (ReconAgent, HU-05)
  FindingDoc     → findings        (ScanAgent,  HU-07)
  AgentRunDoc    → agent_runs      (cada agente, trazabilidad individual)
  PipelineRunDoc → pipeline_runs   (Controller, orquestación end-to-end)
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field

from utils import utc_now


# ── SurfaceMapDoc ─────────────────────────────────────────────────────────────

class SurfaceMapDoc(BaseModel):
    """
    Documento consolidado de la fase de reconocimiento.
    Un documento por engagement (upsert).
    """
    engagement_id:      int
    scope_original:     list[str]           # targets definidos por el operador

    # Resultados OSINT consolidados
    emails_osint:       list[str]   = []    # emails encontrados por theHarvester
    hosts_discovered:   list[str]   = []    # hosts/IPs descubiertos (union de tools)
    new_vs_scope:       list[str]   = []    # hosts fuera del scope original (interesante)

    # Datos crudos por target (para trazabilidad)
    dns_records:        dict        = {}    # {target: {A:[], MX:[], NS:[], TXT:[]}}
    whois_data:         dict        = {}    # {target: {registrar, org, ...}}
    harvester_data:     dict        = {}    # {target: {emails:[], hosts:[], ips:[]}}

    # Metadata
    generated_at:       datetime    = Field(default_factory=utc_now)
    agent_run_id:       Optional[str] = None   # _id del AgentRunDoc correspondiente
    model_used:         Optional[str] = None   # ej: "claude-haiku-4-5-20251001"


# ── FindingDoc ────────────────────────────────────────────────────────────────

class FindingDoc(BaseModel):
    """
    Hallazgo individual normalizado de ScanAgent.
    Un documento por hallazgo (puerto, vulnerabilidad, path, etc.).
    """
    engagement_id:      int
    tool:               str             # nmap_scan | nuclei_run | nikto_scan | gobuster_run
    target:             str             # IP o dominio escaneado

    # Contenido del hallazgo
    raw_output:         str             # salida cruda de la herramienta (criterio M2)
    summary:            str             # descripción legible del hallazgo

    # Clasificación de riesgo
    severity:           str             # critical | high | medium | low | info
    cvss_score:         Optional[float] = None
    cvss_source:        Optional[str]   = None   # NVD | manual (criterio M1)

    # Enriquecimiento (AnalysisAgent — Sprint 3)
    cve_ids:            list[str]       = []
    mitre_technique:    Optional[str]   = None   # ej: T1046

    # Aplicabilidad CVE por-CVE (fix 2026-06-11). Cada entrada:
    #   {cve_id, cvss_score, cvss_source, confidence}
    # confidence ∈ {"confirmed", "version-unknown", "keyword-only"}.
    #   confirmed       → versión del servicio cae en el rango vulnerable (CPE match).
    #   version-unknown → producto coincide pero no hay versión para confirmar.
    #   keyword-only    → el CVE solo apareció por coincidencia de texto (no aplicable).
    # cve_ids / cvss_score / cvss_source de arriba quedan como COMPAT derivado:
    # cve_ids = todos los cve_id; cvss_score = score del CVE aplicable de mayor
    # confianza (NUNCA de uno keyword-only). El reporter excluye keyword-only.
    cve_details:        list[dict]      = []

    # Confianza del finding mismo (no del CVE): la usan los scanners web ante
    # servidores catch-all (soft-200). "high" normal; "low" = evidencia dudosa
    # (p.ej. nikto/gobuster contra un server que responde 200 a toda ruta).
    confidence:         Optional[str]   = None   # high | low

    # Estado de gestión
    status:             str             = "open"   # open | confirmed | false_positive | fixed

    # Datos de red (cuando aplica — nmap)
    port:               Optional[int]   = None
    service:            Optional[str]   = None
    protocol:           Optional[str]   = None

    # Evidencia tool-specific (port/state/product/version para nmap,
    # path/status_code para gobuster, template_id/matched_at para nuclei, etc.)
    evidence:           dict            = {}

    # Trazabilidad
    hitl_action_id:     Optional[int]   = None   # FK a PostgreSQL hitl_actions.id
    discovered_at:      datetime        = Field(default_factory=utc_now)

    # M-4: clave determinística para dedup en re-scans. Calculada por
    # findings_service._compute_dedup_key(); índice único parcial en
    # mongo_client.ensure_indexes() la usa con upsert.
    dedup_key:          Optional[str]   = None


# ── AgentRunDoc ───────────────────────────────────────────────────────────────

class ToolCallEntry(BaseModel):
    """Entrada en el log de tool calls de un agente."""
    tool:           str
    target:         str
    status:         str             # running | completed | error | scope_violation | hitl_rejected | hitl_timeout
    hitl_action_id: Optional[int]  = None
    duration_ms:    Optional[int]  = None
    error:          Optional[str]  = None
    # Observabilidad (live monitoring)
    started_at:     datetime       = Field(default_factory=utc_now)
    finished_at:    Optional[datetime] = None
    params:         Optional[dict] = None      # input truncado para auditoría
    output_preview: Optional[str]  = None      # primeros ~500 chars del output
    # Frase legible para el cuadro de actividad en vivo (services/narration.py).
    # Ej: "Scan usando Nmap para mapear puertos y servicios de 10.42.0.10".
    narration:      Optional[str]  = None


class AgentRunDoc(BaseModel):
    """
    Log completo de ejecución de un agente.
    Persiste cada run para trazabilidad y debugging.
    """
    engagement_id:  int
    agent:          str                     # ReconAgent | ScanAgent
    model:          str                     # claude-haiku-4-5-20251001 | ...
    targets:        list[str]   = []

    # Timing
    started_at:     datetime    = Field(default_factory=utc_now)
    finished_at:    Optional[datetime]  = None

    # Resultado
    status:         str         = "running"     # running | completed | failed
    tools_called:   list[ToolCallEntry] = []
    input_tokens:   Optional[int]   = None      # tokens consumidos (para cost tracking)
    output_tokens:  Optional[int]   = None
    error:          Optional[str]   = None

    # Marcador para que SSE/poll detecte cambios sin diffear toda la lista
    updated_at:     datetime    = Field(default_factory=utc_now)
    findings_count: Optional[int]   = None      # solo ScanAgent
    summary:        Optional[str]   = None      # mensaje final corto del agente
    # Frase legible de arranque para el cuadro de actividad (services/narration.py).
    # Ej: "🔍 Reconocimiento iniciado sobre 2 objetivos".
    narration:      Optional[str]   = None
    # FK al PipelineRunDoc que orquestó este run (si lo lanzó el Controller)
    pipeline_run_id: Optional[str]  = None


# ── PipelineRunDoc ────────────────────────────────────────────────────────────

class StageEntry(BaseModel):
    """Una etapa del pipeline orquestado por el Controller."""
    agent:         str                          # ReconAgent | ScanAgent | AnalysisAgent | ReporterAgent
    status:        str         = "pending"      # pending | running | completed | failed | skipped
    started_at:    Optional[datetime] = None
    finished_at:   Optional[datetime] = None
    agent_run_id:  Optional[str] = None         # _id del AgentRunDoc correspondiente
    error:         Optional[str] = None
    summary:       Optional[str] = None


class PipelineRunDoc(BaseModel):
    """
    Log de la ejecución end-to-end del pipeline orquestado por PipelineController.
    Un doc por pipeline run. Vincula varios AgentRunDoc vía stages[].agent_run_id.
    """
    engagement_id:  int
    stages:         list[StageEntry]            # orden = orden de ejecución

    # Estado global del pipeline
    status:         str        = "running"      # running | completed | failed | aborted
    started_at:     datetime   = Field(default_factory=utc_now)
    finished_at:    Optional[datetime] = None
    updated_at:     datetime   = Field(default_factory=utc_now)

    # Resumen final
    summary:        Optional[str] = None
    error:          Optional[str] = None
    triggered_by:   Optional[str] = None        # "operator" | "scheduler" | "auto"


# ═══════════════════════════════════════════════════════════════════════════════
# Bloque 0 (ADR-005) — Colecciones del blackboard compartido
# ═══════════════════════════════════════════════════════════════════════════════
# Estos schemas son el CONTRATO. El contenido rico de AnalysisDoc lo llena el
# Bloque B (AnalysisAgent); aquí se fija solo el envelope para que A/C/D puedan
# leer/escribir contra una forma estable.


class AnalysisDoc(BaseModel):
    """
    Salida consolidada del AnalysisAgent (Bloque B). Un doc por engagement (upsert).
    Envelope estable; el Bloque B puede enriquecer cada sub-estructura.
    """
    engagement_id:      int

    # Findings enriquecidos con CVE/CVSS/ATT&CK reales (referencian findings por dedup_key)
    enriched_findings:  list[dict] = []
    # Cadenas de ataque / kill chains razonadas por el agente
    attack_vectors:     list[dict] = []
    # Orden de prioridad (claves/ids de findings de mayor a menor riesgo)
    priority_order:     list[str]  = []
    # Resumen ejecutivo del cuadro de riesgo
    summary:            Optional[str] = None

    # Metadata
    generated_at:       datetime    = Field(default_factory=utc_now)
    agent_run_id:       Optional[str] = None
    model_used:         Optional[str] = None

    model_config = {"extra": "allow"}   # el Bloque B puede agregar campos


class AgentRationaleDoc(BaseModel):
    """
    Registro del 'por qué' de una corrida de agente (ADR-005 §3.1). Append-only;
    alimenta auditoría y el contexto que lee el Orquestador.
    """
    engagement_id:  int
    agent:          str                         # uno de AGENT_NAMES
    rationale:      str
    status:         Optional[str] = None        # AgentStatus de la corrida
    run_id:         Optional[str] = None        # _id del AgentRunDoc asociado
    pipeline_run_id: Optional[str] = None
    created_at:     datetime    = Field(default_factory=utc_now)


class ConversationTurnDoc(BaseModel):
    """
    Un turno de la conversación operador↔orquestador (Bloque A). Append-only.
    """
    engagement_id:  int
    role:           str                         # "operator" | "orchestrator" | "system"
    content:        str
    # Metadata opcional: plan propuesto, tool calls delegados, ids HITL, etc.
    meta:           Optional[dict] = None
    created_at:     datetime    = Field(default_factory=utc_now)
