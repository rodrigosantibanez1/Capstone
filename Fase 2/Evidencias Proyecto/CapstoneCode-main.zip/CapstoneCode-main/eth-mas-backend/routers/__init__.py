"""
routers — paquete de APIRouters por dominio (Sesión D, refactor de main.py)
===========================================================================
Cada dominio vive en su módulo; main.py los registra iterando ALL_ROUTERS.
Los paths e implementación son idénticos a los del main.py monolítico
pre-refactor — este paquete solo reorganiza, no cambia comportamiento.

  health        · GET /  ·  GET /health/services
  engagements   · E1 — CRUD + state machine (HU-01, HU-03)
  scope         · E1 — scope targets + validate (HU-01, HU-02)
  hitl          · E4 — cola HITL + expire-pending (HU-09, HU-10)
  pipeline      · E2/E3/E0 — recon, scan, analysis, surface-map, findings,
                  pipeline controller + pipeline-runs (HU-04..HU-08, HU-12/13)
  reports       · E6 — generación y descarga de PDFs GridFS (HU-14)
  orchestrator  · Bloque A — chat operador↔orquestador (ADR-005 §3.3)
  observability · agent_runs + SSE (Capa 1, HU-23)
"""

from . import (
    engagements,
    health,
    hitl,
    observability,
    orchestrator,
    pipeline,
    reports,
    scope,
)

ALL_ROUTERS = [
    health.router,
    engagements.router,
    scope.router,
    pipeline.router,
    reports.router,
    hitl.router,
    orchestrator.router,
    observability.router,
]
