"""
routers/engagements.py — E1 · Engagement (HU-01, HU-03)
=======================================================
CRUD de engagements + máquina de estados de status.
"""

from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

import models
import schemas
from database import get_db
from models import EngagementStatus, VALID_TRANSITIONS
from utils import utc_now

router = APIRouter()


@router.get("/engagements", response_model=List[schemas.EngagementSummary], tags=["engagements"])
def list_engagements(
    status_filter: Optional[str] = Query(None, alias="status"),
    db: Session = Depends(get_db),
):
    q = db.query(models.Engagement)
    if status_filter:
        try:
            st = EngagementStatus(status_filter.lower())
            q = q.filter(models.Engagement.status == st)
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=f"Status invalido: {status_filter!r}. "
                       f"Opciones: {[e.value for e in EngagementStatus]}",
            )
    engagements = q.order_by(models.Engagement.created_at.desc()).all()
    result = []
    for eng in engagements:
        summary = schemas.EngagementSummary.model_validate(eng)
        summary.scope_count = len(eng.scopes)
        result.append(summary)
    return result


@router.post(
    "/engagements",
    response_model=schemas.EngagementResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["engagements"],
)
def create_engagement(payload: schemas.EngagementCreate, db: Session = Depends(get_db)):
    """Crea un nuevo engagement con scope, ROE y tacticas ATT&CK. (HU-01)"""
    engagement = models.Engagement(
        name=payload.name,
        description=payload.description,
        client_name=payload.client_name,
        status=EngagementStatus.PENDING,
        roe=payload.roe.model_dump() if payload.roe else None,
        att_tactics=payload.att_tactics,
    )
    db.add(engagement)
    db.flush()
    for t in payload.scope_targets:
        db_scope = models.ScopeTarget(
            engagement_id=engagement.id,
            target_value=t.target_value,
            target_type=t.target_type.upper(),
        )
        db.add(db_scope)
    db.commit()
    db.refresh(engagement)
    return engagement


@router.get("/engagements/{engagement_id}", response_model=schemas.EngagementResponse, tags=["engagements"])
def get_engagement(engagement_id: int, db: Session = Depends(get_db)):
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")
    return eng


@router.patch("/engagements/{engagement_id}/status", response_model=schemas.EngagementResponse, tags=["engagements"])
def update_engagement_status(
    engagement_id: int,
    payload: schemas.EngagementStatusUpdate,
    db: Session = Depends(get_db),
):
    """Transiciona el status segun la maquina de estados. (HU-03)"""
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")
    try:
        new_status = EngagementStatus(payload.status.lower())
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Status {payload.status!r} invalido.")
    allowed = VALID_TRANSITIONS.get(eng.status, [])
    if new_status not in allowed:
        raise HTTPException(
            status_code=422,
            detail=(
                f"Transicion ilegal: {eng.status.value} -> {new_status.value}. "
                f"Permitidas: {[t.value for t in allowed] or 'ninguna (estado terminal)'}."
            ),
        )
    eng.status = new_status
    eng.updated_at = utc_now()
    db.commit()
    db.refresh(eng)
    return eng
