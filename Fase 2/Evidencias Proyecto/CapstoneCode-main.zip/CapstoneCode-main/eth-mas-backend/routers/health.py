"""
routers/health.py — Health · root + servicios externos
======================================================
GET /                 — liveness básico de la API
GET /health/services  — estado de postgres/mongo/MCP scripts/Anthropic key
"""

from __future__ import annotations

import os

from fastapi import APIRouter, Query
from sqlalchemy import text

from database import engine
from mongo_client import get_mongo_client
from services.anthropic_health import (
    check_anthropic_key_live,
    get_cached_anthropic_status,
)
from utils import utc_now

router = APIRouter()

# Los scripts MCP viven en <backend>/mcp_servers/ — un nivel arriba de routers/.
_BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_OSINT_SERVER = os.path.normpath(
    os.path.join(_BACKEND_DIR, "mcp_servers", "osint_server.py")
)
_SECURITY_SERVER = os.path.normpath(
    os.path.join(_BACKEND_DIR, "mcp_servers", "security_server.py")
)


@router.get("/", tags=["health"])
def read_root():
    return {
        "status": "online",
        "version": "0.3.0",
        "mensaje": "ETH-MAS API activa",
    }


@router.get("/health/services", tags=["health"])
async def health_services(refresh: bool = Query(False, description="Forzar re-chequeo live de Anthropic")):
    """
    Health check de los servicios externos que el sistema necesita.
    Cada servicio reporta status `up | down | degraded` y un detalle.
    No requiere auth: lo usa la barra global del frontend cada 10s.

    Query params:
        refresh=true → fuerza un live-check inmediato de ANTHROPIC_API_KEY
                       (ignora cache de 10 min). Útil tras rotar la key.
    """
    services: dict[str, dict] = {}

    # PostgreSQL
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        services["postgres"] = {"status": "up"}
    except Exception as e:
        services["postgres"] = {"status": "down", "detail": str(e)[:200]}

    # MongoDB
    try:
        await get_mongo_client().admin.command("ping")
        services["mongo"] = {"status": "up"}
    except Exception as e:
        services["mongo"] = {"status": "down", "detail": str(e)[:200]}

    # MCP OSINT server (presencia del script)
    services["osint_mcp"] = (
        {"status": "up", "script": _OSINT_SERVER}
        if os.path.isfile(_OSINT_SERVER)
        else {"status": "down", "detail": f"Script no encontrado: {_OSINT_SERVER}"}
    )

    # MCP Security server (presencia del script)
    services["security_mcp"] = (
        {"status": "up", "script": _SECURITY_SERVER}
        if os.path.isfile(_SECURITY_SERVER)
        else {"status": "down", "detail": f"Script no encontrado: {_SECURITY_SERVER}"}
    )

    # Anthropic API key — Nivel 1: format check + live check cacheado
    # services/anthropic_health.py mantiene el estado real (verificado
    # contra /v1/models). Aquí solo leemos el cache.
    if refresh:
        anth = await check_anthropic_key_live(force=True)
    else:
        anth = get_cached_anthropic_status()

    if anth.get("valid") is True:
        services["anthropic"] = {
            "status":         "up",
            "key_present":    True,
            "key_validated":  True,
            "models_sample":  anth.get("models_sample", []),
            "checked_at":     anth["checked_at"].isoformat() + "Z"
                              if anth.get("checked_at") else None,
        }
    elif anth.get("valid") is False:
        services["anthropic"] = {
            "status":      "down",
            "key_present": True,    # algo hay; la API la rechaza
            "key_validated": False,
            "detail":      anth.get("reason", "key inválida"),
            "checked_at":  anth["checked_at"].isoformat() + "Z"
                           if anth.get("checked_at") else None,
        }
    else:
        # valid=None → aún no se chequeó o no hay conectividad
        services["anthropic"] = {
            "status":      "degraded",
            "key_present": bool(os.getenv("ANTHROPIC_API_KEY", "").strip()),
            "key_validated": None,
            "detail":      anth.get("reason", "estado desconocido"),
            "checked_at":  anth["checked_at"].isoformat() + "Z"
                           if anth.get("checked_at") else None,
        }

    overall = "up"
    if any(s["status"] == "down" for s in services.values()):
        overall = "down"
    elif any(s["status"] == "degraded" for s in services.values()):
        overall = "degraded"

    return {
        "overall":    overall,
        "services":   services,
        "checked_at": utc_now().isoformat() + "Z",
    }
