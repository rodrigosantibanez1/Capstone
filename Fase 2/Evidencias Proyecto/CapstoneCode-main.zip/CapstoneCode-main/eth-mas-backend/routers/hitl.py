"""
routers/hitl.py — E4 · HITL (HU-09, HU-10)
==========================================
Cola de aprobaciones del operador + expire-pending (Fix 1.3 anti-zombi).
"""

from __future__ import annotations

import logging
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

import models
import schemas
from auth import verify_api_key
from database import get_db
from utils import utc_now

logger = logging.getLogger("eth_mas.routers.hitl")

router = APIRouter()


@router.get(
    "/engagements/{engagement_id}/hitl-actions",
    response_model=List[schemas.HitlActionResponse],
    tags=["hitl"],
)
def list_hitl_actions(
    engagement_id: int,
    pending_only: bool = Query(False),
    db: Session = Depends(get_db),
):
    """Lista acciones HITL. ?pending_only=true muestra solo las que esperan
    decisión del operador (decision == 'PENDING').

    Post-migración c7e2d1f8b3a4 (B-2 auditoría 2026-05-19): el estado pendiente
    se representa con decision='PENDING' (no NULL). Las filas legacy con NULL
    fueron normalizadas a PENDING al aplicar esa migración."""
    q = (
        db.query(models.HitlAction)
        .filter(models.HitlAction.engagement_id == engagement_id)
        .order_by(models.HitlAction.requested_at.desc())
    )
    if pending_only:
        q = q.filter(models.HitlAction.decision == "PENDING")
    return q.all()


@router.patch(
    "/hitl-actions/{hitl_id}/decision",
    response_model=schemas.HitlActionResponse,
    tags=["hitl"],
    dependencies=[Depends(verify_api_key)],
)
def decide_hitl_action(hitl_id: int, payload: schemas.HitlDecision, db: Session = Depends(get_db)):
    """El operador aprueba o rechaza una accion HITL pendiente. (HU-09)"""
    action = db.query(models.HitlAction).filter(models.HitlAction.id == hitl_id).first()
    if not action:
        raise HTTPException(status_code=404, detail=f"HitlAction {hitl_id} no encontrada")
    if action.decision is not None and action.decision != "PENDING":
        raise HTTPException(status_code=409, detail=f"Ya tiene decision: {action.decision}")
    valid_decisions = {"APPROVED", "REJECTED", "AUTO-APPROVED"}
    if payload.decision.upper() not in valid_decisions:
        raise HTTPException(status_code=400, detail=f"Decision invalida. Opciones: {sorted(valid_decisions)}")
    action.decision   = payload.decision.upper()
    action.operator   = payload.operator
    action.notes      = payload.notes
    action.decided_at = utc_now()
    db.commit()
    db.refresh(action)
    return action


@router.get("/hitl-actions/{hitl_id}", response_model=schemas.HitlActionResponse, tags=["hitl"])
def get_hitl_action(hitl_id: int, db: Session = Depends(get_db)):
    """Obtiene una accion HITL por ID (para polling de estado)."""
    action = db.query(models.HitlAction).filter(models.HitlAction.id == hitl_id).first()
    if not action:
        raise HTTPException(status_code=404, detail=f"HitlAction {hitl_id} no encontrada")
    return action


@router.post(
    "/engagements/{engagement_id}/hitl-actions/expire-pending",
    tags=["hitl"],
    dependencies=[Depends(verify_api_key)],
)
def expire_pending_hitl(
    engagement_id: int,
    min_age_secs: int = Query(
        600,
        ge=0,
        le=86400,
        description=(
            "Edad mínima (segundos) que debe tener una HITL PENDING para "
            "considerarla zombi. Default 600s (10 min). Usar 0 para forzar "
            "todas las pendientes del engagement."
        ),
    ),
    db: Session = Depends(get_db),
):
    """
    Fix 1.3 — Libera HITL zombis sin esperar al reinicio del backend.

    Marca como EXPIRED toda HitlAction(engagement_id, decision='PENDING')
    cuyo requested_at sea anterior a (ahora - min_age_secs). Útil cuando
    el operador detecta que la cola HITL quedó atascada porque el MCP
    subprocess que las registró ya murió (huérfano de reload o restart).

    Tras correr este endpoint, el pre-check del ScanAgent y el
    PipelineController vuelven a permitir lanzar nuevos scans sobre el
    engagement.
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    from datetime import timedelta
    cutoff = utc_now() - timedelta(seconds=min_age_secs)
    note = (
        f"Expirado manualmente vía /expire-pending ({utc_now().isoformat()}Z). "
        f"PENDING anterior a {cutoff.isoformat()}Z."
    )

    affected = (
        db.query(models.HitlAction)
        .filter(
            models.HitlAction.engagement_id == engagement_id,
            models.HitlAction.decision == "PENDING",
            models.HitlAction.requested_at < cutoff,
        )
        .update(
            {
                "decision":   "EXPIRED",
                "decided_at": utc_now(),
                "operator":   "SYSTEM:MANUAL_EXPIRE",
                "notes":      note,
            },
            synchronize_session=False,
        )
    )
    db.commit()

    logger.warning(
        "Manual expire-pending: engagement=%d affected=%d min_age_secs=%d",
        engagement_id, affected, min_age_secs,
    )

    return {
        "engagement_id":      engagement_id,
        "expired_count":      int(affected or 0),
        "min_age_secs":       min_age_secs,
        "cutoff":             cutoff.isoformat() + "Z",
        "message":            (
            f"{affected or 0} acción(es) HITL expiradas. "
            f"Ahora se pueden lanzar nuevos scans sobre este engagement."
        ),
    }
