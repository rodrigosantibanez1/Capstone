"""
routers/observability.py — Observabilidad · AgentRuns (Capa 1, HU-23)
=====================================================================
Listado y detalle de runs de agentes + SSE en vivo.
"""

from __future__ import annotations

import asyncio
import json
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import StreamingResponse

from services.agent_runs_service import (
    get_latest_run,
    get_run as get_agent_run,
    list_runs as list_agent_runs,
)

router = APIRouter()


@router.get("/engagements/{engagement_id}/agent-runs", tags=["observability"])
async def get_engagement_agent_runs(
    engagement_id: int,
    limit: int = Query(50, ge=1, le=200),
):
    """
    Lista los runs de agentes (Recon/Scan) del engagement, ordenados desc por
    started_at. Cada run incluye su `tools_called` con timestamps y duración.
    """
    runs = await list_agent_runs(engagement_id, limit=limit)
    return {"engagement_id": engagement_id, "total": len(runs), "runs": runs}


@router.get("/agent-runs/{run_id}", tags=["observability"])
async def get_single_agent_run(run_id: str):
    """Detalle completo de un run específico (tools_called + output_preview)."""
    doc = await get_agent_run(run_id)
    if not doc:
        raise HTTPException(status_code=404, detail=f"AgentRun {run_id} no encontrado")
    return doc


@router.get("/engagements/{engagement_id}/agent-runs/stream", tags=["observability"])
async def stream_agent_runs(engagement_id: int, request: Request):
    """
    SSE: emite el run más reciente del engagement cada ~1.5s mientras esté
    activo. Si el cliente se desconecta, el generador termina.
    Cierra el stream cuando el run pase a estado terminal (completed | failed)
    y se haya emitido al menos una vez en ese estado.
    """
    async def event_generator():
        last_payload: Optional[str] = None
        terminal_emitted = False

        # Heartbeat inicial para que el cliente sepa que la conexión vive
        yield "event: hello\ndata: {}\n\n"

        while True:
            if await request.is_disconnected():
                break

            doc = await get_latest_run(engagement_id)
            if doc is None:
                payload = json.dumps({"status": "idle", "engagement_id": engagement_id})
            else:
                payload = json.dumps(doc, default=str)

            # Solo emitir cuando hay cambios
            if payload != last_payload:
                yield f"event: run\ndata: {payload}\n\n"
                last_payload = payload

            # Si el último run ya está en estado terminal, cortar tras
            # emitir el snapshot final
            if doc is not None and doc.get("status") in ("completed", "failed"):
                if terminal_emitted:
                    yield "event: end\ndata: {}\n\n"
                    break
                terminal_emitted = True

            await asyncio.sleep(1.5)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":     "no-cache",
            "X-Accel-Buffering": "no",   # nginx: no bufferear
            "Connection":        "keep-alive",
        },
    )
