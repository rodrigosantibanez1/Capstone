"""
routers/orchestrator.py — Bloque A · Orquestador conversacional (ADR-005 §3.3)
==============================================================================
El operador conversa en NL; el Orquestador (LLM) arma un plan y delega en los
4 workers vía el ejecutor seguro. Dos modos: plan (preview, no ejecuta) y
execute (delega de verdad, en background). El scope y el HITL siguen siendo
control EN CÓDIGO — el orquestador no los aprueba por chat.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Optional

from fastapi import (
    APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request, status,
)
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

import models
from auth import verify_api_key
from database import SessionLocal, get_db
from utils import utc_now

logger = logging.getLogger("eth_mas.routers.orchestrator")

router = APIRouter()


class OrchestratorMessageRequest(BaseModel):
    """Body de POST /engagements/{id}/orchestrator."""
    message: str = Field(..., min_length=1, description="Mensaje del operador en lenguaje natural.")
    mode:    str = Field(
        default="plan",
        description="'plan' (preview sin ejecutar) o 'execute' (delega en los workers).",
    )


async def _run_orchestrator_in_background(engagement_id: int, message: str) -> None:
    """Corre el Orquestador en modo execute con session propia. Fire-and-forget;
    el frontend sigue el avance por SSE /orchestrator/stream."""
    from services.orchestrator_agent import OrchestratorAgent, MODE_EXECUTE

    session = SessionLocal()
    try:
        agent = OrchestratorAgent(engagement_id=engagement_id, db=session)
        result = await agent.handle_message(message, mode=MODE_EXECUTE)
        logger.info(
            "[BG orchestrator] engagement=%d delegaciones=%d",
            engagement_id, len(result.get("delegations", [])),
        )
    except asyncio.CancelledError:
        logger.warning("[BG orchestrator] engagement=%d CANCELADO", engagement_id)
        raise
    except Exception as e:
        logger.exception("[BG orchestrator] engagement=%d falló: %s", engagement_id, e)
        # Dejar huella en la conversación para que el operador lo vea en el chat.
        try:
            from services.blackboard import append_conversation
            await append_conversation(
                engagement_id, "system",
                f"El orquestador falló al ejecutar: {e}", meta={"kind": "error"},
            )
        except Exception:  # noqa: BLE001
            pass
    finally:
        session.close()


@router.post(
    "/engagements/{engagement_id}/orchestrator",
    tags=["orchestrator"],
    dependencies=[Depends(verify_api_key)],
)
async def orchestrator_message(
    engagement_id: int,
    background_tasks: BackgroundTasks,
    body: OrchestratorMessageRequest,
    db: Session = Depends(get_db),
):
    """
    Punto conversacional del operador con el Orquestador (Bloque A, ADR-005).

    - mode='plan'    → síncrono: devuelve el plan (qué workers delegaría y por qué)
                       SIN ejecutar nada. 200.
    - mode='execute' → encola la corrida en background (delega en los workers vía
                       el ejecutor seguro). 202. Seguir por SSE /orchestrator/stream.

    El scope y el HITL son control en código: el orquestador NO los aprueba por
    chat. Si un worker queda waiting_hitl, lo narra y deriva a la consola HITL.
    """
    from services.orchestrator_agent import OrchestratorAgent, VALID_MODES, MODE_EXECUTE, MODE_PLAN

    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    mode = (body.mode or "plan").lower()
    if mode not in VALID_MODES:
        raise HTTPException(
            status_code=422,
            detail=f"mode inválido: {body.mode!r}. Use 'plan' o 'execute'.",
        )

    if mode == MODE_EXECUTE:
        # B8 — marcar RUNNING al delegar de verdad (mismo patrón que /scan y
        # /pipeline). Sin esto el engagement quedaba 'pending' aunque el
        # orquestador delegara: la UI no reflejaba que había trabajo en curso.
        if eng.status == models.EngagementStatus.PENDING:
            eng.status = models.EngagementStatus.RUNNING
            eng.updated_at = utc_now()
            db.commit()

        background_tasks.add_task(_run_orchestrator_in_background, engagement_id, body.message)
        logger.info("[/orchestrator] engagement=%d execute encolado", engagement_id)
        return JSONResponse(
            status_code=status.HTTP_202_ACCEPTED,
            content={
                "status":        "queued",
                "mode":          MODE_EXECUTE,
                "engagement_id": engagement_id,
                "message":       (
                    "Orquestador ejecutando en background. Sigue el avance por SSE "
                    f"/engagements/{engagement_id}/orchestrator/stream."
                ),
            },
        )

    # mode=plan → síncrono (una sola llamada al LLM, rápido).
    agent = OrchestratorAgent(engagement_id=engagement_id, db=db)
    result = await agent.handle_message(body.message, mode=MODE_PLAN)
    return result


@router.get("/engagements/{engagement_id}/orchestrator/conversation", tags=["orchestrator"])
async def orchestrator_conversation(
    engagement_id: int,
    limit: Optional[int] = Query(None, ge=1, le=500),
):
    """Devuelve la conversación operador↔orquestador en orden cronológico."""
    from services.blackboard import read_conversation
    turns = await read_conversation(engagement_id, limit=limit)
    return {"engagement_id": engagement_id, "total": len(turns), "turns": turns}


@router.get("/engagements/{engagement_id}/orchestrator/stream", tags=["orchestrator"])
async def stream_orchestrator(engagement_id: int, request: Request):
    """
    SSE del chat: emite cada turno NUEVO de la conversación (operador, orquestador,
    delegaciones, errores) a medida que se persiste. Mismo patrón de polling-Mongo
    que /agent-runs/stream. Cierra cuando el cliente se desconecta.
    """
    from services.blackboard import read_conversation

    async def event_generator():
        yield "event: hello\ndata: {}\n\n"
        emitted = 0
        # Sembrar con lo ya existente para no re-emitir toda la historia.
        try:
            existing = await read_conversation(engagement_id)
            emitted = len(existing)
        except Exception:  # noqa: BLE001
            emitted = 0

        while True:
            if await request.is_disconnected():
                break
            try:
                turns = await read_conversation(engagement_id)
            except Exception:  # noqa: BLE001
                await asyncio.sleep(1.5)
                continue

            if len(turns) > emitted:
                for turn in turns[emitted:]:
                    yield f"event: turn\ndata: {json.dumps(turn, default=str)}\n\n"
                emitted = len(turns)

            await asyncio.sleep(1.5)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":     "no-cache",
            "X-Accel-Buffering": "no",
            "Connection":        "keep-alive",
        },
    )
