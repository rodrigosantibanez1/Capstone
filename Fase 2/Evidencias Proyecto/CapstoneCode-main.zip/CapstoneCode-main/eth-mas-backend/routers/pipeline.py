"""
routers/pipeline.py — E2/E3/E0 · Recon, Scan, Analysis y Pipeline Controller
============================================================================
  - POST /recon · POST/GET /analysis · GET /surface-map  (HU-04, HU-05, HU-12/13)
  - POST /scan + pre-check HITL 409 + background task     (HU-06)
  - GET  /findings                                        (HU-07, HU-08)
  - POST /pipeline + pipeline-runs + SSE                  (orquestación E0)
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import List, Optional

from fastapi import (
    APIRouter, BackgroundTasks, Body, Depends, HTTPException, Query, Request,
    status,
)
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

import models
from auth import verify_api_key
from database import SessionLocal, get_db
from models import EngagementStatus
from mongo_client import findings_col, surface_map_col
from services.pipeline_controller import DEFAULT_STAGES, PipelineController
from services.pipeline_runs_service import (
    get_latest_pipeline, get_pipeline, list_pipelines,
)
from utils import utc_now

logger = logging.getLogger("eth_mas.routers.pipeline")

router = APIRouter()


# =============================================================================
# E2 · Reconocimiento — HU-04 / HU-05 (ReconAgent real Sprint 2)
# =============================================================================

@router.post("/engagements/{engagement_id}/recon", tags=["pipeline"], dependencies=[Depends(verify_api_key)])
async def launch_recon(engagement_id: int, db: Session = Depends(get_db)):
    """
    Lanza la fase de reconocimiento OSINT del engagement. (HU-04)
    Sprint 2: ReconAgent real — Haiku 4.5 + OSINT MCP Server.
    Persiste surface_map en MongoDB al finalizar (HU-05).
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    scope_count = (
        db.query(models.ScopeTarget)
        .filter(models.ScopeTarget.engagement_id == engagement_id)
        .count()
    )
    if scope_count == 0:
        raise HTTPException(
            status_code=422,
            detail="No hay scope targets configurados. Agrega targets antes de iniciar recon.",
        )

    if eng.status == EngagementStatus.PENDING:
        eng.status = EngagementStatus.RUNNING
        eng.updated_at = utc_now()
        db.commit()

    # Bloque D/E: ReconAgent es nuevo-contrato (BaseAgent). Se ejecuta por el
    # ejecutor seguro (PipelineController) para construir el AgentContext, llevar
    # el bookkeeping de pipeline_runs y registrar el rationale en el blackboard —
    # igual que /analysis y /report. (Antes: agent.run() directo, contrato legacy.)
    controller = PipelineController(
        engagement_id=engagement_id, db=db, stages=["ReconAgent"],
    )
    result = await controller.run()

    return {
        "message":       "Reconocimiento completado",
        "engagement_id": engagement_id,
        "recon_result":  result,
    }


@router.post("/engagements/{engagement_id}/analysis", tags=["pipeline"], dependencies=[Depends(verify_api_key)])
async def launch_analysis(engagement_id: int, db: Session = Depends(get_db)):
    """
    Lanza el AnalysisAgent (HU-12 / HU-13). Enriquece los findings con CVEs reales
    (NVD) y técnicas MITRE ATT&CK validadas, arma vectores de ataque y prioriza por
    explotabilidad. Persiste el análisis en el blackboard y enriquece los findings
    en Mongo.

    Requiere findings persistidos (correr POST /scan antes). Las tools del Analysis
    MCP son pasivas (risk LOW, sin contacto con el target) → sin HITL, corre
    sincrónico. Se ejecuta a través del ejecutor seguro (PipelineController) para
    conservar el bookkeeping de pipeline_runs.
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    controller = PipelineController(
        engagement_id=engagement_id, db=db, stages=["AnalysisAgent"],
    )
    result = await controller.run()

    return {
        "message":         "Análisis completado",
        "engagement_id":   engagement_id,
        "analysis_result": result,
    }


@router.get("/engagements/{engagement_id}/analysis", tags=["pipeline"])
async def get_analysis(engagement_id: int):
    """
    Devuelve el documento de análisis consolidado del engagement (AnalysisDoc):
    findings enriquecidos (CVE/CVSS/ATT&CK), vectores de ataque y priorización.
    Requiere haber ejecutado POST /analysis al menos una vez.
    """
    from services.blackboard import read_state
    state = await read_state(engagement_id, include=("analysis",))
    analysis = state.get("analysis")
    if not analysis:
        raise HTTPException(
            status_code=404,
            detail="Análisis no disponible. Ejecutar POST /engagements/{id}/analysis primero.",
        )
    return analysis


@router.get("/engagements/{engagement_id}/surface-map", tags=["pipeline"])
async def get_surface_map(engagement_id: int, db: Session = Depends(get_db)):
    """
    Retorna el surface map del engagement desde MongoDB. (HU-05)
    Requiere haber ejecutado POST /recon al menos una vez.
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    doc = await surface_map_col().find_one(
        {"engagement_id": engagement_id},
        sort=[("generated_at", -1)],
    )
    if not doc:
        raise HTTPException(
            status_code=404,
            detail="Surface map no disponible. Ejecutar POST /recon primero.",
        )

    doc["_id"] = str(doc["_id"])
    return doc


# =============================================================================
# E3 · Scan — HU-06 (Sprint 2 — ScanAgent + SecurityMCP + HITL)
# =============================================================================

# ── Fix 2.4 — Helpers para ejecución en background ────────────────────────────
# Estos helpers se invocan vía BackgroundTasks. Crean su PROPIA Session porque
# el `db` del request se cierra antes de que termine el agente. Si el agente
# falla, lo logueamos pero NO crasheamos el worker — el AgentRunDoc en MongoDB
# ya queda marcado como `failed`/`aborted` y el SSE notifica al frontend.


async def _run_scan_in_background(engagement_id: int) -> None:
    """Ejecuta el ScanAgent (nuevo-contrato) vía el ejecutor seguro, con session
    propia. Fire-and-forget. El PipelineController arma el AgentContext (lee
    ROE.scan_intensity), conserva el anti-zombi/HITL y registra el rationale."""
    session = SessionLocal()
    try:
        controller = PipelineController(
            engagement_id=engagement_id, db=session, stages=["ScanAgent"],
        )
        result = await controller.run()
        logger.info(
            "[BG scan] engagement=%d status=%s summary=%s",
            engagement_id,
            result.get("status"),
            result.get("summary"),
        )
    except asyncio.CancelledError:
        logger.warning("[BG scan] engagement=%d CANCELADO", engagement_id)
        raise
    except Exception as e:
        logger.exception("[BG scan] engagement=%d falló: %s", engagement_id, e)
    finally:
        session.close()


async def _run_pipeline_in_background(
    engagement_id: int,
    stages: List[str],
    triggered_by: str,
    stop_on_failure: bool,
) -> None:
    """Ejecuta PipelineController.run() con session propia. Fire-and-forget."""
    session = SessionLocal()
    try:
        controller = PipelineController(
            engagement_id   = engagement_id,
            db              = session,
            stages          = stages,
            triggered_by    = triggered_by,
            stop_on_failure = stop_on_failure,
        )
        result = await controller.run()
        logger.info(
            "[BG pipeline] engagement=%d status=%s summary=%s",
            engagement_id,
            result.get("status"),
            result.get("summary"),
        )
    except asyncio.CancelledError:
        logger.warning("[BG pipeline] engagement=%d CANCELADO", engagement_id)
        raise
    except Exception as e:
        logger.exception("[BG pipeline] engagement=%d falló: %s", engagement_id, e)
    finally:
        session.close()


def _check_pending_hitl_or_409(engagement_id: int, db: Session) -> None:
    """
    Pre-check síncrono: si hay HitlAction(decision='PENDING') para
    engagement+ScanAgent, lanza 409 con la lista. Le da feedback inmediato
    al frontend (en lugar de aceptar la request y dejar al agente abortar
    en background sin que el operador se entere).
    """
    pending_rows = (
        db.query(models.HitlAction.id)
        .filter(
            models.HitlAction.engagement_id == engagement_id,
            models.HitlAction.agent == "ScanAgent",
            models.HitlAction.decision == "PENDING",
        )
        .order_by(models.HitlAction.id.asc())
        .all()
    )
    if pending_rows:
        pending_ids = [r[0] for r in pending_rows]
        raise HTTPException(
            status_code=409,
            detail={
                "error":             "pending_hitl_blocks_new_scan",
                "engagement_id":     engagement_id,
                "pending_hitl_ids":  pending_ids,
                "message":           (
                    f"Hay {len(pending_ids)} HITL pendiente(s). Aprobar/rechazar "
                    f"desde la consola HITL o expirarlas con "
                    f"POST /engagements/{engagement_id}/hitl-actions/expire-pending "
                    f"antes de iniciar un nuevo scan."
                ),
            },
        )


@router.post(
    "/engagements/{engagement_id}/scan",
    tags=["pipeline"],
    dependencies=[Depends(verify_api_key)],
    status_code=status.HTTP_202_ACCEPTED,
)
async def launch_scan(
    engagement_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    """
    Lanza la fase de escaneo del engagement. (HU-06)
    Sprint 2: ScanAgent → SecurityMCP → HITL → nmap/nuclei/gobuster → MongoDB.

    Fix 2.4 — Ejecución en background.
    El ScanAgent corre en una BackgroundTask con su propia DB session, así que
    el operador puede cerrar el navegador sin perder findings. El frontend
    sigue el progreso vía SSE /agent-runs/stream.

    Respuestas:
      202 Accepted → scan encolado, retorna {status:'queued', engagement_id}.
      404          → engagement no existe.
      409          → hay HITL PENDING preexistentes (lista en detail).
      422          → engagement sin scope.
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    scope_count = (
        db.query(models.ScopeTarget)
        .filter(models.ScopeTarget.engagement_id == engagement_id)
        .count()
    )
    if scope_count == 0:
        raise HTTPException(
            status_code=422,
            detail="No hay scope targets configurados. Agrega targets antes de iniciar scan.",
        )

    # Pre-check síncrono — feedback inmediato si hay cola pendiente
    _check_pending_hitl_or_409(engagement_id, db)

    if eng.status == EngagementStatus.PENDING:
        eng.status = EngagementStatus.RUNNING
        eng.updated_at = utc_now()
        db.commit()

    background_tasks.add_task(_run_scan_in_background, engagement_id)
    logger.info("[/scan] engagement=%d encolado en background", engagement_id)

    return {
        "status":        "queued",
        "engagement_id": engagement_id,
        "message":       (
            "ScanAgent encolado. Monitorear vía SSE "
            f"/engagements/{engagement_id}/agent-runs/stream o GET "
            f"/engagements/{engagement_id}/agent-runs."
        ),
    }


# =============================================================================
# E3 · Findings — HU-08 (GET /findings)
# =============================================================================

@router.get("/engagements/{engagement_id}/findings", tags=["pipeline"])
async def get_findings(
    engagement_id: int,
    severity: Optional[str] = Query(None, description="Filtrar por severidad: critical, high, medium, low, info"),
    status_filter: Optional[str] = Query(None, alias="status", description="Filtrar por estado: open, closed, false_positive"),
    tool: Optional[str] = Query(None, description="Filtrar por herramienta: nmap, nuclei, nikto"),
    limit: int = Query(200, ge=1, le=1000, description="Máximo de resultados"),
):
    """
    Lista los findings del engagement desde MongoDB. (HU-08)
    Soporta filtros por severidad, estado y herramienta.
    """
    query: dict = {"engagement_id": engagement_id}
    if severity:
        query["severity"] = severity.lower()
    if status_filter:
        query["status"] = status_filter.lower()
    if tool:
        query["tool"] = tool.lower()

    try:
        docs = await findings_col().find(query).sort("discovered_at", -1).to_list(length=limit)
        # Serializar ObjectId → string
        for doc in docs:
            if "_id" in doc:
                doc["_id"] = str(doc["_id"])
        return {
            "engagement_id": engagement_id,
            "total":         len(docs),
            "filters":       {"severity": severity, "status": status_filter, "tool": tool},
            "findings":      docs,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error consultando findings: {e}")


# =============================================================================
# E0 · Pipeline Controller — orquestación end-to-end
# =============================================================================

class PipelineLaunchRequest(BaseModel):
    """Body opcional para POST /engagements/{id}/pipeline."""
    stages:          Optional[List[str]] = Field(
        default=None,
        description=(
            "Lista de agentes a ejecutar en orden. Default: pipeline completo "
            "ReconAgent → ScanAgent → AnalysisAgent → ReporterAgent."
        ),
    )
    stop_on_failure: bool = Field(
        default=True,
        description="Si True, abortar pipeline cuando una stage falle.",
    )
    triggered_by:    str  = Field(
        default="operator",
        description="Quién lanzó el pipeline (operator | scheduler | auto).",
    )


@router.post(
    "/engagements/{engagement_id}/pipeline",
    tags=["pipeline"],
    dependencies=[Depends(verify_api_key)],
    status_code=status.HTTP_202_ACCEPTED,
)
async def launch_pipeline(
    engagement_id: int,
    background_tasks: BackgroundTasks,
    body: PipelineLaunchRequest = Body(default=PipelineLaunchRequest()),
    db: Session = Depends(get_db),
):
    """
    Lanza el pipeline end-to-end (Controller). Por defecto ejecuta el
    pipeline completo de 4 stages: ReconAgent → ScanAgent → AnalysisAgent →
    ReporterAgent (DEFAULT_STAGES). Pasar `stages` para correr un
    subconjunto u orden distinto.

    Fix 2.4 — Ejecución en background.
    El controller corre en una BackgroundTask con su propia DB session. El
    frontend sigue el progreso vía SSE /pipeline-runs/stream.

    Respuestas:
      202 Accepted → pipeline encolado, retorna {status:'queued', engagement_id}.
      400          → stages contiene nombres no registrados.
      404          → engagement no existe.
      409          → hay HITL PENDING preexistentes (la stage ScanAgent
                     no podría arrancar — el pipeline tampoco), o el
                     engagement está en estado terminal (completed/aborted).
      422          → engagement sin scope.
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    # BUG-2 (ciclo de vida): un engagement cerrado (completed/aborted) es
    # terminal — no admite nuevas corridas del pipeline.
    if eng.status in (EngagementStatus.COMPLETED, EngagementStatus.ABORTED):
        raise HTTPException(
            status_code=409,
            detail=(
                f"Engagement {engagement_id} está en estado terminal "
                f"'{eng.status.value}': no admite nuevos pipelines."
            ),
        )

    scope_count = (
        db.query(models.ScopeTarget)
        .filter(models.ScopeTarget.engagement_id == engagement_id)
        .count()
    )
    if scope_count == 0:
        raise HTTPException(
            status_code=422,
            detail="No hay scope targets configurados. Agrega targets antes de iniciar el pipeline.",
        )

    stages = body.stages or DEFAULT_STAGES

    # Validar nombres de stages ANTES de encolar — el operador necesita 400
    # inmediato si pidió un agente inexistente. Reproducimos la validación
    # que hace PipelineController.__init__ para que un error de payload no
    # contamine el log de pipeline_runs con un run que nunca arrancó.
    try:
        PipelineController(
            engagement_id   = engagement_id,
            db              = db,
            stages          = stages,
            triggered_by    = body.triggered_by,
            stop_on_failure = body.stop_on_failure,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # Pre-check síncrono de HITL pendientes — sólo si la stage ScanAgent
    # forma parte del pipeline. Si el operador pidió un pipeline sin
    # ScanAgent (ej. ["ReconAgent"]), no es necesario.
    if "ScanAgent" in stages:
        _check_pending_hitl_or_409(engagement_id, db)

    if eng.status == EngagementStatus.PENDING:
        eng.status = EngagementStatus.RUNNING
        eng.updated_at = utc_now()
        db.commit()

    background_tasks.add_task(
        _run_pipeline_in_background,
        engagement_id,
        stages,
        body.triggered_by,
        body.stop_on_failure,
    )
    logger.info(
        "[/pipeline] engagement=%d encolado stages=%s", engagement_id, stages,
    )

    return {
        "status":        "queued",
        "engagement_id": engagement_id,
        "stages":        stages,
        "message":       (
            "Pipeline encolado. Monitorear vía SSE "
            f"/engagements/{engagement_id}/pipeline-runs/stream."
        ),
    }


@router.get("/engagements/{engagement_id}/pipeline-runs", tags=["pipeline"])
async def get_engagement_pipeline_runs(
    engagement_id: int,
    limit: int = Query(50, ge=1, le=200),
):
    """Lista de pipeline runs del engagement, ordenados desc por started_at."""
    runs = await list_pipelines(engagement_id, limit=limit)
    return {"engagement_id": engagement_id, "total": len(runs), "pipeline_runs": runs}


@router.get("/pipeline-runs/{pipeline_run_id}", tags=["pipeline"])
async def get_single_pipeline_run(pipeline_run_id: str):
    """Detalle de un pipeline run con todas sus stages."""
    doc = await get_pipeline(pipeline_run_id)
    if not doc:
        raise HTTPException(status_code=404, detail=f"PipelineRun {pipeline_run_id} no encontrado")
    return doc


@router.get("/engagements/{engagement_id}/pipeline-runs/stream", tags=["pipeline"])
async def stream_pipeline_runs(engagement_id: int, request: Request):
    """
    SSE: emite el pipeline más reciente cada ~1.5s mientras esté activo.
    Cierra cuando el pipeline pasa a status terminal.
    """
    async def event_generator():
        last_payload: Optional[str] = None
        terminal_emitted = False

        yield "event: hello\ndata: {}\n\n"

        while True:
            if await request.is_disconnected():
                break

            doc = await get_latest_pipeline(engagement_id)
            payload = (
                json.dumps({"status": "idle", "engagement_id": engagement_id})
                if doc is None else json.dumps(doc, default=str)
            )

            if payload != last_payload:
                yield f"event: pipeline\ndata: {payload}\n\n"
                last_payload = payload

            if doc is not None and doc.get("status") in ("completed", "failed", "aborted"):
                if terminal_emitted:
                    yield "event: end\ndata: {}\n\n"
                    break
                terminal_emitted = True

            await asyncio.sleep(1.5)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":     "no-cache",
            "X-Accel-Buffering": "no",
            "Connection":        "keep-alive",
        },
    )
