"""
routers/reports.py — E6 · Reportería (HU-14)
============================================
Generación vía ReporterAgent + listado/descarga de PDFs desde GridFS
(bucket 'reports').
"""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session

import models
from auth import verify_api_key
from database import get_db
from services.pipeline_controller import PipelineController

router = APIRouter()


def _content_disposition(filename: str, fallback: str = "report.pdf") -> str:
    """Arma un header Content-Disposition seguro para nombres no-ASCII.

    Los headers HTTP se codifican en latin-1; los nombres de reporte usan el
    separador em-dash (' — ', U+2014), que NO es latin-1 → enviarlo crudo rompe
    con UnicodeEncodeError (500). RFC 6266: filename ASCII de respaldo +
    filename*=UTF-8'' con el nombre real percent-encoded.
    """
    from urllib.parse import quote

    # Si al quitar lo no-ASCII no queda nada, usamos el fallback. El nombre real
    # (con em-dash/acentos) viaja igual en filename*=UTF-8'' percent-encoded.
    ascii_name = (filename or "").encode("ascii", "ignore").decode("ascii").strip() or fallback
    return f"inline; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(filename or fallback)}"


class ReportRequest(BaseModel):
    """Body opcional de POST /report. `name` = nombre base que el operador asigna
    a los PDFs (técnico y ejecutivo lo comparten con su sufijo de tipo)."""
    name: str | None = None


@router.post("/engagements/{engagement_id}/report", tags=["pipeline"], dependencies=[Depends(verify_api_key)])
async def launch_report(
    engagement_id: int,
    body: ReportRequest = Body(default=ReportRequest()),
    db: Session = Depends(get_db),
):
    """
    Genera los reportes técnico y ejecutivo (HU-14) vía ReporterAgent: narrativa
    por LLM + render determinístico Jinja2/WeasyPrint. Ambos PDFs se guardan en
    GridFS (bucket 'reports'). Descargarlos con GET …/report?type=technical|executive.
    Requiere análisis previo (POST /analysis). Corre por el ejecutor seguro.

    Body opcional `{ "name": "..." }`: nombre base de los PDFs (ej. "Auditoría ACME"
    → "Auditoría ACME — Técnico.pdf" / "Auditoría ACME — Ejecutivo.pdf"). Sin
    nombre, los archivos usan el nombre genérico `eng_{id}_{type}.pdf`.
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    name = (body.name or "").strip() or None
    controller = PipelineController(
        engagement_id=engagement_id, db=db, stages=["ReporterAgent"], report_name=name,
    )
    result = await controller.run()
    return {"message": "Reportes generados", "engagement_id": engagement_id, "report_result": result}


@router.get("/engagements/{engagement_id}/reports", tags=["pipeline"])
async def list_reports(engagement_id: int, db: Session = Depends(get_db)):
    """
    Lista el histórico completo de PDFs generados para el engagement (GridFS,
    bucket 'reports'), del más reciente al más antiguo. Cada entrada incluye
    `file_id` para descargar esa versión específica vía GET …/report?file_id=<id>.
    """
    eng = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not eng:
        raise HTTPException(status_code=404, detail=f"Engagement {engagement_id} no encontrado")

    from mongo_client import get_mongo_db

    db_mongo = get_mongo_db()
    cursor = db_mongo["reports.files"].find(
        {"metadata.engagement_id": engagement_id},
        sort=[("uploadDate", -1)],
    )
    reports = []
    async for f in cursor:
        meta = f.get("metadata") or {}
        reports.append({
            "file_id": str(f["_id"]),
            "filename": f.get("filename"),
            "type": meta.get("type"),
            "length": f.get("length"),
            "upload_date": f.get("uploadDate"),
            "generated_at": meta.get("generated_at"),
            "agent_run_id": meta.get("agent_run_id"),
        })
    return {"engagement_id": engagement_id, "total": len(reports), "reports": reports}


@router.get("/engagements/{engagement_id}/report", tags=["pipeline"])
async def download_report(
    engagement_id: int,
    type: str = Query("technical"),
    file_id: str | None = Query(None),
):
    """
    Descarga un PDF desde GridFS. Sin `file_id` baja el más reciente del tipo
    pedido (technical|executive); con `file_id` baja esa versión específica
    (el histórico se obtiene en GET …/reports).
    """
    from bson import ObjectId
    from bson.errors import InvalidId
    from motor.motor_asyncio import AsyncIOMotorGridFSBucket
    from fastapi.responses import Response
    from mongo_client import get_mongo_db

    db_mongo = get_mongo_db()

    if file_id is not None:
        try:
            oid = ObjectId(file_id)
        except InvalidId:
            raise HTTPException(status_code=422, detail=f"file_id '{file_id}' no es un ObjectId válido")
        doc = await db_mongo["reports.files"].find_one(
            {"_id": oid, "metadata.engagement_id": engagement_id},
        )
        if not doc:
            raise HTTPException(
                status_code=404,
                detail=f"No existe el reporte {file_id} para el engagement {engagement_id}.",
            )
    else:
        if type not in ("technical", "executive"):
            raise HTTPException(status_code=422, detail="type debe ser 'technical' o 'executive'")
        doc = await db_mongo["reports.files"].find_one(
            {"metadata.engagement_id": engagement_id, "metadata.type": type},
            sort=[("uploadDate", -1)],
        )
        if not doc:
            raise HTTPException(
                status_code=404,
                detail=f"No hay reporte '{type}' para el engagement {engagement_id}. Ejecutar POST /report primero.",
            )

    bucket = AsyncIOMotorGridFSBucket(db_mongo, bucket_name="reports")
    stream = await bucket.open_download_stream(doc["_id"])
    data = await stream.read()
    filename = doc.get("filename") or f"eng_{engagement_id}_{(doc.get('metadata') or {}).get('type', 'report')}.pdf"
    return Response(
        content=data,
        media_type="application/pdf",
        headers={"Content-Disposition": _content_disposition(filename, f"eng_{engagement_id}_report.pdf")},
    )
