"""
routers/scope.py — E1 · Scope targets (HU-01, HU-02)
====================================================
CRUD de scope targets + validación de target contra el scope.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

import models
import schemas
from database import get_db
from models import EngagementStatus
from services import scope_validator

router = APIRouter()


@router.get("/engagements/{engagement_id}/scope", tags=["scope"])
def get_scopes(engagement_id: int, db: Session = Depends(get_db)):
    scopes = (
        db.query(models.ScopeTarget)
        .filter(models.ScopeTarget.engagement_id == engagement_id)
        .all()
    )
    return {"message": f"{len(scopes)} objetivos", "data": scopes}


@router.post("/engagements/{engagement_id}/scope", tags=["scope"])
def add_scope_target(engagement_id: int, scope: schemas.ScopeCreate, db: Session = Depends(get_db)):
    engagement = db.query(models.Engagement).filter(models.Engagement.id == engagement_id).first()
    if not engagement:
        engagement = models.Engagement(
            id=engagement_id, name=f"Analisis #{engagement_id}", status=EngagementStatus.PENDING,
        )
        db.add(engagement)
        db.commit()
    db_scope = models.ScopeTarget(
        engagement_id=engagement_id,
        target_value=scope.target_value,
        target_type=scope.target_type.upper(),
    )
    db.add(db_scope)
    db.commit()
    db.refresh(db_scope)
    return {"message": "Objetivo guardado", "data": db_scope}


@router.delete("/engagements/{engagement_id}/scope/{target_id}", tags=["scope"])
def delete_scope_target(engagement_id: int, target_id: int, db: Session = Depends(get_db)):
    target = db.query(models.ScopeTarget).filter(
        models.ScopeTarget.id == target_id,
        models.ScopeTarget.engagement_id == engagement_id,
    ).first()
    if not target:
        raise HTTPException(status_code=404, detail="Objetivo no encontrado")
    db.delete(target)
    db.commit()
    return {"message": "Objetivo eliminado"}


@router.get("/engagements/{engagement_id}/validate", tags=["scope"])
def validate_target(engagement_id: int, target: str, db: Session = Depends(get_db)):
    """Verifica si un target esta autorizado en el scope del engagement. (HU-02)"""
    is_valid = scope_validator.is_target_in_scope(target, engagement_id, db)
    return {
        "target": target,
        "engagement_id": engagement_id,
        "status": "AUTORIZADO" if is_valid else "DENEGADO",
        "in_scope": is_valid,
    }
