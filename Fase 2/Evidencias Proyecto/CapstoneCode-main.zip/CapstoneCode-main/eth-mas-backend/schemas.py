from __future__ import annotations

from datetime import datetime
from typing import Any, List, Optional

from pydantic import BaseModel, Field, model_validator
import ipaddress
import re

# ── Utilidades de validación de targets ──────────────────────────────────────

DOMAIN_REGEX = re.compile(
    r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
)

# Conjunto canónico de tipos de target. Se acepta cualquier case en input
# (fix B-4 auditoría 2026-05-19) y se normaliza a lowercase aquí.
VALID_TARGET_TYPES: set[str] = {"ip", "cidr", "domain"}


def _validate_target_value(target_value: str, target_type: str) -> None:
    """Valida el valor del target. Asume target_type YA normalizado a lowercase."""
    if target_type == "ip":
        try:
            ipaddress.ip_address(target_value)
        except ValueError:
            raise ValueError("Formato de IP inválido")
    elif target_type == "cidr":
        try:
            ipaddress.ip_network(target_value, strict=False)
        except ValueError:
            raise ValueError("Formato CIDR inválido")
    elif target_type == "domain":
        if not DOMAIN_REGEX.match(target_value):
            raise ValueError("Formato de dominio inválido")
    else:
        raise ValueError("target_type debe ser ip, cidr o domain")


# ── Scope ─────────────────────────────────────────────────────────────────────

class ScopeCreate(BaseModel):
    target_value: str
    target_type: str

    @model_validator(mode="after")
    def validate_target(self):
        # B-4: aceptar "IP"/"Ip"/"ip" indistintamente. Lo guardamos en lowercase
        # aquí; el código que escribe a la BD lo pasa a uppercase para casar con
        # el enum nombres (TargetType.IP, TargetType.CIDR, TargetType.DOMAIN).
        normalized = (self.target_type or "").strip().lower()
        if normalized not in VALID_TARGET_TYPES:
            raise ValueError(
                f"target_type debe ser uno de {sorted(VALID_TARGET_TYPES)} "
                f"(case-insensitive), recibido: {self.target_type!r}"
            )
        # Pydantic v2: asignación dentro del validator NO refresca el modelo a
        # menos que mutemos __dict__. Hacemos object.__setattr__ para sortear el
        # frozen-check si lo hubiera y dejar el valor normalizado.
        object.__setattr__(self, "target_type", normalized)
        _validate_target_value(self.target_value, normalized)
        return self


class ScopeResponse(BaseModel):
    id: int
    engagement_id: int
    target_value: str
    target_type: str
    created_at: datetime

    model_config = {"from_attributes": True}


# ── ROE ───────────────────────────────────────────────────────────────────────

class ROE(BaseModel):
    # `time_windows` quedó deprecado (S4, 2026-06-17): generaba confusión y nunca
    # se aplicaba en enforcement. La ejecución ocurre cuando el operador inicia el
    # pipeline. Pydantic v2 ignora el campo si llega de un engagement legacy.
    scan_intensity: str = "MODERATE"
    excluded_paths: List[str] = []
    max_requests_per_second: int = 50
    auto_approve_hitl_below: str = "LOW"
    notification_email: Optional[str] = None


# ── Engagement ────────────────────────────────────────────────────────────────

class EngagementCreate(BaseModel):
    name: str = Field(default="Nuevo Análisis", min_length=1, max_length=200)
    description: Optional[str] = None
    client_name: Optional[str] = None
    scope_targets: List[ScopeCreate] = Field(default_factory=list)
    roe: Optional[ROE] = None
    att_tactics: Optional[List[str]] = None

    @model_validator(mode="after")
    def validate_scope(self):
        seen = set()
        for t in self.scope_targets:
            key = (t.target_value, t.target_type)
            if key in seen:
                raise ValueError(f"Target duplicado: {t.target_value}")
            seen.add(key)
        return self


class EngagementStatusUpdate(BaseModel):
    status: str
    notes: Optional[str] = None


class EngagementResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    client_name: Optional[str]
    status: str
    roe: Optional[Any]
    att_tactics: Optional[Any]
    created_at: datetime
    updated_at: Optional[datetime]
    scopes: List[ScopeResponse] = []

    model_config = {"from_attributes": True}


class EngagementSummary(BaseModel):
    id: int
    name: str
    client_name: Optional[str]
    status: str
    created_at: datetime
    updated_at: Optional[datetime]
    scope_count: int = 0

    model_config = {"from_attributes": True}


# ── HITL Actions ──────────────────────────────────────────────────────────────

class HitlActionCreate(BaseModel):
    engagement_id: int
    agent: str
    tool: str
    risk_level: str
    params: Optional[Any] = None


class HitlDecision(BaseModel):
    decision: str
    operator: str
    notes: Optional[str] = None


class HitlActionResponse(BaseModel):
    id: int
    engagement_id: int
    agent: str
    tool: str
    risk_level: str
    params: Optional[Any]
    decision: Optional[str]
    operator: Optional[str]
    notes: Optional[str]
    requested_at: datetime
    decided_at: Optional[datetime]

    model_config = {"from_attributes": True}
