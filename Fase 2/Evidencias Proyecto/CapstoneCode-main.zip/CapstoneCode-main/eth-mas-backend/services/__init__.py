"""
services — paquete de servicios del backend ETH-MAS.

Este __init__ se mantiene intencionalmente vacío.

Razón: previamente este archivo era una copia literal (279 líneas) de
`enforce_scope.py`, lo que creaba clases duplicadas en dos namespaces
(`services.ScopeViolationError` ≠ `services.enforce_scope.ScopeViolationError`)
y rompía `isinstance` checks de forma silenciosa. Ver auditoría 2026-05-19, hallazgo C-1.

Convención: importar siempre desde el submódulo concreto, p. ej.:
    from services.scope_validator import is_target_in_scope
    from services.recon_agent     import ReconAgent
"""
