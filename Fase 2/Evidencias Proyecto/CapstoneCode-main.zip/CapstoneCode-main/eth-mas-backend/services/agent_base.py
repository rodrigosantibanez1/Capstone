"""
agent_base.py — Contrato común de agentes · ETH-MAS (Bloque 0, ADR-005)
=======================================================================
Fuente de verdad de las interfaces que comparten los 4 workers y el
orquestador. **Todos los bloques (A/B/C/D/E) codean contra esto.** Cualquier
cambio a estos contratos = PR revisado por el equipo (regla anti-divergencia
del plan de bloques).

Dependencias permitidas: pydantic + schemas.ROE. NO importar models/services a
nivel de módulo (evitar import cycles); el builder de contexto importa de forma
perezosa.

Contiene:
  - ScopeItem            → un target del scope, serializable
  - AgentContext         → entrada de run(): goal + contexto + presupuesto
  - AgentResult          → salida de run(): status + rationale (obligatorio) + artefactos
  - BaseAgent (ABC)      → interfaz que implementan ReconAgent/ScanAgent/AnalysisAgent/ReporterAgent
  - AGENT_TOOL_SCHEMAS   → interfaz "agent-as-tool" que usa el Orquestador (Bloque A)
  - build_agent_context  → arma un AgentContext desde la BD + blackboard (helper común)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

from schemas import ROE


# ── Estados terminales/parciales de un agente ─────────────────────────────────
# Alineados con lo que ya devuelven ScanAgent/ReconAgent hoy, más "partial".
AgentStatus = Literal[
    "completed",     # terminó su objetivo
    "waiting_hitl",  # pausado esperando aprobación humana (no es falla)
    "partial",       # avanzó pero no completó (presupuesto agotado, datos faltantes)
    "failed",        # error no recuperable
    "aborted",       # cancelado (operador / shutdown)
    "skipped",       # no había nada que hacer (ej. sin scope, sin findings)
]

# Nombres canónicos de los agentes. Únicos en todo el sistema.
RECON_AGENT    = "ReconAgent"
SCAN_AGENT     = "ScanAgent"
ANALYSIS_AGENT = "AnalysisAgent"
REPORTER_AGENT = "ReporterAgent"
AGENT_NAMES = (RECON_AGENT, SCAN_AGENT, ANALYSIS_AGENT, REPORTER_AGENT)


# ── ScopeItem ─────────────────────────────────────────────────────────────────

class ScopeItem(BaseModel):
    """Un target autorizado del engagement. Espejo serializable de
    models.ScopeTarget (sin acoplar agent_base a SQLAlchemy)."""
    target_value: str
    target_type: str  # "ip" | "cidr" | "domain" (lowercase, igual que schemas)


# ── AgentContext ──────────────────────────────────────────────────────────────

class AgentContext(BaseModel):
    """
    Entrada de `BaseAgent.run()`. Reemplaza el patrón actual donde cada agente
    lee el scope de la BD por su cuenta y hardcodea params. Acá el agente recibe
    un OBJETIVO y el contexto necesario para DECIDIR (ADR-005 §3.1).
    """
    engagement_id: int
    goal: str                                  # objetivo en lenguaje natural, NO un checklist
    scope: list[ScopeItem] = Field(default_factory=list)
    roe: ROE = Field(default_factory=ROE)
    prior_state: dict[str, Any] = Field(default_factory=dict)  # lectura del blackboard
    # Presupuestos: cota dura para que el loop agéntico no se vaya de mambo.
    budget_steps: int = 12                      # máx iteraciones tool-use del loop
    budget_tokens: int = 200_000                # cota informativa de tokens
    # Sobreescritura opcional del operador ("modo sigiloso", "foco en la web app").
    operator_directive: Optional[str] = None
    # Nombre base que el operador asigna al reporte (solo lo usa el ReporterAgent).
    report_name: Optional[str] = None

    def targets(self) -> list[str]:
        """Shortcut: lista de target_value (lo que la mayoría de tools necesita)."""
        return [s.target_value for s in self.scope]


# ── AgentResult ───────────────────────────────────────────────────────────────

class AgentResult(BaseModel):
    """
    Salida de `BaseAgent.run()`. El `rationale` es OBLIGATORIO (ADR-005 §3.1):
    explica POR QUÉ el agente hizo lo que hizo. Es lo que consume el orquestador
    para decidir el siguiente paso y lo que hace el sistema auditable/defendible.
    """
    agent: str
    status: AgentStatus
    rationale: str                              # NL — obligatorio, no vacío
    findings_count: int = 0
    artifacts: dict[str, Any] = Field(default_factory=dict)   # surface_map / analysis / report_path / ...
    pending_hitl_ids: list[int] = Field(default_factory=list)
    budget_used: dict[str, int] = Field(default_factory=dict)  # {"steps": n, "tokens": n}
    error: Optional[str] = None

    model_config = {"extra": "forbid"}


# ── BaseAgent ─────────────────────────────────────────────────────────────────

class BaseAgent(ABC):
    """
    Interfaz común de los 4 workers. Constructor alineado con los agentes
    actuales (engagement_id, db, pipeline_run_id) para que el refactor del
    Bloque D sea mínimo.

    NUEVO respecto a hoy: `run()` recibe un AgentContext (objetivo + estado) y
    devuelve un AgentResult (con rationale). El executor seguro (Bloque E) arma
    el contexto y llama a run(ctx).
    """

    #: nombre canónico del agente (uno de AGENT_NAMES). Lo setea cada subclase.
    name: str = "BaseAgent"

    def __init__(self, engagement_id: int, db: Any, pipeline_run_id: Optional[str] = None):
        self.engagement_id = engagement_id
        self.db = db
        self.pipeline_run_id = pipeline_run_id

    @abstractmethod
    async def run(self, ctx: AgentContext) -> AgentResult:
        """Ejecuta el agente sobre el contexto dado y devuelve su resultado."""
        raise NotImplementedError


# ── Interfaz agent-as-tool (la usa el Orquestador, Bloque A) ──────────────────
# El Orquestador (LLM) invoca a cada worker como si fuera una tool. Este es el
# input_schema canónico. El retorno de la "tool" es un AgentResult serializado.
# Mantener estos nombres ESTABLES: el Orquestador y el executor dependen de ellos.

def _agent_tool_schema(tool_name: str, agent_name: str, extra_props: dict) -> dict:
    props = {
        "engagement_id": {"type": "integer", "description": "ID del engagement activo."},
        "goal": {"type": "string", "description": f"Objetivo en lenguaje natural para {agent_name}."},
        **extra_props,
    }
    return {
        "name": tool_name,
        "description": f"Delega en {agent_name}. Devuelve un AgentResult (status + rationale + artefactos).",
        "input_schema": {
            "type": "object",
            "properties": props,
            "required": ["engagement_id", "goal"],
        },
    }


AGENT_TOOL_SCHEMAS: dict[str, dict] = {
    RECON_AGENT: _agent_tool_schema(
        "run_recon_agent", RECON_AGENT, {},
    ),
    SCAN_AGENT: _agent_tool_schema(
        "run_scan_agent", SCAN_AGENT,
        {"intensity": {
            "type": "string",
            "enum": ["STEALTH", "MODERATE", "AGGRESSIVE"],
            "description": "Override opcional de ROE.scan_intensity para esta corrida.",
        }},
    ),
    ANALYSIS_AGENT: _agent_tool_schema(
        "run_analysis_agent", ANALYSIS_AGENT, {},
    ),
    REPORTER_AGENT: _agent_tool_schema(
        "run_reporter_agent", REPORTER_AGENT,
        {"report_type": {
            "type": "string",
            "enum": ["technical", "executive"],
            "description": "Tipo de reporte a generar.",
        }},
    ),
}

#: nombre-de-tool → nombre-de-agente (lo inverso, para que el Orquestador
#: mapee el tool_use que eligió Claude al agente concreto que debe ejecutar).
TOOL_NAME_TO_AGENT: dict[str, str] = {
    schema["name"]: agent_name for agent_name, schema in AGENT_TOOL_SCHEMAS.items()
}


# ── build_agent_context — helper común (anti-divergencia) ─────────────────────

async def build_agent_context(
    db: Any,
    engagement_id: int,
    goal: str,
    *,
    budget_steps: int = 12,
    budget_tokens: int = 200_000,
    operator_directive: Optional[str] = None,
    prior_state_keys: tuple[str, ...] = ("surface_map", "findings", "analysis"),
) -> AgentContext:
    """
    Arma un AgentContext desde la BD (scope + ROE) y el blackboard (estado previo).
    Todos los bloques deben usar este helper para construir contextos de la misma
    forma (evita que cada quien lo haga distinto y diverja).

    Imports perezosos: mantiene agent_base sin dependencias de carga de models/
    blackboard (evita import cycles).
    """
    import models
    from services.blackboard import read_state

    rows = (
        db.query(models.ScopeTarget)
        .filter(models.ScopeTarget.engagement_id == engagement_id)
        .all()
    )
    scope = [
        ScopeItem(
            target_value=r.target_value,
            target_type=(r.target_type.value if hasattr(r.target_type, "value") else str(r.target_type)).lower(),
        )
        for r in rows
    ]

    eng = (
        db.query(models.Engagement)
        .filter(models.Engagement.id == engagement_id)
        .first()
    )
    roe = ROE(**eng.roe) if (eng and isinstance(eng.roe, dict)) else ROE()

    prior_state = await read_state(engagement_id, include=prior_state_keys)

    return AgentContext(
        engagement_id=engagement_id,
        goal=goal,
        scope=scope,
        roe=roe,
        prior_state=prior_state,
        budget_steps=budget_steps,
        budget_tokens=budget_tokens,
        operator_directive=operator_directive,
    )
