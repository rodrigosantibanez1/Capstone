"""
agent_config.py — Tiering de modelos por agente · ETH-MAS (Bloque 0, ADR-005)
=============================================================================
Fuente única de los modelos LLM que usa cada componente. Centraliza lo que hoy
está disperso (scan_agent.py / recon_agent.py definen su modelo por su cuenta).

Reconciliación pendiente (CLAUDE.md §4.1): el doc declara Opus 4.7 como modelo
de producción, pero el `.env` corre Haiku. El ADR-005 §3.5 fija el tiering
RECOMENDADO; este módulo lo expone vía env para que el equipo lo active sin
tocar código una vez confirmados los IDs de modelo disponibles.

IMPORTANTE — defaults SEGUROS: para garantizar que el stack arranque en
cualquier máquina, el fallback de TODOS los agentes es el modelo "fast" probado
(Haiku). Para activar la agencia real (ADR-005), setear en `.env` los modelos de
razonamiento:

    ORCHESTRATOR_MODEL=<modelo-opus>
    ANALYSIS_MODEL=<modelo-opus>
    SCAN_AGENT_MODEL=<modelo-sonnet>
    REPORTER_MODEL=<modelo-sonnet>
    # RECON_AGENT_MODEL puede quedarse en el fast por defecto

No inventamos IDs de Opus/Sonnet aquí para no romper llamadas a la API con un
string inválido: esa elección es del equipo (decisión §4.1 diferida).
"""

from __future__ import annotations

import os

# Modelo "fast" probado en runtime (único confirmado funcionando en el proyecto).
FAST_MODEL_DEFAULT: str = "claude-haiku-4-5-20251001"

# Tiering RECOMENDADO (ADR-005 §3.5) — referencia/documentación. NO se aplica
# como default automático (ver nota del módulo). El equipo lo activa por env.
RECOMMENDED_TIERING: dict[str, str] = {
    "ORCHESTRATOR_MODEL": "opus     (planificación + diálogo con el operador)",
    "ANALYSIS_MODEL":     "opus     (razonamiento de explotabilidad / kill chains)",
    "SCAN_AGENT_MODEL":   "sonnet   (decisión adaptativa de scan)",
    "REPORTER_MODEL":     "sonnet   (redacción de narrativa)",
    "RECON_AGENT_MODEL":  "haiku    (tarea mecánica)",
}


def _model(env_var: str, default: str = FAST_MODEL_DEFAULT) -> str:
    """Lee el modelo de un env var con fallback seguro."""
    return os.getenv(env_var, default)


def orchestrator_model() -> str:
    return _model("ORCHESTRATOR_MODEL")


def analysis_model() -> str:
    return _model("ANALYSIS_MODEL")


def scan_agent_model() -> str:
    # Reusa el env var ya existente (scan_agent.py lo lee hoy) → migración fluida.
    return _model("SCAN_AGENT_MODEL")


def recon_agent_model() -> str:
    return _model("RECON_AGENT_MODEL")


def reporter_model() -> str:
    return _model("REPORTER_MODEL")


def model_for(agent_name: str) -> str:
    """Resuelve el modelo dado el nombre canónico del agente (AGENT_NAMES)."""
    return {
        "ReconAgent":    recon_agent_model(),
        "ScanAgent":     scan_agent_model(),
        "AnalysisAgent": analysis_model(),
        "ReporterAgent": reporter_model(),
    }.get(agent_name, FAST_MODEL_DEFAULT)


# ── Compatibilidad del parámetro `temperature` ───────────────────────────────
# Los modelos más nuevos (Opus 4.8, Fable 5) DEPRECARON el parámetro
# `temperature`: la API de Anthropic responde 400 "temperature is deprecated for
# this model" si se envía. Los modelos "fast/mid" (Haiku 4.5, Sonnet 4.x) todavía
# lo aceptan. Prefijos de modelo que ya NO aceptan temperature:
_TEMPERATURE_DEPRECATED_PREFIXES: tuple[str, ...] = (
    "claude-opus-4-8",
    "claude-fable-5",
)


def supports_temperature(model: str) -> bool:
    """¿El modelo acepta el parámetro `temperature` en messages.create()?

    Degradación segura: si el modelo está en la lista de deprecados, devolvemos
    False para que el caller OMITA temperature (el modelo usa su default). Omitir
    temperature es inofensivo —el determinismo del mapeo ATT&CK lo garantiza la
    normalización canónica de técnicas, no este parámetro—, mientras que enviarlo
    a un modelo que lo deprecó rompe la llamada con un 400.
    """
    m = (model or "").lower()
    return not any(m.startswith(p) for p in _TEMPERATURE_DEPRECATED_PREFIXES)
