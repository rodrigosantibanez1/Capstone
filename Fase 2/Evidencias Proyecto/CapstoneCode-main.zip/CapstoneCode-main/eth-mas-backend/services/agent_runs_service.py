"""
agent_runs_service.py — Helper de observabilidad de runs de agentes (Capa 1)
============================================================================
Centraliza el ciclo de vida de un AgentRunDoc en MongoDB para que la información
quede visible en tiempo real desde el frontend, en vez de actualizarse solo al
final de la corrida.

Patrón de uso desde un agente:

    run_id = await start_run(engagement_id, "ReconAgent", model, targets)
    try:
        # ... antes de cada tool call ...
        call_idx = await begin_tool_call(run_id, tool="dns_enum", target=t, params={...})
        try:
            # ejecutar tool
            await end_tool_call(run_id, call_idx, status="completed",
                                output_preview=text[:500], duration_ms=ms)
        except Exception as e:
            await end_tool_call(run_id, call_idx, status="error", error=str(e),
                                duration_ms=ms)
    finally:
        await finish_run(run_id, status="completed")

El frontend hace polling/SSE sobre `GET /engagements/{id}/agent-runs` y ve los
ToolCallEntry aparecer en vivo en `tools_called`.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Optional

from bson import ObjectId

from mongo_client import agent_runs_col
from mongo_schemas import AgentRunDoc, ToolCallEntry
from services.narration import narrate_run_start, narrate_tool_start
from utils import utc_now

logger = logging.getLogger(__name__)

# Truncado para mantener docs MongoDB razonables. El raw_output completo se
# guarda en findings_col cuando aplica.
_MAX_OUTPUT_PREVIEW = 500
_MAX_PARAMS_KEYS    = 20


# ── Run lifecycle ─────────────────────────────────────────────────────────────

async def start_run(
    engagement_id: int,
    agent: str,
    model: str,
    targets: list[str],
    pipeline_run_id: Optional[str] = None,
) -> str:
    """
    Crea el AgentRunDoc en status='running' y retorna su _id como string.

    Si el run lo lanza el PipelineController, pasar `pipeline_run_id` para que
    quede vinculado al PipelineRunDoc correspondiente (útil para drill-down y
    para mostrar el run dentro del contexto del pipeline en el frontend).
    """
    doc = AgentRunDoc(
        engagement_id   = engagement_id,
        agent           = agent,
        model           = model,
        targets         = targets,
        pipeline_run_id = pipeline_run_id,
        narration       = narrate_run_start(agent, targets),
    )
    result = await agent_runs_col().insert_one(doc.model_dump())
    run_id = str(result.inserted_id)
    logger.info("[agent_runs] start run_id=%s agent=%s engagement=%d pipeline=%s",
                run_id, agent, engagement_id, pipeline_run_id)
    return run_id


async def finish_run(
    run_id: str,
    status: str,
    error: Optional[str] = None,
    findings_count: Optional[int] = None,
    summary: Optional[str] = None,
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
) -> None:
    """Cierra el run con status final."""
    update: dict[str, Any] = {
        "status":      status,
        "finished_at": utc_now(),
        "updated_at":  utc_now(),
    }
    if error          is not None: update["error"]          = error
    if findings_count is not None: update["findings_count"] = findings_count
    if summary        is not None: update["summary"]        = summary
    if input_tokens   is not None: update["input_tokens"]   = input_tokens
    if output_tokens  is not None: update["output_tokens"]  = output_tokens

    await agent_runs_col().update_one(
        {"_id": ObjectId(run_id)}, {"$set": update}
    )
    logger.info("[agent_runs] finish run_id=%s status=%s", run_id, status)


# ── Tool call lifecycle ───────────────────────────────────────────────────────

def _truncate_params(params: Optional[dict]) -> Optional[dict]:
    """Limita un dict para que no inflame el doc MongoDB."""
    if not params:
        return params
    truncated: dict[str, Any] = {}
    for i, (k, v) in enumerate(params.items()):
        if i >= _MAX_PARAMS_KEYS:
            break
        if isinstance(v, str) and len(v) > 200:
            truncated[k] = v[:200] + "…"
        else:
            truncated[k] = v
    return truncated


async def begin_tool_call(
    run_id: str,
    tool: str,
    target: str,
    params: Optional[dict] = None,
) -> int:
    """
    Inserta una ToolCallEntry en status='running'. Retorna el índice (posición)
    de la entrada en `tools_called` para poder cerrarla con end_tool_call.
    """
    entry = ToolCallEntry(
        tool        = tool,
        target      = target or "",
        status      = "running",
        params      = _truncate_params(params),
        started_at  = utc_now(),
        narration   = narrate_tool_start(tool, target or "", params),
    )
    result = await agent_runs_col().find_one_and_update(
        {"_id": ObjectId(run_id)},
        {
            "$push": {"tools_called": entry.model_dump()},
            "$set":  {"updated_at":   utc_now()},
        },
        return_document=True,  # retorna el doc actualizado
    )
    if not result:
        logger.warning("[agent_runs] begin_tool_call: run_id %s no encontrado", run_id)
        return -1
    # Índice = última posición del array
    return len(result.get("tools_called", [])) - 1


async def end_tool_call(
    run_id: str,
    call_idx: int,
    status: str,
    output_preview: Optional[str] = None,
    error: Optional[str] = None,
    hitl_action_id: Optional[int] = None,
    duration_ms: Optional[int] = None,
) -> None:
    """Actualiza la ToolCallEntry en la posición `call_idx` con su resultado."""
    if call_idx < 0:
        return

    set_fields: dict[str, Any] = {
        f"tools_called.{call_idx}.status":      status,
        f"tools_called.{call_idx}.finished_at": utc_now(),
        "updated_at":                            utc_now(),
    }
    if output_preview is not None:
        set_fields[f"tools_called.{call_idx}.output_preview"] = output_preview[:_MAX_OUTPUT_PREVIEW]
    if error is not None:
        set_fields[f"tools_called.{call_idx}.error"]          = error[:500]
    if hitl_action_id is not None:
        set_fields[f"tools_called.{call_idx}.hitl_action_id"] = hitl_action_id
    if duration_ms is not None:
        set_fields[f"tools_called.{call_idx}.duration_ms"]    = duration_ms

    await agent_runs_col().update_one(
        {"_id": ObjectId(run_id)}, {"$set": set_fields}
    )


# ── Read helpers (usados por endpoints) ───────────────────────────────────────

def _serialize_run(doc: dict) -> dict:
    """Convierte ObjectId y datetime a strings serializables a JSON."""
    if "_id" in doc:
        doc["_id"] = str(doc["_id"])
    for key in ("started_at", "finished_at", "updated_at"):
        v = doc.get(key)
        if isinstance(v, datetime):
            doc[key] = v.isoformat()
    for tc in doc.get("tools_called", []) or []:
        for key in ("started_at", "finished_at"):
            v = tc.get(key)
            if isinstance(v, datetime):
                tc[key] = v.isoformat()
    return doc


async def list_runs(engagement_id: int, limit: int = 50) -> list[dict]:
    """Retorna los runs del engagement ordenados desc por started_at."""
    cursor = (
        agent_runs_col()
        .find({"engagement_id": engagement_id})
        .sort("started_at", -1)
        .limit(limit)
    )
    docs = await cursor.to_list(length=limit)
    return [_serialize_run(d) for d in docs]


async def get_run(run_id: str) -> Optional[dict]:
    """Retorna un run específico con todo su tool_log."""
    doc = await agent_runs_col().find_one({"_id": ObjectId(run_id)})
    return _serialize_run(doc) if doc else None


async def get_latest_run(engagement_id: int) -> Optional[dict]:
    """Atajo: el run más reciente del engagement (running o terminado)."""
    doc = await agent_runs_col().find_one(
        {"engagement_id": engagement_id},
        sort=[("started_at", -1)],
    )
    return _serialize_run(doc) if doc else None
