"""
services/alembic_bootstrap.py — sincroniza Alembic con la realidad de la BD.

Contexto del fix D-2 (auditoría 2026-05-20):
  El backend originalmente arrancaba con `Base.metadata.create_all(engine)`,
  lo que crea las tablas vía SQLAlchemy directamente y NUNCA toca la tabla
  `alembic_version`. Resultado: las migraciones Alembic existen como artefacto
  pero nunca se aplican; cualquier `CheckConstraint` o cambio de schema
  declarado en una migración queda fuera de la BD.

Esta función arregla el bootstrap en tres escenarios:

  1. BD virgen (sin tablas)         → `alembic upgrade head` desde cero.
  2. BD legacy (tablas create_all,  → `alembic stamp head` (marca como
     sin alembic_version)              migrada sin re-ejecutar) y luego
                                       `upgrade head` para migraciones futuras.
  3. BD ya gestionada por Alembic   → `alembic upgrade head` (solo aplica
                                       lo nuevo, idempotente).

Llamar desde el lifespan de FastAPI ANTES de crear las tablas con create_all,
o directamente reemplazando create_all. En esta iteración se llama DESPUÉS
de create_all para mantener compatibilidad: si create_all ya creó las tablas,
detectamos el caso 2 y stampeamos.
"""

from __future__ import annotations

import logging
from pathlib import Path

from sqlalchemy import inspect
from sqlalchemy.engine import Engine

logger = logging.getLogger(__name__)

# Resolver path al alembic.ini (raíz del backend, un nivel arriba de services/).
_ALEMBIC_INI = Path(__file__).resolve().parent.parent / "alembic.ini"


def bootstrap_alembic(engine: Engine) -> str:
    """
    Sincroniza el estado de Alembic con la BD.

    Returns: una etiqueta corta del path tomado, útil para logs/tests.
        "upgrade-virgin"   → BD virgen, se aplicó todas las migraciones.
        "stamp-legacy"     → BD legacy create_all, se marcó head sin ejecutar.
        "upgrade-managed"  → BD ya gestionada, se aplicó solo lo pendiente.
        "skipped"          → Alembic no disponible (libreria ausente).
    """
    try:
        from alembic.config import Config
        from alembic import command
    except ImportError:
        logger.warning("alembic no instalado — bootstrap omitido")
        return "skipped"

    if not _ALEMBIC_INI.exists():
        logger.warning("alembic.ini no encontrado en %s — bootstrap omitido", _ALEMBIC_INI)
        return "skipped"

    inspector = inspect(engine)
    table_names = set(inspector.get_table_names())
    has_alembic_version = "alembic_version" in table_names
    # Usamos engagements como sentinela: si existe, el schema "está poblado".
    has_app_tables = "engagements" in table_names

    cfg = Config(str(_ALEMBIC_INI))
    # Pasarle al config la URL real del engine (sobrescribe sqlalchemy.url y
    # cualquier DATABASE_URL que el env.py haya leído, garantizando consistencia
    # con el engine que ya usa el backend).
    cfg.set_main_option("sqlalchemy.url", str(engine.url))

    if not has_app_tables and not has_alembic_version:
        # Caso 1: BD totalmente virgen → aplicar migraciones desde la base.
        command.upgrade(cfg, "head")
        logger.info("[alembic_bootstrap] BD virgen → upgrade head")
        return "upgrade-virgin"

    if has_app_tables and not has_alembic_version:
        # Caso 2: BD legacy create_all → marcar head sin ejecutar las migraciones
        # existentes (las tablas ya existen). Las próximas migraciones SÍ correrán.
        command.stamp(cfg, "head")
        logger.info("[alembic_bootstrap] BD legacy (create_all) → stamp head")
        return "stamp-legacy"

    # Caso 3: gestionada por Alembic → aplicar lo pendiente.
    command.upgrade(cfg, "head")
    logger.info("[alembic_bootstrap] BD gestionada → upgrade head (idempotente)")
    return "upgrade-managed"
