"""
analysis_agent.py — AnalysisAgent · ETH-MAS Sprint 3 (Bloque B, ADR-005)
========================================================================
Agente de análisis goal-driven. Conforme al contrato BaseAgent (Bloque 0):
recibe un AgentContext y devuelve un AgentResult con rationale.

Qué hace (HU-12 / HU-13):
  1. Lee los findings del engagement desde el blackboard.
  2. Loop agéntico (modelo de analysis_config) sobre el Analysis MCP:
       - cve_lookup            → CVEs reales + CVSS desde NVD (no alucina).
       - attack_technique_lookup → valida/busca técnicas MITRE ATT&CK.
  3. El LLM correlaciona servicio+versión → CVE/CVSS → técnica ATT&CK,
     arma cadenas de ataque (attack_vectors) y prioriza por explotabilidad.
  4. Emite un JSON estructurado final que se persiste:
       - AnalysisDoc en el blackboard (write_analysis),
       - enriquecimiento de cada finding en Mongo (cve_ids/cvss/mitre_technique).

Tools pasivas (risk LOW): no contactan el target, no requieren HITL.
"""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Optional

from services.agent_base import ANALYSIS_AGENT, AgentContext, AgentResult, BaseAgent
from services.agent_config import analysis_model, supports_temperature
from services.agent_runs_service import start_run, finish_run, begin_tool_call, end_tool_call
from services.anthropic_health import mark_anthropic_failure, mark_anthropic_success
from services.blackboard import read_state, write_analysis
from mongo_client import findings_col
from mongo_schemas import AnalysisDoc
from utils import utc_now

logger = logging.getLogger(__name__)

_ANALYSIS_SERVER_SCRIPT = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "mcp_servers", "analysis_server.py")
)

# ── Reconciliación severidad ↔ CVSS (B2) ──────────────────────────────────────
# La severidad de origen la fija el scanner por puerto (classify_severity) y nunca
# se reconciliaba con el CVSS real → un CVE confirmado 9.8 podía quedar 'medium'.
# Acá subimos la severidad a la banda del CVSS *confirmado*, sin bajarla nunca.
_SEVERITY_ORDER = ["info", "low", "medium", "high", "critical"]
_SEVERITY_RANK = {s: i for i, s in enumerate(_SEVERITY_ORDER)}


def _severity_from_cvss(score: float | None) -> str:
    """Banda de severidad CVSS v3 (NVD): 9.0+ critical, 7.0+ high, 4.0+ medium,
    0.1+ low, 0/None info."""
    if score is None:
        return "info"
    if score >= 9.0:
        return "critical"
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    if score > 0:
        return "low"
    return "info"


def _max_severity(a: str | None, b: str | None) -> str:
    """Devuelve la mayor de dos severidades (nunca degrada la observada)."""
    ra = _SEVERITY_RANK.get((a or "info").lower(), 0)
    rb = _SEVERITY_RANK.get((b or "info").lower(), 0)
    return _SEVERITY_ORDER[max(ra, rb)]


# ── Normalización determinística ATT&CK (B5) ──────────────────────────────────
# temperature=0 estabilizó la mayoría del mapeo, pero los findings ambiguos sin
# CVE (telnet, rsh, rutas web) seguían alternando técnica entre corridas. Para
# los servicios/puertos conocidos fijamos la técnica por tabla (normalización
# fina pedida por QA): el mapeo deja de depender del muestreo del LLM. Los puertos
# fuera de la tabla siguen usando la técnica que decidió el LLM.
#   T1190 Exploit Public-Facing Application · T1021 Remote Services
#   T1046 Network Service Discovery        · T1071 Application Layer Protocol
_CANONICAL_TECHNIQUE_BY_PORT: dict[int, str] = {
    21: "T1190", 22: "T1021", 23: "T1021", 25: "T1190", 53: "T1071",
    80: "T1190", 110: "T1190", 111: "T1046", 139: "T1021", 143: "T1190",
    443: "T1190", 445: "T1021", 512: "T1021", 513: "T1021", 514: "T1021",
    1099: "T1190", 1524: "T1190", 2049: "T1046", 2121: "T1190", 3306: "T1190",
    3389: "T1021", 5432: "T1190", 5900: "T1021", 6000: "T1190", 6667: "T1190",
    8009: "T1190", 8080: "T1190", 8180: "T1190",
}

# Servicios de scanner web (sin puerto canónico) → exposición de app pública.
_WEB_TOOLS = {"gobuster", "nikto", "nuclei"}


def _canonical_technique(src: dict) -> str | None:
    """Técnica ATT&CK determinística para un finding de servicio/puerto conocido.
    Devuelve None si no hay mapeo canónico (→ se respeta la decisión del LLM)."""
    ev = src.get("evidence") or {}
    port = src.get("port") or ev.get("port")
    try:
        port = int(port) if port is not None else None
    except (TypeError, ValueError):
        port = None
    if port is not None and port in _CANONICAL_TECHNIQUE_BY_PORT:
        return _CANONICAL_TECHNIQUE_BY_PORT[port]
    if (src.get("tool") or "").lower() in _WEB_TOOLS:
        return "T1190"
    return None


def _normalize_enriched_for_doc(enriched: list[dict],
                                findings: list[dict] | None) -> list[dict]:
    """B5 — determinismo del enriched_findings que se persiste en el AnalysisDoc.

    El loop del LLM (temperature=0) seguía variando la técnica de findings
    ambiguos y, peor, emitía un SUBCONJUNTO distinto cada corrida (p.ej. 26/22/20
    de 38) → la pestaña Analysis y el heatmap cambiaban entre corridas. Esta
    normalización hace dos cosas, alineadas con el override que ya se aplica a los
    findings de Mongo:
      1. Override de `mitre_technique` por la tabla canónica (puerto / web-tool):
         el mapeo deja de depender del muestreo del LLM.
      2. Cobertura completa y ordenada: una entrada por cada finding de origen
         (los que el LLM omitió entran con técnica canónica y sin CVE) → el SET y
         el orden dejan de variar entre corridas.
    Conserva `cve_details`/`note`/etc. del LLM cuando existen para ese ref.
    """
    ef_by_ref: dict[str, dict] = {}
    for ef in (enriched or []):
        ref = ef.get("ref") or ef.get("dedup_key")
        if ref and ref not in ef_by_ref:
            ef_by_ref[ref] = ef

    # Defensivo: sin findings de origen, normaliza la técnica de lo que haya y
    # devuelve ordenado por ref para que el SET/orden sea estable igual.
    if not findings:
        out = []
        for ref in sorted(ef_by_ref):
            ef = dict(ef_by_ref[ref])
            ef["ref"] = ref
            out.append(ef)
        return out

    out: list[dict] = []
    seen: set[str] = set()
    for f in findings:
        ref = f.get("dedup_key") or str(f.get("_id", ""))
        if not ref or ref in seen:
            continue
        seen.add(ref)
        ef = dict(ef_by_ref.get(ref, {}))
        ef["ref"] = ref
        canon = _canonical_technique(f)
        if canon:
            ef["mitre_technique"] = canon
        # sin canónico → se respeta lo que dijo el LLM (ya viene en ef)
        out.append(ef)
    return out


class AnalysisAgent(BaseAgent):
    name = ANALYSIS_AGENT

    def __init__(self, engagement_id: int, db, pipeline_run_id: Optional[str] = None):
        super().__init__(engagement_id, db, pipeline_run_id)
        self.model = analysis_model()
        self._run_id: Optional[str] = None
        self._tool_count = 0

    # ── Entry point (contrato BaseAgent) ──────────────────────────────────────
    async def run(self, ctx: AgentContext) -> AgentResult:
        # 1. Findings desde el blackboard (ctx.prior_state si vino, si no leemos)
        findings = (ctx.prior_state or {}).get("findings")
        if findings is None:
            findings = (await read_state(self.engagement_id, include=("findings",))).get("findings", [])

        if not findings:
            return AgentResult(
                agent=self.name, status="skipped",
                rationale="No hay findings persistidos para analizar. Ejecuta Scan primero.",
            )

        targets = sorted({f.get("target", "") for f in findings if f.get("target")})
        logger.info(
            "[AnalysisAgent] Iniciando — engagement=%d model=%s findings=%d",
            self.engagement_id, self.model, len(findings),
        )

        self._run_id = await start_run(
            engagement_id=self.engagement_id, agent=self.name, model=self.model,
            targets=targets, pipeline_run_id=self.pipeline_run_id,
        )

        status = "completed"
        error_msg: Optional[str] = None
        analysis: dict = {}

        try:
            analysis = await self._run_agentic_loop(findings)
            mark_anthropic_success()
        except Exception as e:  # noqa: BLE001
            from anthropic import APIStatusError
            try:
                from anthropic import AuthenticationError
            except ImportError:
                AuthenticationError = APIStatusError  # type: ignore
            if isinstance(e, AuthenticationError) or (
                isinstance(e, APIStatusError) and getattr(e, "status_code", None) == 401
            ):
                error_msg = "ANTHROPIC_API_KEY inválida o revocada (401)."
                mark_anthropic_failure("401 desde AnalysisAgent")
            else:
                error_msg = str(e)
            logger.error("[AnalysisAgent] Error en loop: %s", e, exc_info=True)
            status = "failed"

        # Persistencia (incluso si el loop terminó parcial)
        enriched = analysis.get("enriched_findings", []) or []
        vectors = analysis.get("attack_vectors", []) or []
        summary = analysis.get("summary") or (error_msg or "Análisis sin resumen.")

        # Había findings de entrada (si no, salimos antes con "skipped") pero el
        # LLM no cerró con análisis estructurado → no es "completed": el operador
        # debe ver el estado parcial en vez de una vista Analysis vacía y en verde.
        if status == "completed" and not enriched:
            status = "partial"
            error_msg = (
                "El agente no emitió análisis estructurado "
                f"(enriched_findings vacío con {len(findings)} findings de entrada)."
            )

        if status != "failed":
            try:
                await self._persist(analysis, enriched, findings)
            except Exception as e:  # noqa: BLE001
                logger.error("[AnalysisAgent] Error persistiendo análisis: %s", e)
                error_msg = error_msg or f"persist: {e}"
                status = "partial"

        rationale = (
            f"Analicé {len(findings)} findings → {len(enriched)} enriquecidos con CVE/ATT&CK, "
            f"{len(vectors)} vector(es) de ataque. {summary[:300]}"
        )

        await finish_run(
            run_id=self._run_id, status=status, error=error_msg,
            summary=f"{self._tool_count} tool calls · {len(enriched)} findings enriquecidos · {len(vectors)} vectores",
        )
        # El rationale NO se auto-registra: va en AgentResult.rationale y lo
        # persiste el ejecutor seguro (PipelineController) — fuente única, sin
        # doble registro (delegación nuevo-contrato, alineado con Recon/Scan).

        return AgentResult(
            agent=self.name,
            status=status if status != "failed" else "failed",
            rationale=rationale,
            findings_count=len(enriched),
            artifacts={"agent_run_id": self._run_id, "attack_vectors": vectors,
                       "priority_order": analysis.get("priority_order", [])},
            error=error_msg,
        )

    # ── Agentic loop ──────────────────────────────────────────────────────────
    async def _run_agentic_loop(self, findings: list[dict]) -> dict:
        from anthropic import AsyncAnthropic
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        server_params = StdioServerParameters(
            command="python", args=[_ANALYSIS_SERVER_SCRIPT], env={**os.environ},
        )

        compact = _compact_findings(findings)

        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                mcp_tools = await session.list_tools()
                anthropic_tools = [
                    {"name": t.name, "description": t.description or "", "input_schema": t.inputSchema}
                    for t in mcp_tools.tools
                ]
                logger.info("[AnalysisAgent] MCP listo — tools: %s", [t["name"] for t in anthropic_tools])

                messages: list[dict] = [{
                    "role": "user",
                    "content": (
                        f"Analiza estos {len(compact)} findings del engagement {self.engagement_id} "
                        f"(engagement_id={self.engagement_id} en cada tool call):\n\n"
                        f"{json.dumps(compact, ensure_ascii=False, indent=1)}\n\n"
                        "Para cada servicio con producto+versión, usa cve_lookup para traer CVEs "
                        "REALES y su CVSS. Valida cada técnica ATT&CK con attack_technique_lookup "
                        "(NO inventes technique_ids ni CVE-IDs). Cuando termines, emite el análisis "
                        "final como un ÚNICO bloque ```json ... ``` con el formato indicado en el system prompt."
                    ),
                }]

                budget = max(6, getattr(self, "_budget_steps", 14))
                final_text = ""
                # Queda True si el loop terminó sin un cierre limpio: budget agotado
                # todavía en tool_use, o respuesta final cortada por max_tokens.
                needs_closing_turn = True
                for _ in range(budget):
                    # temperature=0 estabilizaba el mapeo ATT&CK, pero los modelos
                    # nuevos (Opus 4.8+) deprecaron el parámetro y la API responde
                    # 400 si se envía. Solo lo pasamos cuando el modelo lo acepta;
                    # el determinismo del mapeo ya lo garantiza la normalización
                    # canónica de técnicas (_normalize_enriched_for_doc), no esto.
                    temp_kw = {"temperature": 0} if supports_temperature(self.model) else {}
                    response = await client.messages.create(
                        model=self.model, max_tokens=4096,
                        **temp_kw,
                        system=self._system_prompt(),
                        tools=anthropic_tools, messages=messages,
                    )
                    messages.append({"role": "assistant", "content": response.content})

                    if response.stop_reason == "tool_use":
                        tool_results = []
                        for block in response.content:
                            if block.type != "tool_use":
                                continue
                            t0 = utc_now()
                            tool_input = dict(block.input)
                            call_idx = await begin_tool_call(
                                run_id=self._run_id, tool=block.name,
                                target=str(tool_input.get("product") or tool_input.get("query") or ""),
                                params=tool_input,
                            )
                            self._tool_count += 1
                            try:
                                mcp_result = await session.call_tool(block.name, tool_input)
                                result_text = mcp_result.content[0].text if mcp_result.content else "{}"
                                call_status = "completed"
                                err = None
                            except Exception as e:  # noqa: BLE001
                                result_text = json.dumps({"status": "error", "error": str(e)})
                                call_status = "tool_error"
                                err = str(e)
                            await end_tool_call(
                                run_id=self._run_id, call_idx=call_idx, status=call_status,
                                output_preview=result_text[:500], error=err,
                                hitl_action_id=None,
                                duration_ms=int((utc_now() - t0).total_seconds() * 1000),
                            )
                            tool_results.append({
                                "type": "tool_result", "tool_use_id": block.id, "content": result_text,
                            })
                        messages.append({"role": "user", "content": tool_results})
                    else:
                        final_text = _last_text(response.content)
                        # max_tokens => el JSON final pudo salir truncado
                        needs_closing_turn = response.stop_reason == "max_tokens"
                        break

                analysis = _parse_analysis_json(final_text, findings)
                if needs_closing_turn and not analysis["enriched_findings"]:
                    final_text = await self._force_final_turn(client, anthropic_tools, messages)
                    analysis = _parse_analysis_json(final_text, findings)

        return analysis

    async def _force_final_turn(self, client, anthropic_tools, messages: list[dict]) -> str:
        """
        Turno de cierre sin tools. Se usa cuando el loop agotó el budget todavía
        en tool_use, o cuando la respuesta final salió truncada por max_tokens y
        no se pudo parsear el JSON. Pide el JSON final con tool_choice "none"
        (el modelo no puede seguir llamando tools) y max_tokens más alto.
        """
        closing = (
            "Se acabó el presupuesto de tool calls. NO llames más tools. "
            "Emití AHORA el análisis final COMPLETO como un único bloque "
            "```json ... ``` con el formato del system prompt, usando solo "
            "la evidencia que ya recolectaste."
        )
        last = messages[-1]
        if last["role"] == "assistant":
            # Cierre tras max_tokens: si el assistant quedó con tool_use sin
            # responder, la API exige tool_results antes del siguiente turno.
            pending = [b for b in last["content"] if getattr(b, "type", None) == "tool_use"]
            content: list[dict] = [
                {"type": "tool_result", "tool_use_id": b.id,
                 "content": "(no ejecutado: presupuesto de tool calls agotado)"}
                for b in pending
            ]
            content.append({"type": "text", "text": closing})
            messages.append({"role": "user", "content": content})
        else:
            # Budget agotado: el último mensaje son tool_results. La API exige
            # roles alternados, así que la instrucción va como bloque extra.
            last["content"].append({"type": "text", "text": closing})

        logger.warning(
            "[AnalysisAgent] Loop sin JSON final (budget agotado o max_tokens) — "
            "forzando turno de cierre sin tools (engagement=%d)", self.engagement_id,
        )
        response = await client.messages.create(
            model=self.model, max_tokens=8192,
            system=self._system_prompt(),
            tools=anthropic_tools, tool_choice={"type": "none"},
            messages=messages,
        )
        messages.append({"role": "assistant", "content": response.content})
        return _last_text(response.content)

    # ── Persistencia ──────────────────────────────────────────────────────────
    async def _persist(self, analysis: dict, enriched: list[dict],
                       findings: list[dict] | None = None) -> None:
        # 1. AnalysisDoc (blackboard, upsert 1 por engagement)
        # B5 — el doc guarda el enriched NORMALIZADO (técnica canónica + cobertura
        # completa y ordenada por finding de origen). El loop de gate de CVE más
        # abajo sigue usando el `enriched` crudo del LLM para no perder los
        # cve_details que reportó.
        enriched_doc = _normalize_enriched_for_doc(enriched, findings)
        doc = AnalysisDoc(
            engagement_id=self.engagement_id,
            enriched_findings=enriched_doc,
            attack_vectors=analysis.get("attack_vectors", []) or [],
            priority_order=analysis.get("priority_order", []) or [],
            summary=analysis.get("summary"),
            agent_run_id=self._run_id,
            model_used=self.model,
        )
        written = await write_analysis(self.engagement_id, doc)
        if not written:
            logger.warning(
                "[AnalysisAgent] AnalysisDoc vacío descartado — se conserva el doc "
                "existente con datos (engagement=%d)", self.engagement_id,
            )

        # Índice de findings de origen por ref + enrichment del LLM por ref.
        by_ref: dict[str, dict] = {}
        for f in (findings or []):
            ref = f.get("dedup_key") or str(f.get("_id", ""))
            if ref:
                by_ref[ref] = f
        ef_by_ref: dict[str, dict] = {}
        for ef in enriched:
            ref = ef.get("ref") or ef.get("dedup_key")
            if ref:
                ef_by_ref[ref] = ef

        # 2. Gate de confianza DETERMINÍSTICO sobre TODOS los findings con CVE.
        #    Recorre cada finding de origen (no solo los que el LLM re-procesó):
        #    así un finding con CVE stale del run anterior también queda gateado
        #    (sin esto, lo que el LLM no toca conserva el FP — caso 445 de #24).
        for ref, src in by_ref.items():
            ef = ef_by_ref.get(ref, {})
            # Fuente de los CVE: enrichment del LLM si vino; si no, los que el
            # finding ya tenía persistidos (legacy/stale) para re-gatearlos.
            has_llm_cve = bool(ef.get("cve_details") or ef.get("cve_ids"))
            if has_llm_cve:
                details = _build_cve_details(ef, src)
            elif src.get("cve_ids") or src.get("cve_details"):
                details = _build_cve_details(
                    {"cve_details": src.get("cve_details"),
                     "cve_ids": src.get("cve_ids"),
                     "cvss_score": src.get("cvss_score"),
                     "cvss_source": src.get("cvss_source")},
                    src,
                )
            else:
                details = []

            update: dict = {}
            if details:
                compat = _derive_compat_cve_fields(details)
                update["cve_details"] = details
                update["cve_ids"] = compat["cve_ids"]
                update["cvss_score"] = compat["cvss_score"]   # solo de CVEs confirmed
                update["cvss_source"] = compat["cvss_source"]
                # B2 — reconciliar severidad con el CVSS confirmado (solo subir).
                # Cierra la disonancia "CVSS 9.8 / severity medium" y alimenta el
                # conteo de críticos (B3): un 9.8 confirmado pasa a 'critical'.
                if compat["cvss_score"] is not None:
                    reconciled = _max_severity(
                        src.get("severity"), _severity_from_cvss(compat["cvss_score"])
                    )
                    if reconciled != (src.get("severity") or "info").lower():
                        update["severity"] = reconciled
            # B5 — técnica ATT&CK estable: tabla canónica para servicios conocidos
            # (override determinístico), si no, la que decidió el LLM.
            canon = _canonical_technique(src)
            if canon:
                update["mitre_technique"] = canon
            elif ef.get("mitre_technique"):
                update["mitre_technique"] = ef["mitre_technique"]
            if update:
                await findings_col().update_one(
                    {"engagement_id": self.engagement_id, "dedup_key": ref},
                    {"$set": update},
                )

        # 3. Refinamiento determinístico de findings de scanner web (catch-all /
        #    falsos positivos fuertes de nikto). Corre SIEMPRE, no depende del LLM.
        await self._refine_scanner_findings(findings or [])

    async def _refine_scanner_findings(self, findings: list[dict]) -> None:
        """
        Degrada findings nikto/gobuster no fiables a info + status=false_positive
        + confidence=low cuando:
          - evidence.catchall == True (sonda soft-200 del Security MCP), o
          - el summary matchea una firma de FP fuerte (shell history / home dir =
            web root). Cubre findings legacy escaneados antes de la sonda (#24).
        """
        for f in findings:
            tool = (f.get("tool") or "").lower()
            if tool not in ("nikto", "gobuster"):
                continue
            ev = f.get("evidence") or {}
            summary = (f.get("summary") or f.get("title") or "").lower()
            is_catchall = bool(ev.get("catchall"))
            is_fp_sig = any(s in summary for s in _NIKTO_FP_SIGNATURES)
            if not (is_catchall or is_fp_sig):
                continue
            ref = f.get("dedup_key")
            if not ref:
                continue
            set_doc = {"confidence": "low"}
            # Solo bajamos severidad/estado si era high/medium (no “subimos” nada).
            if (f.get("severity") or "").lower() in ("critical", "high", "medium"):
                set_doc["severity"] = "info"
            if is_fp_sig:
                set_doc["status"] = "false_positive"
            await findings_col().update_one(
                {"engagement_id": self.engagement_id, "dedup_key": ref},
                {"$set": set_doc},
            )

    # ── Prompts ────────────────────────────────────────────────────────────────
    def _system_prompt(self) -> str:
        return (
            "Eres AnalysisAgent del sistema ETH-MAS. Tu objetivo: a partir de findings ya "
            "recolectados, producir un cuadro de riesgo priorizado y con EVIDENCIA REAL.\n\n"
            "REGLAS DURAS:\n"
            "- NUNCA inventes CVE-IDs ni technique_ids. Usa cve_lookup y attack_technique_lookup.\n"
            "- Solo incluye un CVE si vino de cve_lookup. Solo un technique_id si attack_technique_lookup lo validó.\n"
            "- Pasa SIEMPRE el campo 'cpe' del finding a cve_lookup (cve_lookup(cpe=...)). El CPE permite\n"
            "  que NVD haga el match exacto de versión y devuelva solo CVEs aplicables. Si no hay cpe,\n"
            "  usa product+version; si tampoco hay versión, ten en cuenta que el resultado es de BAJA confianza.\n"
            "- NO afirmes que un CVE aplica si no hay versión que lo confirme. Reporta la confianza honesta.\n"
            "- Tus tools son pasivas (no tocan el target).\n\n"
            "CONFIANZA POR CVE (campo 'confidence', usa el 'match_mode' que devuelve cve_lookup):\n"
            "  'confirmed'       → match_mode=cpe_versioned (la versión cae en el rango vulnerable).\n"
            "  'version-unknown' → match_mode=cpe_product (producto coincide, sin versión para confirmar).\n"
            "  'keyword-only'    → match_mode=keyword (solo apareció por texto; NO afirmar que aplica).\n"
            "  El CVSS de cada CVE es el que devolvió cve_lookup para ESE cve_id (no mezcles scores).\n\n"
            "MÉTODO:\n"
            "1. Para cada finding con servicio, llama cve_lookup(cpe=<cpe>) (o product+version si no hay cpe).\n"
            "2. Decide la técnica ATT&CK aplicable y valídala con attack_technique_lookup.\n"
            "3. Construye cadenas de ataque (attack_vectors) encadenando findings cuando tenga sentido.\n"
            "4. Prioriza por explotabilidad: primero CVEs 'confirmed', nunca 'keyword-only'.\n\n"
            "SALIDA FINAL (un único bloque ```json```):\n"
            "{\n"
            '  "summary": "<resumen ejecutivo del riesgo, 2-4 frases>",\n'
            '  "enriched_findings": [\n'
            '    {"ref": "<dedup_key del finding>", "mitre_technique": "T1190",\n'
            '     "cve_details": [\n'
            '       {"cve_id": "CVE-...", "cvss_score": 9.8, "cvss_source": "NVD",\n'
            '        "confidence": "confirmed|version-unknown|keyword-only"}\n'
            "     ], \"note\": \"<por qué>\"}\n"
            "  ],\n"
            '  "attack_vectors": [\n'
            '    {"name": "<nombre>", "steps": ["<paso1>","<paso2>"], "severity": "high",\n'
            '     "refs": ["<dedup_key>"], "mitre_techniques": ["T1190"]}\n'
            "  ],\n"
            '  "priority_order": ["<dedup_key de mayor a menor riesgo>"]\n'
            "}\n"
            "El código aplica un gate final: sin versión, ningún CVE queda 'confirmed'. Sé honesto igual.\n"
            "Usa EXACTAMENTE los dedup_key (campo 'ref') que te di en cada finding."
        )


# ── Gate de confianza CVE (determinístico, en código — fix 2026-06-11) ────────
# El LLM propone CVEs vía cve_lookup, pero la CONFIANZA la decide el código, no
# el prompt (coherente con "validación en código" del proyecto). Tres niveles:
#   confirmed       → la versión del servicio cae en el rango vulnerable (CPE match).
#   version-unknown → producto coincide pero no hay versión para confirmar.
#   keyword-only    → el CVE solo apareció por texto → NO aplicable (se excluye del reporte).

_CONFIDENCE_LEVELS = ("confirmed", "version-unknown", "keyword-only")

# Firmas de falso positivo "fuerte" de nikto: existen por el catch-all (200 a
# toda ruta) de SPAs/proxies, no por un recurso real. Se degradan aunque el scan
# sea previo a la sonda soft-200 (findings legacy como los del engagement #24).
_NIKTO_FP_SIGNATURES = (
    "home directory may be set to the web root",
    "shell history",
    ".bash_history",
    ".sh_history",
)


def _ag_has_concrete_version(version) -> bool:
    return bool(version) and str(version) not in ("*", "-", "")


def _ag_parse_cpe_version(cpe) -> bool:
    """True si el CPE trae versión concreta (cpe:/a:v:p:1.2.3)."""
    if not cpe:
        return False
    c = str(cpe)
    if c.startswith("cpe:2.3:"):
        parts = c.split(":")
        return _ag_has_concrete_version(parts[5] if len(parts) > 5 else None)
    if c.startswith("cpe:/"):
        parts = c[len("cpe:/"):].split(":")
        return _ag_has_concrete_version(parts[3] if len(parts) > 3 else None)
    return False


def _finding_has_version(src: dict) -> bool:
    ev = (src or {}).get("evidence") or {}
    return _ag_has_concrete_version(ev.get("version")) or _ag_parse_cpe_version(ev.get("cpe"))


def _gate_cve_confidence(raw_conf, has_version: bool) -> str:
    """
    Normaliza + acota la confianza de un CVE. Regla dura: sin versión concreta del
    servicio, ningún CVE puede quedar 'confirmed' (se baja a 'version-unknown').
    Una confianza desconocida/None se trata como 'keyword-only' (lo más conservador).
    """
    conf = (raw_conf or "").strip().lower()
    if conf not in _CONFIDENCE_LEVELS:
        conf = "version-unknown" if has_version else "keyword-only"
    if conf == "confirmed" and not has_version:
        conf = "version-unknown"
    return conf


def _build_cve_details(ef: dict, src: dict) -> list[dict]:
    """
    Construye cve_details [{cve_id, cvss_score, cvss_source, confidence}] aplicando
    el gate. Acepta dos formatos del LLM:
      - ef['cve_details'] = [{cve_id, cvss_score, confidence, ...}]  (preferido)
      - ef['cve_ids'] + ef['cvss_score']                            (legacy)
    """
    has_version = _finding_has_version(src)
    details: list[dict] = []

    raw_details = ef.get("cve_details")
    if isinstance(raw_details, list) and raw_details:
        for d in raw_details:
            if not isinstance(d, dict):
                continue
            cid = (d.get("cve_id") or "").strip().upper()
            if not cid:
                continue
            details.append({
                "cve_id": cid,
                "cvss_score": d.get("cvss_score"),
                "cvss_source": d.get("cvss_source", "NVD"),
                "confidence": _gate_cve_confidence(d.get("confidence"), has_version),
            })
    else:
        # Legacy: lista de cve_ids con un único cvss_score. Sin per-CVE info, la
        # confianza se decide solo por si el finding tiene versión.
        base_conf = "version-unknown" if has_version else "keyword-only"
        single_cvss = ef.get("cvss_score")
        for cid in (ef.get("cve_ids") or []):
            cid = (cid or "").strip().upper()
            if not cid:
                continue
            details.append({
                "cve_id": cid,
                "cvss_score": single_cvss,
                "cvss_source": ef.get("cvss_source", "NVD"),
                "confidence": base_conf,
            })
    return details


def _derive_compat_cve_fields(details: list[dict]) -> dict:
    """
    Deriva los campos compat (cve_ids, cvss_score, cvss_source) a partir de
    cve_details. El cvss_score HEADLINE solo proviene de CVEs 'confirmed' (versión
    en rango vulnerable): un CVE no confirmado NO debe pintar el finding como
    alto riesgo en la columna principal. Los version-unknown / keyword-only se
    conservan en cve_details (auditables) y el reporter los muestra/filtra según
    confianza, pero no inflan el cvss_score del finding.
    """
    cve_ids = [d["cve_id"] for d in details]
    confirmed = [d for d in details if d.get("confidence") == "confirmed"
                 and d.get("cvss_score") is not None]
    best = max(confirmed, key=lambda d: d["cvss_score"], default=None)
    return {
        "cve_ids": cve_ids,
        "cvss_score": (best or {}).get("cvss_score"),
        "cvss_source": (best or {}).get("cvss_source") if best else None,
        "cvss_from_cve": (best or {}).get("cve_id") if best else None,
    }


# ── Helpers de módulo (puros, testeables) ─────────────────────────────────────

def _compact_findings(findings: list[dict]) -> list[dict]:
    """Reduce los findings al subset que el LLM necesita para razonar."""
    out = []
    for f in findings:
        ev = f.get("evidence") or {}
        out.append({
            "ref": f.get("dedup_key") or str(f.get("_id", "")),
            "tool": f.get("tool"),
            "target": f.get("target"),
            "title": f.get("summary") or f.get("title"),
            "severity": f.get("severity"),
            "port": f.get("port") or ev.get("port"),
            "service": f.get("service") or ev.get("service"),
            "product": ev.get("product"),
            "version": ev.get("version"),
            # CPE de nmap — pasarlo a cve_lookup permite match exacto por versión.
            "cpe": ev.get("cpe"),
        })
    return out


def _last_text(content) -> str:
    """Extrae el texto del último bloque de texto de una respuesta Anthropic."""
    texts = [b.text for b in content if getattr(b, "type", None) == "text"]
    return texts[-1] if texts else ""


def _parse_analysis_json(text: str, findings: list[dict]) -> dict:
    """
    Extrae el JSON del análisis del texto final del LLM. Tolera bloque ```json```
    o un objeto {...} suelto. Si no parsea, devuelve un envelope vacío con summary.
    """
    if not text:
        return {"summary": "El agente no emitió análisis estructurado.",
                "enriched_findings": [], "attack_vectors": [], "priority_order": []}

    block = None
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if m:
        block = m.group(1)
    else:
        # último objeto {...} balanceado de forma simple
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            block = text[start:end + 1]

    if not block:
        return {"summary": text[:300], "enriched_findings": [], "attack_vectors": [], "priority_order": []}

    try:
        data = json.loads(block)
    except json.JSONDecodeError:
        return {"summary": text[:300], "enriched_findings": [], "attack_vectors": [], "priority_order": []}

    data.setdefault("enriched_findings", [])
    data.setdefault("attack_vectors", [])
    data.setdefault("priority_order", [])
    data.setdefault("summary", "")
    return data
