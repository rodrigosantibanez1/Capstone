"""
anthropic_health.py — Validación y monitoreo de ANTHROPIC_API_KEY (Nivel 1)
==========================================================================
Centraliza la lectura, validación y health-check de la API key de Anthropic
para que el backend reporte estado real (no solo "presente") y para que
los agentes fallen con mensajes claros si la key está revocada.

Capas de validación:
  1. format        — chequea prefijo `sk-ant-` (rápido, síncrono, startup)
  2. live          — llamada async `client.models.list()` con timeout 5s
  3. runtime       — los agentes marcan failure si reciben 401 en una llamada

El último resultado se cachea en memoria 10 min para evitar pegarle a
`/v1/models` cada vez que el frontend pollea `/health/services`.

Documentado en docs/api_keys.md — Niveles 2 y 3 (Docker secrets, Admin API)
quedan pendientes para post-Capstone.
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta
from typing import Optional

from utils import utc_now

logger = logging.getLogger(__name__)


# ── Exception domain ─────────────────────────────────────────────────────────

class AnthropicKeyError(RuntimeError):
    """Lanzada cuando la key falta o es estructuralmente inválida."""


# ── Cache in-process (sin Redis para Capstone) ───────────────────────────────

_last_check: Optional[dict] = None
_CACHE_TTL = timedelta(minutes=10)


# ── Reads ─────────────────────────────────────────────────────────────────────

def get_anthropic_key() -> str:
    """Retorna la key. Lanza AnthropicKeyError si falta."""
    key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    if not key:
        raise AnthropicKeyError(
            "ANTHROPIC_API_KEY ausente. Configurar en .env (ver .env.example)."
        )
    return key


def validate_anthropic_key_format(key: Optional[str] = None) -> tuple[bool, str]:
    """
    Validación rápida sin llamar a la API. Útil al startup (sync, ~µs).
    Retorna (ok, reason_or_msg).
    """
    k = key if key is not None else os.getenv("ANTHROPIC_API_KEY", "").strip()
    if not k:
        return False, "key ausente"
    if not k.startswith("sk-ant-"):
        return False, "formato inválido (debe comenzar con 'sk-ant-')"
    if len(k) < 40:
        return False, "key demasiado corta (esperado ≥40 chars)"
    return True, "formato OK"


# ── Live check (llama a Anthropic) ────────────────────────────────────────────

async def check_anthropic_key_live(force: bool = False) -> dict:
    """
    Hace una llamada lightweight a la API para confirmar que la key funciona.
    Cachea el resultado por _CACHE_TTL. Pasar force=True ignora el cache.

    Retorna:
        {
          "valid":         bool,
          "reason":        str | None,
          "checked_at":    datetime (ISO al serializar),
          "models_sample": list[str]   (solo si valid=True)
        }
    """
    global _last_check
    now = utc_now()

    if not force and _last_check and (now - _last_check["checked_at"]) < _CACHE_TTL:
        return _last_check

    key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    if not key:
        _last_check = {"valid": False, "reason": "key ausente", "checked_at": now}
        return _last_check

    ok_fmt, fmt_reason = validate_anthropic_key_format(key)
    if not ok_fmt:
        _last_check = {"valid": False, "reason": fmt_reason, "checked_at": now}
        return _last_check

    try:
        # Import diferido para que el módulo se cargue aunque el SDK no esté.
        from anthropic import AsyncAnthropic
        # Algunas versiones del SDK exportan AuthenticationError, otras solo APIStatusError.
        try:
            from anthropic import AuthenticationError, APIConnectionError, APIStatusError
        except ImportError:
            from anthropic import APIStatusError, APIConnectionError
            AuthenticationError = APIStatusError   # type: ignore

        client = AsyncAnthropic(api_key=key, timeout=5.0)
        # models.list es free y valida auth + conectividad
        resp = await client.models.list(limit=3)
        sample = [m.id for m in (resp.data or [])][:3]
        _last_check = {
            "valid":         True,
            "reason":        None,
            "checked_at":    now,
            "models_sample": sample,
        }
        logger.info("[anthropic_health] key OK — modelos visibles: %s", sample)

    except AuthenticationError as e:                                   # type: ignore
        _last_check = {
            "valid": False,
            "reason": "key inválida o revocada (401)",
            "checked_at": now,
            "detail": str(e)[:200],
        }
        logger.warning("[anthropic_health] 401 — key inválida/revocada")

    except APIConnectionError as e:                                    # type: ignore
        # No invalida la key — es problema de red. Reportar 'unknown'.
        _last_check = {
            "valid": None,
            "reason": "sin conexión a Anthropic (la key NO fue verificada)",
            "checked_at": now,
            "detail": str(e)[:200],
        }
        logger.warning("[anthropic_health] sin conectividad a Anthropic: %s", e)

    except APIStatusError as e:                                        # type: ignore
        _last_check = {
            "valid": False,
            "reason": f"error API Anthropic ({e.status_code})",
            "checked_at": now,
            "detail": str(e)[:200],
        }
        logger.warning("[anthropic_health] status %s: %s", e.status_code, e)

    except ImportError:
        _last_check = {
            "valid": False,
            "reason": "SDK anthropic no instalado",
            "checked_at": now,
        }

    except Exception as e:
        _last_check = {
            "valid": False,
            "reason": f"error inesperado: {type(e).__name__}",
            "checked_at": now,
            "detail": str(e)[:200],
        }
        logger.exception("[anthropic_health] error inesperado")

    return _last_check


def get_cached_anthropic_status() -> dict:
    """
    Último resultado conocido. Si nunca se chequeó, retorna 'unknown'.
    Usado por /health/services para no bloquear cada request.
    """
    if _last_check is None:
        return {"valid": None, "reason": "aún no validada", "checked_at": None}
    return _last_check


def mark_anthropic_failure(reason: str) -> None:
    """
    Llamado por los agentes cuando reciben 401 en runtime.
    Invalida el cache para que /health/services lo refleje inmediatamente.
    """
    global _last_check
    _last_check = {
        "valid":      False,
        "reason":     reason,
        "checked_at": utc_now(),
        "marked_by":  "runtime",
    }
    logger.warning("[anthropic_health] marcada como inválida por runtime: %s", reason)


def mark_anthropic_success() -> None:
    """
    Llamado por los agentes cuando completan una llamada exitosamente.
    Refresca el cache (extiende su validez) sin tener que pegar a /v1/models.
    """
    global _last_check
    if _last_check and _last_check.get("valid") is True:
        # Solo refrescamos el timestamp — no sobreescribir si actualmente está
        # marcado como inválido, eso requiere check_anthropic_key_live(force=True)
        _last_check = {**_last_check, "checked_at": utc_now()}
