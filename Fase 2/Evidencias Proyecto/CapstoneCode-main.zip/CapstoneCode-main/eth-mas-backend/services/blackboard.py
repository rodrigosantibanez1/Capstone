"""
blackboard.py — Estado compartido del engagement · ETH-MAS (Bloque 0, ADR-005)
==============================================================================
El "blackboard" es la working-memory por engagement sobre MongoDB. Resuelve dos
problemas del diseño actual (ADR-005 §1):
  1. los agentes no compartían estado entre fases (recon → scan → analysis),
  2. el agente perdía memoria entre pausas HITL (re-planificaba de cero).

Cada agente LEE lo relevante del blackboard y ESCRIBE su salida aquí. El
Orquestador (Bloque A) lo lee para decidir. Las colecciones se definen en
mongo_client (shortcuts + índices) y mongo_schemas (forma de los docs).

API:
  read_state(engagement_id, include=...)            → dict con surface_map/findings/analysis
  write_analysis(engagement_id, payload)            → upsert (1 doc por engagement;
                                                       un doc vacío no pisa uno con datos)
  record_rationale(engagement_id, agent, rationale) → append (auditoría del 'por qué')
  append_conversation(engagement_id, role, content) → append (chat operador↔orquestador)
  read_conversation(engagement_id, limit=None)      → list[dict] cronológica
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

from pymongo import ASCENDING, DESCENDING

from mongo_client import (
    surface_map_col,
    findings_col,
    analysis_col,
    agent_rationales_col,
    orchestrator_conversation_col,
)
from mongo_schemas import AnalysisDoc, AgentRationaleDoc, ConversationTurnDoc

logger = logging.getLogger(__name__)

#: claves válidas que puede pedir read_state()
STATE_KEYS = ("surface_map", "findings", "analysis")

#: tope por defecto de findings que se cargan al estado (evita payloads enormes)
DEFAULT_FINDINGS_LIMIT = 500


def _clean(doc: Optional[dict]) -> Optional[dict]:
    """Convierte el ObjectId `_id` en string para que el doc sea JSON-serializable.
    No muta el original."""
    if not doc:
        return doc
    out = dict(doc)
    if "_id" in out:
        out["_id"] = str(out["_id"])
    return out


# ── Lectura del estado ────────────────────────────────────────────────────────

async def read_state(
    engagement_id: int,
    include: Iterable[str] = STATE_KEYS,
    *,
    findings_limit: int = DEFAULT_FINDINGS_LIMIT,
) -> dict[str, Any]:
    """
    Devuelve un snapshot del estado del engagement con las claves pedidas.

    Estructura:
        {
          "surface_map": <doc|None>,
          "findings":    <list[doc]>,   # más recientes primero, hasta findings_limit
          "analysis":    <doc|None>,
        }
    Solo se incluyen las claves presentes en `include`.
    """
    include = set(include)
    state: dict[str, Any] = {}

    if "surface_map" in include:
        state["surface_map"] = _clean(
            await surface_map_col().find_one({"engagement_id": engagement_id})
        )

    if "findings" in include:
        cursor = (
            findings_col()
            .find({"engagement_id": engagement_id})
            .sort("discovered_at", DESCENDING)
            .limit(findings_limit)
        )
        state["findings"] = [_clean(d) for d in await cursor.to_list(length=findings_limit)]

    if "analysis" in include:
        state["analysis"] = _clean(
            await analysis_col().find_one({"engagement_id": engagement_id})
        )

    return state


# ── Escritura del análisis (Bloque B) ─────────────────────────────────────────

def _analysis_has_data(doc: Optional[dict]) -> bool:
    """True si el AnalysisDoc tiene contenido estructurado (no solo summary)."""
    if not doc:
        return False
    return bool(
        doc.get("enriched_findings")
        or doc.get("attack_vectors")
        or doc.get("priority_order")
    )


async def write_analysis(engagement_id: int, payload: AnalysisDoc | dict) -> bool:
    """
    Upsert del documento de análisis (1 por engagement). Acepta un AnalysisDoc o
    un dict ya validado. `engagement_id` del argumento manda sobre el del payload.

    Guard anti-clobbering: un doc SIN contenido estructurado (sin enriched_findings,
    attack_vectors ni priority_order) nunca pisa un doc existente que sí lo tiene —
    una re-corrida del AnalysisAgent que no cerró su JSON no debe vaciar la vista
    Analysis. Devuelve True si escribió, False si conservó el doc existente.
    """
    if isinstance(payload, AnalysisDoc):
        doc = payload.model_dump()
    else:
        doc = dict(payload)
    doc["engagement_id"] = engagement_id

    if not _analysis_has_data(doc):
        existing = await analysis_col().find_one({"engagement_id": engagement_id})
        if _analysis_has_data(existing):
            logger.warning(
                "[blackboard] write_analysis: AnalysisDoc vacío para engagement=%d "
                "— se conserva el doc existente con datos (anti-clobbering)",
                engagement_id,
            )
            return False

    await analysis_col().replace_one(
        {"engagement_id": engagement_id}, doc, upsert=True
    )
    return True


# ── Rationales (auditoría del 'por qué') ──────────────────────────────────────

async def record_rationale(
    engagement_id: int,
    agent: str,
    rationale: str,
    *,
    status: Optional[str] = None,
    run_id: Optional[str] = None,
    pipeline_run_id: Optional[str] = None,
) -> None:
    """Append de un rationale de agente. Append-only (no upsert): cada corrida
    deja su huella para auditoría y para el contexto del Orquestador."""
    doc = AgentRationaleDoc(
        engagement_id=engagement_id,
        agent=agent,
        rationale=rationale,
        status=status,
        run_id=run_id,
        pipeline_run_id=pipeline_run_id,
    ).model_dump()
    await agent_rationales_col().insert_one(doc)


async def read_rationales(engagement_id: int, limit: int = 50) -> list[dict]:
    """Últimos rationales del engagement, más recientes primero."""
    cursor = (
        agent_rationales_col()
        .find({"engagement_id": engagement_id})
        .sort("created_at", DESCENDING)
        .limit(limit)
    )
    return [_clean(d) for d in await cursor.to_list(length=limit)]


# ── Conversación operador↔orquestador (Bloque A) ──────────────────────────────

async def append_conversation(
    engagement_id: int,
    role: str,
    content: str,
    *,
    meta: Optional[dict] = None,
) -> None:
    """Append de un turno de conversación. role ∈ {operator, orchestrator, system}."""
    doc = ConversationTurnDoc(
        engagement_id=engagement_id,
        role=role,
        content=content,
        meta=meta,
    ).model_dump()
    await orchestrator_conversation_col().insert_one(doc)


async def read_conversation(engagement_id: int, limit: Optional[int] = None) -> list[dict]:
    """Conversación en orden cronológico (ascendente). `limit` recorta a los N
    turnos más recientes pero los devuelve igualmente en orden cronológico."""
    if limit is None:
        cursor = (
            orchestrator_conversation_col()
            .find({"engagement_id": engagement_id})
            .sort("created_at", ASCENDING)
        )
        return [_clean(d) for d in await cursor.to_list(length=None)]

    # Traer los N más recientes y reordenar ascendente.
    cursor = (
        orchestrator_conversation_col()
        .find({"engagement_id": engagement_id})
        .sort("created_at", DESCENDING)
        .limit(limit)
    )
    recent = [_clean(d) for d in await cursor.to_list(length=limit)]
    return list(reversed(recent))
