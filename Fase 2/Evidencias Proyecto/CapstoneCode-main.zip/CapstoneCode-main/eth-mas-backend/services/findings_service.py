"""
findings_service.py — Normalización y persistencia de findings de ScanAgent
===========================================================================
Responsabilidades:
  1. normalize_nmap_findings()      → dict canónico desde raw nmap output
  2. normalize_gobuster_findings()  → dict canónico desde raw gobuster output
  3. normalize_nuclei_findings()    → dict canónico desde raw nuclei JSONL output
  4. classify_severity()            → severidad basada en puerto/servicio conocidos
  5. persist_finding()              → inserta un FindingDoc en MongoDB (async)
  6. persist_findings_bulk()        → inserta muchos findings de una vez (async)

HU-07: Los findings normalizados DEBEN persistirse en MongoDB findings_col.
HU-08: El endpoint GET /findings consulta esta colección.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any

from pymongo import UpdateOne

from mongo_client import findings_col
from mongo_schemas import FindingDoc


# ── Puertos de alto riesgo conocidos ─────────────────────────────────────────

_HIGH_RISK_PORTS: set[int] = {
    21,    # FTP — credenciales en texto plano
    23,    # Telnet — credenciales en texto plano
    25,    # SMTP sin auth
    110,   # POP3
    111,   # RPCBind
    135,   # MSRPC
    139,   # NetBIOS
    445,   # SMB — vector crítico (EternalBlue, etc.)
    512,   # rexec
    513,   # rlogin
    514,   # rsh
    1099,  # Java RMI
    2049,  # NFS
    3306,  # MySQL
    5432,  # PostgreSQL
    5900,  # VNC
    6379,  # Redis sin auth
    8009,  # AJP (Apache JServ — Ghostcat)
    27017, # MongoDB sin auth
}

_MEDIUM_RISK_PORTS: set[int] = {
    22,    # SSH — superficie expuesta
    80,    # HTTP
    443,   # HTTPS
    3000,  # Node / dev servers
    3389,  # RDP
    4848,  # GlassFish admin
    6000,  # X11
    8080,  # HTTP alternativo
    8443,  # HTTPS alternativo
    8888,  # Jupyter / dev
    9090,  # Cockpit / admin panels
    9200,  # Elasticsearch sin auth
}


def classify_severity(port: int, service: str | None = None) -> str:
    """
    Clasifica la severidad de un puerto/servicio abierto.
    Usado por normalize_nmap_findings() — puede ser sobreescrito por AnalysisAgent
    con datos CVE/CVSS reales en Sprint 3.

    Returns: "critical" | "high" | "medium" | "low" | "info"
    """
    if port in _HIGH_RISK_PORTS:
        return "high"
    if port in _MEDIUM_RISK_PORTS:
        return "medium"
    # Puertos privilegiados (< 1024) no en lista conocida → medio
    if 0 < port < 1024:
        return "medium"
    # Servicios web en puertos altos
    svc = (service or "").lower()
    if any(kw in svc for kw in ("http", "https", "web", "tomcat", "nginx", "apache")):
        return "medium"
    return "info"


def normalize_nmap_findings(engagement_id: int, raw_findings: list[dict]) -> list[dict]:
    """
    Convierte raw findings de nmap_service.parse_nmap_xml() al formato canónico.
    No persiste — llamar persist_findings_bulk() después para guardar en MongoDB.
    """
    normalized: list[dict] = []

    for item in raw_findings:
        port: int = item.get("port", 0)
        service: str | None = item.get("service")
        product: str | None = item.get("product")
        version: str | None = item.get("version")

        # Título legible
        svc_label = service or "desconocido"
        title = f"Puerto {port} abierto — {svc_label}"
        if product:
            title += f" ({product}"
            if version:
                title += f" {version}"
            title += ")"

        severity = classify_severity(port, service)

        normalized.append({
            "engagement_id": engagement_id,
            "phase": "scan",
            "tool": "nmap",
            "target": item["target"],
            "title": title,
            "severity": severity,
            "status": "open",
            "evidence": {
                "port": port,
                "protocol": item.get("protocol", "tcp"),
                "state": item.get("state", "open"),
                "service": service,
                "product": product,
                "version": version,
                # CPE de nmap (fix 2026-06-11) — el AnalysisAgent lo usa para
                # match exacto producto+versión en NVD (cve_lookup por CPE).
                "cpe": item.get("cpe"),
                "cpes": item.get("cpes", []),
            },
            # Campos ATT&CK / CVE — rellenados por AnalysisAgent en Sprint 3
            "mitre_technique": None,
            "cve_ids": [],
            "cvss_score": None,
            "cvss_source": None,
            # Timestamps
            "discovered_at": datetime.now(timezone.utc).isoformat(),
            "raw_output": item.get("raw_output", ""),
        })

    return normalized


_HIGH_RISK_PATHS: set[str] = {
    "admin", "wp-admin", "private", "backup", "config", "dashboard", "console",
    "phpmyadmin", "manager", "administrator", "secret", "credentials",
}


def normalize_gobuster_findings(
    engagement_id: int,
    target: str,
    raw_output: str,
    mode: str = "dir",
    catchall: bool = False,
) -> list[dict]:
    """
    Parsea la salida de gobuster y la convierte al formato canónico.

    Dir output:  /admin       (Status: 200) [Size: 1234]
    DNS output:  Found: mail.example.com

    Auditoría 2026-05-27 (lab-fixes): se sanitizan los ANSI escape codes
    (`\x1b[2K` clear-line + similares) que `gobuster --no-color` igual
    inyecta en cada línea. Sin esto, el regex `^(/\\S*)...` nunca
    matcheaba porque la línea empieza con `\x1b[2K/admin`, no con `/admin`,
    y los findings nunca se persistían (hallazgo H-4 del lab E2E).

    catchall (fix 2026-06-11): si el server responde 200 a toda ruta (soft-200),
    cada "ruta descubierta" es ruido → confidence="low" + severidad info. El
    operador ve los hits pero no se reportan como hallazgos reales.
    """
    # Strip de cualquier secuencia CSI (ESC [ ...): K, m, J, etc.
    raw_output = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", raw_output or "")

    normalized: list[dict] = []

    if mode == "dir":
        pattern = re.compile(
            r"^(/\S*)\s+\(Status:\s*(\d+)\)\s+\[Size:\s*(\d+)\]", re.MULTILINE
        )
        for match in pattern.finditer(raw_output):
            path = match.group(1)
            status_code = int(match.group(2))
            size = int(match.group(3))
            if status_code >= 400:
                continue
            path_key = path.strip("/").split("/")[0].lower()
            severity = "medium" if path_key in _HIGH_RISK_PATHS else "low"
            confidence = "high"
            if catchall:
                severity = "info"
                confidence = "low"
            normalized.append({
                "engagement_id": engagement_id,
                "phase": "scan",
                "tool": "gobuster",
                "target": target,
                "title": f"Ruta web descubierta: {path} (HTTP {status_code})",
                "severity": severity,
                "status": "open",
                "confidence": confidence,
                "evidence": {
                    "path": path,
                    "status_code": status_code,
                    "size": size,
                    "mode": "dir",
                    "catchall": catchall,
                },
                "mitre_technique": "T1083",
                "cve_ids": [],
                "cvss_score": None,
                "cvss_source": None,
                "discovered_at": datetime.now(timezone.utc).isoformat(),
                "raw_output": raw_output,
            })

    elif mode == "dns":
        pattern = re.compile(r"^Found:\s+(\S+)", re.MULTILINE)
        for match in pattern.finditer(raw_output):
            subdomain = match.group(1)
            normalized.append({
                "engagement_id": engagement_id,
                "phase": "scan",
                "tool": "gobuster",
                "target": target,
                "title": f"Subdominio descubierto: {subdomain}",
                "severity": "info",
                "status": "open",
                "evidence": {"subdomain": subdomain, "mode": "dns"},
                "mitre_technique": "T1018",
                "cve_ids": [],
                "cvss_score": None,
                "cvss_source": None,
                "discovered_at": datetime.now(timezone.utc).isoformat(),
                "raw_output": raw_output,
            })

    return normalized


_NIKTO_HIGH_KEYWORDS: tuple[str, ...] = (
    "sql injection", "xss", "cross-site scripting",
    "remote code", "rce", "command injection",
    "backdoor", "web shell", "reverse shell", "shellshock", "arbitrary file",
    # Nota (fix 2026-06-11): se quitó "shell" desnudo — matcheaba
    # "shell history retrieved" (FP típico de catch-all SPA) y lo subía a high.
)

# Señales de "existencia por código" (200 = el recurso existe). Son las que un
# servidor catch-all (try_files → index.html / soft-200) vuelve no fiables. Bajo
# catch-all, estos findings se degradan a info + confidence=low (fix 2026-06-11).
_NIKTO_EXISTENCE_SIGNALS: tuple[str, ...] = (
    "retrieved", "was found", "found", "identified", "interface",
    "this might be interesting", "directory indexing", "default file",
    "default page", "backup", "/.", ".bash_history", ".sh_history",
)
_NIKTO_MEDIUM_KEYWORDS: tuple[str, ...] = (
    "admin", "phpmyadmin", "config", "backup",
    "password", "credential", "directory listing",
    "osvdb", "default file", "default page",
)


def _parse_nikto_csv(raw_output: str) -> list[dict]:
    """
    Parsea el CSV de nikto (`-Format csv`) a la lista de vulns intermedia
    {id, method, url, description} que consume el loop de normalización.

    Diagnóstico 2026-05-29: el reporter JSON de nikto 2.6.0 crashea
    (`nikto_report_json.plugin` → archivo de 0 bytes), por eso el wrapper pasó
    a `-Format csv`. Columnas observadas del CSV de nikto 2.6.0:

        host , ip , port , id , method , uri , description
        "10.42.0.10","10.42.0.10","80","","GET","/icons/","Directory indexing found."

    La primera línea es un banner de una sola columna ("Nikto - v2.6.0/") y las
    filas de cabecera de host tienen method/uri/description vacíos → se ignoran.
    """
    import csv as _csv
    import io as _io

    vulns: list[dict] = []
    reader = _csv.reader(_io.StringIO(raw_output))
    for row in reader:
        if len(row) < 7:
            continue  # banner / filas incompletas
        description = (row[6] or "").strip()
        if not description:
            continue  # fila de host sin hallazgo
        # row[2] = puerto. Antes se descartaba → FindingDoc.port=null y, peor,
        # dedup_key sin puerto colisionaba entre :80 y :8000 (fix 2026-06-11).
        port_raw = (row[2] or "").strip()
        try:
            port = int(port_raw) if port_raw else None
        except ValueError:
            port = None
        vulns.append({
            "id":          (row[3] or "").strip(),
            "method":      (row[4] or "GET").strip() or "GET",
            "url":         (row[5] or "/").strip() or "/",
            "description": description,
            "port":        port,
        })
    return vulns


def normalize_nikto_findings(
    engagement_id: int,
    target: str,
    raw_output: str,
    catchall: bool = False,
) -> list[dict]:
    """
    Parsea la salida de nikto al formato canónico. Detecta el formato:

      - CSV (`-Format csv`) → formato actual del wrapper. El reporter JSON de
        nikto 2.6.0 crashea (diagnóstico 2026-05-29), por eso se usa CSV.
      - JSON dict / list-of-hosts → compatibilidad legacy (nikto < 2.6).

    Auditoría 2026-05-27 (lab-fixes), hallazgo H-5b: nikto 2.5.x emite el JSON
    como lista de hosts; antes asumíamos dict y `.get()` reventaba con
    AttributeError → cero findings. Se conserva el soporte JSON por compat.

    catchall (fix 2026-06-11): si el server respondió 200 a una ruta aleatoria
    inexistente (soft-200 detectado por la sonda del Security MCP), los findings
    basados en "existencia por código" no son fiables → se degradan a severidad
    info + confidence="low". Los demás (headers faltantes, OPTIONS) conservan su
    severidad pero igual se marcan confidence="low" para que el operador audite.
    """
    import json as _json

    vulns: list[dict] = []
    stripped = (raw_output or "").lstrip()

    if stripped.startswith("{") or stripped.startswith("["):
        # ── Path JSON legacy ──────────────────────────────────────────────────
        try:
            data = _json.loads(raw_output)
        except _json.JSONDecodeError:
            data = None

        if isinstance(data, dict):
            hosts = [data]
        elif isinstance(data, list):
            hosts = data
        else:
            hosts = []
        for h in hosts:
            if isinstance(h, dict):
                vulns.extend(h.get("vulnerabilities", []) or [])
    else:
        # ── Path CSV (formato actual) ─────────────────────────────────────────
        vulns = _parse_nikto_csv(raw_output)

    normalized: list[dict] = []

    for v in vulns:
        raw_desc = v.get("description") or v.get("msg") or "Finding sin descripción"
        desc_lower = raw_desc.lower()

        if any(kw in desc_lower for kw in _NIKTO_HIGH_KEYWORDS):
            severity = "high"
        elif any(kw in desc_lower for kw in _NIKTO_MEDIUM_KEYWORDS):
            severity = "medium"
        else:
            severity = "low"

        confidence = "high"
        if catchall:
            # Catch-all: nada basado en existencia-por-200 es fiable.
            confidence = "low"
            is_existence = any(s in desc_lower for s in _NIKTO_EXISTENCE_SIGNALS)
            if is_existence or severity in ("high", "medium"):
                severity = "info"

        normalized.append({
            "engagement_id": engagement_id,
            "phase": "scan",
            "tool": "nikto",
            "target": target,
            "title": f"[Nikto] {raw_desc[:120]}",
            "severity": severity,
            "status": "open",
            "confidence": confidence,
            "evidence": {
                "nikto_id": v.get("id", ""),
                "method":   v.get("method", "GET"),
                "url":      v.get("url", "/"),
                "port":     v.get("port"),
                "catchall": catchall,
            },
            "mitre_technique": "T1190",
            "cve_ids": [],
            "cvss_score": None,
            "cvss_source": None,
            "discovered_at": datetime.now(timezone.utc).isoformat(),
            "raw_output": raw_output[:1000],
        })

    return normalized


_NUCLEI_SEVERITY_MAP: dict[str, str] = {
    "critical": "critical",
    "high": "high",
    "medium": "medium",
    "low": "low",
    "info": "info",
}


def normalize_nuclei_findings(
    engagement_id: int,
    target: str,
    raw_output: str,
) -> list[dict]:
    """
    Parsea la salida JSONL de nuclei (-j flag) al formato canónico.
    Cada línea del output es un objeto JSON independiente.
    """
    normalized: list[dict] = []

    for line in raw_output.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue

        info = entry.get("info", {})
        nuclei_sev = info.get("severity", "info").lower()
        severity = _NUCLEI_SEVERITY_MAP.get(nuclei_sev, "info")

        template_id = entry.get("template-id", entry.get("template", "unknown"))
        template_name = info.get("name", template_id)
        matched_at = entry.get("matched-at", target)
        description = info.get("description", "")

        classification = info.get("classification", {}) or {}
        raw_cves = classification.get("cve-id", [])
        if isinstance(raw_cves, str):
            raw_cves = [raw_cves]
        cve_ids = [c.upper() for c in raw_cves if c]

        cvss_raw = classification.get("cvss-score")
        cvss_score = float(cvss_raw) if cvss_raw is not None else None

        normalized.append({
            "engagement_id": engagement_id,
            "phase": "scan",
            "tool": "nuclei",
            "target": target,
            "title": f"[Nuclei] {template_name}",
            "severity": severity,
            "status": "open",
            "evidence": {
                "template_id": template_id,
                "matched_at": matched_at,
                "description": description,
                "tags": info.get("tags", []),
            },
            "mitre_technique": None,
            "cve_ids": cve_ids,
            "cvss_score": cvss_score,
            "cvss_source": "nuclei" if cvss_score is not None else None,
            "discovered_at": datetime.now(timezone.utc).isoformat(),
            "raw_output": line,
        })

    return normalized


# ── M-4: dedup_key determinístico ─────────────────────────────────────────────

def _compute_dedup_key(f: dict[str, Any]) -> str:
    """
    Construye una clave determinística que identifica un finding único dentro
    de un engagement. Re-ejecutar el mismo scan produce la misma clave → upsert
    en lugar de duplicar.

    Estrategia por herramienta (campos elegidos por estabilidad):
      nmap      → tool|target|port|protocol
      nuclei    → tool|target|template_id|matched_at
      gobuster  → tool|target|mode|(path|subdomain)
      nikto     → tool|target|port|nikto_id|url
      otros     → tool|target|severity|summary[:80]   (fallback razonable)
    """
    tool   = (f.get("tool") or "").lower()
    target = f.get("target") or ""
    ev     = f.get("evidence") or {}

    if tool == "nmap":
        parts = [tool, target, str(ev.get("port", "")), ev.get("protocol", "") or ""]
    elif tool == "nuclei":
        parts = [tool, target, ev.get("template_id", "") or "", ev.get("matched_at", "") or ""]
    elif tool == "gobuster":
        mode = ev.get("mode", "")
        sub  = ev.get("subdomain", "") if mode == "dns" else ev.get("path", "")
        parts = [tool, target, mode or "", sub or ""]
    elif tool == "nikto":
        # Incluir puerto: sin él, nikto sobre :80 y :8000 colisionaba y se
        # sobreescribía (fix 2026-06-11). "" cuando el CSV no trae puerto.
        parts = [tool, target, str(ev.get("port", "") or ""),
                 str(ev.get("nikto_id", "")), ev.get("url", "") or ""]
    else:
        summary = (f.get("title") or f.get("summary") or "")[:80]
        parts = [tool, target, f.get("severity", "") or "", summary]

    return "|".join(parts)


def _build_finding_doc(f: dict[str, Any]) -> FindingDoc:
    """Construye un FindingDoc desde el dict normalizado, promoviendo
    port/service/protocol desde evidence al top-level del doc para que sean
    indexables y filtrables desde GET /findings.

    Fix B-1 auditoría 2026-05-19: pasa `discovered_at` del dict normalizado
    (cuando viene como ISO string) en lugar de dejar que `default_factory`
    sobrescriba el timestamp generado por normalize_*_findings.
    """
    evidence = f.get("evidence", {}) or {}
    kwargs: dict[str, Any] = dict(
        engagement_id=f["engagement_id"],
        tool=f.get("tool", "nmap"),
        target=f["target"],
        summary=f.get("title", f.get("summary", "")),
        severity=f["severity"],
        status=f.get("status", "open"),
        # phase no existe en el schema; se descarta. Se mantiene en evidence.
        port=evidence.get("port"),
        service=evidence.get("service"),
        protocol=evidence.get("protocol"),
        evidence=evidence,
        mitre_technique=f.get("mitre_technique"),
        cve_ids=f.get("cve_ids", []),
        cvss_score=f.get("cvss_score"),
        cvss_source=f.get("cvss_source"),
        cve_details=f.get("cve_details", []),
        confidence=f.get("confidence"),
        raw_output=f.get("raw_output", ""),
        dedup_key=_compute_dedup_key(f),
    )
    # B-1: solo pasamos discovered_at si el dict lo trae; si no, deja que
    # FindingDoc.default_factory cree uno fresco.
    if f.get("discovered_at") is not None:
        kwargs["discovered_at"] = f["discovered_at"]
    return FindingDoc(**kwargs)


async def persist_finding(finding_dict: dict[str, Any]) -> str:
    """
    Persiste un único finding usando upsert por (engagement_id, dedup_key).
    Retorna el ObjectId string del doc resultante (insertado o existente).
    """
    doc = _build_finding_doc(finding_dict)
    payload = doc.model_dump(exclude_none=False)
    # `discovered_at` solo se setea en insert; en update preservamos el original.
    on_insert = {"discovered_at": payload.pop("discovered_at")}
    result = await findings_col().update_one(
        {"engagement_id": doc.engagement_id, "dedup_key": doc.dedup_key},
        {"$set": payload, "$setOnInsert": on_insert},
        upsert=True,
    )
    if result.upserted_id is not None:
        return str(result.upserted_id)
    existing = await findings_col().find_one(
        {"engagement_id": doc.engagement_id, "dedup_key": doc.dedup_key},
        projection={"_id": 1},
    )
    return str(existing["_id"]) if existing else ""


async def persist_findings_bulk(findings: list[dict[str, Any]]) -> int:
    """
    Persiste múltiples findings con upsert por (engagement_id, dedup_key).
    Re-correr el mismo scan no duplica documentos: actualiza el existente y
    preserva el `discovered_at` original.

    Retorna la cantidad de docs afectados (insertados + modificados).
    """
    if not findings:
        return 0

    ops: list[UpdateOne] = []
    for f in findings:
        doc = _build_finding_doc(f)
        payload = doc.model_dump(exclude_none=False)
        on_insert = {"discovered_at": payload.pop("discovered_at")}
        ops.append(UpdateOne(
            {"engagement_id": doc.engagement_id, "dedup_key": doc.dedup_key},
            {"$set": payload, "$setOnInsert": on_insert},
            upsert=True,
        ))

    result = await findings_col().bulk_write(ops, ordered=False)
    # upserted + modified = "filas tocadas". inserted_count siempre 0 en update bulk.
    return (result.upserted_count or 0) + (result.modified_count or 0)
