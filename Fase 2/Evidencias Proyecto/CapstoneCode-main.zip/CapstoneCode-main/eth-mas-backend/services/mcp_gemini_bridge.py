"""
mcp_gemini_bridge.py — Adaptador MCP tools → Gemini FunctionDeclaration
========================================================================
Convierte las tools de un MCP Server al formato que espera google-genai,
y enruta las FunctionCall de Gemini de vuelta al MCP server vía stdio.

Uso (dentro de un agente):
    from services.mcp_gemini_bridge import load_mcp_tools_for_gemini, call_mcp_tool_from_gemini

    declarations, session, stack = await load_mcp_tools_for_gemini(server_script)
    async with stack:
        # ... loop Gemini ...
        result_text = await call_mcp_tool_from_gemini(session, function_call)
"""

from __future__ import annotations

import contextlib
import json
import os
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def load_mcp_tools_for_gemini(
    server_script: str,
) -> tuple[list[Any], ClientSession, contextlib.AsyncExitStack]:
    """
    Conecta al MCP server vía stdio y convierte sus tools a FunctionDeclaration de Gemini.

    Mantiene la sesión abierta — el llamador debe cerrar el stack con `async with stack`.

    Returns:
        (gemini_declarations, session, exit_stack)
    """
    from google.genai import types

    stack = contextlib.AsyncExitStack()

    server_params = StdioServerParameters(
        command="python",
        args=[server_script],
        env={**os.environ},
    )

    read, write = await stack.enter_async_context(stdio_client(server_params))
    session = await stack.enter_async_context(ClientSession(read, write))
    await session.initialize()

    mcp_tools = await session.list_tools()
    declarations = []
    for tool in mcp_tools.tools:
        schema = _sanitize_schema_for_gemini(tool.inputSchema or {})
        declarations.append(
            types.FunctionDeclaration(
                name=tool.name,
                description=tool.description or "",
                parameters=schema,
            )
        )

    return declarations, session, stack


async def call_mcp_tool_from_gemini(
    session: ClientSession,
    function_call: Any,  # google.genai.types.FunctionCall
) -> str:
    """
    Ejecuta un FunctionCall de Gemini en el MCP server.
    Retorna el resultado como JSON string (para FunctionResponse).
    """
    result = await session.call_tool(
        function_call.name,
        arguments=dict(function_call.args or {}),
    )
    return result.content[0].text if result.content else "{}"


def _sanitize_schema_for_gemini(schema: dict) -> dict:
    """
    Elimina campos del JSON Schema que la API de Gemini rechaza.
    Gemini acepta: type, properties, required, description, enum.
    Rechaza: $schema, additionalProperties, $ref, $defs, allOf, anyOf, oneOf.
    """
    BLOCKED = {"$schema", "additionalProperties", "$ref", "$defs", "allOf", "anyOf", "oneOf"}

    def _clean(obj: Any) -> Any:
        if isinstance(obj, dict):
            return {k: _clean(v) for k, v in obj.items() if k not in BLOCKED}
        if isinstance(obj, list):
            return [_clean(i) for i in obj]
        return obj

    return _clean(schema)
