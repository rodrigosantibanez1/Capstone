"""
narration.py — Narración legible del pipeline en vivo (cuadro de actividad)
===========================================================================
Convierte los eventos técnicos del pipeline (inicio de run, tool call) en
frases simples en español que el operador entiende de un vistazo:

    "Recon usando OSINT para consultar WHOIS de 10.42.0.10"
    "Scan usando Nmap para mapear puertos y servicios de 10.42.0.10"

Se genera en el BACKEND (no en la UI) a propósito: la misma frase se reutiliza
en el cuadro de actividad en vivo (SSE /agent-runs/stream), en los reportes y en
el modo replay de la demo, con texto idéntico en todos lados.

Módulo PURO: sin I/O ni dependencias de BD → testeable de forma directa.
"""

from __future__ import annotations

from typing import Optional

# tool → (agente legible, skill/categoría, acción en infinitivo)
# El "skill" es el MCP/categoría de herramienta; la "tool" es la función concreta.
_TOOL_NARRATION: dict[str, tuple[str, str, str]] = {
    "whois_lookup":            ("Recon",    "OSINT",        "consultar WHOIS de"),
    "dns_enum":                ("Recon",    "OSINT",        "enumerar registros DNS de"),
    "theharvester_run":        ("Recon",    "theHarvester", "buscar correos y hosts de"),
    "nmap_scan":               ("Scan",     "Nmap",         "mapear puertos y servicios de"),
    "nuclei_run":              ("Scan",     "Nuclei",       "probar plantillas de vulnerabilidad en"),
    "nikto_scan":              ("Scan",     "Nikto",        "revisar el servidor web de"),
    "gobuster_run":            ("Scan",     "Gobuster",     "descubrir rutas web en"),
    "cve_lookup":              ("Análisis", "NVD",          "buscar CVEs de"),
    "attack_technique_lookup": ("Análisis", "MITRE ATT&CK", "validar la técnica"),
}

# agente canónico → frase de inicio de run
_AGENT_START: dict[str, str] = {
    "ReconAgent":    "🔍 Reconocimiento iniciado",
    "ScanAgent":     "📡 Escaneo iniciado",
    "AnalysisAgent": "🧠 Análisis iniciado",
    "ReporterAgent": "📄 Generación de reporte iniciada",
}


def narrate_tool_start(tool: str, target: str = "", params: Optional[dict] = None) -> str:
    """Frase legible para el inicio de una tool call.

    Ej: narrate_tool_start("nmap_scan", "10.42.0.10")
        → "Scan usando Nmap para mapear puertos y servicios de 10.42.0.10"
    Para tools sin target de red (cve_lookup / attack_technique_lookup) usa el
    parámetro semántico relevante (producto / query).
    """
    agent, skill, action = _TOOL_NARRATION.get(tool, ("Sistema", tool, "ejecutar"))
    tgt = (target or "").strip()
    if tool == "cve_lookup" and params:
        tgt = str(params.get("product") or params.get("cpe") or tgt).strip()
    elif tool == "attack_technique_lookup" and params:
        tgt = str(params.get("query") or tgt).strip()
    if tgt:
        return f"{agent} usando {skill} para {action} {tgt}"
    return f"{agent} usando {skill}"


def narrate_run_start(agent: str, targets: Optional[list[str]] = None) -> str:
    """Frase legible para el arranque de un agente.

    Ej: narrate_run_start("ReconAgent", ["10.42.0.10", "10.42.0.20"])
        → "🔍 Reconocimiento iniciado sobre 2 objetivos"
    """
    base = _AGENT_START.get(agent, f"{agent} iniciado")
    n = len(targets or [])
    if n:
        return f"{base} sobre {n} objetivo{'s' if n != 1 else ''}"
    return base
