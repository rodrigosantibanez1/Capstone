import os
import subprocess
import xml.etree.ElementTree as ET
from typing import Optional

# Timeout del subprocess nmap, configurable por env (fix H-1 / 2026-06-11).
# 300s era insuficiente para barridos 1-65535 (engagement #24, HITL #95 → tool_error
# a los 324.8s). Default 600s. OJO: debe alinearse con HITL_TIMEOUT_SECS del
# Security MCP (si el tool puede tardar 600s, la ventana HITL no debería ser menor).
_NMAP_TIMEOUT_SECS: float = float(os.getenv("NMAP_TIMEOUT_SECS", "600"))


def run_nmap_scan(
    target: str,
    ports: str = "top100",
    timing: int = 4,
    scripts: Optional[str] = None,
) -> str:
    """
    Ejecuta nmap con detección de versiones sobre el target.

    Args:
        target:  IP, CIDR o hostname a escanear.
        ports:   Rango de puertos (default "top100" = --top-ports 100).
                 Usar "1-1024" para rango clásico, "1-65535" para full.
        timing:  Template T0-T5 (default T4=aggressive).
        scripts: Scripts NSE separados por coma (ej: "vuln,default"). None = sin scripts.

    Returns:
        XML output de nmap como string.
    """
    if ports == "top100":
        port_args = ["--top-ports", "100"]
    else:
        port_args = ["-p", ports]

    command = [
        "nmap",
        "-Pn",
        "-sV",
        *port_args,
        f"-T{timing}",
        "-oX", "-",
        target,
    ]
    if scripts:
        command.extend(["--script", scripts])

    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=_NMAP_TIMEOUT_SECS,
    )

    if result.returncode != 0:
        raise Exception(f"Nmap error: {result.stderr}")

    return result.stdout


# Truncado del XML del host que va a parar al campo raw_output del FindingDoc
# (criterio M2 del CLAUDE.md). 1500 chars cubre nodos típicos sin inflar Mongo.
_RAW_OUTPUT_MAX_CHARS = 1500


def parse_nmap_xml(xml_output: str) -> list[dict]:
    """
    Parsea la salida XML de nmap y devuelve una lista de findings (un dict por
    puerto abierto). Cada finding incluye `raw_output` con el XML del host de
    origen (truncado) para trazabilidad.

    Fixes aplicados (auditoría 2026-05-19):
      - M-1: si <host> no tiene <address>, el host se descarta (antes producía
        target=None y reventaba la validación Pydantic del FindingDoc).
      - M-2: cada finding lleva raw_output = XML del <host> al que pertenece.
    """
    findings: list[dict] = []
    root = ET.fromstring(xml_output)

    for host in root.findall("host"):
        address = host.find("address")
        ip_addr = address.get("addr") if address is not None else None
        if not ip_addr:
            # M-1: sin dirección no podemos atribuir el finding → descartar
            continue

        ports = host.find("ports")
        if ports is None:
            continue

        # M-2: serializamos el <host> una sola vez por host y lo reusamos en
        # cada finding. ET.tostring devuelve bytes; encoding='unicode' → str.
        host_xml = ET.tostring(host, encoding="unicode")
        if len(host_xml) > _RAW_OUTPUT_MAX_CHARS:
            host_xml = host_xml[:_RAW_OUTPUT_MAX_CHARS] + "…"

        for port in ports.findall("port"):
            state_elem = port.find("state")
            service_elem = port.find("service")

            state = state_elem.get("state") if state_elem is not None else None
            if state != "open":
                continue

            # CPE(s) del servicio. nmap emite uno o más <cpe> dentro de <service>
            # (ej. cpe:/a:igor_sysoev:nginx:1.31.1). Es la clave para que el
            # AnalysisAgent matchee CVEs por producto+versión exactos en NVD en
            # lugar de keyword-soup (fix 2026-06-11). Tomamos el primero como
            # canónico y guardamos todos para trazabilidad.
            cpes = (
                [c.text for c in service_elem.findall("cpe") if c.text]
                if service_elem is not None else []
            )

            findings.append({
                "target":   ip_addr,
                "port":     int(port.get("portid")),
                "protocol": port.get("protocol"),
                "state":    state,
                "service":  service_elem.get("name")    if service_elem is not None else None,
                "product":  service_elem.get("product") if service_elem is not None else None,
                "version":  service_elem.get("version") if service_elem is not None else None,
                "cpe":      cpes[0] if cpes else None,
                "cpes":     cpes,
                "raw_output": host_xml,
            })

    return findings