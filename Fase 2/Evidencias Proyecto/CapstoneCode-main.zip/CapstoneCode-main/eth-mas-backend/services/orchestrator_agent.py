"""
orchestrator_agent.py — Orquestador conversacional · ETH-MAS (Bloque A, ADR-005)
================================================================================
El cambio cualitativo frente a la crítica del profesor: un agente LLM (Opus por
env, Haiku seguro por default) que conversa con el operador en lenguaje natural,
arma un PLAN y DELEGA en los 4 workers (agent-as-tool). Es el "cerebro" del
patrón Orquestador + Ejecutor seguro + workers (ADR-005 §3.3).

Principio rector (ADR-005 §3): **estrategia libre, ejecución blindada**. El
orquestador planifica con libertad amplia, pero NO ejecuta tools de seguridad
directamente ni aprueba scope/HITL: delega en cada worker a través del EJECUTOR
SEGURO (`PipelineController.run_single_stage`, Bloque E), que conserva el scope
check programático, el gating HITL (risk ≥ MEDIUM) y el anti-zombi de Fase 1.
Las aprobaciones HITL siguen siendo un control EXPLÍCITO por la consola HITL
(no se aprueban por chat) — esto es intocable.

Dos modos (ADR-005 §4, mitigación de reproducibilidad):
  - PLAN     → describe los pasos (qué worker, qué objetivo, qué intensidad) SIN
               ejecutar nada. El operador revisa antes de comprometer acciones.
  - EXECUTE  → corre el loop tool-use real: delega, reacciona a los rationale de
               los workers y narra el resultado en español.

Las tools del orquestador NO son MCP: son la interfaz agent-as-tool
(`AGENT_TOOL_SCHEMAS`, Bloque 0) + dos tools locales de lectura del blackboard.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Optional

from sqlalchemy.orm import Session

from services.agent_base import AGENT_TOOL_SCHEMAS, TOOL_NAME_TO_AGENT
from services.agent_config import orchestrator_model
from services.blackboard import (
    append_conversation,
    read_conversation,
    read_rationales,
    read_state,
)

logger = logging.getLogger(__name__)

#: tope de iteraciones del loop tool-use en modo execute (cota dura de agencia).
DEFAULT_ORCHESTRATOR_BUDGET = 8

#: modos válidos del endpoint conversacional.
MODE_PLAN = "plan"
MODE_EXECUTE = "execute"
VALID_MODES = (MODE_PLAN, MODE_EXECUTE)


# ── Tools locales de lectura del blackboard ───────────────────────────────────
# El orquestador lee el estado compartido para decidir (no para actuar). Estas
# tools se ejecutan EN PROCESO (no vía MCP) y son de solo lectura.

READ_STATE_TOOL = {
    "name": "read_blackboard_state",
    "description": (
        "Lee el estado compartido del engagement: surface_map (recon), findings "
        "(scan) y analysis (CVE/ATT&CK/vectores). Úsalo para decidir el próximo "
        "paso o para resumirle al operador qué se sabe."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "include": {
                "type": "array",
                "items": {"type": "string", "enum": ["surface_map", "findings", "analysis"]},
                "description": "Qué claves del estado leer. Default: todas.",
            }
        },
        "required": [],
    },
}

READ_RATIONALES_TOOL = {
    "name": "read_agent_rationales",
    "description": (
        "Lee los últimos rationales (el 'por qué' que dejó cada worker) del "
        "engagement. Útil para entender qué decidió un worker y narrarlo."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "limit": {"type": "integer", "description": "Máximo de rationales (default 20)."}
        },
        "required": [],
    },
}

LOCAL_READ_TOOLS = (READ_STATE_TOOL["name"], READ_RATIONALES_TOOL["name"])


# ── Helpers puros (testeables sin API ni BD) ──────────────────────────────────

def orchestrator_tools() -> list[dict]:
    """Lista completa de tools que ve el LLM en modo execute: los 4 workers
    (agent-as-tool) + las 2 tools locales de lectura del blackboard."""
    return [dict(schema) for schema in AGENT_TOOL_SCHEMAS.values()] + [
        READ_STATE_TOOL, READ_RATIONALES_TOOL,
    ]


def compose_operator_directive(
    intensity: Optional[str] = None,
    report_type: Optional[str] = None,
) -> Optional[str]:
    """
    Compone el `operator_directive` que el ejecutor threadea al AgentContext.

    Lleva SOLO los overrides estructurados (intensidad / tipo de reporte), no el
    mensaje crudo del operador — así el match de intensidad de ScanAgent
    (`_resolve_policy`) es determinístico (un único token de intensidad presente).
    El intent semántico del operador viaja por `goal`.
    """
    parts: list[str] = []
    if intensity:
        parts.append(f"Intensidad solicitada: {intensity.upper()}.")
    if report_type:
        parts.append(f"Tipo de reporte solicitado: {report_type}.")
    return " ".join(parts) if parts else None


def extract_delegation(tool_name: str, tool_input: dict) -> dict:
    """
    Mapea un `tool_use` de worker que eligió el LLM a los argumentos concretos del
    ejecutor: agente canónico + goal + operator_directive.

    Lanza KeyError si `tool_name` no es un worker (el caller debe rutear las tools
    locales de lectura por otro lado).
    """
    agent_name = TOOL_NAME_TO_AGENT[tool_name]  # KeyError si no es worker
    goal = (tool_input.get("goal") or "").strip()
    directive = compose_operator_directive(
        intensity=tool_input.get("intensity"),
        report_type=tool_input.get("report_type"),
    )
    return {"agent_name": agent_name, "goal": goal, "operator_directive": directive}


def _worker_catalog() -> str:
    """Catálogo legible de los workers para el system prompt (modo plan)."""
    lines = []
    for agent_name, schema in AGENT_TOOL_SCHEMAS.items():
        props = schema["input_schema"]["properties"]
        extra = [k for k in props if k not in ("engagement_id", "goal")]
        extra_txt = f" · params extra: {', '.join(extra)}" if extra else ""
        lines.append(f"  - {agent_name} (tool `{schema['name']}`){extra_txt}")
    return "\n".join(lines)


def _summarize_worker_result(result: dict) -> dict:
    """Compacta el dict de `run_single_stage` para devolvérselo al LLM como
    tool_result (sin payloads enormes: findings crudos fuera)."""
    inner = result.get("result", {}) if isinstance(result, dict) else {}
    artifacts = inner.get("artifacts", {}) or {}
    return {
        "agent": result.get("agent"),
        "status": result.get("status"),
        "rationale": inner.get("rationale"),
        "findings_count": inner.get("findings_count", 0),
        "pending_hitl_ids": inner.get("pending_hitl_ids", []) or [],
        "pipeline_run_id": result.get("pipeline_run_id"),
        "artifacts": {
            k: v for k, v in artifacts.items()
            if k in ("intensity", "timing", "technical_id", "executive_id", "analysis_id", "agent_run_id")
        },
    }


def _build_system_prompt(engagement_id: int, mode: str, scope_block: str = "") -> str:
    scope_section = f"\n\n{scope_block}" if scope_block else ""
    base = (
        f"Eres el Orquestador conversacional de ETH-MAS, un sistema de pentesting "
        f"ético multi-agente con control humano. Trabajas sobre el engagement "
        f"{engagement_id} y conversas con el operador en español neutro, claro y "
        f"conciso.\n\n"
        f"ESTILO: responde SIEMPRE en español neutro, sin voseo. No uses formas como "
        f"'tenés', 'querés', 'podés', 'delegá', 'fijate' ni el pronombre 'vos'; usa "
        f"el trato neutro/impersonal ('puedes', 'si quieres', 'conviene', 'revisa').\n\n"
        f"Coordinas 4 workers especializados (delegas, no ejecutas herramientas "
        f"directamente):\n"
        f"{_worker_catalog()}\n"
        f"  · read_blackboard_state / read_agent_rationales: leer estado y 'por qués'.\n\n"
        f"GUARDARRAÍLES INTOCABLES (no dependen de ti):\n"
        f"  - El scope autorizado y el HITL (aprobación humana para acciones de "
        f"riesgo medio+) son control EN CÓDIGO. No los apruebas ni los eludes por "
        f"chat. Si un worker queda 'waiting_hitl', explícale al operador que debe "
        f"aprobar/rechazar en la consola HITL para que continúe.\n"
        f"  - Pasa siempre engagement_id={engagement_id} al delegar.\n"
        f"  - Para ScanAgent, traduce el pedido del operador a una intensidad "
        f"(STEALTH / MODERATE / AGGRESSIVE) si la menciona ('sigiloso'→STEALTH, "
        f"'ruidoso/agresivo'→AGGRESSIVE)."
        f"{scope_section}\n\n"
        f"FACTIBILIDAD: antes de delegar, evalúa contra el scope y la ROE de arriba "
        f"si lo que pide el operador es posible. Si un target está fuera de scope, "
        f"NO lo delegues y explica por qué. Si falta info (ej. no hay targets aún), "
        f"pídesela al operador."
    )
    if mode == MODE_PLAN:
        return base + (
            "\n\nMODO PLAN: NO ejecutes ni delegues nada todavía. Devuelve un PLAN "
            "numerado y breve: qué worker(s) delegarías, con qué objetivo (goal) y "
            "qué parámetros (intensidad/tipo de reporte), y por qué en ese orden. "
            "Cierra invitando al operador a confirmar la ejecución."
        )
    return base + (
        "\n\nMODO EJECUTAR: delega en los workers con las tools, en el orden que "
        "tenga sentido. Reacciona a cada rationale que devuelvan. Cuando termines, "
        "narra al operador qué se hizo, hallazgos destacados y próximos pasos "
        "sugeridos (ej. correr análisis o generar el reporte)."
    )


def _history_to_messages(turns: list[dict]) -> list[dict]:
    """Reconstruye una historia simple user/assistant para dar continuidad al LLM.
    operator→user, orchestrator→assistant. Colapsa metadatos: el loop tool-use de
    esta corrida arranca fresco (igual que los workers, que no re-hidratan bloques
    tool crudos)."""
    messages: list[dict] = []
    for t in turns:
        role = t.get("role")
        content = (t.get("content") or "").strip()
        if not content:
            continue
        if role == "operator":
            messages.append({"role": "user", "content": content})
        elif role == "orchestrator":
            messages.append({"role": "assistant", "content": content})
        # 'system' y otros se omiten de la historia del modelo
    return messages


def _collapse_consecutive(messages: list[dict]) -> list[dict]:
    """La API de Anthropic exige roles alternados. Fusiona turnos consecutivos del
    mismo rol (puede pasar con varias narraciones 'orchestrator' seguidas)."""
    out: list[dict] = []
    for m in messages:
        if out and out[-1]["role"] == m["role"]:
            out[-1]["content"] = f"{out[-1]['content']}\n\n{m['content']}"
        else:
            out.append(dict(m))
    return out


# ── OrchestratorAgent ─────────────────────────────────────────────────────────

class OrchestratorAgent:
    """Agente LLM que conversa con el operador y delega en los workers vía el
    ejecutor seguro. Una instancia por request (engagement_id + Session propia)."""

    def __init__(self, engagement_id: int, db: Session):
        self.engagement_id = engagement_id
        self.db = db
        self.model = orchestrator_model()
        # Opción A — un único pipeline_run para toda la sesión execute: cada
        # delegación anexa su stage aquí, así la pestaña Pipeline muestra la
        # secuencia completa (Recon→Scan→Analysis→Report) en vez de solo el último.
        self._session_pipeline_id: Optional[str] = None

    def _scope_summary(self) -> str:
        """Bloque de texto con el scope autorizado + ROE del engagement, para
        groundear la evaluación de factibilidad del orquestador (no inferirla del
        chat). Lee de PostgreSQL vía self.db."""
        import models

        eng = (
            self.db.query(models.Engagement)
            .filter(models.Engagement.id == self.engagement_id)
            .first()
        )
        if not eng:
            return ""

        lines = []
        for s in (eng.scopes or []):
            tt = getattr(s.target_type, "value", None) or str(s.target_type)
            lines.append(f"  - {s.target_value} ({tt})")
        scope_txt = "\n".join(lines) if lines else (
            "  (sin targets definidos todavía — no se puede escanear nada aún)"
        )

        roe = eng.roe if isinstance(eng.roe, dict) else {}
        roe_bits = []
        if roe.get("scan_intensity"):
            roe_bits.append(f"intensidad por defecto {roe['scan_intensity']}")
        if roe.get("auto_approve_hitl_below"):
            roe_bits.append(f"auto-aprueba HITL bajo {roe['auto_approve_hitl_below']}")
        if roe.get("excluded_paths"):
            roe_bits.append(f"rutas excluidas: {', '.join(roe['excluded_paths'])}")
        roe_txt = "; ".join(roe_bits) if roe_bits else "defaults (medium+ requiere HITL)"

        return (
            f"SCOPE AUTORIZADO del engagement {self.engagement_id} "
            f"(control en código — NO lo amplíes):\n"
            f"{scope_txt}\n"
            f"Todo target fuera de esa lista es NO AUTORIZADO. ROE: {roe_txt}."
        )

    async def _ensure_session_pipeline(self) -> str:
        """Crea (lazy, en la 1ª delegación) el pipeline_run compartido de la sesión."""
        if self._session_pipeline_id is None:
            from services.pipeline_runs_service import start_pipeline
            self._session_pipeline_id = await start_pipeline(
                engagement_id=self.engagement_id, agents=[], triggered_by="orchestrator",
            )
        return self._session_pipeline_id

    async def handle_message(
        self,
        message: str,
        mode: str = MODE_PLAN,
        *,
        budget: int = DEFAULT_ORCHESTRATOR_BUDGET,
    ) -> dict:
        """Procesa un mensaje del operador. Persiste el turno del operador y la(s)
        respuesta(s) del orquestador en `orchestrator_conversation`."""
        if mode not in VALID_MODES:
            raise ValueError(f"mode inválido: {mode!r}. Use uno de {VALID_MODES}.")

        await append_conversation(self.engagement_id, "operator", message, meta={"mode": mode})

        history = await read_conversation(self.engagement_id)
        # El último turno es el del operador que acabamos de guardar → ya viene en
        # la historia. Construimos los messages a partir de ella.
        prior = _collapse_consecutive(_history_to_messages(history))
        if not prior or prior[-1]["role"] != "user":
            # Garantía mínima: que el modelo vea el mensaje actual como último 'user'.
            prior.append({"role": "user", "content": message})

        # Si la generación falla (p.ej. ANTHROPIC_API_KEY inválida o timeout del
        # LLM), el turno del operador ya quedó persistido. Sin esto, el chat
        # mostraría un turno "fantasma" sin respuesta. Dejamos un turno 'system'
        # de error visible en el chat/SSE — mismo patrón que el modo execute en
        # routers/orchestrator.py — y re-lanzamos para que el API señale el fallo.
        try:
            if mode == MODE_PLAN:
                return await self._run_plan(prior)
            return await self._run_execute(prior, budget=budget)
        except Exception as e:  # noqa: BLE001
            logger.exception(
                "[Orchestrator] handle_message falló — engagement=%d mode=%s: %s",
                self.engagement_id, mode, e,
            )
            try:
                await append_conversation(
                    self.engagement_id, "system",
                    f"El orquestador no pudo responder: {e}", meta={"kind": "error"},
                )
            except Exception:  # noqa: BLE001
                pass
            raise

    # ── Modo PLAN ──────────────────────────────────────────────────────────────
    async def _run_plan(self, messages: list[dict]) -> dict:
        from anthropic import AsyncAnthropic

        client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        response = await client.messages.create(
            model=self.model,
            max_tokens=2048,
            system=_build_system_prompt(self.engagement_id, MODE_PLAN, self._scope_summary()),
            messages=messages,
        )
        plan_text = _text_of(response)
        await append_conversation(
            self.engagement_id, "orchestrator", plan_text, meta={"kind": "plan"},
        )
        logger.info("[Orchestrator] plan generado — engagement=%d", self.engagement_id)
        return {"mode": MODE_PLAN, "reply": plan_text, "delegations": []}

    # ── Modo EXECUTE ────────────────────────────────────────────────────────────
    async def _run_execute(self, messages: list[dict], *, budget: int) -> dict:
        from anthropic import AsyncAnthropic

        # Import local para evitar ciclo (pipeline_controller importa agentes).
        from services.pipeline_controller import PipelineController

        client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        tools = orchestrator_tools()
        system = _build_system_prompt(self.engagement_id, MODE_EXECUTE, self._scope_summary())

        delegations: list[dict] = []
        final_reply = ""
        work_messages = list(messages)

        for iteration in range(budget):
            response = await client.messages.create(
                model=self.model,
                max_tokens=4096,
                system=system,
                tools=tools,
                messages=work_messages,
            )
            work_messages.append({"role": "assistant", "content": response.content})

            if response.stop_reason != "tool_use":
                final_reply = _text_of(response)
                break

            tool_results = []
            for block in response.content:
                if block.type != "tool_use":
                    continue
                tool_input = dict(block.input)

                if block.name in LOCAL_READ_TOOLS:
                    result_payload = await self._run_local_read(block.name, tool_input)
                else:
                    result_payload = await self._delegate(
                        block.name, tool_input, PipelineController, delegations,
                    )

                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": json.dumps(result_payload, default=str)[:6000],
                })

            work_messages.append({"role": "user", "content": tool_results})
        else:
            final_reply = (
                "Llegué al límite de pasos de orquestación. Revisa el estado del "
                "engagement o pídeme continuar."
            )

        # Cerrar el pipeline_run compartido de la sesión con un status agregado
        # (solo si hubo al menos una delegación → se creó lazy).
        if self._session_pipeline_id is not None:
            from services.pipeline_runs_service import finish_pipeline
            statuses = [d.get("status") for d in delegations]
            if any(s == "waiting_hitl" for s in statuses):
                agg = "waiting_hitl"
            elif any(s == "failed" for s in statuses):
                agg = "partial_failed" if any(s == "completed" for s in statuses) else "failed"
            else:
                agg = "completed"
            done = sum(1 for s in statuses if s in ("completed", "partial"))
            await finish_pipeline(
                pipeline_id=self._session_pipeline_id,
                status=agg,
                summary=f"Orquestador · {done}/{len(delegations)} stages completadas",
            )

        if final_reply:
            await append_conversation(
                self.engagement_id, "orchestrator", final_reply, meta={"kind": "final"},
            )
        logger.info(
            "[Orchestrator] execute terminado — engagement=%d delegaciones=%d pipeline=%s",
            self.engagement_id, len(delegations), self._session_pipeline_id,
        )
        return {"mode": MODE_EXECUTE, "reply": final_reply, "delegations": delegations}

    async def _delegate(
        self,
        tool_name: str,
        tool_input: dict,
        PipelineController: Any,
        delegations: list[dict],
    ) -> dict:
        """Ejecuta un worker a través del ejecutor seguro y narra la delegación."""
        try:
            d = extract_delegation(tool_name, tool_input)
        except KeyError:
            return {"error": f"tool desconocida: {tool_name}", "status": "failed"}

        if not d["goal"]:
            d["goal"] = None  # el ejecutor cae al _DEFAULT_GOALS del agente

        logger.info(
            "[Orchestrator] delegando en %s — goal=%r directive=%r",
            d["agent_name"], d["goal"], d["operator_directive"],
        )
        session_pid = await self._ensure_session_pipeline()
        controller = PipelineController(engagement_id=self.engagement_id, db=self.db)
        result = await controller.run_single_stage(
            d["agent_name"],
            goal=d["goal"],
            operator_directive=d["operator_directive"],
            pipeline_id=session_pid,
        )
        summary = _summarize_worker_result(result)

        # Persistir la delegación como turno (la consume el chat / SSE).
        await append_conversation(
            self.engagement_id,
            "orchestrator",
            f"Delegué en {summary['agent']} → status={summary['status']}, "
            f"{summary['findings_count']} finding(s). {summary.get('rationale') or ''}".strip(),
            meta={
                "kind": "delegation",
                "agent": summary["agent"],
                "status": summary["status"],
                "pipeline_run_id": summary["pipeline_run_id"],
                "pending_hitl_ids": summary["pending_hitl_ids"],
            },
        )
        delegations.append(summary)
        return summary

    async def _run_local_read(self, tool_name: str, tool_input: dict) -> dict:
        """Ejecuta una tool local de lectura del blackboard."""
        if tool_name == READ_STATE_TOOL["name"]:
            include = tool_input.get("include") or ["surface_map", "findings", "analysis"]
            state = await read_state(self.engagement_id, include=include)
            # Recortar findings para no inflar el contexto del LLM.
            findings = state.get("findings")
            if isinstance(findings, list):
                state["findings_count"] = len(findings)
                state["findings"] = findings[:25]
            return state
        if tool_name == READ_RATIONALES_TOOL["name"]:
            limit = int(tool_input.get("limit") or 20)
            return {"rationales": await read_rationales(self.engagement_id, limit=limit)}
        return {"error": f"read tool desconocida: {tool_name}"}


# ── Util ──────────────────────────────────────────────────────────────────────

def _text_of(response: Any) -> str:
    """Concatena los bloques de texto de una respuesta Anthropic."""
    parts = []
    for block in getattr(response, "content", []) or []:
        if getattr(block, "type", None) == "text":
            parts.append(block.text)
    return "\n".join(parts).strip()
