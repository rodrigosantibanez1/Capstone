from __future__ import annotations

"""
pipeline_controller.py — Ejecutor seguro de stages del pipeline ETH-MAS
=======================================================================
Bloque E (ADR-005): degradado de "decisor del orden" a EJECUTOR SEGURO.

El ORDEN ya no es una constante del sistema: lo decide el caller (el Orquestador
del Bloque A, o el operador) pasando `stages=[...]`. `DEFAULT_STAGES` es el
pipeline completo de 4 stages (default oficial, alineado con el frontend).
Lo que este módulo garantiza —y conserva intacto— son los
guardarraíles y el bookkeeping:
  - pre-check de HITL PENDING antes de ScanAgent (anti-zombi, Fase 1),
  - registro en pipeline_runs / agent stages,
  - manejo de waiting_hitl / failed / skipped.

Soporta dos contratos de agente durante la transición:
  - LEGACY  (run(self) -> dict)          → ReconAgent / ScanAgent (hasta Bloque D).
  - NUEVO   (run(ctx) -> AgentResult)     → BaseAgent: AnalysisAgent / ReporterAgent
                                            (stubs por ahora) y los demás tras Bloque D.
"""

import logging
from typing import Optional

from sqlalchemy.orm import Session

import models
from services.pipeline_runs_service import (
    start_pipeline,
    finish_pipeline,
    start_stage,
    finish_stage,
    append_stage,
)
from services.agent_base import BaseAgent, AgentResult, build_agent_context
from services.recon_agent import ReconAgent
from services.scan_agent import ScanAgent
from services.analysis_agent import AnalysisAgent
from services.reporter_agent import ReporterAgent
from utils import utc_now

logger = logging.getLogger(__name__)


# Objetivo por defecto que recibe cada agente nuevo-contrato cuando el caller no
# especifica uno. Los agentes legacy lo ignoran (leen su scope de la BD).
_DEFAULT_GOALS: dict[str, str] = {
    "ReconAgent":    "Mapear pasivamente la superficie de ataque autorizada.",
    "ScanAgent":     "Enumerar y caracterizar la superficie autorizada.",
    "AnalysisAgent": "Producir un cuadro de riesgo priorizado y con evidencia a partir de los findings.",
    "ReporterAgent": "Generar los reportes técnico y ejecutivo del engagement.",
}


# Fix 2.3 — Excepción tipada para "no se puede iniciar la stage porque hay
# HITL PENDING preexistentes". Antes (commit bb3bf12) se usaba un
# RuntimeError genérico que caía en `except Exception` y marcaba la stage
# como `failed`, lo que no era cierto: la stage no falló, simplemente
# rechazó iniciarse porque hay cola pendiente. Esta excepción se captura
# antes del except Exception y mapea a status='waiting_hitl'.
class WaitingHitlError(Exception):
    """Lanzada por _run_stage cuando hay HITL PENDING del engagement+agente."""

    def __init__(
        self,
        agent_name: str,
        engagement_id: int,
        pending_hitl_ids: list[int],
    ):
        self.agent_name      = agent_name
        self.engagement_id   = engagement_id
        self.pending_hitl_ids = pending_hitl_ids
        super().__init__(
            f"No se puede iniciar {agent_name} sobre engagement {engagement_id}: "
            f"hay {len(pending_hitl_ids)} acción(es) HITL PENDING "
            f"(ids={pending_hitl_ids}). Aprobar/rechazar o expirar antes de continuar."
        )


_AGENT_REGISTRY = {
    "ReconAgent":    ReconAgent,
    "ScanAgent":     ScanAgent,
    "AnalysisAgent": AnalysisAgent,
    "ReporterAgent": ReporterAgent,
}

# Default oficial: el pipeline completo de 4 stages goal-driven (ADR-005),
# alineado con el frontend (PipelineView). El caller (Orquestador / operador)
# puede pasar cualquier subconjunto/orden vía `stages=[...]`.
DEFAULT_STAGES: list[str] = ["ReconAgent", "ScanAgent", "AnalysisAgent", "ReporterAgent"]


class PipelineController:
    """Orquestador secuencial de los agentes del pipeline."""

    def __init__(
        self,
        engagement_id: int,
        db: Session,
        stages: Optional[list[str]] = None,
        triggered_by: str = "operator",
        stop_on_failure: bool = True,
        report_name: Optional[str] = None,
    ):
        self.engagement_id = engagement_id
        self.db = db
        self.stages = stages or DEFAULT_STAGES
        self.triggered_by = triggered_by
        self.stop_on_failure = stop_on_failure
        # Nombre base opcional para los PDFs (lo consume el ReporterAgent vía ctx).
        self._report_name = report_name
        self._pipeline_id: Optional[str] = None

        unknown = [s for s in self.stages if s not in _AGENT_REGISTRY]
        if unknown:
            raise ValueError(
                f"Stages desconocidas: {unknown}. "
                f"Disponibles: {list(_AGENT_REGISTRY.keys())}"
            )

    def _is_full_assessment(self) -> bool:
        """¿Esta corrida es un pipeline real de evaluación (no un single-stage
        suelto ni un report-only)? Solo entonces cerramos el engagement. Exige
        ≥2 stages con scan o análisis: así un `POST /analysis` o `/scan` aislado
        (stage única) NO completa el engagement — el operador puede seguir
        iterando — mientras que el pipeline completo (4 stages) sí lo cierra."""
        return len(self.stages) >= 2 and any(
            s in self.stages for s in ("ScanAgent", "AnalysisAgent")
        )

    def _complete_engagement(self) -> None:
        """B1 — transiciona el engagement RUNNING → COMPLETED al cerrar el
        pipeline con éxito, respetando VALID_TRANSITIONS. Antes nada lo cerraba
        automáticamente: quedaba 'running' y el operador lo cerraba a mano DESPUÉS
        de generar el PDF → el reporte congelaba 'running' mientras la UI mostraba
        'completed'. Idempotente."""
        eng = (
            self.db.query(models.Engagement)
            .filter(models.Engagement.id == self.engagement_id)
            .first()
        )
        if not eng:
            return
        if models.EngagementStatus.COMPLETED in models.VALID_TRANSITIONS.get(eng.status, []):
            eng.status = models.EngagementStatus.COMPLETED
            eng.updated_at = utc_now()
            self.db.commit()
            logger.info(
                "[PipelineController] engagement=%d → COMPLETED", self.engagement_id
            )

    async def run(self) -> dict:
        """
        Ejecuta el pipeline completo.
        """
        self._pipeline_id = await start_pipeline(
            engagement_id=self.engagement_id,
            agents=self.stages,
            triggered_by=self.triggered_by,
        )

        logger.info(
            "[PipelineController] Iniciando — pipeline_id=%s engagement=%d stages=%s",
            self._pipeline_id,
            self.engagement_id,
            self.stages,
        )

        results: list[dict] = []
        completed_count = 0
        failed_count = 0
        waiting_hitl = False
        first_error: Optional[str] = None

        for idx, agent_name in enumerate(self.stages):
            await start_stage(self._pipeline_id, idx)
            logger.info(
                "[PipelineController] stage %d/%d → %s",
                idx + 1,
                len(self.stages),
                agent_name,
            )

            # B1 — si la última stage es el reporte y todo lo previo salió bien,
            # cerramos el engagement ANTES de generarlo, así el PDF refleja
            # 'completed' (el reporter lee el estado en vivo). Generar el reporte es
            # el entregable terminal: aplica también al POST /report standalone
            # (stages=["ReporterAgent"]). Si el reporte falla luego, el trabajo de
            # evaluación igual está hecho (es regenerable).
            if (
                idx == len(self.stages) - 1
                and agent_name == "ReporterAgent"
                and not waiting_hitl
                and failed_count == 0
            ):
                self._complete_engagement()

            try:
                stage_result = await self._run_stage(agent_name)
                stage_status = str(stage_result.get("status", "completed")).lower()

                if stage_status == "waiting_hitl":
                    waiting_hitl = True

                    results.append({
                        "agent": agent_name,
                        "status": "waiting_hitl",
                        "result": stage_result,
                    })

                    await finish_stage(
                        pipeline_id=self._pipeline_id,
                        stage_idx=idx,
                        status="waiting_hitl",
                        agent_run_id=stage_result.get("agent_run_id"),
                        summary=_summarize_stage(agent_name, stage_result),
                    )

                    for skip_idx in range(idx + 1, len(self.stages)):
                        await finish_stage(
                            pipeline_id=self._pipeline_id,
                            stage_idx=skip_idx,
                            status="skipped",
                            summary="Pipeline pausado esperando aprobación HITL de la stage anterior.",
                        )

                    logger.info(
                        "[PipelineController] Pipeline pausado por HITL — agent=%s pending_hitl_ids=%s",
                        agent_name,
                        stage_result.get("pending_hitl_ids", []),
                    )
                    break

                # Un AgentResult con status='failed' (contrato nuevo, no levanta
                # excepción) NO debe contarse como completed. Lo tratamos como
                # falla de stage y respetamos stop_on_failure.
                if stage_status == "failed":
                    failed_count += 1
                    if first_error is None:
                        first_error = f"{agent_name}: {stage_result.get('error') or stage_result.get('reason') or 'falló'}"
                    results.append({"agent": agent_name, "status": "failed", "result": stage_result})
                    await finish_stage(
                        pipeline_id=self._pipeline_id,
                        stage_idx=idx,
                        status="failed",
                        agent_run_id=stage_result.get("agent_run_id"),
                        error=str(stage_result.get("error") or stage_result.get("reason") or "")[:500],
                        summary=_summarize_stage(agent_name, stage_result),
                    )
                    if self.stop_on_failure:
                        for skip_idx in range(idx + 1, len(self.stages)):
                            await finish_stage(
                                pipeline_id=self._pipeline_id,
                                stage_idx=skip_idx,
                                status="skipped",
                                summary="Stage anterior falló (stop_on_failure=True).",
                            )
                        break
                    continue

                # completed / partial / skipped → la stage corrió. Registramos el
                # status real (partial se mapea a 'completed' por compat del schema).
                results.append({
                    "agent": agent_name,
                    "status": stage_status,
                    "result": stage_result,
                })
                completed_count += 1

                await finish_stage(
                    pipeline_id=self._pipeline_id,
                    stage_idx=idx,
                    status="completed" if stage_status == "partial" else stage_status,
                    agent_run_id=stage_result.get("agent_run_id"),
                    summary=_summarize_stage(agent_name, stage_result),
                )

            except WaitingHitlError as wh:
                # Fix 2.3 — La stage no se ejecutó porque hay HITL preexistentes.
                # NO es una falla: es el mismo estado terminal que cuando el
                # ScanAgent retorna status='waiting_hitl' desde dentro. Lo
                # mapeamos al mismo flujo (sin counting como failed).
                waiting_hitl = True

                logger.info(
                    "[PipelineController] Stage %s rechazada por HITL preexistentes "
                    "— pending_hitl_ids=%s",
                    agent_name,
                    wh.pending_hitl_ids,
                )

                stage_result_dict = {
                    "status":           "waiting_hitl",
                    "engagement_id":    self.engagement_id,
                    "findings_count":   0,
                    "pending_hitl_ids": wh.pending_hitl_ids,
                    "reason":           str(wh),
                }

                results.append({
                    "agent":  agent_name,
                    "status": "waiting_hitl",
                    "result": stage_result_dict,
                })

                await finish_stage(
                    pipeline_id=self._pipeline_id,
                    stage_idx=idx,
                    status="waiting_hitl",
                    summary=_summarize_stage(agent_name, stage_result_dict),
                )

                for skip_idx in range(idx + 1, len(self.stages)):
                    await finish_stage(
                        pipeline_id=self._pipeline_id,
                        stage_idx=skip_idx,
                        status="skipped",
                        summary="Pipeline pausado: HITL pendientes en stage anterior.",
                    )
                break

            except Exception as e:
                logger.exception(
                    "[PipelineController] stage %s falló: %s",
                    agent_name,
                    e,
                )

                results.append({
                    "agent": agent_name,
                    "status": "failed",
                    "error": str(e),
                })
                failed_count += 1

                if first_error is None:
                    first_error = f"{agent_name}: {e}"

                await finish_stage(
                    pipeline_id=self._pipeline_id,
                    stage_idx=idx,
                    status="failed",
                    error=str(e)[:500],
                )

                if self.stop_on_failure:
                    for skip_idx in range(idx + 1, len(self.stages)):
                        await finish_stage(
                            pipeline_id=self._pipeline_id,
                            stage_idx=skip_idx,
                            status="skipped",
                            summary="Stage anterior falló (stop_on_failure=True).",
                        )
                    break

        if waiting_hitl:
            final_status = "waiting_hitl"
        elif failed_count == 0:
            final_status = "completed"
        elif completed_count == 0:
            final_status = "failed"
        else:
            final_status = "partial_failed"

        if final_status == "waiting_hitl":
            summary = (
                f"{completed_count}/{len(self.stages)} stages completadas · "
                f"pipeline pausado esperando HITL"
            )
        else:
            summary = (
                f"{completed_count}/{len(self.stages)} stages completadas"
                + (f" · {failed_count} fallidas" if failed_count else "")
            )

        # B1 — cierre del engagement para pipelines SIN stage de reporte
        # (ej. Recon→Scan→Analysis): si terminó OK, marcamos COMPLETED. El caso
        # con reporte terminal ya se cerró antes de esa stage (arriba). Idempotente.
        if final_status == "completed" and self._is_full_assessment():
            self._complete_engagement()

        await finish_pipeline(
            pipeline_id=self._pipeline_id,
            status=final_status,
            summary=summary,
            error=first_error,
        )

        logger.info(
            "[PipelineController] Finalizado — pipeline_id=%s status=%s %s",
            self._pipeline_id,
            final_status,
            summary,
        )

        return {
            "pipeline_run_id": self._pipeline_id,
            "engagement_id": self.engagement_id,
            "status": final_status,
            "stages_completed": completed_count,
            "stages_failed": failed_count,
            "summary": summary,
            "results": results,
        }

    async def run_single_stage(
        self,
        agent_name: str,
        *,
        goal: Optional[str] = None,
        operator_directive: Optional[str] = None,
        pipeline_id: Optional[str] = None,
    ) -> dict:
        """
        Ejecuta EXACTAMENTE un agente con un objetivo + directiva explícitos y el
        bookkeeping completo (pipeline_runs de 1 stage). Lo usa el Orquestador
        (Bloque A): por cada `tool_use` que el LLM emite sobre un worker, llama
        aquí con el `goal` que decidió y el `operator_directive` (ej. la intensidad
        pedida por el operador). Conserva intactos el anti-zombi y el registro de
        rationale de `_run_stage`.

        No reemplaza a `run()`: `run()` sigue siendo el camino multi-stage
        secuencial de /pipeline, /scan, etc. Este método es el de grano fino que
        el orquestador necesita para delegar de a un worker por vez.

        Devuelve el dict uniforme de la stage (status/rationale/findings_count/
        pending_hitl_ids/artifacts) + `pipeline_run_id` para trazabilidad.
        """
        if agent_name not in _AGENT_REGISTRY:
            raise ValueError(
                f"Agente desconocido: {agent_name}. "
                f"Disponibles: {list(_AGENT_REGISTRY.keys())}"
            )

        # Dos modos de bookkeeping:
        #  - shared=True  (orquestador): se anexa la stage a UN pipeline_run de la
        #    sesión (Opción A) → la pestaña Pipeline ve la secuencia completa de
        #    agentes. NO se cierra el pipeline aquí (lo cierra el orquestador al final).
        #  - shared=False (default): pipeline_run propio de 1 stage (compat previa).
        shared = pipeline_id is not None
        if shared:
            self._pipeline_id = pipeline_id
            stage_idx = await append_stage(pipeline_id, agent_name)  # ya queda 'running'
        else:
            self._pipeline_id = await start_pipeline(
                engagement_id=self.engagement_id,
                agents=[agent_name],
                triggered_by=self.triggered_by,
            )
            stage_idx = 0
            await start_stage(self._pipeline_id, stage_idx)

        logger.info(
            "[PipelineController] run_single_stage — pipeline_id=%s stage_idx=%d engagement=%d agent=%s goal=%r directive=%r shared=%s",
            self._pipeline_id, stage_idx, self.engagement_id, agent_name, goal, operator_directive, shared,
        )

        # B1 — generar el reporte es el entregable terminal del engagement: si está
        # RUNNING, lo cerramos ANTES de que ReporterAgent lea el estado, para que el
        # PDF diga 'completed' también en el flujo orquestado (run_single_stage) y en
        # el POST /report standalone. Idempotente; respeta VALID_TRANSITIONS.
        if agent_name == "ReporterAgent":
            self._complete_engagement()

        try:
            stage_result = await self._run_stage(
                agent_name, goal=goal, operator_directive=operator_directive,
            )
            stage_status = str(stage_result.get("status", "completed")).lower()

            # partial se mapea a 'completed' por compat del schema de stages,
            # igual que en run().
            finish_status = "completed" if stage_status == "partial" else stage_status
            await finish_stage(
                pipeline_id=self._pipeline_id,
                stage_idx=stage_idx,
                status=finish_status,
                agent_run_id=stage_result.get("agent_run_id"),
                error=str(stage_result.get("error") or "")[:500] or None,
                summary=_summarize_stage(agent_name, stage_result),
            )

            if not shared:
                final_status = (
                    stage_status if stage_status in ("waiting_hitl", "failed", "skipped")
                    else "completed"
                )
                await finish_pipeline(
                    pipeline_id=self._pipeline_id,
                    status=final_status,
                    summary=_summarize_stage(agent_name, stage_result),
                    error=stage_result.get("error") if stage_status == "failed" else None,
                )

        except WaitingHitlError as wh:
            # Pre-check anti-zombi rechazó la stage: no es falla, es waiting_hitl.
            stage_result = {
                "status":           "waiting_hitl",
                "engagement_id":    self.engagement_id,
                "findings_count":   0,
                "pending_hitl_ids": wh.pending_hitl_ids,
                "reason":           str(wh),
                "rationale":        str(wh),
            }
            await finish_stage(
                pipeline_id=self._pipeline_id, stage_idx=stage_idx, status="waiting_hitl",
                summary=_summarize_stage(agent_name, stage_result),
            )
            if not shared:
                await finish_pipeline(
                    pipeline_id=self._pipeline_id, status="waiting_hitl",
                    summary=_summarize_stage(agent_name, stage_result),
                )

        except Exception as e:
            logger.exception("[PipelineController] run_single_stage %s falló: %s", agent_name, e)
            stage_result = {
                "status":         "failed",
                "engagement_id":  self.engagement_id,
                "findings_count": 0,
                "error":          str(e),
                "rationale":      f"La stage {agent_name} falló: {e}",
            }
            await finish_stage(
                pipeline_id=self._pipeline_id, stage_idx=stage_idx, status="failed",
                error=str(e)[:500],
            )
            if not shared:
                await finish_pipeline(
                    pipeline_id=self._pipeline_id, status="failed",
                    summary=f"{agent_name} falló", error=str(e),
                )

        return {
            "pipeline_run_id": self._pipeline_id,
            "agent":           agent_name,
            "status":          stage_result.get("status", "completed"),
            "result":          stage_result,
        }

    async def _run_stage(
        self,
        agent_name: str,
        *,
        goal: Optional[str] = None,
        operator_directive: Optional[str] = None,
    ) -> dict:
        """
        Instancia el agente y lo ejecuta, forwardeando pipeline_run_id.
        Contract-aware: soporta agentes legacy (run()->dict) y nuevos
        (BaseAgent.run(ctx)->AgentResult). Devuelve siempre un dict uniforme
        para que el bookkeeping de run() no cambie.

        `goal` / `operator_directive` (Bloque A): cuando el caller es el
        Orquestador, le pasa un objetivo en NL y una directiva (ej. la
        intensidad pedida). Si `goal` es None se usa `_DEFAULT_GOALS` (el
        camino histórico de run() / /scan / /recon / … queda idéntico).
        """
        if agent_name == "ScanAgent":
            # Anti-zombi (Fase 1): no iniciar si hay HITL PENDING del ScanAgent.
            pending_rows = (
                self.db.query(models.HitlAction.id)
                .filter(
                    models.HitlAction.engagement_id == self.engagement_id,
                    models.HitlAction.agent == "ScanAgent",
                    models.HitlAction.decision == "PENDING",
                )
                .order_by(models.HitlAction.id.asc())
                .all()
            )
            if pending_rows:
                raise WaitingHitlError(
                    agent_name="ScanAgent",
                    engagement_id=self.engagement_id,
                    pending_hitl_ids=[r[0] for r in pending_rows],
                )

        AgentCls = _AGENT_REGISTRY[agent_name]
        agent = AgentCls(
            engagement_id=self.engagement_id,
            db=self.db,
            pipeline_run_id=self._pipeline_id,
        )

        # ── Nuevo contrato (BaseAgent): construye AgentContext, recibe AgentResult ──
        if isinstance(agent, BaseAgent):
            stage_goal = goal or _DEFAULT_GOALS.get(agent_name, f"Ejecutar {agent_name}")
            ctx = await build_agent_context(
                self.db,
                self.engagement_id,
                goal=stage_goal,
                operator_directive=operator_directive,
            )
            # Nombre de reporte que asignó el operador (lo usa solo el ReporterAgent).
            ctx.report_name = self._report_name
            result = await agent.run(ctx)

            # Auditoría: el ejecutor es la ÚNICA fuente del rationale en el
            # blackboard para agentes nuevo-contrato. Los 4 workers lo DELEGAN aquí
            # (no auto-registran) para evitar doble registro. Se enlaza con el
            # AgentRunDoc vía artifacts.agent_run_id cuando el agente lo expone.
            try:
                from services.blackboard import record_rationale
                await record_rationale(
                    self.engagement_id,
                    agent_name,
                    result.rationale,
                    status=result.status,
                    run_id=result.artifacts.get("agent_run_id"),
                    pipeline_run_id=self._pipeline_id,
                )
            except Exception as e:  # noqa: BLE001 — la auditoría no debe tumbar el run
                logger.warning(
                    "[PipelineController] no se pudo registrar rationale de %s: %s",
                    agent_name, e,
                )
            return _result_to_stage_dict(result, self.engagement_id)

        # ── Legacy (ReconAgent / ScanAgent hasta el refactor del Bloque D) ──────
        return await agent.run()


def _result_to_stage_dict(result: AgentResult, engagement_id: int) -> dict:
    """Normaliza un AgentResult (contrato nuevo) al dict uniforme que consume el
    bookkeeping de run() / _summarize_stage / finish_stage."""
    return {
        "status":           result.status,
        "engagement_id":    engagement_id,
        "findings_count":   result.findings_count,
        "pending_hitl_ids": result.pending_hitl_ids,
        "agent_run_id":     result.artifacts.get("agent_run_id"),
        "rationale":        result.rationale,
        "artifacts":        result.artifacts,
        "reason":           result.error or result.rationale,
    }


def _summarize_stage(agent_name: str, result: dict) -> str:
    """Resumen corto de la stage para frontend / pipeline_runs."""
    status = str(result.get("status", "completed")).lower()

    if agent_name == "ReconAgent":
        sm = result.get("surface_map") or {}
        hosts = len(sm.get("hosts_discovered", []) if isinstance(sm, dict) else [])
        emails = len(sm.get("emails_osint", []) if isinstance(sm, dict) else [])
        return f"{hosts} hosts · {emails} emails OSINT"

    if agent_name == "ScanAgent":
        findings_count = result.get("findings_count", 0)
        pending_ids = result.get("pending_hitl_ids", []) or []

        if status == "waiting_hitl":
            return (
                f"{findings_count} findings · "
                f"esperando HITL ({len(pending_ids)} pendientes: {pending_ids})"
            )

        return f"{findings_count} findings"

    return result.get("status", "completed")