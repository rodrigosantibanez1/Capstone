"""
pipeline_runs_service.py — Helper para PipelineRunDoc (orquestación end-to-end)
==============================================================================
Persiste y actualiza el log del PipelineController en `pipeline_runs`.
Cada PipelineRun contiene N `StageEntry` correspondientes a los agentes
ejecutados en orden. Los `agent_run_id` de cada stage referencian el
AgentRunDoc individual con el detalle de tool calls.

Patrón de uso desde el Controller:

    pid = await start_pipeline(engagement_id, ["ReconAgent", "ScanAgent"])
    try:
        for i, agent in enumerate(stages):
            await start_stage(pid, i)
            try:
                run_id = await agent_run()    # ReconAgent.run() / ScanAgent.run()
                await finish_stage(pid, i, "completed", agent_run_id=run_id)
            except Exception as e:
                await finish_stage(pid, i, "failed", error=str(e))
                raise
        await finish_pipeline(pid, "completed")
    except Exception as e:
        await finish_pipeline(pid, "failed", error=str(e))
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Optional

from bson import ObjectId
from pymongo import ReturnDocument

from mongo_client import pipeline_runs_col
from mongo_schemas import PipelineRunDoc, StageEntry
from utils import utc_now

logger = logging.getLogger(__name__)


# ── Pipeline lifecycle ────────────────────────────────────────────────────────

async def start_pipeline(
    engagement_id: int,
    agents: list[str],
    triggered_by: str = "operator",
) -> str:
    """
    Crea el PipelineRunDoc con todas las stages en status='pending'.
    Retorna el _id como string.
    """
    stages = [StageEntry(agent=a) for a in agents]
    doc = PipelineRunDoc(
        engagement_id = engagement_id,
        stages        = stages,
        triggered_by  = triggered_by,
    )
    result = await pipeline_runs_col().insert_one(doc.model_dump())
    pid    = str(result.inserted_id)
    logger.info(
        "[pipeline_runs] start pipeline_id=%s engagement=%d stages=%s",
        pid, engagement_id, agents,
    )
    return pid


async def finish_pipeline(
    pipeline_id: str,
    status: str,
    summary: Optional[str] = None,
    error: Optional[str]   = None,
) -> None:
    """Cierra el PipelineRunDoc con status final."""
    update: dict[str, Any] = {
        "status":      status,
        "finished_at": utc_now(),
        "updated_at":  utc_now(),
    }
    if summary is not None: update["summary"] = summary
    if error   is not None: update["error"]   = error

    await pipeline_runs_col().update_one(
        {"_id": ObjectId(pipeline_id)}, {"$set": update}
    )
    logger.info("[pipeline_runs] finish pipeline_id=%s status=%s", pipeline_id, status)


# ── Stage lifecycle ───────────────────────────────────────────────────────────

async def append_stage(pipeline_id: str, agent: str) -> int:
    """
    Agrega una StageEntry nueva (status='running') al final de un pipeline ya
    creado y devuelve su índice. Para pipelines de stages DINÁMICAS: el
    Orquestador no conoce de antemano qué workers va a delegar, así que cada
    delegación empuja su stage a un único pipeline_run de la sesión (Opción A,
    observabilidad del flujo orquestado).
    """
    stage = StageEntry(agent=agent, status="running", started_at=utc_now())
    doc = await pipeline_runs_col().find_one_and_update(
        {"_id": ObjectId(pipeline_id)},
        {"$push": {"stages": stage.model_dump()}, "$set": {"updated_at": utc_now()}},
        return_document=ReturnDocument.AFTER,
    )
    idx = len(doc.get("stages", [])) - 1
    logger.info("[pipeline_runs] append stage pipeline_id=%s idx=%d agent=%s", pipeline_id, idx, agent)
    return idx


async def start_stage(pipeline_id: str, stage_idx: int) -> None:
    """Marca una stage como running."""
    await pipeline_runs_col().update_one(
        {"_id": ObjectId(pipeline_id)},
        {"$set": {
            f"stages.{stage_idx}.status":     "running",
            f"stages.{stage_idx}.started_at": utc_now(),
            "updated_at":                     utc_now(),
        }},
    )


async def finish_stage(
    pipeline_id: str,
    stage_idx: int,
    status: str,
    agent_run_id: Optional[str] = None,
    summary: Optional[str]      = None,
    error: Optional[str]        = None,
) -> None:
    """Cierra una stage con su resultado."""
    set_fields: dict[str, Any] = {
        f"stages.{stage_idx}.status":      status,
        f"stages.{stage_idx}.finished_at": utc_now(),
        "updated_at":                       utc_now(),
    }
    if agent_run_id is not None: set_fields[f"stages.{stage_idx}.agent_run_id"] = agent_run_id
    if summary      is not None: set_fields[f"stages.{stage_idx}.summary"]      = summary
    if error        is not None: set_fields[f"stages.{stage_idx}.error"]        = error

    await pipeline_runs_col().update_one(
        {"_id": ObjectId(pipeline_id)}, {"$set": set_fields}
    )


# ── Read helpers ──────────────────────────────────────────────────────────────

def _serialize(doc: dict) -> dict:
    """ObjectId y datetime → strings serializables a JSON."""
    if "_id" in doc:
        doc["_id"] = str(doc["_id"])
    for key in ("started_at", "finished_at", "updated_at"):
        v = doc.get(key)
        if isinstance(v, datetime):
            doc[key] = v.isoformat()
    for stage in doc.get("stages", []) or []:
        for key in ("started_at", "finished_at"):
            v = stage.get(key)
            if isinstance(v, datetime):
                stage[key] = v.isoformat()
    return doc


async def list_pipelines(engagement_id: int, limit: int = 50) -> list[dict]:
    """Pipelines del engagement, orden desc por started_at."""
    cursor = (
        pipeline_runs_col()
        .find({"engagement_id": engagement_id})
        .sort("started_at", -1)
        .limit(limit)
    )
    docs = await cursor.to_list(length=limit)
    return [_serialize(d) for d in docs]


async def get_pipeline(pipeline_id: str) -> Optional[dict]:
    """Detalle de un pipeline run."""
    doc = await pipeline_runs_col().find_one({"_id": ObjectId(pipeline_id)})
    return _serialize(doc) if doc else None


async def get_latest_pipeline(engagement_id: int) -> Optional[dict]:
    """Atajo: el pipeline más reciente del engagement."""
    doc = await pipeline_runs_col().find_one(
        {"engagement_id": engagement_id},
        sort=[("started_at", -1)],
    )
    return _serialize(doc) if doc else None
