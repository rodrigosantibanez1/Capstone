"""
recon_agent.py — ReconAgent · ETH-MAS (Bloque D, ADR-005)
=========================================================
Agente de reconocimiento OSINT, refactorizado a GOAL-DRIVEN sobre el contrato
común `BaseAgent` (Bloque 0): recibe un `AgentContext` y devuelve un
`AgentResult` con `rationale`.

Qué cambió respecto al ReconAgent legacy (checklist "para CADA target a/b/c"):
  - PROMPT DE OBJETIVO: la meta es "mapear pasivamente la superficie". El modelo
    decide qué tools usar según el TIPO de target (dominio → enumerar
    subdominios/MX/NS tiene sentido; IP suelta → whois/PTR, theHarvester aporta
    poco). Antes ejecutaba las 3 tools en orden fijo sobre todo.
  - TERMINACIÓN por criterio + PRESUPUESTO (`ctx.budget_steps`).
  - CONTINUIDAD: si ya hay un surface_map previo en el blackboard, lo informa
    al modelo en vez de re-mapear a ciegas.
  - RATIONALE: escribe el porqué de su recon en el blackboard.

Backend del LLM configurable (claude por defecto, gemini alternativo). El MCP
server (osint_server.py) no cambia — es agnóstico al cliente LLM. Las tools de
recon son pasivas (risk LOW, auto-approve): no hay pausa HITL.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Optional

from sqlalchemy.orm import Session

from mongo_client import surface_map_col
from mongo_schemas import SurfaceMapDoc
from services.agent_base import RECON_AGENT, AgentContext, AgentResult, BaseAgent
from services.agent_config import recon_agent_model
from services.agent_runs_service import (
    start_run, finish_run, begin_tool_call, end_tool_call,
)
from services.anthropic_health import (
    mark_anthropic_failure, mark_anthropic_success,
)
from utils import utc_now

logger = logging.getLogger(__name__)

RECON_AGENT_BACKEND = os.getenv("RECON_AGENT_BACKEND", "claude").lower()

_OSINT_SERVER_SCRIPT = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "mcp_servers", "osint_server.py")
)


def _looks_like_ip_or_cidr(value: str) -> bool:
    """Heurística barata: ¿el target es una IP/CIDR (no un dominio)? Sin lookups."""
    import ipaddress
    v = (value or "").strip()
    try:
        ipaddress.ip_network(v, strict=False)
        return True
    except ValueError:
        return False


class ReconAgent(BaseAgent):
    name = RECON_AGENT

    def __init__(
        self,
        engagement_id: int,
        db: Session,
        pipeline_run_id: Optional[str] = None,
    ):
        super().__init__(engagement_id, db, pipeline_run_id)
        self.model = recon_agent_model()
        self._run_id: Optional[str] = None
        self._tool_count: int = 0

    # ── Entry point (contrato BaseAgent) ──────────────────────────────────────
    async def run(self, ctx: AgentContext) -> AgentResult:
        targets = ctx.targets()
        if not targets:
            return AgentResult(
                agent=self.name, status="skipped",
                rationale="No hay scope targets configurados; nada que reconocer.",
            )

        logger.info(
            "[ReconAgent] Iniciando — engagement=%d model=%s targets=%s",
            self.engagement_id, self.model, targets,
        )

        self._run_id = await start_run(
            engagement_id=self.engagement_id, agent=self.name, model=self.model,
            targets=targets, pipeline_run_id=self.pipeline_run_id,
        )

        surface_map: dict = {}
        final_status = "completed"
        error_msg: Optional[str] = None
        scope_values = list(targets)
        budget = max(ctx.budget_steps, len(targets) * 4)

        try:
            if RECON_AGENT_BACKEND == "gemini":
                surface_map = await self._run_agentic_loop_gemini(ctx, targets, scope_values, budget)
            else:
                surface_map = await self._run_agentic_loop(ctx, targets, scope_values, budget)
            if RECON_AGENT_BACKEND == "claude":
                mark_anthropic_success()
        except Exception as e:
            from anthropic import APIStatusError
            try:
                from anthropic import AuthenticationError
            except ImportError:
                AuthenticationError = APIStatusError  # type: ignore

            if isinstance(e, AuthenticationError) or (
                isinstance(e, APIStatusError) and getattr(e, "status_code", None) == 401
            ):
                error_msg = ("ANTHROPIC_API_KEY inválida o revocada (401). "
                             "Revisar configuración en .env y /health/services?refresh=true.")
                logger.error("[ReconAgent] %s", error_msg)
                mark_anthropic_failure("401 desde ReconAgent")
            else:
                logger.error("[ReconAgent] Error en agentic loop: %s", e, exc_info=True)
                error_msg = str(e)
            final_status = "failed"

        hosts = surface_map.get("hosts_discovered", []) if isinstance(surface_map, dict) else []
        emails = surface_map.get("emails_osint", []) if isinstance(surface_map, dict) else []
        summary = f"{self._tool_count} tool calls · {len(hosts)} hosts · {len(emails)} emails"

        await finish_run(
            run_id=self._run_id, status=final_status, error=error_msg, summary=summary,
        )

        # El rationale viaja en AgentResult.rationale; el ejecutor seguro lo
        # persiste en el blackboard (delegación nuevo-contrato, sin doble registro).
        rationale = self._build_rationale(targets, final_status, hosts, emails, error_msg)

        logger.info(
            "[ReconAgent] Finalizado — engagement=%d status=%s tools=%d",
            self.engagement_id, final_status, self._tool_count,
        )

        return AgentResult(
            agent=self.name,
            status=final_status,
            rationale=rationale,
            findings_count=len(hosts),
            artifacts={"agent_run_id": self._run_id, "surface_map": surface_map},
            budget_used={"steps": self._tool_count},
            error=error_msg,
        )

    # ── Agentic loop (Claude) ─────────────────────────────────────────────────
    async def _run_agentic_loop(
        self, ctx: AgentContext, targets: list[str], scope_values: list[str], budget: int,
    ) -> dict:
        from anthropic import AsyncAnthropic
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        server_params = StdioServerParameters(
            command="python", args=[_OSINT_SERVER_SCRIPT], env={**os.environ},
        )

        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                mcp_tools = await session.list_tools()
                anthropic_tools = [
                    {"name": t.name, "description": t.description or "", "input_schema": t.inputSchema}
                    for t in mcp_tools.tools
                ]
                logger.info("[ReconAgent] MCP listo — tools: %s", [t["name"] for t in anthropic_tools])

                messages: list[dict] = [{"role": "user", "content": self._build_kickoff(ctx, targets)}]
                raw_results: list[dict] = []

                for iteration in range(budget):
                    response = await client.messages.create(
                        model=self.model, max_tokens=4096,
                        system=self._build_system_prompt(targets),
                        tools=anthropic_tools, messages=messages,
                    )
                    messages.append({"role": "assistant", "content": response.content})

                    if response.stop_reason == "tool_use":
                        tool_results_content = []
                        for block in response.content:
                            if block.type != "tool_use":
                                continue
                            t_start = utc_now()
                            result_text = "{}"
                            call_status = "completed"
                            error_text: Optional[str] = None
                            hitl_id: Optional[int] = None
                            tool_input = dict(block.input)
                            target_val = tool_input.get("target", "")

                            call_idx = await begin_tool_call(
                                run_id=self._run_id, tool=block.name,
                                target=target_val, params=tool_input,
                            )
                            self._tool_count += 1

                            try:
                                mcp_result = await session.call_tool(block.name, tool_input)
                                result_text = mcp_result.content[0].text if mcp_result.content else "{}"
                                parsed = json.loads(result_text)
                                raw_results.append(parsed)
                                hitl_id = parsed.get("hitl_action_id")
                                if parsed.get("status") == "blocked":
                                    call_status = "scope_violation"
                                    logger.warning(
                                        "[ReconAgent] Scope violation — tool=%s input=%s",
                                        block.name, block.input,
                                    )
                            except Exception as e:
                                result_text = json.dumps({"error": str(e), "status": "error"})
                                call_status = "error"
                                error_text = str(e)
                                logger.error("[ReconAgent] Error tool call %s: %s", block.name, e)

                            await end_tool_call(
                                run_id=self._run_id, call_idx=call_idx, status=call_status,
                                output_preview=result_text, error=error_text,
                                hitl_action_id=hitl_id,
                                duration_ms=int((utc_now() - t_start).total_seconds() * 1000),
                            )
                            tool_results_content.append({
                                "type": "tool_result", "tool_use_id": block.id, "content": result_text,
                            })

                        messages.append({"role": "user", "content": tool_results_content})

                    elif response.stop_reason == "end_turn":
                        logger.info(
                            "[ReconAgent] Loop finalizado por criterio — iter=%d tool_calls=%d",
                            iteration + 1, self._tool_count,
                        )
                        break
                    else:
                        logger.warning("[ReconAgent] stop_reason inesperado: %s", response.stop_reason)
                        break

        return await self._build_and_persist_surface_map(raw_results, scope_values)

    # ── Agentic loop (Gemini) ─────────────────────────────────────────────────
    async def _run_agentic_loop_gemini(
        self, ctx: AgentContext, targets: list[str], scope_values: list[str], budget: int,
    ) -> dict:
        from google.genai import types
        from google import genai
        from services.mcp_gemini_bridge import load_mcp_tools_for_gemini, call_mcp_tool_from_gemini

        gemini_key = os.getenv("GEMINI_API_KEY")
        if not gemini_key:
            raise RuntimeError("RECON_AGENT_BACKEND=gemini requiere GEMINI_API_KEY en .env")

        gemini_client = genai.Client(api_key=gemini_key)
        declarations, session, stack = await load_mcp_tools_for_gemini(_OSINT_SERVER_SCRIPT)
        raw_results: list[dict] = []

        async with stack:
            messages: list[types.Content] = [
                types.Content(role="user", parts=[types.Part(text=self._build_kickoff(ctx, targets))])
            ]
            for iteration in range(budget):
                response = gemini_client.models.generate_content(
                    model=self.model, contents=messages,
                    config=types.GenerateContentConfig(
                        system_instruction=self._build_system_prompt(targets),
                        tools=[types.Tool(function_declarations=declarations)],
                        temperature=0.1,
                    ),
                )
                candidate = response.candidates[0]
                messages.append(candidate.content)
                function_calls = [
                    p for p in candidate.content.parts
                    if hasattr(p, "function_call") and p.function_call
                ]
                if not function_calls:
                    logger.info(
                        "[ReconAgent/Gemini] Loop finalizado — iter=%d tool_calls=%d",
                        iteration + 1, self._tool_count,
                    )
                    break

                function_responses = []
                for part in function_calls:
                    fc = part.function_call
                    t_start = utc_now()
                    result_text = "{}"
                    call_status = "completed"
                    error_text: Optional[str] = None
                    hitl_id: Optional[int] = None
                    fc_args = dict(fc.args or {})
                    target_val = fc_args.get("target", "")

                    call_idx = await begin_tool_call(
                        run_id=self._run_id, tool=fc.name, target=target_val, params=fc_args,
                    )
                    self._tool_count += 1
                    try:
                        result_text = await call_mcp_tool_from_gemini(session, fc)
                        parsed = json.loads(result_text)
                        raw_results.append(parsed)
                        hitl_id = parsed.get("hitl_action_id")
                        if parsed.get("status") == "blocked":
                            call_status = "scope_violation"
                    except Exception as e:
                        result_text = json.dumps({"error": str(e), "status": "error"})
                        call_status = "error"
                        error_text = str(e)
                        logger.error("[ReconAgent/Gemini] Error tool call %s: %s", fc.name, e)

                    await end_tool_call(
                        run_id=self._run_id, call_idx=call_idx, status=call_status,
                        output_preview=result_text, error=error_text, hitl_action_id=hitl_id,
                        duration_ms=int((utc_now() - t_start).total_seconds() * 1000),
                    )
                    function_responses.append(
                        types.Part(function_response=types.FunctionResponse(
                            name=fc.name, response={"result": result_text},
                        ))
                    )
                messages.append(types.Content(role="user", parts=function_responses))

        return await self._build_and_persist_surface_map(raw_results, scope_values)

    # ── Surface map (persistencia determinista, sin cambios de lógica) ────────
    async def _build_and_persist_surface_map(
        self, raw_results: list[dict], scope_values: list[str],
    ) -> dict:
        emails: set[str] = set()
        ips: set[str] = set()
        hosts: set[str] = set()
        dns_records: dict = {}
        whois_data: dict = {}
        harvester_data: dict = {}

        for result in raw_results:
            if not isinstance(result, dict):
                continue
            tool = result.get("tool", "")
            target = result.get("target", "unknown")
            if tool == "dns_enum":
                recs = result.get("records", {})
                dns_records[target] = recs
                ips.update(recs.get("A", []))
            elif tool == "whois_lookup":
                whois_data[target] = result.get("data", {})
            elif tool == "theharvester_run":
                data = result.get("data", {})
                harvester_data[target] = data
                emails.update(data.get("emails", []))
                hosts.update(data.get("hosts", []))
                ips.update(data.get("ips", []))

        all_hosts = hosts | ips
        new_vs_scope = sorted(
            h for h in all_hosts
            if not any(h == sv or h.endswith(f".{sv}") for sv in scope_values)
        )

        doc = SurfaceMapDoc(
            engagement_id=self.engagement_id,
            scope_original=scope_values,
            emails_osint=sorted(emails),
            hosts_discovered=sorted(all_hosts),
            new_vs_scope=new_vs_scope,
            dns_records=dns_records,
            whois_data=whois_data,
            harvester_data=harvester_data,
            model_used=self.model,
        )
        await surface_map_col().replace_one(
            {"engagement_id": self.engagement_id}, doc.model_dump(), upsert=True,
        )
        logger.info(
            "[ReconAgent] Surface map persistido — engagement=%d hosts=%d emails=%d new_vs_scope=%d",
            self.engagement_id, len(doc.hosts_discovered), len(doc.emails_osint), len(doc.new_vs_scope),
        )
        return doc.model_dump()

    # ── Prompts (goal-driven) ─────────────────────────────────────────────────
    def _build_kickoff(self, ctx: AgentContext, targets: list[str]) -> str:
        goal = ctx.goal or "Mapear pasivamente la superficie de ataque autorizada."
        domains = [t for t in targets if not _looks_like_ip_or_cidr(t)]
        ips = [t for t in targets if _looks_like_ip_or_cidr(t)]
        hint = ""
        if domains:
            hint += f" Dominios ({domains}): tiene sentido dns_enum (A/MX/NS/TXT) y theHarvester."
        if ips:
            hint += (f" IPs/CIDR ({ips}): whois aporta; dns_enum/theHarvester rinden poco sobre "
                     f"direcciones sin dominio asociado — no insistas si no devuelven nada.")

        prior = ""
        sm = (ctx.prior_state or {}).get("surface_map")
        if isinstance(sm, dict) and sm.get("hosts_discovered"):
            prior = (f" Ya existe un surface_map previo con "
                     f"{len(sm['hosts_discovered'])} host(s); complementa, no repitas a ciegas.")

        return (
            f"{goal}\n\n"
            f"Engagement {self.engagement_id}. Targets autorizados: {targets}.{hint}{prior}\n"
            f"Incluye siempre engagement_id={self.engagement_id} en cada tool call. "
            f"Cuando tengas un panorama razonable, devuelve un resumen y termina."
        )

    def _build_system_prompt(self, targets: list[str]) -> str:
        return (
            f"Eres ReconAgent, el agente de reconocimiento OSINT (pasivo) de ETH-MAS.\n\n"
            f"OBJETIVO: mapear pasivamente la superficie de ataque de los targets "
            f"autorizados del engagement {self.engagement_id}. Solo recolección pasiva: "
            f"no escanees puertos ni toques el target (eso es del ScanAgent).\n\n"
            f"TARGETS AUTORIZADOS: {targets}\n"
            f"engagement_id obligatorio en cada tool call: {self.engagement_id}\n\n"
            f"HERRAMIENTAS (pasivas, risk LOW, sin HITL):\n"
            f"  - dns_enum(target, engagement_id): registros A/MX/NS/TXT.\n"
            f"  - whois_lookup(target, engagement_id): datos de registro.\n"
            f"  - theharvester_run(target, engagement_id): emails, hosts, IPs OSINT.\n\n"
            f"CÓMO DECIDIR (tú planificas, no hay secuencia obligatoria):\n"
            f"  - Para DOMINIOS: dns_enum y theHarvester suelen rendir; whois da el registro.\n"
            f"  - Para IPs/CIDR sueltos (sin dominio): whois es lo más útil; dns_enum y "
            f"theHarvester suelen volver vacíos — no insistas si no aportan.\n"
            f"  - Si una tool devuelve status 'blocked' (scope), no reintentes ese target.\n"
            f"  - Si devuelve 'tool_not_found'/'timeout', sigue con otra cosa.\n"
            f"  - Detente cuando tengas un panorama razonable; no hace falta correr todas las "
            f"tools sobre todos los targets si no aportan.\n\n"
            f"No infieras vulnerabilidades — eso es tarea de AnalysisAgent. Cierra con un "
            f"resumen breve de hosts/emails/datos encontrados."
        )

    # ── Rationale ──────────────────────────────────────────────────────────────
    def _build_rationale(
        self, targets: list[str], final_status: str,
        hosts: list, emails: list, error_msg: Optional[str],
    ) -> str:
        domains = [t for t in targets if not _looks_like_ip_or_cidr(t)]
        ips = [t for t in targets if _looks_like_ip_or_cidr(t)]
        parts = [
            f"Recon pasivo sobre {len(targets)} target(s) "
            f"({len(domains)} dominio(s), {len(ips)} IP/CIDR).",
            f"Ejecuté {self._tool_count} tool call(s) OSINT y consolidé un surface_map "
            f"con {len(hosts)} host(s) y {len(emails)} email(s).",
        ]
        if ips and not domains:
            parts.append(
                "Targets son IPs sin dominio: prioricé whois; dns/theHarvester aportan poco "
                "en RFC1918, por eso el OSINT puede venir vacío (esperado)."
            )
        if error_msg:
            parts.append(f"Nota de error: {error_msg}")
        return " ".join(parts)
