"""
report_renderer.py — Render determinístico de reportes · ETH-MAS (Bloque C, ADR-005)
====================================================================================
Renderer SIN LLM: Jinja2 (HTML) → WeasyPrint (PDF). El ReporterAgent arma el
contexto (datos del blackboard + narrativa del LLM) y llama aquí para producir el
PDF. Separar el render del razonamiento mantiene esta capa determinística y
testeable.

Imports de jinja2/weasyprint son PEREZOSOS (dentro de las funciones) a propósito:
weasyprint requiere libs de sistema (Pango/Cairo) que existen en la imagen Docker
pero no en el venv local de Windows. Así el módulo se importa en cualquier lado
y los tests de las piezas puras corren sin esas dependencias.
"""

from __future__ import annotations

import os
from typing import Any

_TEMPLATES_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "templates"))


def _jinja_env():
    from jinja2 import Environment, FileSystemLoader, select_autoescape
    return Environment(
        loader=FileSystemLoader(_TEMPLATES_DIR),
        autoescape=select_autoescape(["html", "xml"]),
    )


def render_html(template_name: str, context: dict[str, Any]) -> str:
    """Renderiza el template a HTML (sin PDF). Testeable si jinja2 está instalado."""
    return _jinja_env().get_template(template_name).render(**context)


def render_pdf(template_name: str, context: dict[str, Any]) -> bytes:
    """Renderiza el template a un PDF (bytes). Requiere weasyprint + libs de sistema."""
    from weasyprint import HTML
    html = render_html(template_name, context)
    return HTML(string=html, base_url=_TEMPLATES_DIR).write_pdf()
