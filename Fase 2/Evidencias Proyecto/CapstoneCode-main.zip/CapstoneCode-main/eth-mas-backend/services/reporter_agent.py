"""
reporter_agent.py — ReporterAgent · ETH-MAS Sprint 3 (Bloque C, ADR-005)
========================================================================
Servicio puro de reportería conforme al contrato BaseAgent (Bloque 0):
  - el LLM (reporter_model) escribe SOLO la narrativa (resumen ejecutivo,
    análisis de riesgo, recomendaciones),
  - un renderer DETERMINÍSTICO (Jinja2 + WeasyPrint, services/report_renderer)
    arma los PDF técnico y ejecutivo a partir del análisis del blackboard.

Genera AMBOS reportes en una corrida y los guarda en GridFS (bucket "reports").
El endpoint GET /report?type= elige cuál servir. No requiere parámetros por-tipo
en AgentContext (decisión Bloque C).
"""

from __future__ import annotations

import io
import json
import logging
import os
import re
from typing import Optional

from motor.motor_asyncio import AsyncIOMotorGridFSBucket

from services.agent_base import REPORTER_AGENT, AgentContext, AgentResult, BaseAgent
from services.agent_config import reporter_model
from services.agent_runs_service import start_run, finish_run
from services.anthropic_health import mark_anthropic_failure, mark_anthropic_success
from services.blackboard import read_state
from services.report_renderer import render_pdf
from mongo_client import get_mongo_db
from utils import utc_now

logger = logging.getLogger(__name__)

_SEVERITY_ORDER = ["critical", "high", "medium", "low", "info"]
_SEVERITY_RANK = {s: i for i, s in enumerate(_SEVERITY_ORDER)}


def _applicable_cves(finding: dict) -> list[dict]:
    """
    CVEs reportables de un finding: excluye los 'keyword-only' (no aplicables,
    fix 2026-06-11) y marca cada uno con 'confirmed' (True solo si la versión
    fue validada). Si el finding no tiene cve_details (legacy), cae a cve_ids
    sin confianza → se tratan como version-unknown (no confirmados).
    """
    details = finding.get("cve_details")
    out: list[dict] = []
    if isinstance(details, list) and details:
        for d in details:
            if not isinstance(d, dict):
                continue
            conf = (d.get("confidence") or "").lower()
            if conf == "keyword-only":
                continue  # no aplicable → fuera del reporte
            out.append({
                "cve_id": d.get("cve_id"),
                "cvss_score": d.get("cvss_score"),
                "confirmed": conf == "confirmed",
            })
    else:
        for cid in (finding.get("cve_ids") or []):
            out.append({"cve_id": cid, "cvss_score": finding.get("cvss_score"),
                        "confirmed": False})
    return out


def _is_reportable(finding: dict) -> bool:
    """Excluye del reporte los findings marcados false_positive (catch-all / FP fuerte)."""
    return (finding.get("status") or "").lower() != "false_positive"


def _clean_list(items) -> list[str]:
    """Saneo de listas para el render (B6): descarta None/vacíos/whitespace.
    Evita los `<li>` vacíos en recomendaciones y pasos de vectores. Ojo: hay que
    saltar None ANTES de str() — str(None) == 'None' colaría como item válido."""
    out: list[str] = []
    for it in (items or []):
        if it is None:
            continue
        s = str(it).strip()
        if s and s.lower() != "none":
            out.append(s)
    return out


# B7 — etiqueta de riesgo para el reporte EJECUTIVO: sin jerga técnica (CVE, CVSS,
# "Puerto N abierto —", versiones entre paréntesis). El detalle técnico vive solo
# en el reporte técnico.
_CVE_RE = re.compile(r"\bCVE-\d{4}-\d{4,}\b", re.IGNORECASE)
_PORT_PREFIX_RE = re.compile(r"^\s*puerto\s+\d+\s+abierto\s*[—\-:]\s*", re.IGNORECASE)
_PARENS_RE = re.compile(r"\([^)]*\)")
_VERSION_RE = re.compile(r"\b\d+(?:\.\d+)+[a-z0-9]*\b")  # 2.3.4, 4.7p1, 2.2.8


_TOOL_NAMES_RE = re.compile(r"\b(nmap|nuclei|nikto|gobuster|metasploit|theharvester)\b", re.IGNORECASE)
_PORT_INLINE_RE = re.compile(r"\bpuertos?\s+\d+(?:\s*[,/y]\s*\d+)*\b", re.IGNORECASE)
_CVSS_INLINE_RE = re.compile(r"\bCVSS\s*[:=]?\s*\d+(?:\.\d+)?\b", re.IGNORECASE)

# B7 — tags de herramienta entre corchetes en los títulos de finding:
# "[Nuclei] PHP CGI ...", "[Nikto] ...". Fuera del reporte ejecutivo.
_BRACKET_TAG_RE = re.compile(r"\[[^\]]*\]")

# B7 — frases de riesgo técnicas (a menudo en inglés) → lenguaje de negocio. Se
# evalúan ANTES que el nombre de servicio: si el título describe un ataque
# concreto, esa es la mejor etiqueta ejecutiva.
_RISK_PHRASE_MAP: list[tuple[re.Pattern, str]] = [
    (re.compile(r"remote code execution|\brce\b|ejecuci[oó]n remota", re.I), "Ejecución remota de código"),
    (re.compile(r"sql injection|inyecci[oó]n sql", re.I), "Inyección sobre la base de datos"),
    (re.compile(r"cross[- ]site scripting|\bxss\b", re.I), "Inyección de scripts en el navegador"),
    (re.compile(r"directory traversal|path traversal|lfi|rfi|file inclusion", re.I), "Acceso indebido a archivos del servidor"),
    (re.compile(r"information disclosure|info(rmation)? leak|exposure", re.I), "Exposición de información sensible"),
    (re.compile(r"denial of service|\bdos\b", re.I), "Interrupción del servicio"),
    (re.compile(r"backdoor|puerta trasera", re.I), "Acceso no autorizado por puerta trasera"),
    (re.compile(r"default credential|weak password|brute|fuerza bruta", re.I), "Credenciales débiles o por defecto"),
]

# B7 — nombres técnicos de servicio → frase de riesgo de negocio (cuando el
# título es esencialmente el nombre del servicio, p.ej. "Netbios-ssn").
_SERVICE_BUSINESS_MAP: list[tuple[re.Pattern, str]] = [
    (re.compile(r"netbios|microsoft-ds|samba|\bsmb\b", re.I), "Servicio de archivos compartidos expuesto"),
    (re.compile(r"distcc", re.I), "Servicio de compilación distribuida expuesto"),
    (re.compile(r"phpmyadmin", re.I), "Panel de administración de base de datos expuesto"),
    (re.compile(r"vsftpd|ccproxy-ftp|\bftp\b", re.I), "Transferencia de archivos sin protección (FTP)"),
    (re.compile(r"telnet", re.I), "Acceso remoto sin cifrado (Telnet)"),
    (re.compile(r"\bvnc\b", re.I), "Escritorio remoto expuesto"),
    (re.compile(r"unrealircd|\bircd?\b", re.I), "Servicio de chat heredado expuesto"),
    (re.compile(r"\bmysql\b|postgres", re.I), "Base de datos accesible desde la red"),
    (re.compile(r"rmiregistry|\brpcbind\b|\bnfs\b|ingreslock|\bexec\b|rlogin|\brsh\b|\bshell\b|\blogin\b", re.I), "Servicio de red heredado expuesto"),
]


# B7 (S6) — mensajes de findings web (nikto/nuclei, en inglés) → frase de negocio
# en español. La fuente es el `summary` del finding (ej. "[Nikto] Cookie PHPSESSID
# created without the httponly flag."); tras quitar el tag de tool, el mensaje
# inglés llegaba crudo al ejecutivo. Cubre los patrones que emiten las tools del
# lab; lo no cubierto cae al texto original (legible) o al genérico por severidad.
_WEB_FINDING_MAP: list[tuple[re.Pattern, str]] = [
    (re.compile(r"httponly", re.I), "Cookie de sesión sin protección (httponly)"),
    (re.compile(r"cookie.*secure flag|secure flag.*cookie", re.I), "Cookie de sesión sin protección (secure)"),
    (re.compile(r"out.?of.?date|outdated|no longer supported|end of life", re.I), "Componente de software desactualizado"),
    (re.compile(r"security header|header is not present|missing.*header|x-frame-options|x-content-type-options|content-security-policy|strict-transport-security|referrer-policy|\bhsts\b", re.I), "Falta un encabezado de seguridad recomendado"),
    (re.compile(r"directory indexing|directory listing|index of /", re.I), "Listado de directorios habilitado"),
    (re.compile(r"configuration information|config.*available|/config", re.I), "Posible exposición de información de configuración"),
    (re.compile(r"default file|default page|default install|/icons/readme|\breadme\b", re.I), "Archivo o página por defecto del servidor expuesta"),
    (re.compile(r"x-powered-by|server (banner|leaks)|version disclosure|powered by", re.I), "El servidor revela información de su tecnología"),
    (re.compile(r"phpinfo|php info", re.I), "Página de diagnóstico PHP expuesta (phpinfo)"),
    (re.compile(r"backup|\.bak\b|\.old\b|\.swp\b", re.I), "Archivo de respaldo expuesto"),
    (re.compile(r"\betag\b|\binode", re.I), "El servidor expone metadatos de archivos"),
    (re.compile(r"\btrace\b method|http trace|track method", re.I), "Método HTTP inseguro habilitado (TRACE/TRACK)"),
    (re.compile(r"clickjack", re.I), "Falta protección contra clickjacking"),
    (re.compile(r"information may be available|available remotely|information disclosure|info leak", re.I), "Posible exposición de información sensible"),
]


def _exec_asset(target) -> str:
    """B7 — Activo en términos simples para el ejecutivo: host sin esquema, puerto
    ni ruta (http://10.42.0.10:80/x → 10.42.0.10)."""
    if not target:
        return ""
    t = str(target).strip()
    t = re.sub(r"^[a-z][a-z0-9+.\-]*://", "", t, flags=re.I)  # esquema
    t = t.split("/", 1)[0].split("?", 1)[0]                    # ruta/query
    if t.count(":") == 1:                                      # host:port (no IPv6)
        t = t.split(":", 1)[0]
    return t


def _strip_exec_jargon(text: str) -> str:
    """B7 — quita jerga técnica de la narrativa EJECUTIVA por si el LLM no obedeció
    la instrucción (CVE-IDs, 'CVSS 9.8', 'puerto 21', nombres de herramientas,
    versiones). El reporte ejecutivo debe leerse en términos de negocio."""
    if not text:
        return text
    txt = _BRACKET_TAG_RE.sub("", text)      # [Nuclei]/[Nikto] fuera
    txt = _CVE_RE.sub("", txt)
    txt = _CVSS_INLINE_RE.sub("", txt)
    txt = _PORT_INLINE_RE.sub("el servicio expuesto", txt)
    txt = _TOOL_NAMES_RE.sub("el análisis", txt)
    txt = _PARENS_RE.sub("", txt)            # versiones entre paréntesis
    txt = _VERSION_RE.sub("", txt)
    # Limpiar dobles espacios y espacios antes de puntuación que dejó el borrado.
    txt = re.sub(r"\s+([.,;:])", r"\1", txt)
    txt = re.sub(r"\s{2,}", " ", txt).strip()
    return txt


def _exec_risk_label(item: dict) -> str:
    """Convierte el título técnico de un finding en una etiqueta de riesgo apta
    para gerencia: quita tags de herramienta ([Nuclei]/[Nikto]), CVE-IDs, el
    prefijo 'Puerto N abierto —', versiones y paréntesis; luego traduce frases de
    riesgo y nombres de servicio a lenguaje de negocio. Si no queda nada útil,
    cae a un genérico por severidad."""
    raw = item.get("title") or ""
    txt = _BRACKET_TAG_RE.sub(" ", raw)      # [Nuclei]/[Nikto] fuera (B7)
    txt = _PORT_PREFIX_RE.sub("", txt)
    txt = _PARENS_RE.sub("", txt)
    txt = _CVE_RE.sub("", txt)
    txt = _VERSION_RE.sub("", txt)
    txt = re.sub(r"\s{2,}", " ", txt).strip(" -—:·,/")

    # 1) frase de riesgo concreta (RCE, XSS, traversal…) → la mejor etiqueta.
    for rx, label in _RISK_PHRASE_MAP:
        if rx.search(txt):
            return label
    # 2) nombre de servicio técnico (Netbios-ssn, distccd…) → frase de negocio.
    for rx, label in _SERVICE_BUSINESS_MAP:
        if rx.search(txt):
            return label
    # 3) mensaje de finding web (nikto/nuclei en inglés) → frase de negocio.
    for rx, label in _WEB_FINDING_MAP:
        if rx.search(txt):
            return label
    if not txt:
        sev = (item.get("severity") or "").lower()
        return f"Servicio expuesto de riesgo {sev}" if sev else "Servicio expuesto"
    return txt[:1].upper() + txt[1:]


class ReporterAgent(BaseAgent):
    name = REPORTER_AGENT

    def __init__(self, engagement_id: int, db, pipeline_run_id: Optional[str] = None):
        super().__init__(engagement_id, db, pipeline_run_id)
        self.model = reporter_model()
        self._run_id: Optional[str] = None

    async def run(self, ctx: AgentContext) -> AgentResult:
        state = ctx.prior_state or {}
        findings = state.get("findings")
        analysis = state.get("analysis")
        if findings is None or analysis is None:
            fetched = await read_state(self.engagement_id, include=("findings", "analysis"))
            findings = findings if findings is not None else fetched.get("findings", [])
            analysis = analysis if analysis is not None else fetched.get("analysis")

        if not findings:
            return AgentResult(
                agent=self.name, status="skipped",
                rationale="No hay findings para reportar. Ejecuta Scan (y Analysis) primero.",
            )
        analysis = analysis or {}

        eng_meta = self._engagement_meta(ctx)
        self._run_id = await start_run(
            engagement_id=self.engagement_id, agent=self.name, model=self.model,
            targets=eng_meta.get("scope", []), pipeline_run_id=self.pipeline_run_id,
        )

        status = "completed"
        error_msg: Optional[str] = None
        artifacts: dict = {}

        try:
            narrative = await self._compose_narrative(findings, analysis)
            mark_anthropic_success()
        except Exception as e:  # noqa: BLE001 — el reporte se genera igual con narrativa determinística
            logger.warning("[ReporterAgent] narrativa LLM falló (%s); uso fallback determinístico", e)
            narrative = _fallback_narrative(analysis)
            error_msg = f"narrativa LLM no disponible: {e}"

        context = _compose_context(eng_meta, findings, analysis, narrative)

        try:
            import asyncio
            tech_pdf = await asyncio.to_thread(render_pdf, "report_technical.html", context)
            exec_pdf = await asyncio.to_thread(render_pdf, "report_executive.html", context)
            report_name = getattr(ctx, "report_name", None)
            tech_id = await self._store_pdf(tech_pdf, "technical", report_name)
            exec_id = await self._store_pdf(exec_pdf, "executive", report_name)
            artifacts = {"technical_id": tech_id, "executive_id": exec_id,
                         "technical_bytes": len(tech_pdf), "executive_bytes": len(exec_pdf)}
        except Exception as e:  # noqa: BLE001
            logger.error("[ReporterAgent] render/almacenamiento falló: %s", e, exc_info=True)
            status = "failed"
            error_msg = error_msg or f"render: {e}"

        rationale = (
            f"Generé reporte técnico + ejecutivo del engagement {self.engagement_id} "
            f"({context['stats']['total']} hallazgos, {len(context['attack_vectors'])} vectores). "
            f"{(narrative.get('executive_summary') or '')[:200]}"
        )
        await finish_run(
            run_id=self._run_id, status=status, error=error_msg,
            summary=f"PDFs técnico+ejecutivo · {artifacts.get('technical_bytes', 0)}+{artifacts.get('executive_bytes', 0)} bytes",
        )
        # Rationale delegado al ejecutor seguro (fuente única, sin doble registro).

        return AgentResult(
            agent=self.name, status=status, rationale=rationale,
            findings_count=context["stats"]["total"], artifacts={"agent_run_id": self._run_id, **artifacts},
            error=error_msg,
        )

    # ── Narrativa (LLM, una sola llamada — sin tools) ─────────────────────────
    async def _compose_narrative(self, findings: list[dict], analysis: dict) -> dict:
        from anthropic import AsyncAnthropic
        client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

        # Solo findings reportables; CVEs limitados a los aplicables (sin keyword-only)
        # para que la narrativa no mencione CVEs no aplicables (fix 2026-06-11).
        reportable = [f for f in findings if _is_reportable(f)]
        ctx_blob = {
            # total EXACTO y autoritativo (el listado va truncado a 40 para el prompt).
            "total_findings": len(reportable),
            "analysis_summary": analysis.get("summary"),
            "attack_vectors": analysis.get("attack_vectors", []),
            "priority_order": analysis.get("priority_order", []),
            "findings": [
                {"target": f.get("target"), "title": f.get("summary") or f.get("title"),
                 "severity": f.get("severity"),
                 "cve_ids": [c["cve_id"] for c in _applicable_cves(f)],
                 "cvss_score": f.get("cvss_score"), "mitre": f.get("mitre_technique")}
                for f in reportable[:40]
            ],
        }
        msg = await client.messages.create(
            model=self.model, max_tokens=2048,
            system=(
                "Eres ReporterAgent de ETH-MAS. Redactas la NARRATIVA de un reporte de "
                "pentesting en español, profesional y conciso. NO inventes CVEs ni datos: "
                "usa solo lo que viene en el contexto. Si mencionas una CANTIDAD de hallazgos, "
                "usa EXACTAMENTE el valor de 'total_findings' — NO cuentes el listado (está "
                "truncado a 40) ni estimes otra cifra.\n"
                "RIGOR (no exagerar): NO llames 'crítico' a un hallazgo cuya 'severity' no sea "
                "'critical'; respeta la severidad de cada hallazgo. Los CVEs del contexto son "
                "POSIBLES; NO afirmes explotabilidad ni compromiso que no estén confirmados. "
                "Un puerto abierto es exposición, no una brecha demostrada. Evita lenguaje "
                "catastrofista; describe riesgo proporcional a la evidencia.\n"
                "Generas DOS narrativas para audiencias distintas:\n"
                " - risk_narrative: TÉCNICA (1-2 párrafos), para el equipo de seguridad; "
                "puede nombrar servicios, versiones, CVEs y técnicas ATT&CK.\n"
                " - executive_narrative: EJECUTIVA (2-4 frases), para gerencia SIN jerga "
                "técnica: habla de riesgo de negocio, exposición y prioridad, NO de CVEs, "
                "puertos ni nombres de herramientas.\n"
                "Devuelve EXACTAMENTE un bloque ```json``` con: "
                '{"executive_summary": "<2-4 frases>", '
                '"risk_narrative": "<1-2 párrafos técnicos>", '
                '"executive_narrative": "<2-4 frases ejecutivas sin jerga>", '
                '"recommendations": ["<acción técnica concreta: puede citar CVE/servicio/puerto>", ...], '
                '"executive_recommendations": ["<misma acción en términos de negocio, SIN CVE, CVSS, '
                'puertos ni nombres de herramientas>", ...]}'
            ),
            messages=[{"role": "user", "content": json.dumps(ctx_blob, ensure_ascii=False)}],
        )
        text = "".join(b.text for b in msg.content if getattr(b, "type", None) == "text")
        return _parse_narrative_json(text, analysis)

    # ── GridFS ────────────────────────────────────────────────────────────────
    # Etiqueta de tipo para el nombre de archivo legible.
    _TYPE_LABEL = {"technical": "Técnico", "executive": "Ejecutivo"}

    @staticmethod
    def _sanitize_name(name: str) -> str:
        """Saneo del nombre que da el operador para usarlo como filename: quita
        caracteres problemáticos de ruta y recorta. Vacío → None (cae al genérico)."""
        import re as _re
        cleaned = _re.sub(r'[\\/:*?"<>|]+', " ", str(name)).strip()
        cleaned = _re.sub(r"\s{2,}", " ", cleaned)
        return cleaned[:120]

    async def _store_pdf(self, pdf: bytes, report_type: str,
                         report_name: Optional[str] = None) -> str:
        bucket = AsyncIOMotorGridFSBucket(get_mongo_db(), bucket_name="reports")
        type_label = self._TYPE_LABEL.get(report_type, report_type)
        safe = self._sanitize_name(report_name) if report_name else ""
        # Con nombre del operador: "<nombre> — <Tipo>.pdf". Sin nombre: genérico.
        filename = f"{safe} — {type_label}.pdf" if safe else f"eng_{self.engagement_id}_{report_type}.pdf"
        file_id = await bucket.upload_from_stream(
            filename, io.BytesIO(pdf),
            metadata={"engagement_id": self.engagement_id, "type": report_type,
                      "report_name": safe or None,
                      "generated_at": utc_now(), "agent_run_id": self._run_id,
                      "content_type": "application/pdf"},
        )
        return str(file_id)

    def _engagement_meta(self, ctx: AgentContext) -> dict:
        import models
        eng = self.db.query(models.Engagement).filter(models.Engagement.id == self.engagement_id).first()
        return {
            "id": self.engagement_id,
            "name": (eng.name if eng else f"Engagement {self.engagement_id}"),
            "client_name": (eng.client_name if eng else None),
            "status": (eng.status.value if eng and hasattr(eng.status, "value") else "—"),
            "scope": ctx.targets(),
            "generated_at": utc_now().strftime("%Y-%m-%d %H:%M UTC"),
        }


# ── Helpers de módulo (puros, testeables sin LLM/Mongo/WeasyPrint) ────────────

def _parse_narrative_json(text: str, analysis: dict) -> dict:
    """Extrae el JSON de narrativa del texto del LLM; fallback determinístico."""
    block = None
    if text:
        m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
        if m:
            block = m.group(1)
        else:
            s, e = text.find("{"), text.rfind("}")
            if s != -1 and e > s:
                block = text[s:e + 1]
    if block:
        try:
            data = json.loads(block)
            data.setdefault("executive_summary", "")
            data.setdefault("risk_narrative", "")
            # B7 — narrativa ejecutiva separada; si el LLM no la emitió, cae al
            # resumen ejecutivo (mejor que mostrar la narrativa técnica en el PDF exec).
            data.setdefault("executive_narrative", data.get("executive_summary", ""))
            data.setdefault("recommendations", [])
            # B7 — recomendaciones ejecutivas: si el LLM no las dio, caen a las
            # técnicas (luego el compose les quita la jerga como red de seguridad).
            data.setdefault("executive_recommendations", data.get("recommendations") or [])
            # Sanear listas: descartar items vacíos antes del render (refuerza B6).
            data["recommendations"] = _clean_list(data.get("recommendations"))
            data["executive_recommendations"] = _clean_list(data.get("executive_recommendations"))
            return data
        except json.JSONDecodeError:
            pass
    return _fallback_narrative(analysis)


def _fallback_narrative(analysis: dict) -> dict:
    """Narrativa mínima determinística si el LLM no está disponible."""
    return {
        "executive_summary": analysis.get("summary") or "Análisis de seguridad del engagement.",
        "risk_narrative": "",
        "executive_narrative": analysis.get("summary") or "",
        "recommendations": [
            "Remediar los hallazgos de severidad crítica y alta de forma prioritaria.",
            "Restringir la exposición de servicios legacy y aplicar parches vigentes.",
        ],
        "executive_recommendations": [
            "Priorizar la remediación de los riesgos críticos y altos.",
            "Reducir la exposición de los servicios obsoletos y mantener el parcheo al día.",
        ],
    }


def _compose_context(engagement: dict, findings: list[dict], analysis: dict, narrative: dict) -> dict:
    """Arma el contexto del template (determinístico). Sin LLM ni I/O."""
    by_sev: dict[str, list] = {s: [] for s in _SEVERITY_ORDER}
    for f in findings:
        # Excluir falsos positivos confirmados (catch-all / FP fuerte).
        if not _is_reportable(f):
            continue
        sev = (f.get("severity") or "info").lower()
        applicable = _applicable_cves(f)
        item = {
            "title": f.get("summary") or f.get("title") or "Hallazgo",
            "target": f.get("target", "—"),
            "severity": sev if sev in by_sev else "info",
            "port": f.get("port") or (f.get("evidence") or {}).get("port"),
            "service": f.get("service") or (f.get("evidence") or {}).get("service"),
            # Solo CVEs aplicables (sin keyword-only); cada uno con flag confirmed.
            "cves": applicable,
            "cve_ids": [c["cve_id"] for c in applicable],
            "cvss_score": f.get("cvss_score"),
            "mitre_technique": f.get("mitre_technique"),
            "confidence": f.get("confidence"),
            "ref": f.get("dedup_key"),
        }
        by_sev[item["severity"]].append(item)

    # clave "findings" (no "items": Jinja resuelve .items como el método de dict)
    findings_by_severity = [{"severity": s, "findings": by_sev[s]} for s in _SEVERITY_ORDER]
    # total = reportables (excluye false_positive ya filtrados), consistente con by_severity.
    reportable_total = sum(len(by_sev[s]) for s in _SEVERITY_ORDER)
    stats = {"total": reportable_total,
             "by_severity": {s: len(by_sev[s]) for s in _SEVERITY_ORDER}}

    # top_risks: por priority_order si existe, si no por (severidad, cvss)
    flat = [it for s in _SEVERITY_ORDER for it in by_sev[s]]
    by_ref = {it["ref"]: it for it in flat if it.get("ref")}
    top_risks = []
    for ref in (analysis.get("priority_order") or []):
        if ref in by_ref and by_ref[ref] not in top_risks:
            top_risks.append(by_ref[ref])
        if len(top_risks) >= 3:
            break
    if not top_risks:
        flat_sorted = sorted(
            flat, key=lambda it: (_SEVERITY_RANK.get(it["severity"], 99), -(it.get("cvss_score") or 0))
        )
        top_risks = flat_sorted[:3]

    # B7 — etiqueta de riesgo y activo sin jerga para el reporte ejecutivo.
    for it in top_risks:
        it["exec_label"] = _exec_risk_label(it)
        it["exec_asset"] = _exec_asset(it.get("target"))

    # B6 — sanear los pasos de cada vector (vienen del LLM, pueden traer vacíos).
    clean_vectors = []
    for v in (analysis.get("attack_vectors") or []):
        vv = dict(v)
        vv["steps"] = _clean_list(v.get("steps"))
        clean_vectors.append(vv)

    # B6 — narrativa con recomendaciones saneadas (sin items vacíos) por si llegó
    # de un path que no las limpió. B7 — campos ejecutivos sin jerga técnica
    # (executive_narrative + exec_summary, este último solo para el PDF ejecutivo;
    # el técnico sigue usando executive_summary con su detalle).
    narrative = {
        **narrative,
        "recommendations": _clean_list(narrative.get("recommendations")),
        # Recomendaciones ejecutivas sin jerga (LLM) + strip como red de seguridad.
        "executive_recommendations": [
            _strip_exec_jargon(r) for r in _clean_list(
                narrative.get("executive_recommendations") or narrative.get("recommendations")
            )
        ],
        "executive_narrative": _strip_exec_jargon(narrative.get("executive_narrative") or ""),
        "exec_summary": _strip_exec_jargon(narrative.get("executive_summary") or ""),
    }

    return {
        "engagement": engagement,
        "narrative": narrative,
        "stats": stats,
        "findings_by_severity": findings_by_severity,
        "attack_vectors": clean_vectors,
        "priority_order": analysis.get("priority_order", []) or [],
        "top_risks": top_risks,
    }
