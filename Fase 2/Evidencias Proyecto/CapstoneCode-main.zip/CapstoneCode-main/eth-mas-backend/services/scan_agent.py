"""
scan_agent.py — ScanAgent · ETH-MAS (Bloque D, ADR-005)
=======================================================
Agente de escaneo activo, refactorizado a GOAL-DRIVEN sobre el contrato común
`BaseAgent` (Bloque 0): recibe un `AgentContext` y devuelve un `AgentResult`
con `rationale`.

Qué cambió respecto al ScanAgent legacy (playbook rígido):
  - PROMPT DE OBJETIVO, no checklist: se le da la meta ("enumerar y
    caracterizar") y deja que decida qué tools y en qué orden según lo que
    encuentra. El playbook deja de ser una secuencia fija.
  - INTENSIDAD desde el ROE: lee `ctx.roe.scan_intensity` (STEALTH/MODERATE/
    AGGRESSIVE) y deriva una banda de parámetros (timing/ports/severidad/NSE)
    vía `scan_policy.intensity_policy`. Antes hardcodeaba timing=3. La decisión
    queda OBSERVABLE (el timing real viaja en cada tool_call) y auditable (va en
    el rationale).
  - CONTINUIDAD tras pausas HITL: siembra el set de firmas YA ejecutadas en
    runs previos del engagement (desde los tool_calls en Mongo) e informa al
    modelo qué falta. No re-planifica de cero; retoma donde quedó.
  - TERMINACIÓN por criterio + PRESUPUESTO (`ctx.budget_steps`), no por agotar
    la matriz target×tools.

INTOCABLE (guardarraíles, ADR-005 §3): el scope check programático
(`scope_validator`, dentro del Security MCP) y el HITL para risk ≥ MEDIUM. La
agencia vive ARRIBA de los guardarraíles: el agente decide la estrategia, pero
no puede salirse de scope ni disparar algo riesgoso sin aprobación humana.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Optional

from sqlalchemy.orm import Session

import models
from mongo_client import agent_runs_col, findings_col
from services.agent_base import SCAN_AGENT, AgentContext, AgentResult, BaseAgent
from services.agent_config import scan_agent_model
from services.scan_policy import (
    ScanPolicy,
    intensity_policy,
    normalize_intensity,
    severity_at_or_below,
    signatures_from_tool_calls,
    tool_signature,
)
from services.findings_service import (
    persist_findings_bulk,
    normalize_nmap_findings,
    normalize_gobuster_findings,
    normalize_nikto_findings,
    normalize_nuclei_findings,
)
from services.agent_runs_service import (
    start_run,
    finish_run,
    begin_tool_call,
    end_tool_call,
)
from services.anthropic_health import (
    mark_anthropic_failure,
    mark_anthropic_success,
)
from utils import utc_now

logger = logging.getLogger(__name__)

# Backend del LLM (Claude por defecto). El modelo concreto lo resuelve el
# tiering centralizado (agent_config), no un getenv suelto como antes.
SCAN_AGENT_BACKEND = os.getenv("SCAN_AGENT_BACKEND", "claude").lower()

_SECURITY_SERVER_SCRIPT = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "mcp_servers", "security_server.py")
)

# Tokens de intensidad reconocibles en un operator_directive (override liviano
# de la intensidad del ROE para una corrida puntual, ej. "modo sigiloso").
_DIRECTIVE_INTENSITY_HINTS = {
    "sigilo": "STEALTH", "sigiloso": "STEALTH", "stealth": "STEALTH",
    "moderado": "MODERATE", "moderate": "MODERATE",
    "agresivo": "AGGRESSIVE", "aggressive": "AGGRESSIVE", "ruidoso": "AGGRESSIVE",
}


class ScanAgent(BaseAgent):
    name = SCAN_AGENT

    def __init__(
        self,
        engagement_id: int,
        db: Session,
        pipeline_run_id: Optional[str] = None,
    ):
        super().__init__(engagement_id, db, pipeline_run_id)
        self.model = scan_agent_model()

        if SCAN_AGENT_BACKEND == "gemini":
            raise NotImplementedError(
                "SCAN_AGENT_BACKEND=gemini no está implementado aún. "
                "Usar SCAN_AGENT_BACKEND=claude (default)."
            )

        self._run_id: Optional[str] = None
        self._tool_count: int = 0
        self._inserted_count: int = 0          # filas TOCADAS (upsert+modified) — interno
        self._findings_total: int = 0          # docs DISTINTOS del engagement — user-facing
        self._new_tool_count: int = 0          # tool calls nuevas (no sembradas)
        self._executed_signatures: set[str] = set()
        self._resumed_count: int = 0           # firmas heredadas de runs previos

    # ── Entry point (contrato BaseAgent) ──────────────────────────────────────
    async def run(self, ctx: AgentContext) -> AgentResult:
        targets = ctx.targets()
        if not targets:
            return AgentResult(
                agent=self.name, status="skipped",
                rationale="No hay scope targets configurados; nada que escanear.",
            )

        policy = self._resolve_policy(ctx)

        logger.info(
            "[ScanAgent] Iniciando — engagement=%d model=%s intensity=%s timing=%d targets=%s",
            self.engagement_id, self.model, policy.intensity, policy.timing, targets,
        )

        # Anti-zombi (Fase 1): no iniciar si ya hay HITL PENDING de ScanAgent.
        # Se conserva intacto. Antes creaba un AgentRunDoc fantasma; seguimos
        # cortando ANTES de start_run.
        pending_existing = (
            self.db.query(models.HitlAction.id)
            .filter(
                models.HitlAction.engagement_id == self.engagement_id,
                models.HitlAction.agent == "ScanAgent",
                models.HitlAction.decision == "PENDING",
            )
            .order_by(models.HitlAction.id.asc())
            .all()
        )
        if pending_existing:
            pending_ids = [p[0] for p in pending_existing]
            logger.info(
                "[ScanAgent] Aborto antes de start_run — engagement=%d pending_hitl_ids=%s",
                self.engagement_id, pending_ids,
            )
            return AgentResult(
                agent=self.name, status="waiting_hitl",
                rationale=(
                    f"Hay {len(pending_ids)} acción(es) HITL pendiente(s) por aprobar o "
                    f"expirar antes de iniciar un nuevo scan (ids={pending_ids})."
                ),
                pending_hitl_ids=pending_ids,
            )

        # Continuidad: sembrar lo YA ejecutado en runs previos del engagement.
        self._executed_signatures = await self._load_prior_signatures()
        self._resumed_count = len(self._executed_signatures)

        self._run_id = await start_run(
            engagement_id=self.engagement_id,
            agent=self.name,
            model=self.model,
            targets=targets,
            pipeline_run_id=self.pipeline_run_id,
        )

        final_status = "completed"
        error_msg: Optional[str] = None
        all_findings: list[dict] = []
        pending_hitl_ids: list[int] = []
        stop_reason_note = "cobertura suficiente / fin de turno"
        cancelled = False

        loop_budget = max(ctx.budget_steps, len(targets) * 6)

        try:
            loop_result = await self._run_agentic_loop(ctx, targets, policy, loop_budget)
            all_findings = loop_result["findings"]
            pending_hitl_ids = loop_result["pending_hitl_ids"]
            stop_reason_note = loop_result["stop_reason"]

            mark_anthropic_success()
            if pending_hitl_ids:
                final_status = "waiting_hitl"

        except asyncio.CancelledError:
            logger.warning(
                "[ScanAgent] CancelledError — engagement=%d findings_persistidos=%d",
                self.engagement_id, self._inserted_count,
            )
            final_status = "aborted"
            error_msg = "Run cancelado (HTTP cancel / shutdown). Findings parciales persistidos."
            cancelled = True

        except Exception as e:
            from anthropic import APIStatusError
            try:
                from anthropic import AuthenticationError
            except ImportError:
                AuthenticationError = APIStatusError  # type: ignore

            if isinstance(e, AuthenticationError) or (
                isinstance(e, APIStatusError) and getattr(e, "status_code", None) == 401
            ):
                error_msg = (
                    "ANTHROPIC_API_KEY inválida o revocada (401). "
                    "Revisar configuración en .env y /health/services?refresh=true."
                )
                logger.error("[ScanAgent] %s", error_msg)
                mark_anthropic_failure("401 desde ScanAgent")
            else:
                logger.error("[ScanAgent] Error en agentic loop: %s", e, exc_info=True)
                error_msg = str(e)
            final_status = "failed"

        # Conteo AUTORITATIVO de findings: documentos DISTINTOS del engagement en
        # la colección. `self._inserted_count` (filas tocadas = upsert+modified)
        # sobre-cuenta re-toques/duplicados por dedup_key y NO debe usarse como
        # "findings" de cara al operador — esa era la discrepancia entre el detalle
        # del ScanAgent y la vista Findings/PDF. Esta cifra coincide con ambos.
        try:
            self._findings_total = await findings_col().count_documents(
                {"engagement_id": self.engagement_id}
            )
        except Exception as e:  # noqa: BLE001 — si Mongo falla, caer al contador interno
            logger.warning("[ScanAgent] count_documents falló, uso contador interno: %s", e)
            self._findings_total = self._inserted_count

        rationale = self._build_rationale(
            policy, final_status, pending_hitl_ids, stop_reason_note, error_msg,
        )

        summary = self._build_run_summary(final_status, pending_hitl_ids)
        try:
            await finish_run(
                run_id=self._run_id, status=final_status, error=error_msg,
                findings_count=self._findings_total, summary=summary,
            )
        except Exception as finish_err:  # noqa: BLE001
            logger.error("[ScanAgent] finish_run falló (no bloqueante): %s", finish_err)

        # Nota: el rationale NO se auto-registra aquí. Va en AgentResult.rationale
        # y el ejecutor seguro (PipelineController) lo persiste en el blackboard
        # vía record_rationale — los agentes nuevo-contrato DELEGAN ese registro
        # al ejecutor (ver pipeline_controller._run_stage). Evita doble registro.

        logger.info(
            "[ScanAgent] Finalizado — engagement=%d status=%s findings=%d (filas_tocadas=%d) pending_hitl=%s",
            self.engagement_id, final_status, self._findings_total, self._inserted_count, pending_hitl_ids,
        )

        if cancelled:
            # Preserva la semántica de CancelledError para el caller.
            raise asyncio.CancelledError(f"ScanAgent run {self._run_id} cancelado")

        return AgentResult(
            agent=self.name,
            status=final_status,
            rationale=rationale,
            findings_count=self._findings_total,
            pending_hitl_ids=pending_hitl_ids,
            artifacts={
                "agent_run_id": self._run_id,
                "intensity": policy.intensity,
                "timing": policy.timing,
                "findings": all_findings,
            },
            budget_used={"steps": self._tool_count},
            error=error_msg,
        )

    # ── Intensidad / política ─────────────────────────────────────────────────
    def _resolve_policy(self, ctx: AgentContext) -> ScanPolicy:
        """Deriva la banda de parámetros desde el ROE, con override liviano si el
        operator_directive menciona una intensidad explícita."""
        intensity = ctx.roe.scan_intensity if ctx.roe else "MODERATE"
        directive = (ctx.operator_directive or "").lower()
        for token, mapped in _DIRECTIVE_INTENSITY_HINTS.items():
            if token in directive:
                intensity = mapped
                logger.info(
                    "[ScanAgent] Intensidad override por operator_directive: %s → %s",
                    token, mapped,
                )
                break
        return intensity_policy(intensity)

    # ── Continuidad: firmas de runs previos ───────────────────────────────────
    async def _load_prior_signatures(self) -> set[str]:
        """Reconstruye las firmas tool/target/params YA ejecutadas en runs
        previos de ScanAgent sobre este engagement, para no repetir trabajo tras
        una pausa HITL. Excluye las que quedaron en waiting_hitl/running (para que
        la tool recién aprobada se re-emita)."""
        try:
            cursor = agent_runs_col().find(
                {"engagement_id": self.engagement_id, "agent": self.name},
                {"tools_called": 1},
            )
            sigs: set[str] = set()
            async for doc in cursor:
                sigs |= signatures_from_tool_calls(doc.get("tools_called", []))
            if sigs:
                logger.info(
                    "[ScanAgent] Continuidad — %d firmas heredadas de runs previos (engagement=%d)",
                    len(sigs), self.engagement_id,
                )
            return sigs
        except Exception as e:  # noqa: BLE001 — la continuidad es best-effort
            logger.warning("[ScanAgent] No se pudieron cargar firmas previas: %s", e)
            return set()

    # ── Normalización de resultados (sin cambios respecto al legacy) ──────────
    def _normalize_tool_result(
        self, tool_name: str, target_val: str, tool_input: dict, parsed: dict,
    ) -> list[dict]:
        findings: list[dict] = []
        try:
            incoming = parsed.get("findings", []) or []
            if incoming:
                return incoming

            if tool_name == "nmap_scan":
                raw_findings = parsed.get("raw_findings", []) or []
                if raw_findings:
                    findings = normalize_nmap_findings(self.engagement_id, raw_findings)

            elif tool_name == "nuclei_run":
                raw_output = parsed.get("raw_output") or parsed.get("output") or ""
                if raw_output:
                    findings = normalize_nuclei_findings(self.engagement_id, target_val, raw_output)

            elif tool_name == "nikto_scan":
                raw_output = parsed.get("raw_output") or parsed.get("output") or ""
                if raw_output:
                    findings = normalize_nikto_findings(self.engagement_id, target_val, raw_output)

            elif tool_name == "gobuster_run":
                raw_output = parsed.get("raw_output") or parsed.get("output") or ""
                mode = tool_input.get("mode", "dir")
                if raw_output:
                    findings = normalize_gobuster_findings(
                        self.engagement_id, target_val, raw_output, mode=mode,
                    )
        except Exception as e:  # noqa: BLE001
            logger.error(
                "[ScanAgent] Error normalizando %s sobre %s: %s",
                tool_name, target_val, e, exc_info=True,
            )
            return []
        return findings

    # ── Agentic loop ──────────────────────────────────────────────────────────
    async def _run_agentic_loop(
        self,
        ctx: AgentContext,
        targets: list[str],
        policy: ScanPolicy,
        loop_budget: int,
    ) -> dict:
        from anthropic import AsyncAnthropic
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        server_params = StdioServerParameters(
            command="python", args=[_SECURITY_SERVER_SCRIPT], env={**os.environ},
        )

        all_findings: list[dict] = []
        pending_hitl_ids: list[int] = []
        stop_reason = "presupuesto agotado"

        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                mcp_tools = await session.list_tools()
                anthropic_tools = [
                    {"name": t.name, "description": t.description or "", "input_schema": t.inputSchema}
                    for t in mcp_tools.tools
                ]
                logger.info("[ScanAgent] MCP listo — tools: %s", [t["name"] for t in anthropic_tools])

                messages: list[dict] = [{"role": "user", "content": self._build_kickoff(ctx, targets, policy)}]

                for iteration in range(loop_budget):
                    response = await client.messages.create(
                        model=self.model,
                        max_tokens=4096,
                        system=self._build_system_prompt(ctx, targets, policy),
                        tools=anthropic_tools,
                        messages=messages,
                    )
                    messages.append({"role": "assistant", "content": response.content})

                    if response.stop_reason == "tool_use":
                        tool_results_content = []
                        pause_for_hitl = False

                        for block in response.content:
                            if block.type != "tool_use":
                                continue

                            t_start = utc_now()
                            result_text = "{}"
                            call_status = "completed"
                            error_text: Optional[str] = None
                            hitl_id: Optional[int] = None
                            tool_input = dict(block.input)
                            target_val = tool_input.get("target", "")
                            signature = tool_signature(block.name, tool_input)

                            call_idx = await begin_tool_call(
                                run_id=self._run_id, tool=block.name,
                                target=target_val, params=tool_input,
                            )
                            self._tool_count += 1

                            if signature in self._executed_signatures:
                                # Cubre tanto el dedup intra-run como la continuidad
                                # (firmas heredadas de runs previos).
                                result_text = json.dumps({
                                    "tool": block.name, "target": target_val,
                                    "status": "skipped_duplicate",
                                    "reason": (
                                        "Esa combinación tool/target/parámetros ya fue "
                                        "ejecutada (en este run o en uno previo del engagement)."
                                    ),
                                })
                                call_status = "skipped_duplicate"
                                await end_tool_call(
                                    run_id=self._run_id, call_idx=call_idx, status=call_status,
                                    output_preview=result_text, error=None, hitl_action_id=None,
                                    duration_ms=int((utc_now() - t_start).total_seconds() * 1000),
                                )
                                tool_results_content.append({
                                    "type": "tool_result", "tool_use_id": block.id, "content": result_text,
                                })
                                continue

                            self._executed_signatures.add(signature)
                            self._new_tool_count += 1

                            try:
                                mcp_result = await session.call_tool(block.name, tool_input)
                                result_text = mcp_result.content[0].text if mcp_result.content else "{}"
                                parsed = json.loads(result_text)
                                hitl_id = parsed.get("hitl_action_id")
                                status = str(parsed.get("status", "")).lower()

                                if status == "blocked":
                                    call_status = "scope_violation"
                                    logger.warning(
                                        "[ScanAgent] Scope violation — tool=%s input=%s",
                                        block.name, block.input,
                                    )
                                elif status == "rejected":
                                    call_status = "hitl_rejected"
                                elif status == "hitl_timeout":
                                    call_status = "hitl_timeout"
                                elif status == "error":
                                    call_status = "tool_error"
                                    error_text = str(parsed.get("error", "")) or None
                                    logger.warning(
                                        "[ScanAgent] Tool falló post-aprobación — tool=%s hitl_id=%s error=%s",
                                        block.name, hitl_id, error_text,
                                    )
                                elif status in {
                                    "pending", "hitl_pending", "awaiting_hitl",
                                    "waiting_hitl", "requires_hitl",
                                }:
                                    call_status = "waiting_hitl"
                                    if hitl_id is not None and hitl_id not in pending_hitl_ids:
                                        pending_hitl_ids.append(hitl_id)
                                    logger.info(
                                        "[ScanAgent] Tool pausada por HITL — tool=%s hitl_id=%s",
                                        block.name, hitl_id,
                                    )
                                    pause_for_hitl = True
                                elif status == "completed":
                                    findings = self._normalize_tool_result(
                                        tool_name=block.name, target_val=target_val,
                                        tool_input=tool_input, parsed=parsed,
                                    )
                                    all_findings.extend(findings)
                                    inserted_now = 0
                                    if findings:
                                        inserted_now = await persist_findings_bulk(findings)
                                        self._inserted_count += inserted_now
                                    logger.info(
                                        "[ScanAgent] tool=%s target=%s normalized=%d inserted_now=%d total=%d",
                                        block.name, target_val, len(findings), inserted_now,
                                        self._inserted_count,
                                    )
                                else:
                                    # status desconocido con hitl_id: verificar la fila real
                                    # antes de asumir pending (evita desync, fix auditoría 05-25).
                                    if hitl_id is not None:
                                        row = (
                                            self.db.query(models.HitlAction.decision)
                                            .filter(models.HitlAction.id == hitl_id)
                                            .first()
                                        )
                                        current = row[0] if row else None
                                        if current == "PENDING":
                                            call_status = "waiting_hitl"
                                            if hitl_id not in pending_hitl_ids:
                                                pending_hitl_ids.append(hitl_id)
                                            pause_for_hitl = True
                                        else:
                                            call_status = "tool_error"
                                            logger.warning(
                                                "[ScanAgent] status '%s' hitl_id=%s decision=%s (no PENDING)",
                                                status, hitl_id, current or "<none>",
                                            )
                                    else:
                                        call_status = "tool_error"
                                        logger.warning(
                                            "[ScanAgent] status inesperado tool=%s status=%s",
                                            block.name, status,
                                        )

                            except Exception as e:
                                result_text = json.dumps({"error": str(e), "status": "error"})
                                call_status = "error"
                                error_text = str(e)
                                logger.error("[ScanAgent] Error tool call %s: %s", block.name, e, exc_info=True)

                            await end_tool_call(
                                run_id=self._run_id, call_idx=call_idx, status=call_status,
                                output_preview=result_text, error=error_text,
                                hitl_action_id=hitl_id,
                                duration_ms=int((utc_now() - t_start).total_seconds() * 1000),
                            )
                            tool_results_content.append({
                                "type": "tool_result", "tool_use_id": block.id, "content": result_text,
                            })

                            if pause_for_hitl:
                                logger.info(
                                    "[ScanAgent] Cortando iteración por HITL pendiente ids=%s",
                                    pending_hitl_ids,
                                )
                                break

                        if pause_for_hitl:
                            stop_reason = "pausa por aprobación HITL pendiente"
                            break

                        messages.append({"role": "user", "content": tool_results_content})

                    elif response.stop_reason == "end_turn":
                        stop_reason = "el agente consideró suficiente la cobertura"
                        logger.info(
                            "[ScanAgent] Loop finalizado por criterio — iter=%d tool_calls=%d findings=%d",
                            iteration + 1, self._tool_count, len(all_findings),
                        )
                        break
                    else:
                        stop_reason = f"stop_reason inesperado del modelo ({response.stop_reason})"
                        logger.warning("[ScanAgent] %s", stop_reason)
                        break
                else:
                    stop_reason = f"presupuesto de {loop_budget} pasos agotado"

        return {
            "findings": all_findings,
            "pending_hitl_ids": pending_hitl_ids,
            "stop_reason": stop_reason,
        }

    # ── Prompts (goal-driven) ─────────────────────────────────────────────────
    def _build_kickoff(self, ctx: AgentContext, targets: list[str], policy: ScanPolicy) -> str:
        """Mensaje 'user' inicial: objetivo + contexto de continuidad. Concreto,
        no un checklist."""
        prior = self._prior_state_brief(ctx)
        goal = ctx.goal or "Enumerar y caracterizar la superficie de ataque autorizada."
        return (
            f"{goal}\n\n"
            f"Engagement {self.engagement_id}. Targets autorizados: {targets}.\n"
            f"Intensidad de la corrida: {policy.intensity}.\n"
            f"{prior}\n"
            f"Incluye siempre engagement_id={self.engagement_id} en cada tool call. "
            f"Decide qué herramientas usar y en qué orden según lo que vayas "
            f"encontrando; profundiza donde haya servicios interesantes y detén "
            f"el escaneo cuando la cobertura sea razonable."
        )

    def _prior_state_brief(self, ctx: AgentContext) -> str:
        """Resumen del estado previo (surface_map + findings) para dar continuidad
        al modelo: qué ya se sabe y qué tools ya corrieron."""
        ps = ctx.prior_state or {}
        bits: list[str] = []

        sm = ps.get("surface_map")
        if isinstance(sm, dict):
            hosts = sm.get("hosts_discovered") or []
            if hosts:
                bits.append(f"Recon previo descubrió {len(hosts)} host(s).")

        findings = ps.get("findings") or []
        if findings:
            by_tool: dict[str, int] = {}
            for f in findings:
                by_tool[f.get("tool", "?")] = by_tool.get(f.get("tool", "?"), 0) + 1
            resumen = ", ".join(f"{k}:{v}" for k, v in sorted(by_tool.items()))
            bits.append(f"Ya hay {len(findings)} finding(s) persistidos ({resumen}).")

        if self._resumed_count:
            bits.append(
                f"{self._resumed_count} combinación(es) tool/target ya se ejecutaron en "
                f"corridas previas: NO las repitas (te devolverán 'skipped_duplicate'); "
                f"enfoca el esfuerzo en lo que falta o en profundizar."
            )

        if not bits:
            return "Estado previo: sin findings ni recon previo — empiezas de cero."
        return "Estado previo (continuidad): " + " ".join(bits)

    def _build_system_prompt(self, ctx: AgentContext, targets: list[str], policy: ScanPolicy) -> str:
        """System prompt GOAL-DRIVEN. Da el objetivo y la POLÍTICA de intensidad
        (banda de parámetros derivada del ROE), no una secuencia fija de pasos.
        El modelo decide tools/orden/profundidad dentro de la banda."""
        allowed_sev = severity_at_or_below(policy.max_severity)
        nse_line = (
            "Puedes proponer scripts NSE de nmap si aportan (ten en cuenta que eleva el "
            "riesgo a HIGH y requiere aprobación HITL con notas)."
            if policy.allow_nse else
            "NO uses scripts NSE de nmap ni timing >= 4 en esta intensidad "
            "(elevaría el riesgo y la fricción HITL innecesariamente)."
        )
        return (
            f"Eres ScanAgent, el agente de escaneo activo de ETH-MAS.\n\n"
            f"OBJETIVO: enumerar y caracterizar la superficie de ataque AUTORIZADA del "
            f"engagement {self.engagement_id}. Enumerar y caracterizar, NO explotar.\n\n"
            f"TARGETS AUTORIZADOS: {targets}\n"
            f"engagement_id obligatorio en cada tool call: {self.engagement_id}\n\n"
            f"POLÍTICA DE INTENSIDAD = {policy.intensity}\n"
            f"  {policy.note}\n"
            f"  - nmap: usa timing={policy.timing} y ports='{policy.ports}' como base "
            f"(ajusta ports si el contexto lo amerita, pero respeta el timing de la intensidad).\n"
            f"  - nuclei: severidad hasta '{policy.max_severity}' (permitidas: {allowed_sev}).\n"
            f"  - {nse_line}\n\n"
            f"HERRAMIENTAS (todas pasan por scope check + HITL antes de ejecutar):\n"
            f"  - nmap_scan(target, engagement_id, ports, timing): puertos + servicios.\n"
            f"  - nuclei_run(target, engagement_id, severity): templates de vulnerabilidades.\n"
            f"  - nikto_scan(target, engagement_id, port=80|443): análisis de servidor HTTP.\n"
            f"  - gobuster_run(target, engagement_id, mode='dir'|'dns'): rutas web / subdominios.\n\n"
            f"CÓMO DECIDIR (tú planificas, no hay secuencia fija):\n"
            f"  - Comienza reconociendo puertos/servicios con nmap. Observa el resultado.\n"
            f"  - Profundiza donde haya valor: si ves un servicio web (http/https en "
            f"cualquier puerto), considera nuclei / nikto / gobuster 'dir' sobre ese target.\n"
            f"  - gobuster 'dns' solo tiene sentido sobre dominios (no IPs), una vez.\n"
            f"  - Si un target no expone servicios web, no malgastes tools web en él.\n"
            f"  - Detente cuando la cobertura sea suficiente para un buen reporte, o cuando "
            f"se agote el presupuesto de pasos. No hace falta agotar todas las tools.\n\n"
            f"MANEJO DE RESPUESTAS:\n"
            f"  - 'completed' → sigue decidiendo el próximo paso.\n"
            f"  - 'blocked' (scope) → no reintentes ese target; continúa.\n"
            f"  - 'rejected' → el operador rechazó; no reintentes con los mismos args.\n"
            f"  - 'hitl_timeout' → no se decidió; sigue con otra cosa.\n"
            f"  - 'waiting_hitl'/'pending' → la tool espera aprobación: DETENTE, no pidas "
            f"más tools y termina el turno. El sistema reanuda solo cuando el operador decida.\n"
            f"  - 'skipped_duplicate' → ya se hizo (aquí o en un run previo); no insistas.\n\n"
            f"REGLAS MECÁNICAS (las hace cumplir el sistema; respétalas igual):\n"
            f"  - Pide a lo más UNA tool por turno.\n"
            f"  - No repitas la misma tool sobre el mismo target con los mismos args.\n"
            f"  - Cuando termines, devuelve un resumen ejecutivo de 3-5 líneas: servicios "
            f"encontrados, severidades destacadas, paths/subdominios de interés. Eso cierra el loop."
        )

    # ── Rationale + summary ────────────────────────────────────────────────────
    def _build_rationale(
        self,
        policy: ScanPolicy,
        final_status: str,
        pending_hitl_ids: list[int],
        stop_reason_note: str,
        error_msg: Optional[str],
    ) -> str:
        parts = [
            f"Intensidad {policy.intensity} (de ROE.scan_intensity) → timing {policy.timing}, "
            f"ports base '{policy.ports}', nuclei hasta '{policy.max_severity}', "
            f"NSE {'permitido' if policy.allow_nse else 'no permitido'}.",
        ]
        if self._resumed_count:
            parts.append(
                f"Retomé con continuidad: {self._resumed_count} combinación(es) ya "
                f"ejecutada(s) en runs previos se omitieron en vez de re-planificar de cero."
            )
        parts.append(
            f"Ejecuté {self._new_tool_count} tool call(s) nueva(s) "
            f"({self._tool_count} total con dedup); el engagement totaliza "
            f"{self._findings_total} finding(s) distinto(s) persistido(s)."
        )
        if pending_hitl_ids:
            parts.append(f"Quedé pausado esperando HITL (ids={pending_hitl_ids}).")
        parts.append(f"Terminé porque: {stop_reason_note}.")
        if error_msg:
            parts.append(f"Nota de error: {error_msg}")
        return " ".join(parts)

    def _build_run_summary(self, final_status: str, pending_hitl_ids: list[int]) -> str:
        if final_status == "waiting_hitl":
            return (
                f"{self._tool_count} tool calls · {self._findings_total} findings · "
                f"HITL pendientes: {pending_hitl_ids}"
            )
        if final_status == "aborted":
            return (
                f"{self._tool_count} tool calls · {self._findings_total} findings · "
                f"CANCELADO (HTTP cancel / shutdown)"
            )
        return f"{self._tool_count} tool calls · {self._findings_total} findings"
