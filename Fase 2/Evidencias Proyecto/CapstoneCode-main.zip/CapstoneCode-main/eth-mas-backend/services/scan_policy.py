"""
scan_policy.py — Política de intensidad + continuidad del ScanAgent (Bloque D)
=============================================================================
Helpers PUROS (sin Mongo, sin LLM, sin red) que materializan dos piezas del
rediseño agéntico (ADR-005, Bloque D) de forma verificable en host:

  1. intensity_policy(scan_intensity) -> ScanPolicy
     Traduce ROE.scan_intensity (STEALTH/MODERATE/AGGRESSIVE) a una banda de
     parámetros (timing/ports/severidad/NSE). Es lo que hace OBSERVABLE y
     TESTEABLE el criterio de aceptación del Bloque D ("STEALTH vs AGGRESSIVE
     ⇒ timing distinto") sin depender de la corrida del LLM. El ScanAgent
     inyecta esta política en su prompt; el modelo elige el param dentro de la
     banda (decisión ágentica con guía determinista).

  2. tool_signature() + signatures_from_tool_calls()
     Firma canónica tool/target/params para deduplicar trabajo YA ejecutado,
     tanto dentro de un run como ENTRE runs (continuidad tras pausas HITL).
     `signatures_from_tool_calls` reconstruye el set de firmas desde los
     tool_calls de runs previos (incluye tools que dieron 0 findings, ej.
     gobuster vacío) para que el agente no re-planifique de cero.

Relación con los guardarraíles: NADA de esto reemplaza el scope check ni el
HITL (siguen en scope_validator + Security MCP). La política solo GUÍA la
estrategia; la ejecución sigue blindada (ADR-005 §3).
"""

from __future__ import annotations

import json
from dataclasses import dataclass

# Severidad nuclei, de menor a mayor — para razonar "hasta qué severidad".
_SEVERITY_ORDER = ("info", "low", "medium", "high", "critical")


@dataclass(frozen=True)
class ScanPolicy:
    """Banda de parámetros derivada de la intensidad del ROE.

    El ScanAgent la usa para construir su prompt y su rationale. El modelo
    elige el valor concreto dentro de la banda; el helper la hace determinista
    y auditable.
    """
    intensity: str        # normalizada: STEALTH | MODERATE | AGGRESSIVE
    timing: int           # nmap -T (T0..T5). timing>=4 ⇒ el MCP lo marca risk HIGH.
    ports: str            # rango de puertos sugerido para nmap
    max_severity: str     # techo de severidad para nuclei (uno de _SEVERITY_ORDER)
    allow_nse: bool       # si se permite proponer scripts NSE (escala a HIGH+HITL)
    note: str             # frase corta para el prompt/rationale


# Tabla canónica. Alineada con el catálogo ROE (CLAUDE.md §4.5):
#   STEALTH (T1-T2) · MODERATE (T3) · AGGRESSIVE (T4-T5)
# y con el risk_level del Security MCP (timing>=4 o scripts ⇒ HIGH).
_POLICIES: dict[str, ScanPolicy] = {
    "STEALTH": ScanPolicy(
        intensity="STEALTH",
        timing=2,
        ports="1-1024",
        max_severity="medium",
        allow_nse=False,
        note=(
            "Sigilo: timing bajo (T2), solo puertos comunes, sin NSE, "
            "severidad de templates acotada a medium. Minimiza ruido y "
            "fricción HITL; prioriza no ser detectado sobre cobertura."
        ),
    ),
    "MODERATE": ScanPolicy(
        intensity="MODERATE",
        timing=3,
        ports="1-1024",
        max_severity="high",
        allow_nse=False,
        note=(
            "Moderado: timing normal (T3), puertos comunes, sin NSE, "
            "templates hasta high. Balance entre cobertura y ruido."
        ),
    ),
    "AGGRESSIVE": ScanPolicy(
        intensity="AGGRESSIVE",
        timing=4,
        ports="1-65535",
        max_severity="critical",
        allow_nse=True,
        note=(
            "Agresivo: timing alto (T4), rango de puertos completo, NSE "
            "permitido y templates hasta critical. Maximiza cobertura "
            "asumiendo más ruido; esto eleva el risk_level a HIGH y por lo "
            "tanto requiere aprobación HITL con notas."
        ),
    ),
}


def normalize_intensity(scan_intensity: str | None) -> str:
    """Normaliza el string de intensidad a una clave conocida (default MODERATE)."""
    key = (scan_intensity or "").strip().upper()
    return key if key in _POLICIES else "MODERATE"


def intensity_policy(scan_intensity: str | None) -> ScanPolicy:
    """Devuelve la ScanPolicy para una intensidad de ROE. Tolera None/desconocido
    cayendo a MODERATE (default seguro)."""
    return _POLICIES[normalize_intensity(scan_intensity)]


def severity_at_or_below(max_severity: str) -> list[str]:
    """Lista de severidades nuclei permitidas hasta `max_severity` (inclusive)."""
    try:
        idx = _SEVERITY_ORDER.index(max_severity.lower())
    except (ValueError, AttributeError):
        idx = _SEVERITY_ORDER.index("high")
    return list(_SEVERITY_ORDER[: idx + 1])


# ── Firma de tool-call para dedup intra e inter-run ───────────────────────────

def tool_signature(tool_name: str, tool_input: dict) -> str:
    """Firma canónica determinista de una tool-call (tool + target + params
    relevantes). Igual valor ⇒ mismo trabajo. Se usa para:
      - dedup dentro del run (evitar repetir),
      - sembrar lo YA ejecutado en runs previos (continuidad tras HITL).

    Solo se incluyen los params que cambian el resultado de la herramienta, así
    una diferencia cosmética (ej. orden de claves) no rompe el match.
    """
    target = str(tool_input.get("target", "")).strip().lower()

    if tool_name == "nmap_scan":
        body = {
            "tool": tool_name,
            "target": target,
            "ports": str(tool_input.get("ports", "1-1024")),
            "timing": int(tool_input.get("timing", 3)),
            "scripts": tool_input.get("scripts"),
        }
    elif tool_name == "nuclei_run":
        body = {
            "tool": tool_name,
            "target": target,
            "severity": str(tool_input.get("severity", "medium")).lower(),
            "templates": tool_input.get("templates"),
        }
    elif tool_name == "nikto_scan":
        body = {
            "tool": tool_name,
            "target": target,
            "port": int(tool_input.get("port", 80)),
        }
    elif tool_name == "gobuster_run":
        body = {
            "tool": tool_name,
            "target": target,
            "mode": str(tool_input.get("mode", "dir")).lower(),
            "wordlist": tool_input.get("wordlist"),
        }
    else:
        body = {"tool": tool_name, "input": tool_input}

    return json.dumps(body, sort_keys=True)


#: Estados de tool-call que NO cuentan como "ya ejecutado" para la continuidad.
#: - waiting_hitl: la tool quedó pausada esperando aprobación → al retomar DEBE
#:   re-emitirse para que el MCP la ejecute con el HITL ya aprobado.
#: - running: quedó a medias (crash/reload) → no asumir que terminó.
_NON_EXECUTED_STATUSES = frozenset({"waiting_hitl", "pending", "running"})


def signatures_from_tool_calls(
    tool_calls: list[dict],
    *,
    exclude_statuses: frozenset[str] = _NON_EXECUTED_STATUSES,
) -> set[str]:
    """Reconstruye el set de firmas de las tool-calls YA ejecutadas a partir de
    los `tools_called` de uno o varios AgentRunDoc previos.

    Excluye las que no llegaron a ejecutarse (waiting_hitl/running) para que el
    agente SÍ re-emita la tool que el operador acaba de aprobar.
    """
    sigs: set[str] = set()
    for tc in tool_calls or []:
        if not isinstance(tc, dict):
            continue
        status = str(tc.get("status", "")).strip().lower()
        if status in exclude_statuses:
            continue
        tool = tc.get("tool")
        if not tool:
            continue
        params = tc.get("params") or {}
        # `target` suele venir como columna propia además de en params.
        if "target" not in params and tc.get("target"):
            params = {**params, "target": tc["target"]}
        sigs.add(tool_signature(tool, params))
    return sigs
