"""
scope_validator.py — Validación de target ∈ scope autorizado
============================================================
HU-02: cualquier tool call de Recon/Scan tiene que pasar por aquí
antes de ejecutarse. Es la garantía técnica de "scope enforcement
programático" del proyecto (CLAUDE.md §1).

Auditoría 2026-05-27 (lab-fixes): se extendió la función para soportar:
  - Targets en formato URL (ej. http://10.42.0.10:80/path) — nuclei
    y gobuster los pasan así. Se extrae el host antes del check.
  - Target = CIDR cuando el scope autorizado también es CIDR — se
    valida contención completa (subnet_of). Cierra el hallazgo H-3
    de la auditoría 2026-05-26.
  - Strip de puerto en hostnames (ej. "10.42.0.10:80" → "10.42.0.10").
"""

from __future__ import annotations

import ipaddress
import logging
from urllib.parse import urlparse

from sqlalchemy.orm import Session

import models

logger = logging.getLogger(__name__)


def _extract_host(target: str) -> str:
    """
    Normaliza un target llegado del LLM a su forma "host pelado":
      http://10.42.0.10:80/foo → 10.42.0.10
      https://example.com/x    → example.com
      10.42.0.10:8180          → 10.42.0.10
      [::1]:80                 → ::1
      10.42.0.0/24             → 10.42.0.0/24   (sin cambios — caso CIDR)
      10.42.0.10               → 10.42.0.10
    No hace lookups DNS — solo manipulación sintáctica.
    """
    if not target:
        return target
    t = target.strip()

    # Caso CIDR: se devuelve tal cual; el caller decide si es válido.
    if "/" in t and "://" not in t:
        # IPv4/IPv6 CIDR sin esquema → respetar.
        try:
            ipaddress.ip_network(t, strict=False)
            return t
        except ValueError:
            pass  # no era CIDR, sigue al parsing URL.

    # Caso URL completa: usar urlparse.
    if "://" in t:
        parsed = urlparse(t)
        host = parsed.hostname or ""
        return host

    # Caso "host:port" sin esquema. Cuidar IPv6 entre corchetes.
    if t.startswith("[") and "]" in t:
        # [::1]:80 o [::1]
        return t[1 : t.index("]")]

    # Heurística: si hay un único ":" y la parte derecha es numérica,
    # es host:port. Si hay múltiples ":" sin corchetes, es IPv6 puro.
    if t.count(":") == 1:
        host, _, port = t.partition(":")
        if port.isdigit():
            return host

    return t


def is_target_in_scope(target: str, engagement_id: int, db: Session) -> bool:
    """
    Verifica si un target encontrado por el agente está dentro del scope
    autorizado para `engagement_id`.

    Reglas:
      * scope IP        → target debe ser exactamente esa IP.
      * scope CIDR      → target puede ser una IP individual (in_network)
                          o un CIDR completamente contenido (subnet_of).
      * scope DOMAIN    → target debe ser el dominio exacto o un subdominio.

    El `target` puede venir como URL, host:port, IPv4/IPv6 plana o CIDR.
    Se normaliza con `_extract_host` antes de comparar.
    """
    raw_target = target
    host = _extract_host(target)

    scopes = (
        db.query(models.ScopeTarget)
        .filter(models.ScopeTarget.engagement_id == engagement_id)
        .all()
    )

    # Pre-parseo del target normalizado en sus dos formas posibles.
    target_is_ip = False
    target_is_cidr = False
    parsed_ip = None
    parsed_net = None

    try:
        parsed_ip = ipaddress.ip_address(host)
        target_is_ip = True
    except (ValueError, TypeError):
        pass

    if not target_is_ip:
        try:
            parsed_net = ipaddress.ip_network(host, strict=False)
            # ip_network acepta "10.0.0.1" como /32 — distinguir entre IP y CIDR puro.
            if "/" in host:
                target_is_cidr = True
        except (ValueError, TypeError):
            pass

    target_lower = (host or "").lower()

    for scope in scopes:
        tipo = (
            scope.target_type.name
            if hasattr(scope.target_type, "name")
            else str(scope.target_type).upper()
        )
        scope_value = scope.target_value

        if tipo == "IP":
            if target_is_ip and host == scope_value:
                return True

        elif tipo == "CIDR":
            try:
                scope_net = ipaddress.ip_network(scope_value, strict=False)
            except ValueError:
                continue
            if target_is_ip and parsed_ip in scope_net:
                return True
            if target_is_cidr and parsed_net is not None:
                try:
                    if parsed_net.subnet_of(scope_net):
                        return True
                except (ValueError, TypeError):
                    pass

        elif tipo == "DOMAIN":
            scope_lower = scope_value.lower()
            if target_lower == scope_lower or target_lower.endswith(f".{scope_lower}"):
                return True

    logger.debug(
        "scope_check NEG raw=%r host=%r engagement_id=%s scopes=%s",
        raw_target,
        host,
        engagement_id,
        [(s.target_type, s.target_value) for s in scopes],
    )
    return False
