"""
Tests para services/agent_config.py — helper supports_temperature().

Regresión 2026-06-26: el AnalysisAgent enviaba `temperature=0` a Opus 4.8, que
deprecó el parámetro → la API respondía 400 ("temperature is deprecated for this
model") y el análisis fallaba con un ExceptionGroup enmascarado. supports_temperature()
decide si pasar el parámetro según el modelo.
"""

from __future__ import annotations

from services.agent_config import supports_temperature


def test_opus_4_8_no_acepta_temperature():
    # El modelo de la regresión: debe omitirse temperature.
    assert supports_temperature("claude-opus-4-8") is False


def test_fable_5_no_acepta_temperature():
    assert supports_temperature("claude-fable-5") is False


def test_haiku_acepta_temperature():
    assert supports_temperature("claude-haiku-4-5-20251001") is True


def test_sonnet_acepta_temperature():
    assert supports_temperature("claude-sonnet-4-6") is True


def test_opus_4_7_acepta_temperature():
    # Solo 4.8+ deprecó el parámetro; el 4.7 todavía lo acepta.
    assert supports_temperature("claude-opus-4-7") is True


def test_prefijo_insensible_a_mayusculas():
    assert supports_temperature("Claude-Opus-4-8") is False


def test_modelo_vacio_o_none_no_rompe():
    # Degradación segura: ante un modelo desconocido/vacío preferimos pasar
    # temperature (True), salvo que matchee un prefijo deprecado.
    assert supports_temperature("") is True
    assert supports_temperature(None) is True  # type: ignore[arg-type]
