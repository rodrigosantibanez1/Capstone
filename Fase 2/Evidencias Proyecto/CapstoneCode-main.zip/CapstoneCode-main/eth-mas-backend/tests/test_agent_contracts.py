"""
Tests de los contratos del Bloque 0 (ADR-005).

Cubren las piezas puras (sin Mongo): AgentContext / AgentResult / ScopeItem,
la interfaz agent-as-tool, el tiering de modelos y los schemas de las
colecciones nuevas del blackboard. La verificación de blackboard.py contra
Mongo se hace aparte (integración), porque requiere una BD viva.
"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from services.agent_base import (
    ScopeItem,
    AgentContext,
    AgentResult,
    BaseAgent,
    AGENT_NAMES,
    AGENT_TOOL_SCHEMAS,
    TOOL_NAME_TO_AGENT,
)
from schemas import ROE


# ── AgentContext ──────────────────────────────────────────────────────────────

def test_agent_context_defaults_and_targets():
    ctx = AgentContext(
        engagement_id=18,
        goal="Enumerar la superficie web autorizada",
        scope=[
            ScopeItem(target_value="10.42.0.10", target_type="ip"),
            ScopeItem(target_value="10.42.0.20", target_type="ip"),
        ],
    )
    assert ctx.targets() == ["10.42.0.10", "10.42.0.20"]
    # ROE por defecto presente y con la intensidad canónica
    assert isinstance(ctx.roe, ROE)
    assert ctx.roe.scan_intensity == "MODERATE"
    assert ctx.budget_steps == 12
    assert ctx.prior_state == {}


def test_agent_context_accepts_roe_and_directive():
    ctx = AgentContext(
        engagement_id=1,
        goal="x",
        roe=ROE(scan_intensity="STEALTH"),
        operator_directive="modo sigiloso",
    )
    assert ctx.roe.scan_intensity == "STEALTH"
    assert ctx.operator_directive == "modo sigiloso"


# ── AgentResult ───────────────────────────────────────────────────────────────

def test_agent_result_roundtrip():
    r = AgentResult(
        agent="ScanAgent",
        status="completed",
        rationale="nmap detectó 80/http → corrí nikto y gobuster dir.",
        findings_count=27,
        artifacts={"surface_map_id": "abc"},
        budget_used={"steps": 6, "tokens": 1234},
    )
    dumped = r.model_dump()
    again = AgentResult(**dumped)
    assert again == r
    assert again.status == "completed"


def test_agent_result_rejects_unknown_status():
    with pytest.raises(ValidationError):
        AgentResult(agent="X", status="nope", rationale="...")


def test_agent_result_forbids_extra_fields():
    # extra='forbid' protege el contrato de que alguien meta campos ad-hoc.
    with pytest.raises(ValidationError):
        AgentResult(agent="X", status="completed", rationale="r", foo="bar")


# ── agent-as-tool ─────────────────────────────────────────────────────────────

def test_agent_tool_schemas_cover_all_agents():
    assert set(AGENT_TOOL_SCHEMAS.keys()) == set(AGENT_NAMES)
    for schema in AGENT_TOOL_SCHEMAS.values():
        assert "name" in schema and "input_schema" in schema
        props = schema["input_schema"]["properties"]
        assert "engagement_id" in props and "goal" in props
        assert schema["input_schema"]["required"] == ["engagement_id", "goal"]


def test_tool_name_to_agent_is_inverse():
    for agent_name, schema in AGENT_TOOL_SCHEMAS.items():
        assert TOOL_NAME_TO_AGENT[schema["name"]] == agent_name
    # nombres de tool estables y esperados
    assert TOOL_NAME_TO_AGENT["run_scan_agent"] == "ScanAgent"
    assert TOOL_NAME_TO_AGENT["run_analysis_agent"] == "AnalysisAgent"


def test_scan_tool_exposes_intensity_and_reporter_type():
    scan_props = AGENT_TOOL_SCHEMAS["ScanAgent"]["input_schema"]["properties"]
    assert scan_props["intensity"]["enum"] == ["STEALTH", "MODERATE", "AGGRESSIVE"]
    rep_props = AGENT_TOOL_SCHEMAS["ReporterAgent"]["input_schema"]["properties"]
    assert rep_props["report_type"]["enum"] == ["technical", "executive"]


# ── BaseAgent ─────────────────────────────────────────────────────────────────

def test_base_agent_is_abstract():
    with pytest.raises(TypeError):
        BaseAgent(engagement_id=1, db=None)  # no implementa run()


def test_base_agent_subclass_contract():
    class DummyAgent(BaseAgent):
        name = "ScanAgent"

        async def run(self, ctx):  # type: ignore[override]
            return AgentResult(agent=self.name, status="completed", rationale="ok")

    a = DummyAgent(engagement_id=7, db=None, pipeline_run_id="p1")
    assert a.engagement_id == 7 and a.pipeline_run_id == "p1"


# ── agent_config (tiering de modelos) ─────────────────────────────────────────

def test_agent_config_defaults_safe(monkeypatch):
    import importlib
    for v in ("ORCHESTRATOR_MODEL", "ANALYSIS_MODEL", "SCAN_AGENT_MODEL",
              "RECON_AGENT_MODEL", "REPORTER_MODEL"):
        monkeypatch.delenv(v, raising=False)
    import services.agent_config as cfg
    importlib.reload(cfg)
    # Sin env, todos caen al modelo fast probado (no rompen el runtime).
    assert cfg.orchestrator_model() == cfg.FAST_MODEL_DEFAULT
    assert cfg.analysis_model() == cfg.FAST_MODEL_DEFAULT
    assert cfg.model_for("ScanAgent") == cfg.FAST_MODEL_DEFAULT


def test_agent_config_env_override(monkeypatch):
    monkeypatch.setenv("ANALYSIS_MODEL", "modelo-opus-test")
    monkeypatch.setenv("SCAN_AGENT_MODEL", "modelo-sonnet-test")
    import services.agent_config as cfg
    assert cfg.analysis_model() == "modelo-opus-test"
    assert cfg.model_for("AnalysisAgent") == "modelo-opus-test"
    assert cfg.scan_agent_model() == "modelo-sonnet-test"


# ── schemas de colecciones del blackboard ─────────────────────────────────────

def test_blackboard_docs_construct():
    from mongo_schemas import AnalysisDoc, AgentRationaleDoc, ConversationTurnDoc

    a = AnalysisDoc(engagement_id=1)
    assert a.enriched_findings == [] and a.attack_vectors == []
    assert a.generated_at is not None
    # extra='allow' → el Bloque B puede enriquecer
    a2 = AnalysisDoc(engagement_id=1, extra_field={"k": "v"})
    assert a2.model_dump()["extra_field"] == {"k": "v"}

    r = AgentRationaleDoc(engagement_id=1, agent="ScanAgent", rationale="porque sí")
    assert r.created_at is not None

    c = ConversationTurnDoc(engagement_id=1, role="operator", content="escaneá esto")
    assert c.role == "operator"
