"""
Tests del AnalysisAgent (Bloque B) — helpers puros, sin red ni Mongo.

El loop agéntico (con LLM + MCP) se verifica en integración. Acá cubrimos la
compactación de findings, el parsing del JSON final del LLM (la parte frágil),
el turno de cierre forzado (BUG-1) y la guard anti-clobbering de write_analysis.
"""

from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

import services.blackboard as blackboard
from services.analysis_agent import AnalysisAgent, _compact_findings, _parse_analysis_json
from services.blackboard import _analysis_has_data, write_analysis


# ── _compact_findings ─────────────────────────────────────────────────────────

def test_compact_findings_maps_fields():
    findings = [{
        "dedup_key": "nmap|10.42.0.10|21|tcp",
        "tool": "nmap",
        "target": "10.42.0.10",
        "summary": "Puerto 21 abierto — ftp (vsftpd 2.3.4)",
        "severity": "high",
        "port": 21,
        "service": "ftp",
        "evidence": {"product": "vsftpd", "version": "2.3.4", "port": 21},
    }]
    out = _compact_findings(findings)
    assert len(out) == 1
    f = out[0]
    assert f["ref"] == "nmap|10.42.0.10|21|tcp"
    assert f["product"] == "vsftpd"
    assert f["version"] == "2.3.4"
    assert f["service"] == "ftp"


def test_compact_findings_ref_falls_back_to_id():
    out = _compact_findings([{"_id": "abc123", "tool": "nmap", "target": "x"}])
    assert out[0]["ref"] == "abc123"


# ── _parse_analysis_json ──────────────────────────────────────────────────────

def test_parse_json_fenced_block():
    payload = {
        "summary": "1 RCE crítico en FTP.",
        "enriched_findings": [{"ref": "nmap|x|21|tcp", "cve_ids": ["CVE-2011-2523"],
                               "cvss_score": 9.8, "mitre_technique": "T1190"}],
        "attack_vectors": [{"name": "FTP backdoor", "steps": ["conectar 6200"]}],
        "priority_order": ["nmap|x|21|tcp"],
    }
    text = f"Analicé todo.\n```json\n{json.dumps(payload)}\n```\nFin."
    out = _parse_analysis_json(text, [])
    assert out["summary"].startswith("1 RCE")
    assert out["enriched_findings"][0]["cve_ids"] == ["CVE-2011-2523"]
    assert out["priority_order"] == ["nmap|x|21|tcp"]


def test_parse_json_bare_object():
    text = 'resultado: {"summary":"ok","enriched_findings":[],"attack_vectors":[],"priority_order":[]}'
    out = _parse_analysis_json(text, [])
    assert out["summary"] == "ok"


def test_parse_json_invalid_falls_back():
    out = _parse_analysis_json("no hay json aquí, solo texto", [])
    assert out["enriched_findings"] == []
    assert out["attack_vectors"] == []
    assert out["summary"]  # conserva algo de texto


def test_parse_json_empty_text():
    out = _parse_analysis_json("", [])
    assert out["enriched_findings"] == []
    assert "summary" in out


def test_parse_json_fills_defaults():
    text = '```json\n{"summary":"solo resumen"}\n```'
    out = _parse_analysis_json(text, [])
    assert out["enriched_findings"] == []
    assert out["attack_vectors"] == []
    assert out["priority_order"] == []


def test_parse_json_truncated_by_max_tokens():
    # JSON cortado a mitad de objeto (stop_reason=max_tokens): no parsea pero
    # tampoco crashea — devuelve envelope vacío con algo de summary.
    text = ('```json\n{"summary": "riesgo alto", "enriched_findings": '
            '[{"ref": "nmap|x|21|tcp", "cve_ids": ["CVE-2011-2523"]}, {"ref": "nmap|x|22')
    out = _parse_analysis_json(text, [])
    assert out["enriched_findings"] == []
    assert out["attack_vectors"] == []
    assert out["priority_order"] == []
    assert out["summary"]


def test_parse_json_truncated_with_partial_close():
    # Variante: hay un "}" interno (cierra un sub-objeto) pero el objeto raíz
    # quedó abierto → json.loads falla → fallback al envelope vacío.
    text = '{"summary": "x", "enriched_findings": [{"ref": "a"}'
    out = _parse_analysis_json(text, [])
    assert out["enriched_findings"] == []
    assert out["summary"]


# ── _force_final_turn (BUG-1: cierre forzado sin tools) ───────────────────────

class _FakeMessagesAPI:
    """client.messages.create falso: registra kwargs y devuelve texto fijo."""

    def __init__(self, text: str):
        self._text = text
        self.last_kwargs: dict | None = None

    async def create(self, **kwargs):
        self.last_kwargs = kwargs
        return SimpleNamespace(
            content=[SimpleNamespace(type="text", text=self._text)],
            stop_reason="end_turn",
        )


class _FakeClient:
    def __init__(self, text: str):
        self.messages = _FakeMessagesAPI(text)


def test_force_final_turn_after_budget_exhausted():
    # Budget agotado: el último mensaje es user con tool_results → la instrucción
    # de cierre se suma como bloque extra (la API exige roles alternados).
    agent = AnalysisAgent(1, None)
    client = _FakeClient('```json\n{"summary":"cerrado","enriched_findings":[{"ref":"a"}]}\n```')
    messages = [
        {"role": "user", "content": "analizá"},
        {"role": "assistant", "content": [SimpleNamespace(type="tool_use", id="tu_1")]},
        {"role": "user", "content": [
            {"type": "tool_result", "tool_use_id": "tu_1", "content": "{}"},
        ]},
    ]
    text = asyncio.run(agent._force_final_turn(client, [], messages))
    assert "cerrado" in text
    # la instrucción quedó como bloque de texto dentro del mensaje de tool_results
    closing_blocks = [b for b in messages[2]["content"] if b.get("type") == "text"]
    assert len(closing_blocks) == 1
    assert "NO llames más tools" in closing_blocks[0]["text"]
    # el turno de cierre va sin posibilidad de tool calls
    assert client.messages.last_kwargs["tool_choice"] == {"type": "none"}


def test_force_final_turn_after_max_tokens_with_pending_tool_use():
    # max_tokens cortó al assistant con un tool_use sin responder → el turno de
    # cierre debe inyectar tool_results stub antes de la instrucción.
    agent = AnalysisAgent(1, None)
    client = _FakeClient('{"summary":"ok","enriched_findings":[],"attack_vectors":[],"priority_order":[]}')
    messages = [
        {"role": "user", "content": "analizá"},
        {"role": "assistant", "content": [
            SimpleNamespace(type="text", text="voy a buscar"),
            SimpleNamespace(type="tool_use", id="tu_9"),
        ]},
    ]
    asyncio.run(agent._force_final_turn(client, [], messages))
    # se agregó un mensaje user con tool_result para tu_9 + la instrucción
    closing_msg = messages[2]
    assert closing_msg["role"] == "user"
    results = [b for b in closing_msg["content"] if b["type"] == "tool_result"]
    assert [r["tool_use_id"] for r in results] == ["tu_9"]
    assert closing_msg["content"][-1]["type"] == "text"


# ── write_analysis: guard anti-clobbering (BUG-1) ─────────────────────────────

class _FakeAnalysisCol:
    """Colección Mongo falsa: find_one devuelve `existing`, replace_one registra."""

    def __init__(self, existing: dict | None = None):
        self.existing = existing
        self.replaced: dict | None = None

    async def find_one(self, query):
        return self.existing

    async def replace_one(self, query, doc, upsert=False):
        self.replaced = doc


def test_analysis_has_data():
    assert not _analysis_has_data(None)
    assert not _analysis_has_data({})
    assert not _analysis_has_data({"summary": "solo texto", "enriched_findings": []})
    assert _analysis_has_data({"enriched_findings": [{"ref": "a"}]})
    assert _analysis_has_data({"attack_vectors": [{"name": "x"}]})
    assert _analysis_has_data({"priority_order": ["a"]})


def test_write_analysis_empty_doc_does_not_clobber(monkeypatch):
    fake = _FakeAnalysisCol(existing={
        "engagement_id": 1,
        "enriched_findings": [{"ref": "a", "cve_ids": ["CVE-2011-2523"]}],
    })
    monkeypatch.setattr(blackboard, "analysis_col", lambda: fake)

    written = asyncio.run(write_analysis(1, {
        "summary": "el agente no cerró",
        "enriched_findings": [], "attack_vectors": [], "priority_order": [],
    }))
    assert written is False
    assert fake.replaced is None  # el doc bueno sobrevive


def test_write_analysis_empty_doc_writes_when_no_existing(monkeypatch):
    fake = _FakeAnalysisCol(existing=None)
    monkeypatch.setattr(blackboard, "analysis_col", lambda: fake)

    written = asyncio.run(write_analysis(2, {"summary": "primera corrida sin datos"}))
    assert written is True
    assert fake.replaced["engagement_id"] == 2


def test_write_analysis_empty_doc_replaces_empty_existing(monkeypatch):
    fake = _FakeAnalysisCol(existing={"engagement_id": 3, "enriched_findings": []})
    monkeypatch.setattr(blackboard, "analysis_col", lambda: fake)

    written = asyncio.run(write_analysis(3, {"summary": "nuevo intento"}))
    assert written is True
    assert fake.replaced["summary"] == "nuevo intento"


def test_write_analysis_doc_with_data_always_writes(monkeypatch):
    fake = _FakeAnalysisCol(existing={
        "engagement_id": 4, "enriched_findings": [{"ref": "viejo"}],
    })
    monkeypatch.setattr(blackboard, "analysis_col", lambda: fake)

    written = asyncio.run(write_analysis(4, {
        "enriched_findings": [{"ref": "nuevo", "cve_ids": ["CVE-2024-0001"]}],
    }))
    assert written is True
    assert fake.replaced["enriched_findings"][0]["ref"] == "nuevo"
    assert fake.replaced["engagement_id"] == 4
