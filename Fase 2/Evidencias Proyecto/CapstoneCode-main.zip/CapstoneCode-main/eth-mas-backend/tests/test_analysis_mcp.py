"""
Tests del Analysis MCP (Bloque B) — lógica pura, sin red.

Cubre el parser de la respuesta NVD 2.0 (cve_lookup) y el lookup de técnicas
ATT&CK (attack_technique_lookup). La llamada real a NVD se prueba aparte.
"""

from __future__ import annotations

from mcp_servers.analysis_server import _parse_nvd_response, _attack_lookup


# ── _parse_nvd_response ───────────────────────────────────────────────────────

_NVD_SAMPLE = {
    "vulnerabilities": [
        {
            "cve": {
                "id": "CVE-2011-2523",
                "descriptions": [
                    {"lang": "es", "value": "puerta trasera"},
                    {"lang": "en", "value": "vsftpd 2.3.4 downloaded contains a backdoor."},
                ],
                "metrics": {
                    "cvssMetricV2": [
                        {"cvssData": {"baseScore": 10.0}, "baseSeverity": "HIGH"}
                    ]
                },
            }
        },
        {
            "cve": {
                "id": "CVE-2021-3618",
                "descriptions": [{"lang": "en", "value": "ALPACA attack."}],
                "metrics": {
                    "cvssMetricV31": [
                        {"cvssData": {"baseScore": 7.4, "baseSeverity": "HIGH"}}
                    ]
                },
            }
        },
    ]
}


def test_parse_nvd_extracts_id_score_severity():
    out = _parse_nvd_response(_NVD_SAMPLE, max_results=8)
    assert len(out) == 2
    by_id = {c["cve_id"]: c for c in out}

    backdoor = by_id["CVE-2011-2523"]
    assert backdoor["cvss_score"] == 10.0
    assert backdoor["cvss_severity"] == "high"     # normalizado a lowercase
    assert "backdoor" in backdoor["description"]   # tomó la descripción en inglés
    assert backdoor["source"] == "NVD"

    alpaca = by_id["CVE-2021-3618"]
    assert alpaca["cvss_score"] == 7.4             # tomó v3.1


def test_parse_nvd_respects_max_results():
    out = _parse_nvd_response(_NVD_SAMPLE, max_results=1)
    assert len(out) == 1


def test_parse_nvd_empty():
    assert _parse_nvd_response({"vulnerabilities": []}, 8) == []
    assert _parse_nvd_response({}, 8) == []


def test_parse_nvd_skips_entries_without_id():
    data = {"vulnerabilities": [{"cve": {"descriptions": []}}]}
    assert _parse_nvd_response(data, 8) == []


# ── _attack_lookup ────────────────────────────────────────────────────────────

def test_attack_validate_known_id():
    r = _attack_lookup("T1046")
    assert r["status"] == "validated"
    assert r["matches"][0]["name"] == "Network Service Discovery"
    assert r["matches"][0]["tactic"] == "Discovery"


def test_attack_validate_is_case_insensitive():
    assert _attack_lookup("t1190")["status"] == "validated"


def test_attack_unknown_id_is_not_found():
    r = _attack_lookup("T9999")
    assert r["status"] == "not_found"
    assert r["matches"] == []


def test_attack_keyword_search():
    r = _attack_lookup("service discovery")
    assert r["status"] == "found"
    ids = {m["technique_id"] for m in r["matches"]}
    assert "T1046" in ids


def test_attack_keyword_by_tactic():
    r = _attack_lookup("credential access")
    assert r["status"] == "found"
    assert any(m["technique_id"] == "T1110" for m in r["matches"])  # Brute Force


def test_attack_no_match():
    assert _attack_lookup("zzzznotatechnique")["status"] == "not_found"
