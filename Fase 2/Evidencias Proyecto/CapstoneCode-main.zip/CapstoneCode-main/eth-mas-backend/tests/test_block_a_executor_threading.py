"""
Tests del Bloque A — punto de integración del ejecutor.

Verifican que `_run_stage` (y por ende `run_single_stage`, que lo usa) threadea
el `goal` + `operator_directive` que decide el Orquestador hasta el
`AgentContext` que recibe el worker, y que cuando `goal` es None cae al
`_DEFAULT_GOALS` histórico (el camino de run()/​/scan/​/recon queda idéntico).

No tocan Mongo/BD: se mockean `build_agent_context` y `record_rationale`.
"""

from __future__ import annotations

import asyncio

from services.agent_base import AgentContext, AgentResult, BaseAgent
import services.pipeline_controller as pc


class _EchoAgent(BaseAgent):
    """Agente stub que registra el AgentContext que recibió."""
    name = "AnalysisAgent"  # un nombre ya registrado que NO dispara el pre-check anti-zombi
    last_ctx: AgentContext | None = None

    async def run(self, ctx: AgentContext) -> AgentResult:
        type(self).last_ctx = ctx
        return AgentResult(agent=self.name, status="completed", rationale="ok")


def _patch(monkeypatch, captured: dict):
    async def fake_build(db, engagement_id, *, goal, operator_directive=None, **kw):
        captured["goal"] = goal
        captured["operator_directive"] = operator_directive
        return AgentContext(
            engagement_id=engagement_id, goal=goal, operator_directive=operator_directive,
        )

    async def fake_record(*a, **k):
        return None

    monkeypatch.setattr(pc, "build_agent_context", fake_build)
    monkeypatch.setitem(pc._AGENT_REGISTRY, "AnalysisAgent", _EchoAgent)
    monkeypatch.setattr("services.blackboard.record_rationale", fake_record)


def test_run_stage_threads_goal_and_directive(monkeypatch):
    captured: dict = {}
    _patch(monkeypatch, captured)
    _EchoAgent.last_ctx = None

    ctrl = pc.PipelineController(engagement_id=7, db=None, stages=["AnalysisAgent"])
    out = asyncio.run(
        ctrl._run_stage(
            "AnalysisAgent",
            goal="meta X",
            operator_directive="Intensidad solicitada: STEALTH",
        )
    )

    assert captured["goal"] == "meta X"
    assert captured["operator_directive"] == "Intensidad solicitada: STEALTH"
    assert _EchoAgent.last_ctx is not None
    assert _EchoAgent.last_ctx.operator_directive == "Intensidad solicitada: STEALTH"
    assert out["status"] == "completed"


def test_run_stage_defaults_goal_when_none(monkeypatch):
    """Sin goal explícito → cae al _DEFAULT_GOALS del agente (camino histórico)."""
    captured: dict = {}
    _patch(monkeypatch, captured)

    ctrl = pc.PipelineController(engagement_id=7, db=None, stages=["AnalysisAgent"])
    asyncio.run(ctrl._run_stage("AnalysisAgent"))

    assert captured["goal"] == pc._DEFAULT_GOALS["AnalysisAgent"]
    assert captured["operator_directive"] is None
