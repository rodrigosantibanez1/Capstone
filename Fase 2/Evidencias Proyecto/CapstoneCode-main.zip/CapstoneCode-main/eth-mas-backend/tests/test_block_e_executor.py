"""
Tests del Bloque E — ejecutor seguro contract-aware.

Cubre lo que no requiere Mongo/API: registro de los 4 agentes, los stubs
nuevo-contrato (AnalysisAgent/ReporterAgent) y el converter AgentResult→dict.
La ejecución end-to-end vía PipelineController (que toca BD + blackboard) se
verifica aparte como integración.
"""

from __future__ import annotations

import asyncio

from services.agent_base import AgentContext, AgentResult, BaseAgent
from services.analysis_agent import AnalysisAgent
from services.reporter_agent import ReporterAgent
from services.pipeline_controller import _AGENT_REGISTRY, _result_to_stage_dict


def test_registry_has_four_agents():
    assert set(_AGENT_REGISTRY.keys()) == {
        "ReconAgent", "ScanAgent", "AnalysisAgent", "ReporterAgent",
    }


def test_analysis_reporter_are_base_agents():
    # AnalysisAgent (Bloque B) y ReporterAgent (Bloque C) son agentes reales,
    # pero conservan el contrato BaseAgent que el ejecutor espera.
    assert issubclass(AnalysisAgent, BaseAgent)
    assert issubclass(ReporterAgent, BaseAgent)
    assert AnalysisAgent(1, None).name == "AnalysisAgent"
    assert ReporterAgent(1, None).name == "ReporterAgent"


def test_result_to_stage_dict_maps_fields():
    r = AgentResult(
        agent="AnalysisAgent",
        status="completed",
        rationale="razonó X",
        findings_count=3,
        artifacts={"agent_run_id": "abc", "analysis_id": "z"},
        pending_hitl_ids=[9],
    )
    d = _result_to_stage_dict(r, engagement_id=42)
    assert d["status"] == "completed"
    assert d["engagement_id"] == 42
    assert d["findings_count"] == 3
    assert d["agent_run_id"] == "abc"
    assert d["pending_hitl_ids"] == [9]
    assert d["rationale"] == "razonó X"


def test_result_to_stage_dict_reason_prefers_error():
    r = AgentResult(agent="X", status="failed", rationale="r", error="boom")
    d = _result_to_stage_dict(r, 1)
    assert d["reason"] == "boom"
