"""
Tests para services/findings_service.normalize_*

Cubre los normalizadores de gobuster (dir + dns), nikto y nuclei.
Foco principal: fix del H-4 (escape codes de gobuster).
"""

from __future__ import annotations

import json

import pytest

from services.findings_service import (
    normalize_gobuster_findings,
    normalize_nikto_findings,
    normalize_nuclei_findings,
)


# ── gobuster dir ─────────────────────────────────────────────────────────────

def test_gobuster_dir_basic():
    raw = (
        "/admin               (Status: 200) [Size: 1234]\n"
        "/login               (Status: 200) [Size: 45]\n"
    )
    out = normalize_gobuster_findings(1, "http://x", raw, mode="dir")
    assert len(out) == 2
    assert out[0]["evidence"]["path"] == "/admin"
    assert out[0]["evidence"]["status_code"] == 200
    assert out[0]["severity"] == "medium"   # admin ∈ _HIGH_RISK_PATHS
    assert out[1]["severity"] == "low"


def test_gobuster_dir_handles_redirect_301():
    """3xx debe persistirse (sólo 4xx+ se filtra)."""
    raw = "/test                (Status: 301) [Size: 312]\n"
    out = normalize_gobuster_findings(1, "http://x", raw, mode="dir")
    assert len(out) == 1
    assert out[0]["evidence"]["status_code"] == 301


def test_gobuster_dir_filters_4xx():
    raw = "/notfound            (Status: 404) [Size: 0]\n"
    out = normalize_gobuster_findings(1, "http://x", raw, mode="dir")
    assert out == []


def test_gobuster_dir_strips_ansi_escape_codes_h4():
    """
    Reproducción exacta del hallazgo H-4: gobuster --no-color igual emite
    \\x1b[2K (clear-line) al inicio de cada línea cuando corre con
    stdout-buffering off. El normalizer debe sanitizarlos antes del regex.
    """
    raw = (
        "\x1b[2K/admin               (Status: 200) [Size: 1234]\n"
        "\x1b[2K/test                (Status: 301) [Size: 312] [--> http://x/test/]\n"
    )
    out = normalize_gobuster_findings(1, "http://x", raw, mode="dir")
    assert len(out) == 2
    paths = sorted(f["evidence"]["path"] for f in out)
    assert paths == ["/admin", "/test"]


def test_gobuster_dir_strips_csi_with_color_codes():
    """Variante: sequencias SGR (`\\x1b[31m`) también deben sanitizarse."""
    raw = "\x1b[31m\x1b[2K/secret              (Status: 200) [Size: 100]\x1b[0m\n"
    out = normalize_gobuster_findings(1, "http://x", raw, mode="dir")
    assert len(out) == 1
    assert out[0]["evidence"]["path"] == "/secret"


# ── gobuster dns ─────────────────────────────────────────────────────────────

def test_gobuster_dns_basic():
    raw = (
        "Found: mail.example.com\n"
        "Found: api.example.com\n"
    )
    out = normalize_gobuster_findings(1, "example.com", raw, mode="dns")
    assert len(out) == 2
    assert out[0]["evidence"]["subdomain"] == "mail.example.com"
    assert out[0]["severity"] == "info"


def test_gobuster_dns_strips_ansi():
    raw = "\x1b[2KFound: mail.example.com\n"
    out = normalize_gobuster_findings(1, "example.com", raw, mode="dns")
    assert len(out) == 1


# ── nikto ────────────────────────────────────────────────────────────────────

def test_nikto_basic_dict_format():
    """nikto < 2.5: emite dict directo."""
    data = {
        "host": "10.42.0.10",
        "port": 80,
        "vulnerabilities": [
            {"id": "001234", "description": "SQL Injection detected at /login", "url": "/login", "method": "POST"},
            {"id": "999000", "description": "Directory listing enabled", "url": "/private/", "method": "GET"},
            {"id": "111111", "description": "Server header reveals version", "url": "/", "method": "GET"},
        ],
    }
    out = normalize_nikto_findings(1, "10.42.0.10", json.dumps(data))
    assert len(out) == 3
    severities = [f["severity"] for f in out]
    assert "high" in severities       # SQL Injection
    assert "medium" in severities     # directory listing
    assert "low" in severities        # versión revealed


def test_nikto_list_of_hosts_h5b():
    """nikto 2.5.x emite list[dict]. Reproduce H-5b del lab E2E."""
    data = [
        {
            "host": "10.42.0.10",
            "port": 80,
            "vulnerabilities": [
                {"id": "000434", "description": "HTTP TRACE method is active", "url": "/", "method": "TRACE"},
                {"id": "111", "description": "Default file present: phpinfo.php", "url": "/phpinfo.php", "method": "GET"},
            ],
        }
    ]
    out = normalize_nikto_findings(1, "10.42.0.10", json.dumps(data))
    assert len(out) == 2
    assert any("HTTP TRACE" in f["title"] for f in out)


def test_nikto_list_multiple_hosts():
    """Hipotético: nikto -h con múltiples targets en list[dict]."""
    data = [
        {"host": "10.42.0.10", "port": 80, "vulnerabilities": [{"description": "X-Frame-Options missing"}]},
        {"host": "10.42.0.20", "port": 80, "vulnerabilities": [{"description": "X-XSS-Protection missing"}]},
    ]
    out = normalize_nikto_findings(1, "10.42.0.10", json.dumps(data))
    assert len(out) == 2


def test_nikto_empty_vulns():
    data = {"host": "x", "port": 80, "vulnerabilities": []}
    out = normalize_nikto_findings(1, "x", json.dumps(data))
    assert out == []


def test_nikto_empty_list():
    out = normalize_nikto_findings(1, "x", json.dumps([]))
    assert out == []


def test_nikto_bad_json_returns_empty():
    out = normalize_nikto_findings(1, "x", "not valid json {{{")
    assert out == []


# ── nikto: formato CSV (diagnóstico 2026-05-29 — el reporter JSON crashea) ────

# Muestra real de nikto 2.6.0 `-Format csv` contra Metasploitable2.
_NIKTO_CSV_SAMPLE = (
    '"Nikto - v2.6.0/"\n'
    '"10.42.0.10","10.42.0.10","80","","","",""\n'
    '"10.42.0.10","10.42.0.10","80","","GET","/","Retrieved x-powered-by header: PHP/5.2.4-2ubuntu5.10."\n'
    '"10.42.0.10","10.42.0.10","80","","GET","/icons/","Directory indexing found."\n'
    '"10.42.0.10","10.42.0.10","80","","GET","/phpinfo.php","PHP is installed, and a test script which runs phpinfo() was found."\n'
    '"10.42.0.10","10.42.0.10","80","","GET","/admin/","This might be interesting: admin login page/section."\n'
)


def test_nikto_csv_basic():
    out = normalize_nikto_findings(1, "10.42.0.10", _NIKTO_CSV_SAMPLE)
    # 4 hallazgos (la fila banner y la fila de host vacía se ignoran)
    assert len(out) == 4
    titles = " ".join(f["title"] for f in out)
    assert "phpinfo" in titles
    urls = {f["evidence"]["url"] for f in out}
    assert "/icons/" in urls
    assert "/phpinfo.php" in urls


def test_nikto_csv_severity_classification():
    out = normalize_nikto_findings(1, "10.42.0.10", _NIKTO_CSV_SAMPLE)
    by_url = {f["evidence"]["url"]: f for f in out}
    assert by_url["/admin/"]["severity"] == "medium"   # "admin" ∈ keywords medium
    assert by_url["/icons/"]["severity"] == "low"      # "directory indexing" no está en keywords (≠ "directory listing")


def test_nikto_csv_evidence_fields():
    out = normalize_nikto_findings(1, "10.42.0.10", _NIKTO_CSV_SAMPLE)
    f = [x for x in out if x["evidence"]["url"] == "/phpinfo.php"][0]
    assert f["evidence"]["method"] == "GET"
    assert f["tool"] == "nikto"
    assert f["mitre_technique"] == "T1190"


def test_nikto_csv_only_banner_returns_empty():
    """CSV con solo el banner y filas de host vacías → sin findings."""
    raw = (
        '"Nikto - v2.6.0/"\n'
        '"10.42.0.10","10.42.0.10","80","","","",""\n'
    )
    assert normalize_nikto_findings(1, "10.42.0.10", raw) == []


def test_nikto_empty_string_returns_empty():
    assert normalize_nikto_findings(1, "x", "") == []


# ── nuclei ───────────────────────────────────────────────────────────────────

def test_nuclei_jsonl_basic():
    line1 = json.dumps({
        "template-id": "ssh-version",
        "matched-at": "10.42.0.10:22",
        "info": {"name": "OpenSSH version", "severity": "info"},
    })
    line2 = json.dumps({
        "template-id": "cve-2007-2447",
        "matched-at": "10.42.0.10:445",
        "info": {
            "name": "Samba RCE",
            "severity": "critical",
            "classification": {"cve-id": ["cve-2007-2447"], "cvss-score": 9.8},
        },
    })
    out = normalize_nuclei_findings(1, "http://10.42.0.10", f"{line1}\n{line2}\n")
    assert len(out) == 2
    crit = [f for f in out if f["severity"] == "critical"][0]
    assert crit["cve_ids"] == ["CVE-2007-2447"]
    assert crit["cvss_score"] == 9.8
    assert crit["cvss_source"] == "nuclei"


def test_nuclei_ignores_blank_and_invalid_lines():
    valid = json.dumps({"template-id": "x", "info": {"name": "X", "severity": "low"}})
    out = normalize_nuclei_findings(1, "x", f"\n\n{valid}\n  \nnot json\n")
    assert len(out) == 1
