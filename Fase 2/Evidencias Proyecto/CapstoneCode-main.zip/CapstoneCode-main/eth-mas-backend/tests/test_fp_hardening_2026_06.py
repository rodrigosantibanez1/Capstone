"""
Tests del hardening anti-falsos-positivos (2026-06-11).

Cubre la lógica nueva introducida tras la verificación del engagement #24:
  - findings_service: captura de puerto nikto, dedup_key con puerto, degradación
    catch-all (soft-200) de nikto y gobuster.
  - analysis_agent:   gate de confianza CVE determinístico + CVSS por-CVE.
  - analysis_server:  parsing de CPE 2.2/2.3 y virtualMatchString para NVD.

Todo es lógica pura (sin red ni DB): testeable en CI sin servicios.
"""

from __future__ import annotations

import json

import pytest

from services.findings_service import (
    _compute_dedup_key,
    normalize_gobuster_findings,
    normalize_nikto_findings,
)
from services.analysis_agent import (
    _build_cve_details,
    _derive_compat_cve_fields,
    _finding_has_version,
    _gate_cve_confidence,
)
from mcp_servers.analysis_server import (
    _build_virtual_match,
    _has_concrete_version,
    _parse_cpe,
)


# ════════════════════════════════════════════════════════════════════════════
# findings_service — nikto puerto + dedup
# ════════════════════════════════════════════════════════════════════════════

# CSV real de nikto con dos puertos distintos para el MISMO host (:80 y :8000).
_NIKTO_CSV_TWO_PORTS = (
    '"Nikto - v2.6.0/"\n'
    '"192.168.56.1","192.168.56.1","80","","GET","/","Suggested security header missing: x-content-type-options."\n'
    '"192.168.56.1","192.168.56.1","8000","","GET","/","Suggested security header missing: x-content-type-options."\n'
)


def test_nikto_captures_port_from_csv():
    out = normalize_nikto_findings(1, "192.168.56.1", _NIKTO_CSV_TWO_PORTS)
    ports = sorted(f["evidence"]["port"] for f in out)
    assert ports == [80, 8000]


def test_nikto_dedup_key_distinguishes_ports():
    """
    Fix 2026-06-11: sin el puerto en el dedup_key, el finding de :80 y el de :8000
    colisionaban (mismo url + nikto_id) y uno sobreescribía al otro en Mongo.
    """
    out = normalize_nikto_findings(1, "192.168.56.1", _NIKTO_CSV_TWO_PORTS)
    keys = {_compute_dedup_key(f) for f in out}
    assert len(keys) == 2, f"esperaba 2 dedup_keys distintos, hubo: {keys}"


# ════════════════════════════════════════════════════════════════════════════
# findings_service — degradación catch-all (soft-200)
# ════════════════════════════════════════════════════════════════════════════

_NIKTO_CSV_EXISTENCE = (
    '"Nikto - v2.6.0/"\n'
    '"192.168.56.1","192.168.56.1","80","","GET","/.bash_history",'
    '"A user\'s home directory may be set to the web root, the shell history was retrieved."\n'
)


def test_nikto_shell_history_not_high_without_keyword_shell():
    """El bare 'shell' se sacó de los high-keywords → este FP ya no es high."""
    out = normalize_nikto_findings(1, "192.168.56.1", _NIKTO_CSV_EXISTENCE)
    assert len(out) == 1
    assert out[0]["severity"] != "high"


def test_nikto_catchall_degrades_existence_findings():
    out = normalize_nikto_findings(1, "192.168.56.1", _NIKTO_CSV_EXISTENCE, catchall=True)
    f = out[0]
    assert f["severity"] == "info"
    assert f["confidence"] == "low"
    assert f["evidence"]["catchall"] is True


def test_nikto_no_catchall_keeps_high_confidence():
    out = normalize_nikto_findings(1, "192.168.56.1", _NIKTO_CSV_EXISTENCE, catchall=False)
    assert out[0]["confidence"] == "high"


def test_gobuster_catchall_degrades_all_paths():
    raw = (
        "/admin               (Status: 200) [Size: 1234]\n"
        "/login               (Status: 200) [Size: 45]\n"
    )
    out = normalize_gobuster_findings(1, "http://x", raw, mode="dir", catchall=True)
    assert len(out) == 2
    assert all(f["severity"] == "info" for f in out)
    assert all(f["confidence"] == "low" for f in out)


def test_gobuster_no_catchall_unchanged():
    raw = "/admin               (Status: 200) [Size: 1234]\n"
    out = normalize_gobuster_findings(1, "http://x", raw, mode="dir", catchall=False)
    assert out[0]["severity"] == "medium"   # admin ∈ high-risk paths
    assert out[0]["confidence"] == "high"


# ════════════════════════════════════════════════════════════════════════════
# analysis_agent — gate de confianza CVE
# ════════════════════════════════════════════════════════════════════════════

def test_gate_downgrades_confirmed_without_version():
    # Regla dura: sin versión, ningún CVE puede quedar 'confirmed'.
    assert _gate_cve_confidence("confirmed", has_version=False) == "version-unknown"
    assert _gate_cve_confidence("confirmed", has_version=True) == "confirmed"


def test_gate_unknown_label_is_conservative():
    assert _gate_cve_confidence(None, has_version=False) == "keyword-only"
    assert _gate_cve_confidence(None, has_version=True) == "version-unknown"
    assert _gate_cve_confidence("garbage", has_version=False) == "keyword-only"


def test_gate_preserves_keyword_only():
    assert _gate_cve_confidence("keyword-only", has_version=True) == "keyword-only"


def test_finding_has_version_from_evidence():
    assert _finding_has_version({"evidence": {"version": "1.2.3"}}) is True
    assert _finding_has_version({"evidence": {"version": None}}) is False
    assert _finding_has_version({"evidence": {}}) is False


def test_finding_has_version_from_cpe():
    assert _finding_has_version({"evidence": {"cpe": "cpe:/a:igor_sysoev:nginx:1.31.1"}}) is True
    # Windows sin versión (caso msrpc/SMB de #24) → no confirmable.
    assert _finding_has_version({"evidence": {"cpe": "cpe:/o:microsoft:windows"}}) is False


def test_build_cve_details_applies_gate_no_version():
    # Reproduce #24: msrpc sin versión, el LLM propuso 'confirmed' → gateado.
    ef = {"cve_details": [
        {"cve_id": "CVE-2003-0352", "cvss_score": 7.5, "confidence": "confirmed"},
    ]}
    src = {"evidence": {"product": "Microsoft Windows RPC", "version": None,
                        "cpe": "cpe:/o:microsoft:windows"}}
    details = _build_cve_details(ef, src)
    assert details[0]["confidence"] == "version-unknown"


def test_build_cve_details_legacy_cve_ids():
    ef = {"cve_ids": ["CVE-2020-7695"], "cvss_score": 5.3}
    src = {"evidence": {"version": None}}  # sin versión → keyword-only
    details = _build_cve_details(ef, src)
    assert details[0]["cve_id"] == "CVE-2020-7695"
    assert details[0]["confidence"] == "keyword-only"


def test_derive_compat_headline_cvss_only_from_confirmed():
    # Headline cvss SOLO de confirmed. version-unknown/keyword-only no inflan el score
    # (pero se conservan en cve_ids/cve_details para auditar).
    details = [
        {"cve_id": "CVE-AAAA", "cvss_score": 7.2, "confidence": "confirmed"},
        {"cve_id": "CVE-BBBB", "cvss_score": 5.3, "confidence": "version-unknown"},
        {"cve_id": "CVE-CCCC", "cvss_score": 9.9, "confidence": "keyword-only"},
    ]
    compat = _derive_compat_cve_fields(details)
    assert compat["cvss_score"] == 7.2
    assert compat["cvss_from_cve"] == "CVE-AAAA"
    assert compat["cve_ids"] == ["CVE-AAAA", "CVE-BBBB", "CVE-CCCC"]


def test_derive_compat_no_confirmed_means_no_headline_cvss():
    # Caso #24: msrpc/SMB sin versión → todo version-unknown → sin cvss headline.
    details = [
        {"cve_id": "CVE-2003-0352", "cvss_score": 7.5, "confidence": "version-unknown"},
        {"cve_id": "CVE-2026-2652", "cvss_score": 8.6, "confidence": "keyword-only"},
    ]
    compat = _derive_compat_cve_fields(details)
    assert compat["cvss_score"] is None
    assert compat["cvss_source"] is None
    assert compat["cve_ids"] == ["CVE-2003-0352", "CVE-2026-2652"]  # auditables


# ════════════════════════════════════════════════════════════════════════════
# analysis_server — CPE parsing + virtualMatchString
# ════════════════════════════════════════════════════════════════════════════

def test_parse_cpe_22_uri():
    p = _parse_cpe("cpe:/a:igor_sysoev:nginx:1.31.1")
    assert p == {"part": "a", "vendor": "igor_sysoev", "product": "nginx", "version": "1.31.1"}


def test_parse_cpe_23_formatted():
    p = _parse_cpe("cpe:2.3:a:f5:nginx:1.27.0:*:*:*:*:*:*:*")
    assert p["product"] == "nginx"
    assert p["version"] == "1.27.0"


def test_parse_cpe_no_version():
    p = _parse_cpe("cpe:/o:microsoft:windows")
    assert p["product"] == "windows"
    assert not _has_concrete_version(p["version"])


def test_has_concrete_version():
    assert _has_concrete_version("1.2.3") is True
    assert _has_concrete_version("*") is False
    assert _has_concrete_version("-") is False
    assert _has_concrete_version("") is False
    assert _has_concrete_version(None) is False


def test_build_virtual_match_wildcards_vendor_keeps_version():
    p = _parse_cpe("cpe:/a:igor_sysoev:nginx:1.31.1")
    vm = _build_virtual_match(p)
    # Vendor comodín (recall), producto+versión acotan (FP-safe).
    assert vm == "cpe:2.3:a:*:nginx:1.31.1:*:*:*:*:*:*:*"


def test_build_virtual_match_no_version_wildcards_version():
    p = _parse_cpe("cpe:/o:microsoft:windows")
    vm = _build_virtual_match(p)
    assert vm == "cpe:2.3:o:*:windows:*:*:*:*:*:*:*:*"
