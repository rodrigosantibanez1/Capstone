"""
test_narration.py — Narración legible del pipeline (services/narration.py)
==========================================================================
El módulo es puro: se testea sin BD ni API.
"""

from services.narration import narrate_run_start, narrate_tool_start


# ── narrate_run_start ─────────────────────────────────────────────────────────

def test_run_start_recon_pluraliza_objetivos():
    txt = narrate_run_start("ReconAgent", ["10.42.0.10", "10.42.0.20"])
    assert "Reconocimiento iniciado" in txt
    assert "2 objetivos" in txt


def test_run_start_un_objetivo_singular():
    txt = narrate_run_start("ScanAgent", ["10.42.0.10"])
    assert "Escaneo iniciado" in txt
    assert "1 objetivo" in txt
    assert "objetivos" not in txt   # singular


def test_run_start_sin_targets_no_agrega_conteo():
    txt = narrate_run_start("AnalysisAgent", [])
    assert "Análisis iniciado" in txt
    assert "objetivo" not in txt


def test_run_start_agente_desconocido_no_rompe():
    txt = narrate_run_start("FooAgent", ["x"])
    assert "FooAgent" in txt


# ── narrate_tool_start ────────────────────────────────────────────────────────

def test_tool_start_nmap():
    txt = narrate_tool_start("nmap_scan", "10.42.0.10")
    assert txt == "Scan usando Nmap para mapear puertos y servicios de 10.42.0.10"


def test_tool_start_whois_es_osint_recon():
    txt = narrate_tool_start("whois_lookup", "10.42.0.10")
    assert "Recon" in txt and "OSINT" in txt and "10.42.0.10" in txt


def test_tool_start_cve_lookup_usa_producto_no_target():
    txt = narrate_tool_start("cve_lookup", "", {"product": "vsftpd"})
    assert "NVD" in txt
    assert "vsftpd" in txt


def test_tool_start_attack_lookup_usa_query():
    txt = narrate_tool_start("attack_technique_lookup", "", {"query": "T1190"})
    assert "MITRE ATT&CK" in txt
    assert "T1190" in txt


def test_tool_start_sin_target_no_cuelga_la_preposicion():
    txt = narrate_tool_start("nmap_scan", "")
    assert txt == "Scan usando Nmap"


def test_tool_start_tool_desconocida_degrada_con_gracia():
    txt = narrate_tool_start("mística_tool", "x")
    assert "mística_tool" in txt
