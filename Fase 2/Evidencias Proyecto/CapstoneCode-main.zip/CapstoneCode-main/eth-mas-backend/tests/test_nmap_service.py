"""
Tests de services/nmap_service.parse_nmap_xml — parser puro del XML de nmap.
Cubre los fixes M-1 (host sin <address> descartado) y M-2 (raw_output por finding),
y el mapeo servicio/producto/versión/CPE que alimenta al AnalysisAgent.
"""
from __future__ import annotations

from services.nmap_service import parse_nmap_xml

_XML_OK = """<?xml version="1.0"?>
<nmaprun>
  <host>
    <address addr="10.42.0.10" addrtype="ipv4"/>
    <ports>
      <port protocol="tcp" portid="22">
        <state state="open"/>
        <service name="ssh" product="OpenSSH" version="4.7p1">
          <cpe>cpe:/a:openbsd:openssh:4.7p1</cpe>
        </service>
      </port>
      <port protocol="tcp" portid="23">
        <state state="closed"/>
        <service name="telnet"/>
      </port>
      <port protocol="tcp" portid="80">
        <state state="open"/>
        <service name="http" product="Apache httpd" version="2.2.8">
          <cpe>cpe:/a:apache:http_server:2.2.8</cpe>
          <cpe>cpe:/o:linux:linux_kernel</cpe>
        </service>
      </port>
    </ports>
  </host>
</nmaprun>"""


def test_parse_open_ports_only():
    ports = sorted(f["port"] for f in parse_nmap_xml(_XML_OK))
    assert ports == [22, 80]          # 23 (closed) se descarta


def test_parse_service_product_version_cpe():
    by_port = {f["port"]: f for f in parse_nmap_xml(_XML_OK)}
    ssh = by_port[22]
    assert ssh["target"] == "10.42.0.10"
    assert ssh["protocol"] == "tcp"
    assert ssh["service"] == "ssh"
    assert ssh["product"] == "OpenSSH"
    assert ssh["version"] == "4.7p1"
    assert ssh["cpe"] == "cpe:/a:openbsd:openssh:4.7p1"
    assert "10.42.0.10" in ssh["raw_output"]    # M-2


def test_parse_multiple_cpes_first_is_canonical():
    http = {f["port"]: f for f in parse_nmap_xml(_XML_OK)}[80]
    assert http["cpe"] == "cpe:/a:apache:http_server:2.2.8"
    assert http["cpes"] == ["cpe:/a:apache:http_server:2.2.8", "cpe:/o:linux:linux_kernel"]


def test_parse_host_without_address_discarded():
    # M-1: sin <address> no se puede atribuir el finding → host descartado
    xml = ('<nmaprun><host><ports>'
           '<port protocol="tcp" portid="22"><state state="open"/></port>'
           '</ports></host></nmaprun>')
    assert parse_nmap_xml(xml) == []


def test_parse_host_without_ports():
    xml = '<nmaprun><host><address addr="10.0.0.1" addrtype="ipv4"/></host></nmaprun>'
    assert parse_nmap_xml(xml) == []


def test_parse_no_hosts():
    assert parse_nmap_xml('<nmaprun></nmaprun>') == []


def test_parse_raw_output_truncated():
    # host con muchos puertos → su XML supera 1500 chars → raw_output truncado.
    ports = "".join(
        f'<port protocol="tcp" portid="{p}"><state state="open"/>'
        f'<service name="svc{p}" product="ProductoConNombreLargo {p}" version="1.0.{p}"/></port>'
        for p in range(1, 60)
    )
    xml = (f'<nmaprun><host><address addr="10.0.0.2" addrtype="ipv4"/>'
           f'<ports>{ports}</ports></host></nmaprun>')
    findings = parse_nmap_xml(xml)
    assert findings
    assert findings[0]["raw_output"].endswith("…")
    assert len(findings[0]["raw_output"]) <= 1501


def test_parse_service_without_version_fields_none():
    xml = ('<nmaprun><host><address addr="10.0.0.3" addrtype="ipv4"/><ports>'
           '<port protocol="tcp" portid="139"><state state="open"/>'
           '<service name="netbios-ssn"/></port></ports></host></nmaprun>')
    f = parse_nmap_xml(xml)[0]
    assert f["service"] == "netbios-ssn"
    assert f["product"] is None and f["version"] is None
    assert f["cpe"] is None and f["cpes"] == []
