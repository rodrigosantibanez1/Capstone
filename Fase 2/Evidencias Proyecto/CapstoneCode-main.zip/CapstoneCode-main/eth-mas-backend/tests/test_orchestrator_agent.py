"""
Tests del Bloque A — helpers puros del Orquestador (sin API ni BD).

Cubren el contrato agent-as-tool del orquestador: la lista de tools que ve el
LLM, el mapeo tool_use→delegación (agente + goal + operator_directive) y la
composición determinística del operator_directive (intensidad).
"""

from __future__ import annotations

import pytest

from services.agent_base import TOOL_NAME_TO_AGENT
from services.orchestrator_agent import (
    LOCAL_READ_TOOLS,
    MODE_EXECUTE,
    MODE_PLAN,
    compose_operator_directive,
    extract_delegation,
    orchestrator_tools,
    _build_system_prompt,
    _collapse_consecutive,
    _history_to_messages,
    _summarize_worker_result,
)


def test_orchestrator_tools_has_four_workers_plus_two_reads():
    names = [t["name"] for t in orchestrator_tools()]
    # los 4 workers (agent-as-tool) + las 2 tools locales de lectura
    for worker_tool in TOOL_NAME_TO_AGENT:
        assert worker_tool in names
    for read_tool in LOCAL_READ_TOOLS:
        assert read_tool in names
    assert len(names) == len(TOOL_NAME_TO_AGENT) + len(LOCAL_READ_TOOLS)


def test_compose_directive_only_intensity_is_deterministic():
    d = compose_operator_directive(intensity="stealth")
    assert d == "Intensidad solicitada: STEALTH."
    # un único token de intensidad presente → match determinístico en ScanAgent
    assert d.lower().count("stealth") == 1
    assert "moderate" not in d.lower() and "aggressive" not in d.lower()


def test_compose_directive_none_when_empty():
    assert compose_operator_directive() is None


def test_compose_directive_includes_report_type():
    d = compose_operator_directive(report_type="technical")
    assert "technical" in d


def test_extract_delegation_maps_scan_intensity():
    d = extract_delegation("run_scan_agent", {
        "engagement_id": 5, "goal": "escaneá la web app", "intensity": "AGGRESSIVE",
    })
    assert d["agent_name"] == "ScanAgent"
    assert d["goal"] == "escaneá la web app"
    assert d["operator_directive"] == "Intensidad solicitada: AGGRESSIVE."


def test_extract_delegation_recon_has_no_directive():
    d = extract_delegation("run_recon_agent", {"engagement_id": 5, "goal": "mapeá"})
    assert d["agent_name"] == "ReconAgent"
    assert d["operator_directive"] is None


def test_extract_delegation_unknown_tool_raises():
    with pytest.raises(KeyError):
        extract_delegation("read_blackboard_state", {})


def test_system_prompt_plan_vs_execute():
    plan = _build_system_prompt(3, MODE_PLAN)
    ex = _build_system_prompt(3, MODE_EXECUTE)
    assert "engagement 3" in plan
    assert "NO ejecutes" in plan          # plan-preview no delega
    assert "MODO EJECUTAR" in ex
    # guardarraíl HITL presente en ambos modos
    assert "HITL" in plan and "HITL" in ex


def test_history_to_messages_roles_and_collapse():
    turns = [
        {"role": "operator", "content": "hola"},
        {"role": "orchestrator", "content": "plan A"},
        {"role": "orchestrator", "content": "delegué en ScanAgent"},
        {"role": "system", "content": "ignorame"},
        {"role": "operator", "content": "dale"},
    ]
    msgs = _collapse_consecutive(_history_to_messages(turns))
    assert [m["role"] for m in msgs] == ["user", "assistant", "user"]
    # los dos turnos orchestrator consecutivos se fusionan
    assert "plan A" in msgs[1]["content"] and "ScanAgent" in msgs[1]["content"]


def test_summarize_worker_result_trims_payload():
    raw = {
        "agent": "ScanAgent", "status": "completed", "pipeline_run_id": "p1",
        "result": {
            "rationale": "razoné", "findings_count": 12, "pending_hitl_ids": [],
            "artifacts": {"intensity": "STEALTH", "findings": [1, 2, 3], "agent_run_id": "r1"},
        },
    }
    s = _summarize_worker_result(raw)
    assert s["findings_count"] == 12
    assert s["artifacts"]["intensity"] == "STEALTH"
    assert "findings" not in s["artifacts"]   # payload crudo descartado
