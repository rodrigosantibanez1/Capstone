"""
Tests de los fixes de bugs de reportes/análisis/orquestador (B1-B8, 2026-06-15).
Helpers puros — sin LLM/Mongo/red. El render Jinja2, el cierre de engagement vía
run() y el flip de estado del orquestador se verifican en integración (container).
"""

from __future__ import annotations

from services.analysis_agent import (
    _severity_from_cvss,
    _max_severity,
    _canonical_technique,
    _normalize_enriched_for_doc,
)
from services.reporter_agent import (
    _parse_narrative_json,
    _clean_list,
    _strip_exec_jargon,
    _exec_risk_label,
    _exec_asset,
)
from services.pipeline_controller import PipelineController


# ── B2 · reconciliación severidad ↔ CVSS ──────────────────────────────────────

def test_severity_from_cvss_bands():
    assert _severity_from_cvss(9.8) == "critical"
    assert _severity_from_cvss(9.0) == "critical"
    assert _severity_from_cvss(7.5) == "high"
    assert _severity_from_cvss(4.0) == "medium"
    assert _severity_from_cvss(0.1) == "low"
    assert _severity_from_cvss(0.0) == "info"
    assert _severity_from_cvss(None) == "info"


def test_max_severity_never_degrades():
    # Sube cuando el CVSS lo justifica…
    assert _max_severity("medium", "critical") == "critical"
    assert _max_severity("info", "high") == "high"
    # …pero nunca baja la severidad observada.
    assert _max_severity("high", "low") == "high"
    assert _max_severity("critical", "medium") == "critical"
    assert _max_severity(None, None) == "info"


# ── B5 · técnica ATT&CK determinística ────────────────────────────────────────

def test_canonical_technique_known_ports():
    assert _canonical_technique({"evidence": {"port": 21}}) == "T1190"   # ftp
    assert _canonical_technique({"evidence": {"port": 23}}) == "T1021"   # telnet
    assert _canonical_technique({"port": 445}) == "T1021"                 # smb
    assert _canonical_technique({"evidence": {"port": 514}}) == "T1021"  # rsh
    assert _canonical_technique({"evidence": {"port": 111}}) == "T1046"  # rpcbind


def test_canonical_technique_web_tool_and_unknown():
    # Tool web sin puerto canónico → exposición de app pública.
    assert _canonical_technique({"tool": "gobuster"}) == "T1190"
    assert _canonical_technique({"tool": "nikto", "evidence": {}}) == "T1190"
    # Puerto desconocido y sin tool web → None (respeta la decisión del LLM).
    assert _canonical_technique({"evidence": {"port": 31337}}) is None
    assert _canonical_technique({"port": None}) is None


def test_canonical_technique_is_stable():
    """La misma entrada siempre da la misma técnica (la base de la estabilidad B5)."""
    f = {"evidence": {"port": 23}, "tool": "nmap"}
    assert _canonical_technique(f) == _canonical_technique(f) == "T1021"


# ── B5 (S2) · enriched_findings normalizado y determinístico para el AnalysisDoc ─

def test_normalize_enriched_overrides_technique_with_canonical():
    """La técnica del LLM se reemplaza por la canónica del puerto/servicio.
    Cierra el flip SSH/22 T1110↔T1021 que veía el operador."""
    enriched = [{"ref": "nmap|h|22|tcp", "mitre_technique": "T1110",
                 "cve_details": [{"cve_id": "CVE-X"}]}]
    findings = [{"dedup_key": "nmap|h|22|tcp", "port": 22, "tool": "nmap"}]
    out = _normalize_enriched_for_doc(enriched, findings)
    assert len(out) == 1
    assert out[0]["mitre_technique"] == "T1021"        # override canónico
    assert out[0]["cve_details"] == [{"cve_id": "CVE-X"}]  # conserva enrichment LLM


def test_normalize_enriched_full_coverage_is_deterministic():
    """Cubre TODOS los findings de origen (los omitidos por el LLM entran con
    técnica canónica) y en orden fijo → el set deja de variar entre corridas."""
    findings = [
        {"dedup_key": "nmap|h|22|tcp", "port": 22, "tool": "nmap"},
        {"dedup_key": "nikto|h|80||/x", "port": 80, "tool": "nikto"},
        {"dedup_key": "nmap|h|25|tcp", "port": 25, "tool": "nmap"},
    ]
    # El LLM sólo emitió 1 de los 3.
    enriched = [{"ref": "nmap|h|22|tcp", "mitre_technique": "T1110"}]
    out1 = _normalize_enriched_for_doc(enriched, findings)
    out2 = _normalize_enriched_for_doc(enriched, findings)
    assert [e["ref"] for e in out1] == ["nmap|h|22|tcp", "nikto|h|80||/x", "nmap|h|25|tcp"]
    assert [e["mitre_technique"] for e in out1] == ["T1021", "T1190", "T1190"]
    assert out1 == out2  # determinístico


def test_normalize_enriched_dedups_refs():
    findings = [
        {"dedup_key": "r1", "port": 22, "tool": "nmap"},
        {"dedup_key": "r1", "port": 22, "tool": "nmap"},  # duplicado
    ]
    out = _normalize_enriched_for_doc([], findings)
    assert len(out) == 1


# ── B6/B7 · narrativa: recs sin vacíos + executive_narrative separada ──────────

def test_parse_narrative_filters_empty_recommendations():
    txt = ('```json\n{"executive_summary":"e","risk_narrative":"r",'
           '"executive_narrative":"x","recommendations":["A","","  ","B",null]}\n```')
    d = _parse_narrative_json(txt, {})
    assert d["recommendations"] == ["A", "B"]


def test_parse_narrative_executive_narrative_present_and_fallback():
    # Presente → se respeta.
    txt = '```json\n{"executive_summary":"e","executive_narrative":"ejecutiva"}\n```'
    assert _parse_narrative_json(txt, {})["executive_narrative"] == "ejecutiva"
    # Ausente → cae al executive_summary (mejor que mostrar la narrativa técnica).
    txt2 = '```json\n{"executive_summary":"solo resumen","risk_narrative":"tecnica"}\n```'
    d = _parse_narrative_json(txt2, {})
    assert d["executive_narrative"] == "solo resumen"


def test_parse_narrative_executive_recommendations_fallback():
    # Si el LLM no da executive_recommendations, caen a las técnicas (luego el
    # compose les quita la jerga).
    txt = '```json\n{"executive_summary":"e","recommendations":["Parchar X","Cerrar Y"]}\n```'
    d = _parse_narrative_json(txt, {})
    assert d["executive_recommendations"] == ["Parchar X", "Cerrar Y"]


# ── B6 · _clean_list dropea None / vacíos / whitespace ────────────────────────

def test_clean_list_drops_none_and_blanks():
    assert _clean_list(["A", "", "  ", None, "B"]) == ["A", "B"]
    assert _clean_list([None, "none", "None"]) == []   # str(None) == 'None' no debe colarse
    assert _clean_list(None) == []


# ── B7 · sin jerga técnica en el ejecutivo ────────────────────────────────────

def test_strip_exec_jargon():
    s = "El FTP (vsftpd 2.3.4) tiene CVE-2011-2523 con CVSS 9.8 en el puerto 21, visto por nmap."
    out = _strip_exec_jargon(s)
    for token in ("CVE-", "CVSS", "21", "nmap", "vsftpd 2.3.4"):
        assert token not in out, (token, out)


def test_exec_risk_label_strips_technical_bits():
    item = {"title": "Puerto 21 abierto — vsftpd 2.3.4 (vsftpd 2.3.4) CVE-2011-2523",
            "severity": "critical"}
    label = _exec_risk_label(item)
    assert "Puerto" not in label and "CVE-" not in label and "2.3.4" not in label
    # No queda vacío y arranca en mayúscula.
    assert label and label[0].isupper()


def test_exec_risk_label_strips_tool_tags():
    """B7 (S1) — el tag de herramienta [Nuclei]/[Nikto] no debe llegar al ejecutivo."""
    item = {"title": "[Nuclei] PHP CGI v5./ Remote Code Execution", "severity": "high"}
    label = _exec_risk_label(item)
    assert "[" not in label and "Nuclei" not in label
    assert label == "Ejecución remota de código"   # frase de riesgo en negocio


def test_exec_risk_label_maps_service_names_to_business():
    """B7 (S1) — un título que es sólo el nombre técnico del servicio se traduce."""
    assert _exec_risk_label({"title": "Netbios-ssn"}) == "Servicio de archivos compartidos expuesto"
    assert _exec_risk_label({"title": "distccd"}) == "Servicio de compilación distribuida expuesto"
    assert _exec_risk_label({"title": "/phpMyAdmin/changelog.php"}) == "Panel de administración de base de datos expuesto"


def test_exec_asset_strips_scheme_port_path():
    """B7 (S1) — la columna Activo muestra el host limpio, no la URL cruda."""
    assert _exec_asset("http://10.42.0.10") == "10.42.0.10"
    assert _exec_asset("http://10.42.0.10:80/path?x=1") == "10.42.0.10"
    assert _exec_asset("10.42.0.10:3306") == "10.42.0.10"
    assert _exec_asset("10.42.0.10") == "10.42.0.10"
    assert _exec_asset(None) == ""


def test_strip_exec_jargon_removes_bracket_tags():
    """B7 (S1) — la red de seguridad de la narrativa también barre [Nikto]/[Nuclei]."""
    out = _strip_exec_jargon("Revisar [Nikto] el hallazgo crítico urgente")
    assert "[" not in out and "Nikto" not in out


def test_exec_risk_label_translates_web_findings():
    """B7 (S6) — mensajes nikto/nuclei (inglés) → frase de negocio en español.
    Los textos provienen del `summary` real de findings de los engagements #26/#27."""
    cases = {
        "[Nikto] Cookie PHPSESSID created without the httponly flag.":
            "Cookie de sesión sin protección (httponly)",
        "[Nikto] Apache/2.4.10 appears to be outdated (current is at least 2.4.66).":
            "Componente de software desactualizado",
        "[Nikto] Suggested security header missing: content-security-policy.":
            "Falta un encabezado de seguridad recomendado",
        "[Nikto] Configuration information may be available remotely.":
            "Posible exposición de información de configuración",
        "[Nikto] Directory indexing found.":
            "Listado de directorios habilitado",
        "[Nikto] Apache default file found.":
            "Archivo o página por defecto del servidor expuesta",
    }
    for raw, expected in cases.items():
        assert _exec_risk_label({"title": raw, "severity": "low"}) == expected, raw


def test_exec_risk_label_no_english_leftover_on_known_web_msgs():
    """Un mensaje web conocido no debe dejar la frase inglesa cruda en el ejecutivo.
    ('Cookie' y 'httponly' sí se conservan: 'Cookie' es préstamo y 'httponly' es el
    nombre del atributo.)"""
    label = _exec_risk_label(
        {"title": "[Nikto] Cookie PHPSESSID created without the httponly flag."}
    ).lower()
    for english in ("without", "created", "flag", "missing"):
        assert english not in label


# ── B1 · guard de cierre de engagement ────────────────────────────────────────

def test_is_full_assessment_guard():
    # Single-stage suelto o report-only → NO completa el engagement.
    assert PipelineController(1, None, stages=["ReporterAgent"])._is_full_assessment() is False
    assert PipelineController(1, None, stages=["AnalysisAgent"])._is_full_assessment() is False
    assert PipelineController(1, None, stages=["ScanAgent"])._is_full_assessment() is False
    # Pipeline real (≥2 stages con scan/análisis) → sí completa.
    assert PipelineController(1, None, stages=["AnalysisAgent", "ReporterAgent"])._is_full_assessment() is True
    assert PipelineController(
        1, None, stages=["ReconAgent", "ScanAgent", "AnalysisAgent", "ReporterAgent"]
    )._is_full_assessment() is True
