"""
Tests del ReporterAgent (Bloque C) — helpers puros, sin LLM/Mongo/WeasyPrint.

El render Jinja2/WeasyPrint se verifica en integración (container). Acá: armado
del contexto del template, parsing de la narrativa y fallback determinístico.
"""

from __future__ import annotations

import json

from services.reporter_agent import _compose_context, _parse_narrative_json, _fallback_narrative


_FINDINGS = [
    {"dedup_key": "nmap|10.42.0.10|21|tcp", "summary": "FTP vsftpd 2.3.4", "severity": "critical",
     "target": "10.42.0.10", "port": 21, "service": "ftp",
     "cve_ids": ["CVE-2011-2523"], "cvss_score": 9.8, "mitre_technique": "T1210"},
    {"dedup_key": "nmap|10.42.0.10|80|tcp", "summary": "HTTP Apache", "severity": "medium",
     "target": "10.42.0.10", "port": 80, "service": "http", "cve_ids": [], "cvss_score": None},
    {"dedup_key": "gob|10.42.0.10|/test", "summary": "ruta /test", "severity": "low",
     "target": "10.42.0.10"},
]
_ANALYSIS = {
    "summary": "Riesgo crítico por vsftpd backdoor.",
    "attack_vectors": [{"name": "FTP backdoor", "steps": ["conectar 6200"], "severity": "critical"}],
    "priority_order": ["nmap|10.42.0.10|21|tcp", "nmap|10.42.0.10|80|tcp"],
}
_ENG = {"id": 20, "name": "Lab", "client_name": None, "status": "running", "scope": ["10.42.0.10"],
        "generated_at": "2026-06-01 19:00 UTC"}


def test_compose_context_groups_and_stats():
    ctx = _compose_context(_ENG, _FINDINGS, _ANALYSIS, _fallback_narrative(_ANALYSIS))
    assert ctx["stats"]["total"] == 3
    assert ctx["stats"]["by_severity"]["critical"] == 1
    assert ctx["stats"]["by_severity"]["medium"] == 1
    # grupos en orden de severidad
    sevs = [g["severity"] for g in ctx["findings_by_severity"]]
    assert sevs == ["critical", "high", "medium", "low", "info"]
    crit = [g for g in ctx["findings_by_severity"] if g["severity"] == "critical"][0]
    assert crit["findings"][0]["cve_ids"] == ["CVE-2011-2523"]


def test_compose_context_top_risks_from_priority_order():
    ctx = _compose_context(_ENG, _FINDINGS, _ANALYSIS, _fallback_narrative(_ANALYSIS))
    refs = [r["ref"] for r in ctx["top_risks"]]
    assert refs[0] == "nmap|10.42.0.10|21|tcp"   # respeta priority_order
    assert len(ctx["top_risks"]) <= 3


def test_compose_context_top_risks_fallback_by_severity():
    analysis_no_prio = {"summary": "x", "attack_vectors": [], "priority_order": []}
    ctx = _compose_context(_ENG, _FINDINGS, analysis_no_prio, _fallback_narrative(analysis_no_prio))
    # sin priority_order → ordena por severidad: critical primero
    assert ctx["top_risks"][0]["severity"] == "critical"


def test_compose_context_passes_attack_vectors():
    ctx = _compose_context(_ENG, _FINDINGS, _ANALYSIS, {})
    assert ctx["attack_vectors"][0]["name"] == "FTP backdoor"


# ── narrativa ─────────────────────────────────────────────────────────────────

def test_parse_narrative_fenced():
    payload = {"executive_summary": "Resumen.", "risk_narrative": "Detalle.",
               "recommendations": ["Parchear FTP"]}
    out = _parse_narrative_json(f"```json\n{json.dumps(payload)}\n```", _ANALYSIS)
    assert out["executive_summary"] == "Resumen."
    assert out["recommendations"] == ["Parchear FTP"]


def test_parse_narrative_invalid_falls_back_to_analysis():
    out = _parse_narrative_json("no json", _ANALYSIS)
    assert out["executive_summary"] == _ANALYSIS["summary"]
    assert isinstance(out["recommendations"], list) and out["recommendations"]


def test_parse_narrative_fills_defaults():
    out = _parse_narrative_json('```json\n{"executive_summary":"solo eso"}\n```', _ANALYSIS)
    assert out["risk_narrative"] == ""
    assert out["recommendations"] == []


def test_fallback_narrative_uses_summary():
    out = _fallback_narrative({"summary": "mi resumen"})
    assert out["executive_summary"] == "mi resumen"
    assert len(out["recommendations"]) >= 1
