"""
Tests para routers/reports.py — helper _content_disposition().

Regresión 2026-06-26: la descarga de un reporte con nombre personalizado
(separador em-dash ' — ', U+2014, y acentos) devolvía 500 porque el header
Content-Disposition se codifica en latin-1 y el em-dash no es latin-1
(UnicodeEncodeError). El helper arma un header RFC 6266 seguro.
"""

from __future__ import annotations

from routers.reports import _content_disposition


def test_header_es_latin1_codificable_con_emdash():
    # La aserción clave de la regresión: el header DEBE poder codificarse en
    # latin-1 sin romper (es lo que hace Starlette/uvicorn al enviarlo).
    disp = _content_disposition("Defensa Capstone — Técnico.pdf")
    disp.encode("latin-1")  # no debe levantar UnicodeEncodeError


def test_incluye_fallback_ascii_y_utf8():
    disp = _content_disposition("Auditoría ACME — Ejecutivo.pdf")
    assert 'filename="' in disp
    assert "filename*=UTF-8''" in disp
    # El fallback ASCII no debe contener el em-dash ni los acentos.
    ascii_part = disp.split('filename="')[1].split('"')[0]
    ascii_part.encode("ascii")  # no debe levantar
    assert "—" not in ascii_part


def test_nombre_solo_no_ascii_cae_al_fallback():
    # Si al quitar lo no-ASCII no queda NADA, usa el fallback provisto.
    disp = _content_disposition("———", fallback="eng_9_report.pdf")
    assert 'filename="eng_9_report.pdf"' in disp
    disp.encode("latin-1")


def test_nombre_ascii_se_preserva():
    disp = _content_disposition("eng_37_technical.pdf")
    assert 'filename="eng_37_technical.pdf"' in disp
