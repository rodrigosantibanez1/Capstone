"""
Tests del ScanAgent (Bloque D) a nivel decisión — host, sin LLM/Mongo/red.

Verifican el criterio de aceptación clave "STEALTH vs AGGRESSIVE ⇒ timing
distinto, decisión observable" directamente sobre el agente:
  - _resolve_policy lee ROE.scan_intensity,
  - operator_directive puede overridear la intensidad,
  - el system prompt refleja el timing/severidad de la política (lo que el
    modelo recibe → lo que termina viajando en cada tool_call).

ScanAgent se construye con db=None: estos métodos no tocan la BD.
"""

from __future__ import annotations

from schemas import ROE
from services.agent_base import AgentContext, ScopeItem
from services.scan_agent import ScanAgent


def _ctx(intensity: str, directive: str | None = None) -> AgentContext:
    return AgentContext(
        engagement_id=99,
        goal="Enumerar y caracterizar la superficie autorizada.",
        scope=[ScopeItem(target_value="10.42.0.10", target_type="ip")],
        roe=ROE(scan_intensity=intensity),
        operator_directive=directive,
    )


def _agent() -> ScanAgent:
    return ScanAgent(engagement_id=99, db=None)


def test_resolve_policy_reads_roe_intensity():
    agent = _agent()
    assert agent._resolve_policy(_ctx("STEALTH")).timing == 2
    assert agent._resolve_policy(_ctx("MODERATE")).timing == 3
    assert agent._resolve_policy(_ctx("AGGRESSIVE")).timing == 4


def test_stealth_vs_aggressive_yield_different_timing_at_agent_level():
    agent = _agent()
    stealth = agent._resolve_policy(_ctx("STEALTH"))
    aggressive = agent._resolve_policy(_ctx("AGGRESSIVE"))
    assert stealth.timing != aggressive.timing


def test_operator_directive_overrides_roe_intensity():
    agent = _agent()
    # ROE dice MODERATE pero el operador pide "modo sigiloso".
    pol = agent._resolve_policy(_ctx("MODERATE", directive="por favor en modo sigiloso"))
    assert pol.intensity == "STEALTH"
    # "agresivo" también overridea.
    pol2 = agent._resolve_policy(_ctx("STEALTH", directive="hacelo agresivo, hay poco tiempo"))
    assert pol2.intensity == "AGGRESSIVE"


def test_system_prompt_reflects_intensity_timing():
    agent = _agent()
    targets = ["10.42.0.10"]
    stealth_pol = agent._resolve_policy(_ctx("STEALTH"))
    aggr_pol = agent._resolve_policy(_ctx("AGGRESSIVE"))

    p_stealth = agent._build_system_prompt(_ctx("STEALTH"), targets, stealth_pol)
    p_aggr = agent._build_system_prompt(_ctx("AGGRESSIVE"), targets, aggr_pol)

    assert "timing=2" in p_stealth
    assert "timing=4" in p_aggr
    # En STEALTH el prompt prohíbe NSE/timing alto; en AGGRESSIVE lo habilita.
    assert "NO uses scripts NSE" in p_stealth
    assert "scripts NSE" in p_aggr and "NO uses scripts NSE" not in p_aggr


def test_rationale_mentions_intensity_decision():
    agent = _agent()
    pol = agent._resolve_policy(_ctx("AGGRESSIVE"))
    r = agent._build_rationale(pol, "completed", [], "fin de turno", None)
    assert "AGGRESSIVE" in r
    assert "timing 4" in r
    assert r.strip() != ""
