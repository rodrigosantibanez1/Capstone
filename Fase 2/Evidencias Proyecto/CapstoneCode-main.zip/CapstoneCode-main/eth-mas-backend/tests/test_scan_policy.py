"""
Tests de services/scan_policy.py (Bloque D) — helpers puros, sin Mongo/LLM/red.

Cubren los criterios de aceptación verificables sin Opus:
  - intensity_policy: STEALTH vs AGGRESSIVE producen timing distinto (decisión
    observable y determinista),
  - normalización tolerante (None/desconocido → MODERATE),
  - tool_signature estable / sensible a params relevantes,
  - signatures_from_tool_calls: reconstruye lo ya ejecutado y EXCLUYE las
    tool-calls que quedaron en waiting_hitl (para que el resume re-emita la
    tool recién aprobada).
"""

from __future__ import annotations

from services.scan_policy import (
    ScanPolicy,
    intensity_policy,
    normalize_intensity,
    severity_at_or_below,
    signatures_from_tool_calls,
    tool_signature,
)


# ── intensity_policy ──────────────────────────────────────────────────────────

def test_stealth_vs_aggressive_differ_in_timing():
    stealth = intensity_policy("STEALTH")
    aggressive = intensity_policy("AGGRESSIVE")
    assert stealth.timing != aggressive.timing
    assert stealth.timing == 2
    assert aggressive.timing == 4
    # AGGRESSIVE escala a HIGH en el MCP (timing>=4) — es la decisión esperada.
    assert aggressive.timing >= 4
    assert stealth.timing < 4


def test_moderate_is_t3_and_default():
    assert intensity_policy("MODERATE").timing == 3
    # None y strings desconocidos caen a MODERATE (default seguro).
    assert intensity_policy(None).timing == 3
    assert intensity_policy("banana").intensity == "MODERATE"


def test_normalize_intensity_is_case_insensitive():
    assert normalize_intensity("stealth") == "STEALTH"
    assert normalize_intensity("  Aggressive ") == "AGGRESSIVE"
    assert normalize_intensity("") == "MODERATE"


def test_policy_bands_are_monotonic():
    s, m, a = (intensity_policy(x) for x in ("STEALTH", "MODERATE", "AGGRESSIVE"))
    assert s.timing <= m.timing <= a.timing
    assert s.allow_nse is False and m.allow_nse is False
    assert a.allow_nse is True
    assert isinstance(s, ScanPolicy)


def test_severity_at_or_below():
    assert severity_at_or_below("medium") == ["info", "low", "medium"]
    assert severity_at_or_below("critical")[-1] == "critical"
    # tolerante a basura → cae a 'high'
    assert severity_at_or_below("???") == ["info", "low", "medium", "high"]


# ── tool_signature ────────────────────────────────────────────────────────────

def test_tool_signature_stable_and_target_case_insensitive():
    a = tool_signature("nmap_scan", {"target": "10.42.0.10", "ports": "1-1024", "timing": 3})
    b = tool_signature("nmap_scan", {"timing": 3, "ports": "1-1024", "target": "10.42.0.10"})
    c = tool_signature("nmap_scan", {"target": "10.42.0.10", "ports": "1-1024", "timing": 4})
    assert a == b          # orden de claves no importa
    assert a != c          # timing distinto ⇒ firma distinta


def test_tool_signature_distinguishes_tools_and_modes():
    g_dir = tool_signature("gobuster_run", {"target": "x", "mode": "dir"})
    g_dns = tool_signature("gobuster_run", {"target": "x", "mode": "dns"})
    assert g_dir != g_dns


# ── signatures_from_tool_calls ────────────────────────────────────────────────

def test_signatures_reconstruct_executed_work():
    tool_calls = [
        {"tool": "nmap_scan", "target": "10.42.0.10",
         "params": {"target": "10.42.0.10", "ports": "1-1024", "timing": 3},
         "status": "completed"},
        {"tool": "gobuster_run", "target": "10.42.0.10",
         "params": {"target": "10.42.0.10", "mode": "dir"},
         "status": "completed"},  # 0 findings pero ejecutada: debe contar
    ]
    sigs = signatures_from_tool_calls(tool_calls)
    assert tool_signature("nmap_scan", {"target": "10.42.0.10", "ports": "1-1024", "timing": 3}) in sigs
    assert tool_signature("gobuster_run", {"target": "10.42.0.10", "mode": "dir"}) in sigs
    assert len(sigs) == 2


def test_signatures_exclude_waiting_hitl_and_running():
    tool_calls = [
        {"tool": "nmap_scan", "target": "10.42.0.10",
         "params": {"target": "10.42.0.10"}, "status": "waiting_hitl"},
        {"tool": "nikto_scan", "target": "10.42.0.10",
         "params": {"target": "10.42.0.10"}, "status": "running"},
    ]
    # Ninguna llegó a ejecutarse → set vacío (al retomar se re-emiten).
    assert signatures_from_tool_calls(tool_calls) == set()


def test_signatures_target_fallback_from_column():
    # params sin 'target' pero la columna target sí lo tiene.
    tc = [{"tool": "nmap_scan", "target": "10.42.0.20",
           "params": {"ports": "1-1024", "timing": 3}, "status": "completed"}]
    sigs = signatures_from_tool_calls(tc)
    assert tool_signature("nmap_scan", {"target": "10.42.0.20", "ports": "1-1024", "timing": 3}) in sigs


def test_signatures_tolerates_garbage():
    assert signatures_from_tool_calls([]) == set()
    assert signatures_from_tool_calls([None, {}, {"status": "completed"}]) == set()
