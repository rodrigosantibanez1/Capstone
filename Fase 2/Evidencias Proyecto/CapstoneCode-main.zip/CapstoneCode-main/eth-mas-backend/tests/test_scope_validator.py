"""
Tests para services/scope_validator.py

Cubre el contrato post-auditoría 2026-05-27 (lab-fixes):
  - IP exacta in/out scope IP
  - IP dentro de CIDR autorizado
  - CIDR contenido en CIDR autorizado (cierre H-3)
  - URL http://host:port/path → se compara por host
  - host:port → se compara por host
  - Dominio + subdominios
  - Casos negativos (fuera de scope) en cada formato
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from services.scope_validator import _extract_host, is_target_in_scope


# ── _extract_host ────────────────────────────────────────────────────────────

@pytest.mark.parametrize(
    "raw,expected",
    [
        ("10.42.0.10", "10.42.0.10"),
        ("10.42.0.10:80", "10.42.0.10"),
        ("http://10.42.0.10", "10.42.0.10"),
        ("http://10.42.0.10:80", "10.42.0.10"),
        ("http://10.42.0.10:80/admin", "10.42.0.10"),
        ("https://example.com/path?x=1", "example.com"),
        ("https://api.example.com", "api.example.com"),
        ("10.42.0.0/24", "10.42.0.0/24"),       # CIDR pasa intacto
        ("2001:db8::1", "2001:db8::1"),         # IPv6 plano
        ("[2001:db8::1]:80", "2001:db8::1"),    # IPv6 con puerto
        ("http://[2001:db8::1]:80/x", "2001:db8::1"),
        ("", ""),                                # vacío → vacío
    ],
)
def test_extract_host(raw, expected):
    assert _extract_host(raw) == expected


# ── helpers de fixture ───────────────────────────────────────────────────────

def _mk_scope(target_type: str, target_value: str):
    """Crea un objeto que se comporta como models.ScopeTarget para el caller."""
    return SimpleNamespace(target_type=target_type, target_value=target_value)


def _mk_db(scopes: list):
    """Crea un mock de Session de SQLAlchemy que devuelve `scopes` para el query."""
    db = MagicMock()
    db.query.return_value.filter.return_value.all.return_value = scopes
    return db


# ── Casos IP ─────────────────────────────────────────────────────────────────

def test_ip_in_scope_exact():
    db = _mk_db([_mk_scope("IP", "10.42.0.10")])
    assert is_target_in_scope("10.42.0.10", 1, db) is True


def test_ip_out_of_scope():
    db = _mk_db([_mk_scope("IP", "10.42.0.10")])
    assert is_target_in_scope("10.42.0.99", 1, db) is False


def test_ip_in_scope_via_url():
    """Lo que el LLM envía a nuclei_run: http://10.42.0.10:80/."""
    db = _mk_db([_mk_scope("IP", "10.42.0.10")])
    assert is_target_in_scope("http://10.42.0.10:80/", 1, db) is True


def test_ip_in_scope_via_host_port():
    """Lo que gobuster a veces recibe: 10.42.0.10:80."""
    db = _mk_db([_mk_scope("IP", "10.42.0.10")])
    assert is_target_in_scope("10.42.0.10:80", 1, db) is True


# ── Casos CIDR ───────────────────────────────────────────────────────────────

def test_ip_inside_cidr_scope():
    db = _mk_db([_mk_scope("CIDR", "10.42.0.0/24")])
    assert is_target_in_scope("10.42.0.10", 1, db) is True


def test_ip_outside_cidr_scope():
    db = _mk_db([_mk_scope("CIDR", "10.42.0.0/24")])
    assert is_target_in_scope("10.99.0.1", 1, db) is False


def test_cidr_contained_in_cidr_scope_h3():
    """H-3: scope = 10.42.0.0/24, target = 10.42.0.0/28 → contenido OK."""
    db = _mk_db([_mk_scope("CIDR", "10.42.0.0/24")])
    assert is_target_in_scope("10.42.0.0/28", 1, db) is True


def test_cidr_larger_than_scope_rejected():
    """target /16 NO está contenido en scope /24 → falso."""
    db = _mk_db([_mk_scope("CIDR", "10.42.0.0/24")])
    assert is_target_in_scope("10.42.0.0/16", 1, db) is False


def test_cidr_same_as_scope_accepted():
    """H-3: target = scope literal → permitido (subnet_of incluye igualdad)."""
    db = _mk_db([_mk_scope("CIDR", "10.42.0.0/24")])
    assert is_target_in_scope("10.42.0.0/24", 1, db) is True


def test_url_against_cidr_scope():
    db = _mk_db([_mk_scope("CIDR", "10.42.0.0/24")])
    assert is_target_in_scope("http://10.42.0.10/path", 1, db) is True


# ── Casos DOMAIN ─────────────────────────────────────────────────────────────

def test_domain_exact():
    db = _mk_db([_mk_scope("DOMAIN", "example.com")])
    assert is_target_in_scope("example.com", 1, db) is True


def test_domain_subdomain():
    db = _mk_db([_mk_scope("DOMAIN", "example.com")])
    assert is_target_in_scope("api.example.com", 1, db) is True


def test_domain_unrelated_rejected():
    db = _mk_db([_mk_scope("DOMAIN", "example.com")])
    assert is_target_in_scope("example.com.evil.test", 1, db) is False
    assert is_target_in_scope("notexample.com", 1, db) is False


def test_domain_url_form():
    db = _mk_db([_mk_scope("DOMAIN", "example.com")])
    assert is_target_in_scope("https://api.example.com/x", 1, db) is True


def test_domain_case_insensitive():
    db = _mk_db([_mk_scope("DOMAIN", "EXAMPLE.com")])
    assert is_target_in_scope("api.Example.COM", 1, db) is True


# ── Múltiples scopes ─────────────────────────────────────────────────────────

def test_multiple_scopes_any_match():
    db = _mk_db([
        _mk_scope("IP", "10.42.0.10"),
        _mk_scope("DOMAIN", "example.com"),
    ])
    assert is_target_in_scope("10.42.0.10", 1, db) is True
    assert is_target_in_scope("api.example.com", 1, db) is True
    assert is_target_in_scope("8.8.8.8", 1, db) is False


def test_empty_scope_rejects_everything():
    db = _mk_db([])
    assert is_target_in_scope("10.42.0.10", 1, db) is False
