"""
utils.py — utilidades transversales del backend ETH-MAS.

Mantener este módulo libre de dependencias internas (no importar de models,
schemas, services, ...) para que sea seguro importarlo desde cualquier capa
sin riesgo de import cycles.
"""

from __future__ import annotations

from datetime import datetime, timezone


def utc_now() -> datetime:
    """
    Reemplazo de `datetime.utcnow()` (deprecado desde Python 3.12).

    Devuelve un datetime TZ-naive en UTC, compatible con las columnas
    SQLAlchemy `DateTime` (sin `timezone=True`) ya existentes en el schema.
    BSON serializa Date como UTC también, así que es seguro para MongoDB.

    Fix B-3 auditoría 2026-05-19.
    """
    return datetime.now(timezone.utc).replace(tzinfo=None)
