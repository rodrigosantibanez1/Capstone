// App.jsx — Shell + routing (Fase 2 React Router).
//
// Estructura:
//   <BrowserRouter>
//     <TooltipProvider>
//       <Sidebar /> + <TopBar /> + <main><Routes/></main>
//       <ApiKeyModal /> + <Toaster />
//
// Cada ruta carga su vista vía lazy() → code splitting automático por Vite.
// El warning de chunks >500 KB desaparece.

import { useState, useEffect, lazy, Suspense } from 'react'
import {
  BrowserRouter, Routes, Route, NavLink, useLocation, useNavigate,
} from 'react-router-dom'
import {
  LogOut, Settings, AlertTriangle, Circle,
  LayoutDashboard, Folder, Plus, Zap, Activity,
} from 'lucide-react'

import { apiEvents, API_BASE } from '@/lib/api'
import { ROUTES, NAV_DEFINITION } from '@/lib/routes'
import useHitlPending from '@/hooks/useHitlPending'
import HitlAlert      from '@/components/HitlAlert'
import ApiKeyModal    from '@/components/ApiKeyModal'

import { Button }    from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip'
import { Toaster } from '@/components/ui/sonner'
import { cn }      from '@/lib/utils'

// ─── Vistas — lazy load por ruta ──────────────────────────────────────────────
// Code splitting: cada vista es un chunk separado, solo se carga al navegar.

import LoginView                 from './views/LoginView'   // eager: rare path
const HomeView                   = lazy(() => import('./views/HomeView'))
const EngagementWorkspaceView    = lazy(() => import('./views/EngagementWorkspaceView'))
const EngagementSetupView        = lazy(() => import('./views/EngagementSetupView'))
const HitlConsoleView            = lazy(() => import('./views/HitlConsoleView'))
const AgentRunsView              = lazy(() => import('./views/AgentRunsView'))

// Mapa de iconos por id de nav (separado del routes.js que es serializable).
const NAV_ICONS = {
  home:          LayoutDashboard,
  workspace:     Folder,
  newEngagement: Plus,
  hitl:          Zap,
  agentRuns:     Activity,
}

// ─── HealthBar ───────────────────────────────────────────────────────────────
// Pollea /health/services cada 10s, muestra punto+tooltip por servicio.

const SERVICE_LABELS = {
  postgres:     'PostgreSQL',
  mongo:        'MongoDB',
  osint_mcp:    'MCP OSINT',
  security_mcp: 'MCP Security',
  anthropic:    'Anthropic API',
}
const SERVICE_SHORT = {
  postgres: 'pg', mongo: 'mongo', osint_mcp: 'osint',
  security_mcp: 'sec', anthropic: 'claude',
}

function statusClasses(status) {
  if (status === 'up')       return 'text-success'
  if (status === 'degraded') return 'text-warning'
  return 'text-destructive'
}

function HealthBar() {
  const [health, setHealth] = useState(null)
  const [error,  setError]  = useState(false)

  useEffect(() => {
    let cancelled = false
    const poll = async () => {
      try {
        const res = await fetch(`${API_BASE}/health/services`)
        if (!res.ok) throw new Error()
        const data = await res.json()
        if (!cancelled) { setHealth(data); setError(false) }
      } catch {
        if (!cancelled) setError(true)
      }
    }
    poll()
    const id = setInterval(poll, 10_000)
    return () => { cancelled = true; clearInterval(id) }
  }, [])

  if (error || !health) {
    return (
      <div title="Backend no responde a /health/services"
        className="flex items-center gap-1.5 rounded-md bg-destructive/15 px-2 py-1
                   font-mono text-xs text-destructive">
        <AlertTriangle className="size-3" />
        <span>API offline</span>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-2 rounded-md border border-border
                    bg-background px-2 py-1 font-mono text-xs">
      <Circle className={cn('size-2 fill-current', statusClasses(health.overall))} />
      <span className="mr-1 text-muted-foreground">{health.overall}</span>
      {Object.entries(health.services).map(([key, svc]) => {
        const label = SERVICE_LABELS[key] || key
        const detail = svc.detail ? ` — ${svc.detail}` : ''
        return (
          <Tooltip key={key} delayDuration={300}>
            <TooltipTrigger asChild>
              <span className="flex cursor-help items-center gap-0.5">
                <Circle className={cn('size-2 fill-current', statusClasses(svc.status))} />
                <span className="text-[10px] text-muted-foreground/80">
                  {SERVICE_SHORT[key] || key}
                </span>
              </span>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              <div className="text-xs">
                <div className="font-semibold">{label}</div>
                <div className={statusClasses(svc.status)}>{svc.status}</div>
                {svc.detail && <div className="text-muted-foreground">{detail}</div>}
                {svc.checked_at && (
                  <div className="mt-0.5 text-[10px] text-muted-foreground/70">
                    {new Date(svc.checked_at).toLocaleTimeString('es-CL', { hour12: false })}
                  </div>
                )}
              </div>
            </TooltipContent>
          </Tooltip>
        )
      })}
    </div>
  )
}

// ─── Sidebar ─────────────────────────────────────────────────────────────────

function Sidebar({ onLogout, hitlPendingCount }) {
  const location = useLocation()

  // ¿El item está activo? Match exact o startsWith según definition.
  const isActive = (item) => {
    if (item.match === 'startsWith') return location.pathname.startsWith(item.to)
    return location.pathname === item.to
  }

  return (
    <aside
      className="flex h-screen w-[220px] shrink-0 flex-col overflow-y-auto
                 border-r border-border bg-sidebar"
      aria-label="Navegación principal"
    >
      {/* Logo */}
      <div className="px-4 pt-6 pb-2">
        <div className="font-mono text-xl font-extrabold tracking-[2px] text-primary">
          ETH-MAS
        </div>
        <div className="mt-0.5 text-[11px] text-muted-foreground/70">
          v0.1 · academic prototype
        </div>
      </div>

      <Separator className="mx-4" />

      {/* Nav groups */}
      <nav className="flex-1 p-2" aria-label="Secciones">
        {NAV_DEFINITION.map((grupo) => (
          <div key={grupo.label} className="mb-2">
            <div className="px-2 pb-0.5 pt-1 text-[11px] font-semibold uppercase
                            tracking-[1px] text-muted-foreground/80">
              {grupo.label}
            </div>
            {grupo.items.map((item) => {
              const Icon = NAV_ICONS[item.id]
              const activo = isActive(item)
              const badge = item.id === 'hitl' && hitlPendingCount > 0 ? hitlPendingCount : null
              return (
                <NavLink
                  key={item.id}
                  to={item.to}
                  aria-current={activo ? 'page' : undefined}
                  className={cn(
                    'mb-px flex w-full items-center gap-2 rounded-md px-2.5 py-1.5',
                    'border-l-[3px] text-left text-sm transition-all',
                    activo
                      ? 'border-l-primary bg-primary/10 font-bold text-primary'
                      : 'border-l-transparent text-muted-foreground hover:bg-accent hover:text-foreground'
                  )}
                >
                  {Icon && <Icon className="size-4 shrink-0" aria-hidden="true" />}
                  <span className="flex-1 truncate">{item.label}</span>
                  {badge && (
                    <span className="rounded-full bg-warning px-1.5 py-px text-[10px]
                                     font-bold text-warning-foreground">
                      {badge}
                    </span>
                  )}
                </NavLink>
              )
            })}
          </div>
        ))}
      </nav>

      <Separator className="mx-4" />

      {/* Footer / Usuario */}
      <div className="p-4">
        <div className="mb-2 flex items-center gap-1.5 text-xs text-muted-foreground">
          <Circle className="size-2 fill-success text-success" />
          Sistema: Activo
        </div>
        <div className="flex items-center gap-2">
          <div className="flex size-8 shrink-0 items-center justify-center rounded-full
                          bg-primary text-sm font-bold text-primary-foreground">
            A
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-semibold text-foreground">Admin User</div>
            <div className="truncate text-[11px] text-muted-foreground/70">
              admin@eth-mas.cl
            </div>
          </div>
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            onClick={onLogout}
            aria-label="Cerrar sesión"
            title="Cerrar sesión"
          >
            <LogOut className="size-4" />
          </Button>
        </div>
      </div>
    </aside>
  )
}

// ─── Suspense fallback ───────────────────────────────────────────────────────

function RouteLoader() {
  return (
    <div className="flex h-64 items-center justify-center text-sm text-muted-foreground/70">
      <Circle className="mr-2 size-3 animate-pulse" />
      Cargando vista…
    </div>
  )
}

// ─── HitlAlert wrapper que conoce la ruta actual ─────────────────────────────

function HitlBannerSlot({ count, items }) {
  const location = useLocation()
  const navigate = useNavigate()
  return (
    <HitlAlert
      count={count}
      items={items}
      visible={!location.pathname.startsWith(ROUTES.hitl)}
      onOpen={() => navigate(ROUTES.hitl)}
    />
  )
}

// ─── Shell (dentro del Router) ───────────────────────────────────────────────

function AppShell({ onLogout, hitlCount, hitlItems }) {
  const [apiKeyOpen, setApiKeyOpen] = useState(false)
  const [authError,  setAuthError]  = useState(false)

  // Auto-open modal si llega 401
  useEffect(() => {
    const onUnauthorized = () => { setAuthError(true); setApiKeyOpen(true) }
    apiEvents.addEventListener('unauthorized', onUnauthorized)
    return () => apiEvents.removeEventListener('unauthorized', onUnauthorized)
  }, [])

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">

      <Sidebar onLogout={onLogout} hitlPendingCount={hitlCount} />

      <div className="flex flex-1 flex-col overflow-hidden">

        {/* Top bar */}
        <header className="flex shrink-0 items-center justify-end gap-3 border-b
                           border-border bg-sidebar px-10 py-2">
          <HealthBar />
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => { setAuthError(false); setApiKeyOpen(true) }}
            title="Configurar API key"
            className={cn(
              'gap-1.5 font-mono',
              authError && 'border-destructive text-destructive hover:bg-destructive/10'
            )}
          >
            {authError
              ? <AlertTriangle className="size-3.5" />
              : <Settings className="size-3.5" />}
            API Key
          </Button>
        </header>

        {/* Main scroll area */}
        <main className="flex flex-1 flex-col gap-4 overflow-y-auto p-10">
          <HitlBannerSlot count={hitlCount} items={hitlItems} />

          <Suspense fallback={<RouteLoader />}>
            <Routes>
              <Route path={ROUTES.home}          element={<HomeView />} />
              <Route path={ROUTES.engagementNew} element={<EngagementSetupView />} />
              <Route path={ROUTES.workspace}     element={<EngagementWorkspaceView />} />
              <Route path={ROUTES.workspace + '/:engagementId'}
                                                  element={<EngagementWorkspaceView />} />
              <Route path={ROUTES.hitl}          element={<HitlConsoleView />} />
              <Route path={ROUTES.agentRuns}     element={<AgentRunsView />} />
              {/* fallback */}
              <Route path="*"                    element={<HomeView />} />
            </Routes>
          </Suspense>
        </main>
      </div>

      <ApiKeyModal
        open={apiKeyOpen}
        onClose={() => setApiKeyOpen(false)}
        onAuthError={authError}
      />
      <Toaster richColors position="bottom-right" closeButton />
    </div>
  )
}

// ─── App root ────────────────────────────────────────────────────────────────

export default function App() {
  // LoginView desactivado temporalmente — no es foco del sprint académico.
  const [isLoggedIn, setIsLoggedIn] = useState(true)
  const { count: hitlCount, items: hitlItems } = useHitlPending(5000)

  if (!isLoggedIn) {
    return <LoginView onLogin={() => setIsLoggedIn(true)} />
  }

  return (
    <BrowserRouter>
      <TooltipProvider delayDuration={400} skipDelayDuration={200}>
        <AppShell
          onLogout={() => setIsLoggedIn(false)}
          hitlCount={hitlCount}
          hitlItems={hitlItems}
        />
      </TooltipProvider>
    </BrowserRouter>
  )
}
