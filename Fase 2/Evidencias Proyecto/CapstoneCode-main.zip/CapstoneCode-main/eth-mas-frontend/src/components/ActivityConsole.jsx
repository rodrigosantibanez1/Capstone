// ActivityConsole — Cuadro de actividad en vivo del pipeline.
//
// Muestra, en lenguaje simple, qué está haciendo el sistema mientras corre el
// engagement: "Recon iniciado", "Recon usando OSINT para consultar WHOIS de X",
// "Scan usando Nmap para mapear puertos de Y", etc. Las frases las genera el
// BACKEND (services/narration.py) y viajan en cada AgentRun / ToolCall, así que
// el texto es idéntico al de los reportes y al modo replay de la demo.
//
// Fuente de datos: poll de GET /engagements/{id}/agent-runs (el SSE de agent-runs
// emite solo el run más reciente y cierra al terminar — incómodo para un ticker
// continuo de los 4 agentes, así que pooleamos el listado y lo aplanamos en orden
// cronológico). Cadencia 2s, suficiente para una consola de actividad.

import { useEffect, useRef, useState, useCallback } from 'react'
import { Activity, CheckCircle2, AlertTriangle, Loader2, PauseCircle } from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

const POLL_MS = 2000
const TERMINAL_OK = new Set(['completed'])
const TERMINAL_BAD = new Set(['error', 'failed', 'scope_violation', 'hitl_rejected', 'hitl_timeout'])

function fmtMs(ms) {
  if (ms == null) return null
  if (ms < 1000) return `${ms}ms`
  return `${(ms / 1000).toFixed(1)}s`
}

// Aplana los runs (newest-first del backend) a un feed cronológico de eventos:
// una línea por arranque de agente + una línea por cada tool call.
function buildFeed(runs) {
  const feed = []
  const ordered = [...(runs || [])].sort(
    (a, b) => new Date(a.started_at || 0) - new Date(b.started_at || 0),
  )
  for (const run of ordered) {
    feed.push({
      key: `run-${run._id}`,
      kind: 'run',
      text: run.narration || `${run.agent} iniciado`,
      status: run.status,
    })
    const tools = run.tools_called || []
    tools.forEach((tc, i) => {
      // Una tool "running" con hitl_action_id está esperando aprobación humana.
      const waiting = tc.status === 'running' && tc.hitl_action_id != null
      feed.push({
        key: `tc-${run._id}-${i}`,
        kind: waiting ? 'hitl' : 'tool',
        text: tc.narration || `${tc.tool} · ${tc.target}`,
        status: tc.status,
        durationMs: tc.duration_ms,
        hitlId: tc.hitl_action_id,
      })
    })
  }
  return feed
}

function StatusDot({ status, kind }) {
  if (kind === 'hitl') {
    return <PauseCircle className="size-3.5 shrink-0 text-warning" />
  }
  if (status === 'running') {
    return <Loader2 className="size-3.5 shrink-0 animate-spin text-warning" />
  }
  if (TERMINAL_OK.has(status)) {
    return <CheckCircle2 className="size-3.5 shrink-0 text-success" />
  }
  if (TERMINAL_BAD.has(status)) {
    return <AlertTriangle className="size-3.5 shrink-0 text-destructive" />
  }
  return <span className="size-3.5 shrink-0 rounded-full border border-border" />
}

export default function ActivityConsole({ engagementId = 1, className }) {
  const [feed, setFeed] = useState([])
  const [live, setLive] = useState(false)
  const bottomRef = useRef(null)

  const poll = useCallback(async () => {
    try {
      const res = await authedFetch(`/engagements/${engagementId}/agent-runs?limit=20`)
      if (!res.ok) { setLive(false); return }
      const data = await res.json()
      setFeed(buildFeed(data.runs || []))
      setLive(true)
    } catch {
      setLive(false)
    }
  }, [engagementId])

  useEffect(() => {
    setFeed([])
    poll()
    const id = setInterval(poll, POLL_MS)
    return () => clearInterval(id)
  }, [poll])

  // Auto-scroll al último evento cuando crece el feed.
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [feed.length])

  const anyRunning = feed.some((e) => e.status === 'running')

  return (
    <Card className={cn('flex flex-col', className)}>
      <div className="flex items-center gap-2 border-b border-border px-4 py-2.5">
        <Activity className={cn('size-4', anyRunning ? 'text-warning' : 'text-muted-foreground')} />
        <span className="text-sm font-semibold text-foreground">Actividad en vivo</span>
        <span className={cn(
          'ml-auto flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider',
          live ? 'text-success' : 'text-muted-foreground/70',
        )}>
          <span className={cn(
            'size-1.5 rounded-full',
            live ? (anyRunning ? 'animate-pulse bg-warning' : 'bg-success') : 'bg-muted-foreground/40',
          )} />
          {live ? (anyRunning ? 'corriendo' : 'conectado') : 'sin conexión'}
        </span>
      </div>

      <CardContent className="flex max-h-[60vh] min-h-[200px] flex-col gap-1.5 overflow-y-auto p-3">
        {feed.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-2 py-8 text-center">
            <Activity className="size-7 text-muted-foreground/30" />
            <div className="text-xs text-muted-foreground/70">
              Sin actividad todavía. Cuando lances recon, scan, análisis o reporte,
              aquí verás paso a paso qué hace el sistema.
            </div>
          </div>
        ) : (
          feed.map((e) => (
            <div
              key={e.key}
              className={cn(
                'flex items-start gap-2 rounded-md px-2 py-1.5 text-xs leading-snug',
                e.kind === 'run' && 'bg-muted/40 font-medium text-foreground',
                e.kind === 'hitl' && 'border border-dashed border-warning/40 bg-warning/10 text-warning',
                e.kind === 'tool' && 'text-muted-foreground',
              )}
            >
              <span className="mt-0.5"><StatusDot status={e.status} kind={e.kind} /></span>
              <span className="min-w-0 flex-1 break-words">
                {e.text}
                {e.kind === 'hitl' && e.hitlId != null && (
                  <span className="ml-1 font-mono text-[10px]">(HITL #{e.hitlId} — aprueba en la consola)</span>
                )}
              </span>
              {e.durationMs != null && TERMINAL_OK.has(e.status) && (
                <span className="shrink-0 font-mono text-[10px] text-muted-foreground/60">
                  {fmtMs(e.durationMs)}
                </span>
              )}
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </CardContent>
    </Card>
  )
}
