// ApiKeyModal — Configurar la API key X-API-Key desde la UI.
// Persiste en localStorage vía lib/api.js. Al guardar emite 'apikey-changed'
// para que el resto de la app (HealthBar, polls) se refresque.
//
// Migrado a shadcn/ui Dialog + Tailwind v4 + lucide-react.

import { useState, useEffect } from 'react'
import { AlertTriangle, Check, Eye, EyeOff, KeyRound, X } from 'lucide-react'

import { getApiKey, setApiKey, API_BASE, authedFetch } from '@/lib/api'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

export default function ApiKeyModal({ open, onClose, onAuthError }) {
  const [value,   setValue]   = useState('')
  const [testing, setTesting] = useState(false)
  const [testRes, setTestRes] = useState(null)   // { ok: bool, msg: string }
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    if (open) {
      setValue(getApiKey())
      setTestRes(null)
    }
  }, [open])

  const save = () => {
    setApiKey(value)
    onClose?.()
  }

  const testKey = async () => {
    setTesting(true); setTestRes(null)
    try {
      const previous = getApiKey()
      setApiKey(value)
      try {
        const res = await authedFetch('/hitl-actions/0', { method: 'GET' })
        // 404 = key válida (endpoint existe, recurso no), 401 = key inválida
        if (res.status === 401) {
          setTestRes({ ok: false, msg: 'La key fue rechazada por el backend (401).' })
        } else {
          setTestRes({ ok: true, msg: `Conexión OK (HTTP ${res.status}).` })
        }
      } finally {
        setApiKey(previous)
      }
    } catch (e) {
      setTestRes({ ok: false, msg: `Sin conexión con ${API_BASE}: ${e.message}` })
    } finally {
      setTesting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose?.() }}>
      <DialogContent
        className={cn(
          'sm:max-w-[480px]',
          onAuthError && 'border-destructive/70 shadow-[0_0_0_1px_var(--destructive)]'
        )}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <KeyRound className="size-4 text-primary" />
            Configurar API Key
          </DialogTitle>
          <DialogDescription>
            Header{' '}
            <code className="font-mono text-primary">X-API-Key</code>
            {' '}usado en endpoints protegidos (pipeline, scan, HITL).
          </DialogDescription>
        </DialogHeader>

        {/* Auth-error banner */}
        {onAuthError && (
          <div className="flex items-start gap-2 rounded-md border border-destructive/40
            bg-destructive/10 p-3 text-sm text-destructive">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" />
            <div>
              El backend rechazó la última llamada con <code>401</code>.
              Verifica que la key coincida con{' '}
              <code className="font-mono">ETH_MAS_API_KEY</code> del backend.
            </div>
          </div>
        )}

        {/* Input */}
        <div className="space-y-1.5">
          <label htmlFor="apikey-input" className="text-sm text-muted-foreground">
            API Key
          </label>
          <div className="flex gap-1.5">
            <Input
              id="apikey-input"
              type={visible ? 'text' : 'password'}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="dev-key-insecure-change-me"
              className="flex-1 font-mono"
              autoFocus
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => setVisible(!visible)}
              title={visible ? 'Ocultar' : 'Mostrar'}
            >
              {visible ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Se guarda en <code className="font-mono">localStorage</code> del
            navegador. Si lo dejas vacío, el frontend usa la key inyectada al
            build (variable <code className="font-mono">VITE_API_KEY</code>,
            derivada de <code className="font-mono">ETH_MAS_API_KEY</code> del
            <code className="font-mono"> .env</code> del backend).
          </p>
        </div>

        {/* Test feedback */}
        {testRes && (
          <div
            className={cn(
              'flex items-start gap-2 rounded-md border p-3 text-sm font-mono',
              testRes.ok
                ? 'border-success/40 bg-success/10 text-success'
                : 'border-destructive/40 bg-destructive/10 text-destructive'
            )}
          >
            {testRes.ok
              ? <Check className="mt-0.5 size-4 shrink-0" />
              : <X className="mt-0.5 size-4 shrink-0" />}
            <div>{testRes.msg}</div>
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={testKey}
            disabled={testing || !value}
          >
            {testing ? 'Probando…' : 'Probar conexión'}
          </Button>
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancelar
          </Button>
          <Button type="button" onClick={save}>
            Guardar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
