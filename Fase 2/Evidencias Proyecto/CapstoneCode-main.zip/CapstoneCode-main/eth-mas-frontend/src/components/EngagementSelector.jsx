// EngagementSelector — Dropdown para elegir engagement activo.
// Pollea /engagements y muestra cada uno con su status badge.
//
// Props:
//   value          : number   ID del engagement seleccionado
//   onChange       : (id, engagementObj) => void
//   onCreateNew    : () => void   (opcional) — callback al click "Nuevo"
//   autoSelectFirst: boolean  (default false) — si true y no hay value, elige
//                    el primero automáticamente. Apagado por defecto: el
//                    auto-abrir del "último engagement" confundía al operador
//                    (elección explícita > implícita).
//
// Migrado a Tailwind v4 + shadcn DropdownMenu + lucide-react.

import { useState, useEffect } from 'react'
import {
  ChevronDown, Plus, AlertTriangle,
  CirclePlay, Circle, Pause, CheckCircle2, XCircle,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const STATUS_META = {
  pending:   { color: 'text-info',          Icon: Circle },
  running:   { color: 'text-warning',       Icon: CirclePlay },
  paused:    { color: 'text-muted-foreground/60', Icon: Pause },
  completed: { color: 'text-success',       Icon: CheckCircle2 },
  aborted:   { color: 'text-destructive',   Icon: XCircle },
}

export default function EngagementSelector({ value, onChange, onCreateNew, autoSelectFirst = false }) {
  const [list,    setList]    = useState([])
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState(null)

  const fetchAll = async () => {
    setLoading(true); setError(null)
    try {
      const res = await authedFetch('/engagements')
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      setList(await res.json())
    } catch (e) {
      setError(e.message || 'Error')
      setList([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchAll() }, [])

  // Si no hay value pero ya cargó, auto-selecciona el primero — SOLO si el
  // caller lo pide explícitamente (autoSelectFirst). Por defecto no, para que
  // el operador elija a mano y nada se "abra solo".
  useEffect(() => {
    if (autoSelectFirst && !loading && list.length > 0 && !value) {
      onChange?.(list[0].id, list[0])
    }
  }, [autoSelectFirst, loading, list, value, onChange])

  const selected = list.find((e) => e.id === value)
  const selMeta  = STATUS_META[selected?.status] || STATUS_META.pending
  const SelIcon  = selMeta.Icon

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className="min-w-[280px] justify-start gap-2 h-auto py-2"
        >
          {loading ? (
            <span className="text-muted-foreground/70">Cargando engagements…</span>
          ) : error ? (
            <>
              <AlertTriangle className="size-4 text-destructive" />
              <span className="text-destructive">{error}</span>
            </>
          ) : selected ? (
            <>
              <SelIcon className={cn('size-4 shrink-0', selMeta.color)} />
              <div className="min-w-0 flex-1 text-left">
                <div className="truncate text-sm font-semibold text-foreground">
                  {selected.name}
                </div>
                <div className="truncate font-mono text-[11px] text-muted-foreground/70">
                  #{selected.id} · {selected.status}
                  {selected.client_name && ` · ${selected.client_name}`}
                </div>
              </div>
            </>
          ) : (
            <span className="text-muted-foreground/70">Sin engagements creados</span>
          )}
          <ChevronDown className="ml-auto size-3.5 text-muted-foreground/70" />
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent
        align="end"
        className="w-[var(--radix-dropdown-menu-trigger-width)] max-h-80 overflow-y-auto"
      >
        <DropdownMenuLabel className="text-[11px] uppercase tracking-wider text-muted-foreground/70">
          Engagements ({list.length})
        </DropdownMenuLabel>
        <DropdownMenuSeparator />

        {list.length === 0 ? (
          <div className="px-3 py-4 text-center text-sm text-muted-foreground/70">
            No hay engagements creados aún.
          </div>
        ) : (
          list.map((e) => {
            const meta = STATUS_META[e.status] || STATUS_META.pending
            const Icon = meta.Icon
            const sel  = e.id === value
            return (
              <DropdownMenuItem
                key={e.id}
                onSelect={() => onChange?.(e.id, e)}
                className={cn(
                  'flex items-center gap-2 cursor-pointer',
                  sel && 'bg-primary/10 focus:bg-primary/15'
                )}
              >
                <Icon className={cn('size-4 shrink-0', meta.color)} />
                <div className="min-w-0 flex-1">
                  <div className={cn(
                    'truncate text-sm',
                    sel ? 'font-bold text-primary' : 'font-medium text-foreground'
                  )}>
                    {e.name}
                  </div>
                  <div className="font-mono text-[11px] text-muted-foreground/70">
                    #{e.id} · {e.status}
                    {e.scope_count != null && ` · ${e.scope_count} target${e.scope_count !== 1 ? 's' : ''}`}
                  </div>
                </div>
              </DropdownMenuItem>
            )
          })
        )}

        {onCreateNew && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onSelect={() => onCreateNew()}
              className="cursor-pointer text-primary focus:bg-primary/10 focus:text-primary"
            >
              <Plus className="size-4" />
              Nuevo engagement
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
