// HitlAlert — Banner global fijo (top) cuando hay acciones HITL pendientes.
// Se muestra en cualquier vista que NO sea la consola HITL, para que el
// operador no pierda solicitudes mientras navega por el resto del dashboard.
//
// Migrado a Tailwind v4 + shadcn Button + lucide-react.
//
// Props:
//   count    : number   cantidad de pendientes
//   items    : array    lista de acciones (usa primer item para preview)
//   visible  : bool     si es false (ej. usuario ya está en HitlView), oculta
//   onOpen   : fn       callback al click "Ver consola"

import { Zap, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function HitlAlert({ count, items, visible, onOpen }) {
  if (!visible || count <= 0) return null

  const first = items?.[0]
  const more  = count - 1

  return (
    <div
      role="alert"
      aria-live="polite"
      className="flex items-center gap-3 rounded-md border border-warning/40
                 border-l-4 border-l-warning bg-warning/10
                 px-4 py-2 animate-[pulse-warn_2s_ease-in-out_infinite]"
    >
      {/* Keyframes inline — alcance local del banner */}
      <style>{`
        @keyframes pulse-warn {
          0%, 100% { box-shadow: 0 0 0 0 rgba(245,158,11,0); }
          50%      { box-shadow: 0 0 0 6px rgba(245,158,11,0.15); }
        }
      `}</style>

      <Zap className="size-5 shrink-0 text-warning" aria-hidden="true" />

      <div className="min-w-0 flex-1">
        <div className="text-sm font-bold text-warning">
          {count} acción HITL pendiente{count !== 1 ? 's' : ''} de aprobación
        </div>
        {first && (
          <div className="truncate font-mono text-xs text-muted-foreground">
            {first.agent} → {first.tool}
            {first.params?.target ? ` · ${first.params.target}` : ''}
            {first.risk_level ? ` · ${first.risk_level}` : ''}
            {more > 0 && (
              <span className="text-muted-foreground/70"> · +{more} más</span>
            )}
          </div>
        )}
      </div>

      <Button
        type="button"
        onClick={onOpen}
        size="sm"
        className="bg-warning text-warning-foreground hover:bg-warning/90 shrink-0"
      >
        Ver consola
        <ArrowRight className="size-4" />
      </Button>
    </div>
  )
}
