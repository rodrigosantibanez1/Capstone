// RoeBuilder — Editor de Rules of Engagement (ROE) con UI visual.
//
// Props:
//   value     : ROE object (schema §4.5 CLAUDE.md)
//   onChange  : (newRoe) => void
//   mode      : 'edit' | 'view'   (default: 'edit'; view = read-only)
//
// Tabs: "Visual" (form) y "JSON avanzado" (textarea). Sync bidireccional.
//
// Migrado a Tailwind v4 + shadcn (Tabs, Input, Textarea, Slider, Button) + lucide-react.

import { useState, useEffect } from 'react'
import { X, Check, AlertCircle } from 'lucide-react'

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Slider } from '@/components/ui/slider'
import { cn } from '@/lib/utils'

// ─── Defaults y constantes ────────────────────────────────────────────────────

export const DEFAULT_ROE = {
  scan_intensity: 'MODERATE',
  excluded_paths: [],
  max_requests_per_second: 50,
  auto_approve_hitl_below: 'MEDIUM',
  notification_email: null,
}

const INTENSITY_OPTS = [
  { id: 'STEALTH',    label: 'Stealth',    desc: 'nmap T1-T2', activeClass: 'data-[active=true]:bg-info/20    data-[active=true]:text-info'    },
  { id: 'MODERATE',   label: 'Moderate',   desc: 'nmap T3',    activeClass: 'data-[active=true]:bg-success/20 data-[active=true]:text-success' },
  { id: 'AGGRESSIVE', label: 'Aggressive', desc: 'nmap T4-T5', activeClass: 'data-[active=true]:bg-destructive/20 data-[active=true]:text-destructive' },
]

const HITL_OPTS = [
  { id: 'LOW',    label: 'LOW (solo lectura)', activeClass: 'data-[active=true]:bg-info/20    data-[active=true]:text-info' },
  { id: 'MEDIUM', label: 'MEDIUM (activos)',   activeClass: 'data-[active=true]:bg-warning/20 data-[active=true]:text-warning' },
]

// ─── Helpers ──────────────────────────────────────────────────────────────────

function normalizeRoe(raw) {
  if (!raw || typeof raw !== 'object') return { ...DEFAULT_ROE }
  // time_windows quedó deprecado (S4): la ejecución es al iniciar el pipeline.
  // Se descarta si viene de un engagement legacy.
  const { time_windows: _legacyTimeWindows, ...rest } = raw
  return { ...DEFAULT_ROE, ...rest }
}

// ─── Subcomponentes ───────────────────────────────────────────────────────────

function Section({ title, hint, children }) {
  return (
    <div>
      <div className="mb-0.5 text-sm font-semibold text-foreground">{title}</div>
      {hint && (
        <div className="mb-2 text-xs text-muted-foreground/70">{hint}</div>
      )}
      {children}
    </div>
  )
}

function SegmentedControl({ options, value, onChange, disabled }) {
  return (
    <div className="inline-flex gap-0.5 rounded-md border border-border bg-background p-0.5">
      {options.map((o) => {
        const sel = o.id === value
        return (
          <button
            key={o.id}
            type="button"
            disabled={disabled}
            data-active={sel}
            onClick={() => onChange?.(o.id)}
            title={o.desc}
            className={cn(
              'rounded-sm px-3.5 py-1.5 text-sm transition-colors',
              'font-medium text-muted-foreground',
              'data-[active=true]:font-bold',
              'hover:text-foreground',
              disabled && 'cursor-default opacity-60',
              o.activeClass,
            )}
          >
            {o.label}
            {o.desc && (
              <span className="ml-1.5 text-[10px] opacity-60">{o.desc}</span>
            )}
          </button>
        )
      })}
    </div>
  )
}

// ─── Componente principal ─────────────────────────────────────────────────────

export default function RoeBuilder({ value, onChange, mode = 'edit' }) {
  const isView = mode === 'view'
  const [roe,  setRoe]  = useState(() => normalizeRoe(value))
  const [tab,  setTab]  = useState('visual')
  const [json, setJson] = useState(() => JSON.stringify(normalizeRoe(value), null, 2))
  const [jsonError, setJsonError] = useState('')
  const [excludedInput, setExcludedInput] = useState('')

  useEffect(() => {
    if (!value) return
    const norm = normalizeRoe(value)
    setRoe(norm)
    setJson(JSON.stringify(norm, null, 2))
  }, [value])

  const update = (patch) => {
    if (isView) return
    const next = { ...roe, ...patch }
    setRoe(next)
    setJson(JSON.stringify(next, null, 2))
    onChange?.(next)
  }

  // ── Excluded paths ───────────────────────────────────────────────────────
  const addExcluded = () => {
    const v = excludedInput.trim().replace(/^,$/, '')
    if (!v) return
    if (roe.excluded_paths.includes(v)) { setExcludedInput(''); return }
    update({ excluded_paths: [...roe.excluded_paths, v] })
    setExcludedInput('')
  }

  const removeExcluded = (p) => update({
    excluded_paths: roe.excluded_paths.filter((x) => x !== p),
  })

  // ── JSON tab ─────────────────────────────────────────────────────────────
  const onJsonChange = (val) => {
    setJson(val)
    try {
      const parsed = JSON.parse(val)
      setJsonError('')
      setRoe(parsed)
      onChange?.(parsed)
    } catch (e) {
      setJsonError(e.message)
    }
  }

  // ─── Render ──────────────────────────────────────────────────────────────

  // Modo view: solo render del bloque visual sin tabs
  if (isView) {
    return <VisualForm
      roe={roe} isView
      excludedInput={excludedInput} setExcludedInput={setExcludedInput}
      addExcluded={addExcluded} removeExcluded={removeExcluded}
      update={update}
    />
  }

  return (
    <Tabs value={tab} onValueChange={setTab}>
      <TabsList className="mb-4">
        <TabsTrigger value="visual">Visual</TabsTrigger>
        <TabsTrigger value="json">JSON avanzado</TabsTrigger>
      </TabsList>

      <TabsContent value="visual" className="mt-0">
        <VisualForm
          roe={roe} isView={false}
          excludedInput={excludedInput} setExcludedInput={setExcludedInput}
          addExcluded={addExcluded} removeExcluded={removeExcluded}
          update={update}
        />
      </TabsContent>

      <TabsContent value="json" className="mt-0">
        <div>
          <div className="mb-1 text-xs text-muted-foreground/70">
            Schema validado contra el modelo Pydantic ROE del backend (§4.5 CLAUDE.md).
            Cambios aquí se reflejan en la pestaña Visual.
          </div>
          <Textarea
            value={json}
            onChange={(e) => onJsonChange(e.target.value)}
            rows={14}
            className={cn(
              'font-mono text-sm leading-relaxed resize-y',
              jsonError && 'border-destructive focus-visible:border-destructive'
            )}
          />
          {jsonError ? (
            <div className="mt-1.5 flex items-center gap-1 text-sm text-destructive">
              <AlertCircle className="size-3.5" /> {jsonError}
            </div>
          ) : (
            <div className="mt-1.5 flex items-center gap-1 text-sm text-success">
              <Check className="size-3.5" /> JSON válido
            </div>
          )}
        </div>
      </TabsContent>
    </Tabs>
  )
}

// ─── Form visual (compartido entre edit y view) ──────────────────────────────

function VisualForm({
  roe, isView,
  excludedInput, setExcludedInput, addExcluded, removeExcluded,
  update,
}) {
  return (
    <div className="flex flex-col gap-6">

      {/* Scan intensity */}
      <Section title="Intensidad de escaneo" hint="Afecta los flags timing de nmap">
        <SegmentedControl options={INTENSITY_OPTS} value={roe.scan_intensity}
          onChange={(v) => update({ scan_intensity: v })}
          disabled={isView}
        />
      </Section>

      {/* HITL auto-approve */}
      <Section title="Auto-aprobación HITL hasta"
        hint="Acciones de risk_level mayor requieren operador">
        <SegmentedControl options={HITL_OPTS} value={roe.auto_approve_hitl_below}
          onChange={(v) => update({ auto_approve_hitl_below: v })}
          disabled={isView}
        />
        <div className="mt-1.5 text-xs text-muted-foreground/70">
          HIGH y CRITICAL siempre requieren aprobación humana (no configurable).
        </div>
      </Section>

      {/* Rate limit */}
      <Section title="Límite de velocidad"
        hint="Máximo de requests por segundo aplicado en los wrappers de tools">
        <div className="flex items-center gap-3">
          <Slider
            min={1} max={200} step={1}
            value={[roe.max_requests_per_second]}
            disabled={isView}
            onValueChange={(v) => update({ max_requests_per_second: v[0] })}
            className="flex-1"
          />
          <Input type="number" min={1} max={500}
            value={roe.max_requests_per_second}
            disabled={isView}
            onChange={(e) => update({ max_requests_per_second: Number(e.target.value) })}
            className="w-20 text-right font-mono"
          />
          <span className="text-sm text-muted-foreground">req/s</span>
        </div>
      </Section>

      {/* Excluded paths */}
      <Section title="Paths excluidos" hint="Nikto y Nuclei los saltarán">
        <div className={cn(
          'flex min-h-11 flex-wrap items-center gap-1 rounded-md border px-3 py-2',
          isView ? 'border-border bg-transparent' : 'border-border bg-input'
        )}>
          {roe.excluded_paths.map((p) => (
            <span key={p}
              className="inline-flex items-center gap-1 rounded-full border border-destructive/40
                         bg-destructive/15 px-2.5 py-0.5 font-mono text-xs font-semibold text-destructive">
              {p}
              {!isView && (
                <button type="button"
                  onClick={() => removeExcluded(p)}
                  className="rounded-full transition-colors hover:bg-black/20"
                  aria-label={`Quitar ${p}`}>
                  <X className="size-2.5" />
                </button>
              )}
            </span>
          ))}
          {!isView && (
            <input value={excludedInput}
              onChange={(e) => setExcludedInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ',') {
                  e.preventDefault(); addExcluded()
                }
              }}
              onBlur={addExcluded}
              placeholder={roe.excluded_paths.length === 0 ? '/admin, /payment, /api/private…' : ''}
              className="min-w-[140px] flex-1 bg-transparent font-mono text-sm
                         text-foreground placeholder:text-muted-foreground/60 outline-none"
            />
          )}
          {isView && roe.excluded_paths.length === 0 && (
            <span className="text-sm italic text-muted-foreground/60">
              Ninguno definido
            </span>
          )}
        </div>
      </Section>

      {/* Notification email */}
      <Section title="Email de notificaciones"
        hint="Para alertas budget.exceeded (opcional)">
        <Input type="email"
          value={roe.notification_email || ''}
          disabled={isView}
          onChange={(e) => update({ notification_email: e.target.value || null })}
          placeholder="security-ops@empresa.com"
          className="w-full"
        />
      </Section>
    </div>
  )
}
