// RunDetailDrawer — drawer compartido con el timeline de un AgentRun.
// Usado por AgentRunsView (drill desde la lista) y PipelineView (drill desde
// una stage del pipeline). Auto-refresca cada 2 s si el run sigue running.
//
// Migrado a Tailwind v4 + shadcn Sheet + lucide-react.

import { useState, useEffect, useCallback } from 'react'
import {
  Play, Check, X as XIcon, Hand,        // status icons
  AlertOctagon, ShieldX, Clock, Ban,
  ChevronDown, ChevronRight,
  Terminal,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

// ─── Maps de estado ──────────────────────────────────────────────────────────
// Exportados porque PipelineView y AgentRunsView los necesitan.

export const STATUS_COLOR = {
  pending:         'text-muted-foreground',
  running:         'text-warning',
  completed:       'text-success',
  failed:          'text-destructive',
  error:           'text-destructive',
  skipped:         'text-muted-foreground/70',
  scope_violation: 'text-destructive',
  hitl_rejected:   'text-destructive',
  hitl_timeout:    'text-warning',
  aborted:         'text-destructive',
}

export const STATUS_BG = {
  pending:         'bg-muted text-muted-foreground',
  running:         'bg-warning/15 text-warning border-warning/40',
  completed:       'bg-success/15 text-success border-success/40',
  failed:          'bg-destructive/15 text-destructive border-destructive/40',
  error:           'bg-destructive/15 text-destructive border-destructive/40',
  skipped:         'bg-muted text-muted-foreground border-border',
  scope_violation: 'bg-destructive/15 text-destructive border-destructive/40',
  hitl_rejected:   'bg-destructive/15 text-destructive border-destructive/40',
  hitl_timeout:    'bg-warning/15 text-warning border-warning/40',
  aborted:         'bg-destructive/15 text-destructive border-destructive/40',
}

export const STATUS_ICON_COMPONENT = {
  pending:         Clock,
  running:         Play,
  completed:       Check,
  failed:          XIcon,
  error:           XIcon,
  skipped:         Ban,
  scope_violation: ShieldX,
  hitl_rejected:   Hand,
  hitl_timeout:    Clock,
  aborted:         AlertOctagon,
}

// Legacy compat — Unicode icons for callers that need a string
export const STATUS_ICON = {
  pending: '○', running: '▶', completed: '✓', failed: '✗', error: '✗',
  skipped: '–', scope_violation: '⛔', hitl_rejected: '✗', hitl_timeout: '⏱',
  aborted: '⛔',
}

// ─── Formatters compartidos ──────────────────────────────────────────────────

export function fmtMs(ms) {
  if (ms == null) return '—'
  if (ms < 1000) return `${ms} ms`
  return `${(ms / 1000).toFixed(1)} s`
}

export function fmtTime(iso) {
  if (!iso) return '—'
  try { return new Date(iso).toLocaleTimeString('es-CL', { hour12: false }) }
  catch { return iso }
}

export function fmtDateTime(iso) {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString('es-CL', {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    })
  } catch { return iso }
}

export function durationOf(item) {
  if (!item?.started_at) return null
  const end = item.finished_at ? new Date(item.finished_at) : new Date()
  return Math.max(0, end - new Date(item.started_at))
}

// ─── Renderer de status como badge ───────────────────────────────────────────

export function StatusBadge({ status, size = 'sm' }) {
  const Icon = STATUS_ICON_COMPONENT[status] || Clock
  return (
    <Badge
      variant="outline"
      className={cn(
        'gap-1 font-mono uppercase tracking-wider',
        size === 'sm' ? 'text-[10px]' : 'text-xs',
        STATUS_BG[status] || 'bg-muted text-muted-foreground border-border'
      )}
    >
      <Icon className={cn(size === 'sm' ? 'size-3' : 'size-3.5')} aria-hidden="true" />
      {status}
    </Badge>
  )
}

// ─── ToolCallRow ─────────────────────────────────────────────────────────────

export function ToolCallRow({ call, idx }) {
  const [open, setOpen] = useState(false)
  const StatusIconCmp = STATUS_ICON_COMPONENT[call.status] || Clock
  const colorClass = STATUS_COLOR[call.status] || 'text-muted-foreground'

  return (
    <div className="border-b border-border font-mono text-xs">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className={cn(
          'flex w-full items-center gap-2 px-3 py-2 text-left transition-colors',
          'hover:bg-accent/40',
          call.status === 'running' && 'bg-warning/5'
        )}
      >
        <span className="w-6 text-right text-muted-foreground/70">#{idx + 1}</span>
        <StatusIconCmp className={cn('size-3.5 shrink-0', colorClass)} aria-hidden="true" />
        <span className="min-w-[110px] truncate font-bold text-primary">{call.tool}</span>
        <span className="min-w-0 flex-1 truncate text-foreground">
          {call.target || <span className="text-muted-foreground/60">—</span>}
        </span>
        <span className={cn('min-w-[100px] text-[10px] uppercase tracking-wider', colorClass)}>
          {call.status}
        </span>
        <span className="min-w-[60px] text-right text-[10px] text-muted-foreground/70">
          {fmtMs(call.duration_ms)}
        </span>
        <span className="min-w-[70px] text-right text-[10px] text-muted-foreground/70">
          {fmtTime(call.started_at)}
        </span>
        {open
          ? <ChevronDown className="size-3 text-muted-foreground/70" />
          : <ChevronRight className="size-3 text-muted-foreground/70" />}
      </button>

      {open && (
        <div className="border-t border-border bg-background/60 p-3 space-y-2">
          <div className="text-[10px] text-muted-foreground/70">
            started_at: <span className="text-muted-foreground">{fmtDateTime(call.started_at)}</span>
            {call.finished_at && (
              <> · finished_at: <span className="text-muted-foreground">{fmtDateTime(call.finished_at)}</span></>
            )}
          </div>

          {call.params && Object.keys(call.params).length > 0 && (
            <div>
              <div className="mb-1 text-[10px] text-muted-foreground/70">params</div>
              <pre className="max-h-[120px] overflow-auto rounded-sm bg-terminal-bg p-2
                              text-[10px] text-info">
                {JSON.stringify(call.params, null, 2)}
              </pre>
            </div>
          )}

          {call.output_preview && (
            <div>
              <div className="mb-1 text-[10px] text-muted-foreground/70">
                output_preview (truncado 500 chars)
              </div>
              <pre className="max-h-[160px] overflow-auto whitespace-pre-wrap rounded-sm
                              bg-terminal-bg p-2 text-[10px] text-terminal">
                {call.output_preview}
              </pre>
            </div>
          )}

          {call.error && (
            <div>
              <div className="mb-1 text-[10px] text-destructive">error</div>
              <pre className="max-h-[120px] overflow-auto whitespace-pre-wrap rounded-sm
                              border border-destructive/30 bg-destructive/10 p-2
                              text-[10px] text-destructive">
                {call.error}
              </pre>
            </div>
          )}

          {call.hitl_action_id && (
            <div className="text-[10px] text-warning">
              HITL action #{call.hitl_action_id}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ─── RunDetailDrawer ─────────────────────────────────────────────────────────

export default function RunDetailDrawer({ runId, onClose }) {
  const [run,     setRun]     = useState(null)
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState(null)

  const fetchRun = useCallback(async () => {
    setLoading(true); setError(null)
    try {
      const res = await authedFetch(`/agent-runs/${runId}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      setRun(await res.json())
    } catch (e) {
      setError(e.message || 'Error')
    } finally {
      setLoading(false)
    }
  }, [runId])

  useEffect(() => { fetchRun() }, [fetchRun])

  // Auto-refresh si el run está running
  useEffect(() => {
    if (!run || run.status !== 'running') return
    const id = setInterval(fetchRun, 2000)
    return () => clearInterval(id)
  }, [run, fetchRun])

  const tools = run?.tools_called || []
  const open  = !!runId

  return (
    <Sheet open={open} onOpenChange={(o) => { if (!o) onClose?.() }}>
      <SheetContent
        side="right"
        className="w-[720px] max-w-[90vw] sm:max-w-[90vw] p-0
                   flex flex-col gap-0 bg-sidebar"
      >
        <SheetHeader className="border-b border-border p-6">
          <SheetTitle className="flex items-center gap-2">
            <span className="text-lg font-bold">{run?.agent || 'AgentRun'}</span>
            {run && <StatusBadge status={run.status} />}
          </SheetTitle>
          <SheetDescription className="truncate font-mono text-xs">
            {runId}
          </SheetDescription>
        </SheetHeader>

        {/* min-h-0 + overflow-hidden: sin esto, el hijo flex (min-height:auto)
            crece hasta el alto del contenido y el viewport de Radix nunca
            scrollea — al expandir un tool_called lo que sobra queda inalcanzable. */}
        <ScrollArea className="flex-1 min-h-0 overflow-hidden">
          <div className="flex flex-col gap-6 p-6">

            {loading && !run && (
              <div className="py-16 text-center text-sm text-muted-foreground/70">
                Cargando run…
              </div>
            )}

            {error && (
              <div className="flex items-center gap-2 rounded-md border border-destructive/40
                              bg-destructive/10 p-3 text-sm font-mono text-destructive">
                <AlertOctagon className="size-4 shrink-0" />
                {error}
              </div>
            )}

            {run && (
              <>
                {/* Meta grid */}
                <div className="rounded-lg border border-border bg-card p-5 grid grid-cols-2 gap-4">
                  {[
                    { label: 'Engagement',  value: `#${run.engagement_id}` },
                    { label: 'Agente',      value: run.agent },
                    { label: 'Modelo',      value: run.model, mono: true },
                    { label: 'Status',      value: run.status,
                      className: STATUS_COLOR[run.status] || 'text-foreground' },
                    { label: 'Tool calls',  value: tools.length },
                    ...(run.findings_count != null
                      ? [{ label: 'Findings', value: run.findings_count, className: 'text-warning' }]
                      : []),
                    { label: 'Inicio',      value: fmtDateTime(run.started_at), mono: true },
                    { label: 'Fin',         value: fmtDateTime(run.finished_at), mono: true },
                    { label: 'Duración',    value: fmtMs(durationOf(run)), mono: true },
                  ].map((f) => (
                    <div key={f.label}>
                      <div className="mb-0.5 text-[10px] text-muted-foreground/70">{f.label}</div>
                      <div className={cn(
                        'truncate text-sm font-semibold text-foreground',
                        f.mono && 'font-mono',
                        f.className,
                      )}>
                        {f.value ?? '—'}
                      </div>
                    </div>
                  ))}

                  {run.targets && run.targets.length > 0 && (
                    <div className="col-span-2">
                      <div className="mb-0.5 text-[10px] text-muted-foreground/70">Targets</div>
                      <div className="font-mono text-sm text-foreground">
                        {run.targets.join(', ')}
                      </div>
                    </div>
                  )}

                  {run.pipeline_run_id && (
                    <div className="col-span-2 font-mono text-[10px] text-info">
                      ↳ pipeline_run_id: {run.pipeline_run_id}
                    </div>
                  )}

                  {run.summary && (
                    <div className="col-span-2 border-t border-border pt-3 text-sm text-muted-foreground">
                      <span className="text-muted-foreground/70">Summary:</span> {run.summary}
                    </div>
                  )}

                  {run.error && (
                    <div className="col-span-2 border-t border-border pt-3 font-mono text-sm
                                    text-destructive flex items-start gap-2">
                      <AlertOctagon className="mt-0.5 size-4 shrink-0" />
                      {run.error}
                    </div>
                  )}
                </div>

                {/* Timeline */}
                <div className="overflow-hidden rounded-lg border border-border bg-card">
                  <div className="flex items-center gap-3 border-b border-border bg-background/60
                                  px-3 py-2 font-mono text-xs text-muted-foreground">
                    <Terminal className="size-3.5 text-terminal" />
                    <span>tools_called[]</span>
                    <span className="ml-auto text-muted-foreground/70">
                      {tools.length} entries
                    </span>
                  </div>
                  {tools.length === 0 ? (
                    <div className="py-12 text-center font-mono text-xs text-muted-foreground/70">
                      Este run aún no llamó tools.
                    </div>
                  ) : (
                    tools.map((call, i) => <ToolCallRow key={i} call={call} idx={i} />)
                  )}
                </div>
              </>
            )}
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  )
}
