// TacticsPicker — Selector de tácticas MITRE ATT&CK con presets.
//
// Props:
//   value      : string[]   IDs de tácticas seleccionadas (ej. ['TA0043'])
//   onChange   : (newIds[]) => void
//   disabled   : bool
//
// Migrado a Tailwind v4 + shadcn Checkbox + lucide-react.

import { Eraser } from 'lucide-react'
import { Checkbox } from '@/components/ui/checkbox'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export const ATTACK_TACTICS = [
  { id: 'TA0043', name: 'Reconnaissance',        desc: 'Recopilación de información del objetivo' },
  { id: 'TA0042', name: 'Resource Development',  desc: 'Establecimiento de recursos para el ataque' },
  { id: 'TA0001', name: 'Initial Access',        desc: 'Acceso inicial al entorno objetivo' },
  { id: 'TA0002', name: 'Execution',             desc: 'Ejecución de código malicioso' },
  { id: 'TA0003', name: 'Persistence',           desc: 'Mantenimiento del acceso' },
  { id: 'TA0004', name: 'Privilege Escalation',  desc: 'Elevación de privilegios' },
  { id: 'TA0005', name: 'Defense Evasion',       desc: 'Evasión de defensas' },
  { id: 'TA0006', name: 'Credential Access',     desc: 'Robo de credenciales' },
  { id: 'TA0007', name: 'Discovery',             desc: 'Descubrimiento del entorno' },
  { id: 'TA0008', name: 'Lateral Movement',      desc: 'Movimiento lateral en la red' },
  { id: 'TA0009', name: 'Collection',            desc: 'Recopilación de datos sensibles' },
  { id: 'TA0011', name: 'Command and Control',   desc: 'Comunicación con sistemas comprometidos' },
  { id: 'TA0010', name: 'Exfiltration',          desc: 'Extracción de datos del entorno' },
  { id: 'TA0040', name: 'Impact',                desc: 'Manipulación, interrupción o destrucción' },
]

export const TACTIC_PRESETS = [
  {
    id: 'recon-only',
    label: 'Recon-only',
    desc: 'Solo descubrimiento pasivo',
    tactics: ['TA0043', 'TA0042', 'TA0007'],
  },
  {
    id: 'standard-pentest',
    label: 'Standard pentest',
    desc: 'Recon + acceso + descubrimiento',
    tactics: ['TA0043', 'TA0001', 'TA0002', 'TA0007', 'TA0006'],
  },
  {
    id: 'full-killchain',
    label: 'Full kill chain',
    desc: 'Las 14 tácticas (laboratorio aislado)',
    tactics: ATTACK_TACTICS.map((t) => t.id),
  },
]

export default function TacticsPicker({ value = [], onChange, disabled = false }) {
  const setIds = (ids) => onChange?.(ids)

  const toggle = (id) => {
    if (disabled) return
    setIds(value.includes(id) ? value.filter((t) => t !== id) : [...value, id])
  }

  const applyPreset = (preset) => {
    if (disabled) return
    setIds([...preset.tactics])
  }

  const matchedPreset = TACTIC_PRESETS.find(
    (p) => p.tactics.length === value.length &&
           p.tactics.every((t) => value.includes(t))
  )

  return (
    <div>
      {/* Presets */}
      {!disabled && (
        <div className="mb-4 flex flex-wrap items-center gap-1.5">
          <span className="mr-1 self-center text-xs text-muted-foreground/70">
            Preset:
          </span>
          {TACTIC_PRESETS.map((p) => {
            const sel = matchedPreset?.id === p.id
            return (
              <Button
                key={p.id}
                type="button"
                variant={sel ? 'default' : 'outline'}
                size="xs"
                onClick={() => applyPreset(p)}
                title={p.desc}
                className={cn('rounded-full gap-1', sel ? '' : '')}
              >
                {p.label}
                <span className="rounded-sm bg-black/20 px-1 font-mono text-[10px]">
                  {p.tactics.length}
                </span>
              </Button>
            )
          })}
          {value.length > 0 && (
            <Button
              type="button"
              variant="outline"
              size="xs"
              onClick={() => setIds([])}
              className="gap-1 rounded-full border-destructive/40 text-destructive
                         hover:bg-destructive/10 hover:text-destructive"
            >
              <Eraser className="size-3" />
              Limpiar
            </Button>
          )}
        </div>
      )}

      {/* Grid de checkboxes */}
      <div className="grid grid-cols-[repeat(auto-fill,minmax(260px,1fr))] gap-2">
        {ATTACK_TACTICS.map((tac) => {
          const sel = value.includes(tac.id)
          return (
            <label
              key={tac.id}
              className={cn(
                'flex items-start gap-2 rounded-md border p-2 transition-colors',
                sel
                  ? 'border-primary/40 bg-primary/10'
                  : 'border-border bg-transparent hover:bg-accent/40',
                disabled
                  ? (sel ? 'opacity-100 cursor-default' : 'opacity-50 cursor-default')
                  : 'cursor-pointer'
              )}
            >
              <Checkbox
                checked={sel}
                disabled={disabled}
                onCheckedChange={() => toggle(tac.id)}
                className="mt-0.5"
              />
              <div className="min-w-0 flex-1">
                <div className={cn(
                  'text-sm',
                  sel ? 'font-bold text-primary' : 'font-medium text-muted-foreground'
                )}>
                  <span className="mr-1.5 font-mono">{tac.id}</span>
                  {tac.name}
                </div>
                <div className="mt-0.5 text-[11px] text-muted-foreground/70">
                  {tac.desc}
                </div>
              </div>
            </label>
          )
        })}
      </div>

      {/* Footer */}
      <div className="mt-4 text-xs text-muted-foreground/70">
        {value.length} de {ATTACK_TACTICS.length} tácticas habilitadas
        {matchedPreset && (
          <span className="ml-2 text-primary">
            · preset &ldquo;{matchedPreset.label}&rdquo;
          </span>
        )}
      </div>
    </div>
  )
}
