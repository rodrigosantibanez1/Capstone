// TargetTagInput — Widget multi-tag para definir targets del scope.
// Compartido por EngagementSetupView (creación) y EngagementsView (edición).
//
// Features:
//   - Autodetección IP / CIDR / Dominio
//   - Validación por tag con feedback inline
//   - Bulk add: pegar varios separados por coma, espacio o newline
//   - Enter / coma / espacio → agrega; Backspace en vacío → quita el último
//
// Props:
//   value      : [{ value, type: 'ip'|'cidr'|'domain' }]
//   onChange   : (newValue) => void
//   disabled   : bool
//   placeholder: string
//
// Migrado a Tailwind v4 + lucide-react.

import { useState } from 'react'
import { X as XIcon, AlertCircle } from 'lucide-react'
import { cn } from '@/lib/utils'

// ─── Validación / autodetección ───────────────────────────────────────────────

const _RE_IPV4   = /^(\d{1,3}\.){3}\d{1,3}$/
const _RE_CIDR   = /^(\d{1,3}\.){3}\d{1,3}\/\d{1,2}$/
const _RE_DOMAIN = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+$/

export function detectTargetType(val) {
  const v = val.trim()
  if (!v) return null
  if (_RE_IPV4.test(v))   return 'ip'
  if (_RE_CIDR.test(v))   return 'cidr'
  if (_RE_DOMAIN.test(v)) return 'domain'
  return null
}

// ─── Estilos por tipo de target ──────────────────────────────────────────────

export const TARGET_TYPE_STYLE = {
  ip:     { class: 'bg-primary/15 text-primary border-primary/30',     label: 'IP' },
  cidr:   { class: 'bg-warning/15 text-warning border-warning/40',     label: 'CIDR' },
  domain: { class: 'bg-info/15    text-info    border-info/40',        label: 'Dominio' },
}

// ─── Componente ───────────────────────────────────────────────────────────────

export default function TargetTagInput({
  value = [],
  onChange,
  disabled = false,
  placeholder = '192.168.56.101, 192.168.56.0/24, vulnsite.com…',
}) {
  const [text,  setText]  = useState('')
  const [error, setError] = useState('')

  const _emit = (next) => onChange?.(next)

  const addOne = (raw) => {
    const v = raw.trim().replace(/,$/, '')
    if (!v) return false
    const type = detectTargetType(v)
    if (!type) {
      setError(`"${v}" no es una IP, CIDR ni dominio válido`)
      return false
    }
    if (value.some((t) => t.value === v)) {
      setError(`"${v}" ya está en la lista`)
      return false
    }
    _emit([...value, { value: v, type }])
    return true
  }

  /** Bulk add: divide el input por coma / espacio / newline. */
  const addBulk = (raw) => {
    const tokens = raw.split(/[,\s\n\r]+/).map((t) => t.trim()).filter(Boolean)
    if (tokens.length === 0) return
    setError('')
    const seen   = new Set(value.map((t) => t.value))
    const next   = [...value]
    const errors = []
    for (const tok of tokens) {
      if (seen.has(tok)) continue
      const type = detectTargetType(tok)
      if (!type) { errors.push(tok); continue }
      next.push({ value: tok, type })
      seen.add(tok)
    }
    _emit(next)
    if (errors.length) {
      setError(`Rechazados (formato inválido): ${errors.slice(0, 3).join(', ')}` +
               (errors.length > 3 ? ` … +${errors.length - 3}` : ''))
    }
  }

  const onKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault()
      if (addOne(text)) setText('')
    } else if (e.key === ' ' && text.trim()) {
      e.preventDefault()
      if (addOne(text)) setText('')
    } else if (e.key === 'Backspace' && !text && value.length > 0) {
      _emit(value.slice(0, -1))
      setError('')
    }
  }

  const onPaste = (e) => {
    const pasted = e.clipboardData.getData('text')
    if (/[,\s\n]/.test(pasted)) {
      e.preventDefault()
      addBulk(pasted)
      setText('')
    }
  }

  const onBlur = () => {
    if (text.trim()) {
      if (addOne(text)) setText('')
    }
  }

  const remove = (v) => {
    _emit(value.filter((t) => t.value !== v))
    setError('')
  }

  const clear = () => {
    if (value.length > 0 && confirm(`¿Quitar los ${value.length} targets?`)) {
      _emit([])
    }
  }

  return (
    <div>
      <div
        onClick={() => document.getElementById('target-tag-input-internal')?.focus()}
        className={cn(
          'flex min-h-12 flex-wrap items-center gap-1 rounded-md border bg-input px-3 py-2',
          error ? 'border-destructive' : 'border-border focus-within:border-ring',
          disabled && 'cursor-not-allowed opacity-60',
          !disabled && 'cursor-text'
        )}
      >
        {value.map((t) => {
          const s = TARGET_TYPE_STYLE[t.type] || TARGET_TYPE_STYLE.ip
          return (
            <span
              key={t.value}
              className={cn(
                'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5',
                'font-mono text-xs font-semibold',
                s.class
              )}
            >
              <span>{t.value}</span>
              <span className="rounded-sm bg-black/25 px-1.5 text-[9px] uppercase tracking-wider font-bold">
                {s.label}
              </span>
              {!disabled && (
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); remove(t.value) }}
                  className="flex size-4 items-center justify-center rounded-full
                             bg-black/20 transition-colors hover:bg-black/40"
                  aria-label={`Quitar ${t.value}`}
                  title="Quitar"
                >
                  <XIcon className="size-2.5" />
                </button>
              )}
            </span>
          )
        })}

        <input
          id="target-tag-input-internal"
          value={text}
          disabled={disabled}
          onChange={(e) => { setText(e.target.value); setError('') }}
          onKeyDown={onKeyDown}
          onPaste={onPaste}
          onBlur={onBlur}
          placeholder={value.length === 0 ? placeholder : ''}
          className="min-w-[160px] flex-1 bg-transparent font-mono text-sm
                     text-foreground placeholder:text-muted-foreground/60
                     outline-none disabled:cursor-not-allowed"
        />

        {value.length > 0 && !disabled && (
          <button
            type="button"
            onClick={clear}
            title="Quitar todos los targets"
            className="rounded-sm border border-border bg-transparent px-2 py-0.5
                       text-[10px] text-muted-foreground/70 transition-colors
                       hover:bg-accent hover:text-foreground"
          >
            limpiar
          </button>
        )}
      </div>

      {/* Footer: error o hint */}
      <div className="mt-1.5 min-h-4 text-xs">
        {error ? (
          <span className="flex items-center gap-1 text-destructive">
            <AlertCircle className="size-3" /> {error}
          </span>
        ) : value.length === 0 ? (
          <span className="text-muted-foreground/70">
            Tip: presiona{' '}
            <kbd className="rounded-sm border border-border bg-background px-1.5 py-px font-mono text-[10px] text-muted-foreground">
              Enter
            </kbd>
            {' '}o{' '}
            <kbd className="rounded-sm border border-border bg-background px-1.5 py-px font-mono text-[10px] text-muted-foreground">
              ,
            </kbd>
            {' '}para agregar. Pegar texto con comas/espacios agrega varios a la vez.
          </span>
        ) : (
          <span className="text-muted-foreground/70">
            {value.length} target{value.length > 1 ? 's' : ''} ·
            {' '}{value.filter((t) => t.type === 'ip').length} IP ·
            {' '}{value.filter((t) => t.type === 'cidr').length} CIDR ·
            {' '}{value.filter((t) => t.type === 'domain').length} dominio
          </span>
        )}
      </div>
    </div>
  )
}
