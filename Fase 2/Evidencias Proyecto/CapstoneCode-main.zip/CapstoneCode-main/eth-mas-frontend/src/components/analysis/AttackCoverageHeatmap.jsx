// AttackCoverageHeatmap — Heatmap de cobertura ATT&CK del engagement.
// Canibaliza la antigua AttackCoverageView (que era un placeholder) y la
// convierte en un componente data-driven que consume los enriched_findings
// del AnalysisDoc: agrupa por técnica MITRE, colorea por CVSS máximo y
// muestra el conteo de findings por técnica, organizado por táctica.

import { Grid3x3 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import {
  TACTIC_ORDER, techniqueName, techniqueTactic, cvssCellClass,
} from './mitre'
import { MitreHover } from './MitreBadge'

// enriched: [{ ref, mitre_technique, cvss_score, cve_ids, note }]
function buildCells(enriched) {
  const byTech = new Map()
  for (const ef of enriched) {
    const tech = ef.mitre_technique
    if (!tech) continue
    const prev = byTech.get(tech) || { tech, count: 0, maxCvss: null, cves: new Set() }
    prev.count += 1
    if (ef.cvss_score != null) {
      prev.maxCvss = prev.maxCvss == null ? ef.cvss_score : Math.max(prev.maxCvss, ef.cvss_score)
    }
    for (const c of ef.cve_ids || []) prev.cves.add(c)
    byTech.set(tech, prev)
  }
  // Agrupar por táctica
  const byTactic = new Map()
  for (const cell of byTech.values()) {
    const tactic = techniqueTactic(cell.tech)
    if (!byTactic.has(tactic)) byTactic.set(tactic, [])
    byTactic.get(tactic).push(cell)
  }
  // Ordenar tácticas: las conocidas en orden canónico, luego "Otras"
  const tactics = [...byTactic.keys()].sort((a, b) => {
    const ia = TACTIC_ORDER.indexOf(a)
    const ib = TACTIC_ORDER.indexOf(b)
    return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib)
  })
  return tactics.map((tactic) => ({
    tactic,
    cells: byTactic.get(tactic).sort((a, b) => (b.maxCvss || 0) - (a.maxCvss || 0)),
  }))
}

export default function AttackCoverageHeatmap({ enrichedFindings = [] }) {
  const columns = buildCells(enrichedFindings)
  const totalTechniques = columns.reduce((s, c) => s + c.cells.length, 0)

  if (totalTechniques === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
          <Grid3x3 className="size-8 text-muted-foreground/30" />
          <div className="text-sm font-semibold text-muted-foreground">
            Sin técnicas mapeadas
          </div>
          <p className="max-w-md text-xs text-muted-foreground/70">
            El análisis no asoció técnicas MITRE ATT&CK a ningún finding.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="p-5 space-y-4">
        <div className="flex items-center gap-2">
          <Grid3x3 className="size-4 text-info" />
          <span className="text-sm font-semibold text-foreground">
            Cobertura ATT&CK
          </span>
          <span className="font-mono text-xs text-muted-foreground/70">
            {totalTechniques} técnica{totalTechniques !== 1 ? 's' : ''}
          </span>
        </div>

        <div className="flex flex-wrap gap-4">
          {columns.map((col) => (
            <div key={col.tactic} className="min-w-[180px] flex-1">
              <div className="mb-2 truncate text-[11px] font-semibold uppercase
                              tracking-wider text-muted-foreground/80">
                {col.tactic}
              </div>
              <div className="flex flex-col gap-2">
                {col.cells.map((cell) => (
                  <MitreHover
                    key={cell.tech}
                    technique={cell.tech}
                    extra={
                      <div className="space-y-0.5 border-t border-border pt-2 text-xs text-muted-foreground">
                        <div>
                          {cell.count} finding{cell.count !== 1 ? 's' : ''}
                          {' · '}CVSS máx {cell.maxCvss != null ? cell.maxCvss.toFixed(1) : 'N/A'}
                        </div>
                        {cell.cves.size > 0 && (
                          <div className="max-w-[240px] font-mono text-[10px]">
                            {[...cell.cves].slice(0, 4).join(', ')}
                            {cell.cves.size > 4 && ` +${cell.cves.size - 4}`}
                          </div>
                        )}
                      </div>
                    }
                  >
                    <div className={cn(
                      'cursor-help rounded-md border px-2.5 py-2 transition-colors',
                      cvssCellClass(cell.maxCvss),
                    )}>
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-xs font-bold">{cell.tech}</span>
                        <span className="rounded-full bg-background/60 px-1.5 text-[10px] font-bold">
                          {cell.count}
                        </span>
                      </div>
                      <div className="mt-0.5 truncate text-[11px] opacity-90">
                        {techniqueName(cell.tech)}
                      </div>
                    </div>
                  </MitreHover>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
