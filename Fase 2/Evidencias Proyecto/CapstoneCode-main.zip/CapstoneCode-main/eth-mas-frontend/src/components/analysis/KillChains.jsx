// KillChains — Cadenas de ataque (attack_vectors) identificadas por AnalysisAgent.
// Canibaliza la antigua AttackVectorsView (placeholder) y la vuelve data-driven:
// renderiza cada vector del AnalysisDoc como una tarjeta expandible con sus
// pasos (kill chain), severidad, técnicas MITRE y findings de respaldo (refs).

import { useState } from 'react'
import {
  GitBranch, ChevronRight, ArrowDown, Target,
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { SEV_BADGE } from './mitre'
import { MitreHover } from './MitreBadge'

// vectors: [{ name, steps:[], severity, refs:[], mitre_techniques:[] }]
export default function KillChains({ vectors = [] }) {
  const [openIdx, setOpenIdx] = useState(0)

  if (!vectors.length) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
          <GitBranch className="size-8 text-muted-foreground/30" />
          <div className="text-sm font-semibold text-muted-foreground">
            Sin vectores de ataque
          </div>
          <p className="max-w-md text-xs text-muted-foreground/70">
            El análisis no encadenó findings en cadenas de ataque. Esto puede
            ocurrir si los hallazgos son aislados o de baja explotabilidad.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="flex flex-col gap-3">
      {vectors.map((v, idx) => {
        const open = openIdx === idx
        const sevKey = (v.severity || 'info').toLowerCase()
        return (
          <Card key={`${v.name}-${idx}`} className={cn(
            'overflow-hidden border-l-4',
            sevKey === 'critical' || sevKey === 'high'
              ? 'border-l-sev-high'
              : sevKey === 'medium' ? 'border-l-sev-medium' : 'border-l-info',
          )}>
            <button
              type="button"
              onClick={() => setOpenIdx(open ? -1 : idx)}
              className="flex w-full items-center gap-3 px-5 py-3 text-left
                         transition-colors hover:bg-accent"
            >
              <GitBranch className="size-4 shrink-0 text-info" />
              <span className="min-w-0 flex-1 truncate font-semibold text-foreground">
                {v.name || `Vector #${idx + 1}`}
              </span>
              <Badge variant="outline"
                className={cn('uppercase tracking-wider text-[10px]', SEV_BADGE[sevKey] || SEV_BADGE.info)}>
                {sevKey}
              </Badge>
              {Array.isArray(v.steps) && (
                <span className="font-mono text-xs text-muted-foreground/70">
                  {v.steps.length} paso{v.steps.length !== 1 ? 's' : ''}
                </span>
              )}
              <ChevronRight className={cn(
                'size-4 shrink-0 text-muted-foreground/70 transition-transform',
                open && 'rotate-90',
              )} />
            </button>

            {open && (
              <CardContent className="space-y-4 border-t border-border pt-4">
                {/* Pasos de la kill chain */}
                {Array.isArray(v.steps) && v.steps.length > 0 && (
                  <ol className="flex flex-col gap-0">
                    {v.steps.map((step, i) => (
                      <li key={i} className="flex flex-col">
                        <div className="flex items-start gap-3">
                          <span className="flex size-6 shrink-0 items-center justify-center
                                           rounded-full border border-primary/40 bg-primary/10
                                           font-mono text-xs font-bold text-primary">
                            {i + 1}
                          </span>
                          <span className="pt-0.5 text-sm text-muted-foreground">{step}</span>
                        </div>
                        {i < v.steps.length - 1 && (
                          <ArrowDown className="my-1 ml-2.5 size-3 text-muted-foreground/40" />
                        )}
                      </li>
                    ))}
                  </ol>
                )}

                {/* Técnicas MITRE */}
                {Array.isArray(v.mitre_techniques) && v.mitre_techniques.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] text-muted-foreground/70">MITRE:</span>
                    {v.mitre_techniques.map((t) => (
                      <MitreHover key={t} technique={t}>
                        <button type="button"
                          className="cursor-help rounded-md border border-border bg-background px-1.5 py-0.5
                                     font-mono text-[10px] text-muted-foreground transition-colors
                                     hover:border-primary/50 hover:text-foreground focus:outline-none
                                     focus-visible:ring-2 focus-visible:ring-primary/40">
                          {t}
                        </button>
                      </MitreHover>
                    ))}
                  </div>
                )}

                {/* Findings de respaldo */}
                {Array.isArray(v.refs) && v.refs.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Target className="size-3 text-muted-foreground/70" />
                    <span className="text-[11px] text-muted-foreground/70">Evidencia:</span>
                    {v.refs.map((r) => (
                      <code key={r} className="rounded-sm border border-border bg-background
                                               px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                        {r}
                      </code>
                    ))}
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        )
      })}
    </div>
  )
}
