// MitreBadge — Técnica MITRE ATT&CK con popover explicativo (HoverCard) + link
// al sitio oficial. Reemplaza los `title=` nativos por una ventana emergente con
// nombre, táctica, explicación breve y un enlace "Ver en MITRE ATT&CK".
//
// Pedido del operador (S3): al posarse sobre el dato MITRE, mostrar explicación
// breve y poder redireccionar al sitio de MITRE.

import { ExternalLink } from 'lucide-react'
import {
  HoverCard, HoverCardTrigger, HoverCardContent,
} from '@/components/ui/hover-card'
import { cn } from '@/lib/utils'
import { techniqueName, techniqueTactic, techniqueDesc, mitreUrl } from './mitre'

// Contenido del popover, reutilizable. `extra` = nodo opcional con stats (heatmap).
export function MitreHover({ technique, children, extra, openDelay = 120, closeDelay = 120 }) {
  if (!technique) return children ?? null
  return (
    <HoverCard openDelay={openDelay} closeDelay={closeDelay}>
      <HoverCardTrigger asChild>{children}</HoverCardTrigger>
      <HoverCardContent side="top" className="w-72 space-y-2">
        <div className="flex items-baseline gap-2">
          <span className="font-mono text-xs font-bold text-primary">{technique}</span>
          <span className="text-sm font-semibold leading-tight text-foreground">
            {techniqueName(technique)}
          </span>
        </div>
        <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Táctica: {techniqueTactic(technique)}
        </div>
        <p className="text-xs leading-relaxed text-muted-foreground">
          {techniqueDesc(technique)}
        </p>
        {extra}
        <a
          href={mitreUrl(technique)}
          target="_blank"
          rel="noreferrer noopener"
          className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
        >
          Ver en MITRE ATT&CK
          <ExternalLink className="size-3" />
        </a>
      </HoverCardContent>
    </HoverCard>
  )
}

// Badge clickable/hoverable: el id de la técnica como disparador del popover.
export default function MitreBadge({ technique, className, extra }) {
  if (!technique) return <span className="text-muted-foreground/60">—</span>
  return (
    <MitreHover technique={technique} extra={extra}>
      <button
        type="button"
        className={cn(
          'cursor-help rounded-sm border border-border bg-background px-2 py-0.5',
          'font-mono text-xs text-muted-foreground transition-colors',
          'hover:border-primary/50 hover:text-foreground',
          'focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/40',
          className,
        )}
      >
        {technique}
      </button>
    </MitreHover>
  )
}
