// mitre.js — Tabla de referencia MITRE ATT&CK para la tab Analysis.
// Nombres legibles + tácticas para agrupar técnicas en el heatmap. No es
// exhaustivo: cubre las técnicas que AnalysisAgent suele emitir sobre los
// targets del lab (Metasploitable2 / DVWA). Técnicas no listadas caen en
// la columna "Otras".

// technique_id → { name, tactic, desc }
// `desc`: explicación breve (1 frase) para el popover de la tab Analysis.
export const MITRE_TECHNIQUES = {
  T1595: { name: 'Active Scanning',                 tactic: 'Reconnaissance',     desc: 'Sondeo activo de la infraestructura del objetivo para descubrir servicios y vulnerabilidades.' },
  T1046: { name: 'Network Service Discovery',       tactic: 'Discovery',          desc: 'Enumeración de los servicios de red y puertos abiertos expuestos por el objetivo.' },
  T1083: { name: 'File & Directory Discovery',      tactic: 'Discovery',          desc: 'Descubrimiento de archivos y directorios accesibles en el sistema o aplicación web.' },
  T1082: { name: 'System Information Discovery',    tactic: 'Discovery',          desc: 'Recolección de información del sistema operativo, versiones y configuración.' },
  T1190: { name: 'Exploit Public-Facing App',       tactic: 'Initial Access',     desc: 'Explotación de una aplicación o servicio expuesto a la red para obtener acceso inicial.' },
  T1133: { name: 'External Remote Services',        tactic: 'Initial Access',     desc: 'Uso de servicios de acceso remoto externos (VPN, RDP) como vía de entrada.' },
  T1078: { name: 'Valid Accounts',                  tactic: 'Initial Access',     desc: 'Uso de credenciales válidas (por defecto, débiles o robadas) para acceder al sistema.' },
  T1210: { name: 'Exploit Remote Services',         tactic: 'Lateral Movement',   desc: 'Explotación de vulnerabilidades en servicios de red para moverse lateralmente.' },
  T1021: { name: 'Remote Services',                 tactic: 'Lateral Movement',   desc: 'Uso de servicios de acceso remoto (SSH, SMB, Telnet) para moverse dentro de la red.' },
  T1110: { name: 'Brute Force',                     tactic: 'Credential Access',  desc: 'Adivinación sistemática de credenciales mediante intentos repetidos.' },
  T1040: { name: 'Network Sniffing',                tactic: 'Credential Access',  desc: 'Captura de tráfico de red para obtener credenciales o información sensible.' },
  T1059: { name: 'Command & Scripting Interpreter', tactic: 'Execution',          desc: 'Ejecución de comandos o scripts en el sistema comprometido.' },
  T1203: { name: 'Exploitation for Client Exec',    tactic: 'Execution',          desc: 'Explotación de software cliente (navegador, ofimática) para ejecutar código.' },
}

// Orden canónico de tácticas para las columnas del heatmap.
export const TACTIC_ORDER = [
  'Reconnaissance',
  'Initial Access',
  'Execution',
  'Discovery',
  'Credential Access',
  'Lateral Movement',
]

export function techniqueName(id) {
  return MITRE_TECHNIQUES[id]?.name || id
}

export function techniqueTactic(id) {
  return MITRE_TECHNIQUES[id]?.tactic || 'Otras'
}

// Descripción breve para el popover. Si la técnica no está en la tabla, un genérico.
export function techniqueDesc(id) {
  return MITRE_TECHNIQUES[id]?.desc
    || 'Técnica del framework MITRE ATT&CK. Consulta el sitio oficial para el detalle.'
}

// URL del sitio oficial MITRE ATT&CK para la técnica (o sub-técnica T####.###).
export function mitreUrl(id) {
  if (!id) return 'https://attack.mitre.org/techniques/'
  const path = String(id).trim().replace('.', '/')
  return `https://attack.mitre.org/techniques/${path}/`
}

// Color de celda del heatmap según CVSS máximo asociado a la técnica.
export function cvssCellClass(score) {
  if (score == null)  return 'bg-muted/40 text-muted-foreground border-border'
  if (score >= 9)     return 'bg-sev-critical/20 text-sev-critical border-sev-critical/40'
  if (score >= 7)     return 'bg-sev-high/20 text-sev-high border-sev-high/40'
  if (score >= 4)     return 'bg-sev-medium/20 text-sev-medium border-sev-medium/40'
  return 'bg-sev-low/20 text-sev-low border-sev-low/40'
}

// Color por severidad textual (vectores de ataque).
export const SEV_BADGE = {
  critical: 'bg-sev-critical/15 text-sev-critical border-sev-critical/40',
  high:     'bg-sev-high/15 text-sev-high border-sev-high/40',
  medium:   'bg-sev-medium/15 text-sev-medium border-sev-medium/40',
  low:      'bg-sev-low/15 text-sev-low border-sev-low/40',
  info:     'bg-muted text-muted-foreground border-border',
}
