// useHitlPending — Hook global de acciones HITL pendientes
//
// Pollea /engagements + /hitl-actions cada `intervalMs` ms y expone:
//   { count, items, loading, error, refresh }
//
// Usado por:
//   - App.jsx → badge dinámico en sidebar + banner global HitlAlert
//   - Cualquier vista que quiera mostrar el conteo
//
// Estrategia: una sola conexión "global" en el root (App.jsx). Las vistas que
// necesiten acceso al estado pueden levantarlo vía props desde App o
// reinstanciar el hook con su propio polling (más simple, costo bajo).

import { useState, useEffect, useCallback, useRef } from 'react'
import { authedFetch, API_BASE, apiEvents } from '../lib/api'

const DEFAULT_INTERVAL = 5000   // 5 s

export default function useHitlPending(intervalMs = DEFAULT_INTERVAL) {
  const [count,   setCount]   = useState(0)
  const [items,   setItems]   = useState([])
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState(null)
  const mountedRef = useRef(true)

  const refresh = useCallback(async () => {
    try {
      // Lista de engagements (no requiere auth)
      const engRes = await fetch(`${API_BASE}/engagements`)
      if (!engRes.ok) throw new Error(`HTTP ${engRes.status}`)
      const engs = await engRes.json()
      if (!engs.length) {
        if (mountedRef.current) {
          setCount(0); setItems([]); setError(null); setLoading(false)
        }
        return
      }

      // HITL actions pending de cada engagement (en paralelo)
      const results = await Promise.all(
        engs.map((eng) =>
          authedFetch(`/engagements/${eng.id}/hitl-actions?pending_only=true`)
            .then((r) => r.ok ? r.json() : [])
            .then((arr) => Array.isArray(arr) ? arr.map((a) => ({ ...a, engagement_id: eng.id })) : [])
            .catch(() => [])
        )
      )
      const allPending = results.flat()
      if (mountedRef.current) {
        setCount(allPending.length)
        setItems(allPending)
        setError(null)
        setLoading(false)
      }
    } catch (e) {
      if (mountedRef.current) {
        setError(e.message || 'Error')
        setLoading(false)
      }
    }
  }, [])

  useEffect(() => {
    mountedRef.current = true
    refresh()
    const id = setInterval(refresh, intervalMs)
    // Refrescar inmediatamente si cambia la API key
    const onKey = () => refresh()
    apiEvents.addEventListener('apikey-changed', onKey)
    return () => {
      mountedRef.current = false
      clearInterval(id)
      apiEvents.removeEventListener('apikey-changed', onKey)
    }
  }, [intervalMs, refresh])

  return { count, items, loading, error, refresh }
}
