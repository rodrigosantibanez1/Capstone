// theme.js — Design tokens · LEGACY (migración en curso a Tailwind v4)
// =================================================================
// ⚠ DEPRECATED para código nuevo. La fuente de verdad ahora son las CSS
// variables definidas en src/index.css (consumidas por Tailwind v4 y shadcn).
//
// Este archivo queda como capa de compatibilidad para que las vistas
// existentes (inline styles) sigan funcionando durante la migración.
// Cada vista se migra a clases Tailwind progresivamente y al terminar
// puede dejar de importar de aquí.
//
// Para CÓDIGO NUEVO usa clases Tailwind:
//   <div className="bg-card border border-border rounded-lg p-4">…</div>
//   <span className="text-muted-foreground text-sm">…</span>
//   <button className="bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-md">…</button>
//
// Equivalencias rápidas COLORS → Tailwind class:
//   COLORS.bgApp       → bg-background
//   COLORS.bgCard      → bg-card
//   COLORS.bgSidebar   → bg-sidebar
//   COLORS.border      → border-border
//   COLORS.textPrimary → text-foreground
//   COLORS.textMuted   → text-muted-foreground
//   COLORS.textDim     → text-muted-foreground/70 (o text-zinc-500)
//   COLORS.accent      → text-primary / bg-primary
//   COLORS.danger      → text-destructive / bg-destructive
//   COLORS.warning     → text-warning  (utility custom)
//   COLORS.success     → text-success  (utility custom)
//   COLORS.info        → text-info     (utility custom)
//   COLORS.sevCritical → text-sev-critical, COLORS.sevHigh → text-sev-high, etc.

export const COLORS = {
  // Fondos
  bgApp:       '#14151a',
  bgSidebar:   '#1a1c23',
  bgCard:      '#22252e',
  bgTerminal:  '#000000',
  bgInput:     '#14151a',

  // Bordes
  border:      '#2c2f3a',

  // Texto — textDim subido a #6b7280 para cumplir WCAG AA (Fase 4 a11y)
  textPrimary: '#ffffff',
  textMuted:   '#8b949e',
  textDim:     '#6b7280',

  // Acentos
  accent:      '#2d68ff',
  accentAlpha: '#2d68ff22',
  danger:      '#ff2e63',
  dangerAlpha: '#ff2e6322',
  warning:     '#f59e0b',
  warningAlpha:'#f59e0b22',
  success:     '#22c55e',
  successAlpha:'#22c55e22',
  terminal:    '#00ff00',
  info:        '#38bdf8',
  infoAlpha:   '#38bdf822',

  // Severidades
  sevCritical: '#ff2e63',
  sevHigh:     '#f97316',
  sevMedium:   '#f59e0b',
  sevLow:      '#38bdf8',
  sevInfo:     '#8b949e',
};

export const FONT = {
  base:    "system-ui, -apple-system, sans-serif",
  mono:    "'Courier New', Courier, monospace",
  sizeXS:  '11px',
  sizeSM:  '12px',
  sizeMD:  '14px',
  sizeLG:  '16px',
  sizeXL:  '20px',
  size2XL: '24px',
  size3XL: '32px',
  size4XL: '48px',
};

export const RADIUS = {
  sm:   '4px',
  md:   '8px',
  lg:   '12px',
  full: '9999px',
};

export const SPACING = {
  xs:  '4px',
  sm:  '8px',
  md:  '16px',
  lg:  '24px',
  xl:  '32px',
  xxl: '40px',
};
