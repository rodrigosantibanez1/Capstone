// AgentRunsView — Lista de runs por engagement con drill-down.
//
// Migrado a Tailwind v4 + shadcn (Card, Select, Table, Button) + lucide-react.

import { useState, useEffect, useCallback } from 'react'
import { useSearchParams } from 'react-router-dom'
import {
  Activity, RefreshCw, AlertTriangle, Clock,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import RunDetailDrawer, {
  STATUS_COLOR, STATUS_ICON_COMPONENT,
  fmtMs, fmtDateTime, durationOf,
} from '@/components/RunDetailDrawer'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { cn } from '@/lib/utils'

export default function AgentRunsView({ engagementId = 1 }) {
  const [searchParams, setSearchParams] = useSearchParams()
  // engagementId puede venir de ?eid=, runId del drawer de ?runId=
  const eidFromUrl    = Number(searchParams.get('eid')) || engagementId
  const selectedRunId = searchParams.get('runId') || null

  const setSelectedEng = (id) => {
    setSearchParams((prev) => {
      const p = new URLSearchParams(prev)
      p.set('eid', String(id))
      p.delete('runId')   // cambiar engagement cierra el drawer
      return p
    })
  }
  const setSelectedRunId = (id) => {
    setSearchParams((prev) => {
      const p = new URLSearchParams(prev)
      if (id) p.set('runId', id); else p.delete('runId')
      return p
    })
  }

  const [engagements, setEngagements] = useState([])
  const [runs,        setRuns]        = useState([])
  const [loading,     setLoading]     = useState(true)
  const [error,       setError]       = useState(null)
  const [filAgent,    setFilAgent]    = useState('todos')
  const [filStatus,   setFilStatus]   = useState('todos')

  const selectedEng = eidFromUrl

  // Engagements para selector
  useEffect(() => {
    authedFetch('/engagements')
      .then((r) => (r.ok ? r.json() : []))
      .then(setEngagements)
      .catch(() => setEngagements([]))
  }, [])

  // Runs del engagement
  const fetchRuns = useCallback(async () => {
    setLoading(true); setError(null)
    try {
      const res = await authedFetch(`/engagements/${selectedEng}/agent-runs?limit=100`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setRuns(data.runs || [])
    } catch (e) {
      setRuns([])
      setError(e.message || 'Error')
    } finally {
      setLoading(false)
    }
  }, [selectedEng])

  useEffect(() => { fetchRuns() }, [fetchRuns])

  // Auto-refresh si hay runs running
  useEffect(() => {
    const hasRunning = runs.some((r) => r.status === 'running')
    if (!hasRunning) return
    const id = setInterval(fetchRuns, 3000)
    return () => clearInterval(id)
  }, [runs, fetchRuns])

  // Filtros
  const filtered = runs.filter((r) => {
    if (filAgent  !== 'todos' && r.agent  !== filAgent)  return false
    if (filStatus !== 'todos' && r.status !== filStatus) return false
    return true
  })

  // Stats
  const stats = {
    total:     runs.length,
    running:   runs.filter((r) => r.status === 'running').length,
    completed: runs.filter((r) => r.status === 'completed').length,
    failed:    runs.filter((r) => r.status === 'failed').length,
    toolCalls: runs.reduce((acc, r) => acc + (r.tools_called?.length || 0), 0),
  }

  return (
    <div className="flex flex-col gap-6">

      {/* Header */}
      <div className="flex items-start gap-4">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
            <Activity className="size-6 text-info" />
            Agent Runs
          </h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            Auditoría de todas las corridas de agentes · click en una fila para ver
            el timeline completo
          </p>
        </div>
        <Button
          type="button" variant="outline" size="sm"
          onClick={fetchRuns} disabled={loading}
          className="ml-auto gap-1.5"
        >
          <RefreshCw className={cn('size-3.5', loading && 'animate-spin')} />
          Actualizar
        </Button>
      </div>

      {/* Stats */}
      <div className="flex flex-wrap gap-4">
        {[
          { label: 'Total runs',  value: stats.total,     className: 'text-foreground' },
          { label: 'Running',     value: stats.running,   className: 'text-warning',
            pulse: stats.running > 0 },
          { label: 'Completed',   value: stats.completed, className: 'text-success' },
          { label: 'Failed',      value: stats.failed,    className: 'text-destructive' },
          { label: 'Tool calls',  value: stats.toolCalls, className: 'text-info' },
        ].map((s) => (
          <Card key={s.label}
            className={cn(
              'flex-1 min-w-[120px]',
              s.pulse && 'border-warning/60 ring-1 ring-warning/40'
            )}>
            <CardContent className="p-4">
              <div className="mb-1 text-[10px] text-muted-foreground/70">{s.label}</div>
              <div className={cn('text-3xl font-extrabold leading-none', s.className)}>
                {s.value}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filtros */}
      <Card>
        <CardContent className="flex flex-wrap items-center gap-3 p-4">
          <span className="text-sm text-muted-foreground/70">Engagement:</span>
          <Select value={String(selectedEng)} onValueChange={(v) => setSelectedEng(Number(v))}>
            <SelectTrigger className="w-[260px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {engagements.length === 0 && (
                <SelectItem value={String(selectedEng)}>#{selectedEng}</SelectItem>
              )}
              {engagements.map((e) => (
                <SelectItem key={e.id} value={String(e.id)}>
                  #{e.id} · {e.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filAgent} onValueChange={setFilAgent}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Agente: Todos</SelectItem>
              {['ReconAgent', 'ScanAgent', 'AnalysisAgent'].map((a) => (
                <SelectItem key={a} value={a}>{a}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filStatus} onValueChange={setFilStatus}>
            <SelectTrigger className="w-[160px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Status: Todos</SelectItem>
              {['running', 'completed', 'failed'].map((s) => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <span className="ml-auto text-xs text-muted-foreground/70">
            {filtered.length} de {runs.length} runs
          </span>
        </CardContent>
      </Card>

      {/* Error */}
      {error && (
        <div className="flex items-center gap-2 rounded-md border border-destructive/40
                        bg-destructive/10 p-3 font-mono text-sm text-destructive">
          <AlertTriangle className="size-4 shrink-0" />
          No se pudo conectar al backend: {error}
        </div>
      )}

      {/* Tabla */}
      <Card className="overflow-hidden">
        {loading && runs.length === 0 ? (
          <CardContent className="py-12 text-center text-sm text-muted-foreground/70">
            Cargando runs desde el backend…
          </CardContent>
        ) : !error && filtered.length === 0 ? (
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <Clock className="size-8 text-muted-foreground/30" />
            <div className="text-sm font-semibold text-muted-foreground">
              Sin runs para este engagement
            </div>
            <div className="text-xs text-muted-foreground/70">
              Lanza un agente desde la vista <strong>Pipeline</strong> para que
              aparezca aquí.
            </div>
          </CardContent>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[180px]">Status</TableHead>
                <TableHead>Agente</TableHead>
                <TableHead>Modelo</TableHead>
                <TableHead>Targets</TableHead>
                <TableHead className="w-24">Tool calls</TableHead>
                <TableHead className="w-24">Findings</TableHead>
                <TableHead className="w-24">Duración</TableHead>
                <TableHead>Inicio</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((r) => {
                const StatusIcon = STATUS_ICON_COMPONENT[r.status] || Clock
                const colorClass = STATUS_COLOR[r.status] || 'text-muted-foreground'
                const isRunning = r.status === 'running'
                return (
                  <TableRow
                    key={r._id}
                    onClick={() => setSelectedRunId(r._id)}
                    className={cn(
                      'cursor-pointer transition-colors',
                      isRunning && 'bg-warning/5',
                      'hover:bg-accent'
                    )}
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <StatusIcon className={cn('size-4 shrink-0', colorClass)} />
                        <span className={cn(
                          'font-mono text-[10px] font-bold uppercase tracking-wider',
                          colorClass
                        )}>
                          {r.status}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="font-semibold text-foreground">
                      {r.agent}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {r.model || '—'}
                    </TableCell>
                    <TableCell className="max-w-[180px] truncate font-mono text-xs text-muted-foreground">
                      {(r.targets || []).join(', ') || '—'}
                    </TableCell>
                    <TableCell className="font-mono font-bold text-primary">
                      {(r.tools_called || []).length}
                    </TableCell>
                    <TableCell className={cn(
                      'font-mono font-bold',
                      r.findings_count > 0 ? 'text-warning' : 'text-muted-foreground/60'
                    )}>
                      {r.findings_count ?? '—'}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {fmtMs(durationOf(r))}
                    </TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[10px] text-muted-foreground/70">
                      {fmtDateTime(r.started_at)}
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        )}
      </Card>

      {/* Drawer */}
      {selectedRunId && (
        <RunDetailDrawer runId={selectedRunId} onClose={() => setSelectedRunId(null)} />
      )}
    </div>
  )
}
