// AnalysisView — Salida del AnalysisAgent (HU-12 / HU-13) dentro del Workspace.
// Consume GET /engagements/{id}/analysis (AnalysisDoc):
//   - Riesgo priorizado  (priority_order × enriched_findings × findings)
//   - Heatmap ATT&CK      (AttackCoverageHeatmap, canibalizado)
//   - Kill chains         (KillChains, canibalizado)
// Si no hay análisis (404), ofrece lanzar POST /analysis.
//
// Patrón embedded como el resto de tabs del workspace: recibe engagementId.

import { useState, useEffect, useCallback } from 'react'
import { toast } from 'sonner'
import {
  Brain, Play, RefreshCw, AlertTriangle, ListOrdered, ShieldAlert,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge }  from '@/components/ui/badge'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { cn } from '@/lib/utils'
import AttackCoverageHeatmap from '@/components/analysis/AttackCoverageHeatmap'
import KillChains from '@/components/analysis/KillChains'
import MitreBadge from '@/components/analysis/MitreBadge'
import { SEV_BADGE } from '@/components/analysis/mitre'

function CvssScore({ score }) {
  if (score == null) return <span className="font-mono text-muted-foreground/60">—</span>
  const color = score >= 9 ? 'text-sev-critical'
              : score >= 7 ? 'text-sev-high'
              : score >= 4 ? 'text-sev-medium'
              : 'text-sev-low'
  return <span className={cn('font-mono font-bold', color)}>{Number(score).toFixed(1)}</span>
}

function SevBadge({ sev }) {
  const key = (sev || 'info').toLowerCase()
  return (
    <Badge variant="outline"
      className={cn('font-bold uppercase tracking-wider text-[10px]', SEV_BADGE[key] || SEV_BADGE.info)}>
      {key}
    </Badge>
  )
}

// Construye las filas de riesgo priorizado cruzando priority_order con
// enriched_findings (por ref) y los findings crudos (por dedup_key/_id).
function buildRiskRows(analysis, findings) {
  const enrichedByRef = new Map()
  for (const ef of analysis.enriched_findings || []) {
    if (ef.ref) enrichedByRef.set(ef.ref, ef)
  }
  const findingByKey = new Map()
  for (const f of findings) {
    const k = f.dedup_key || f._id
    if (k) findingByKey.set(k, f)
  }

  // Orden: priority_order si existe; si no, todas las técnicas enriquecidas.
  const order = (analysis.priority_order && analysis.priority_order.length)
    ? analysis.priority_order
    : [...enrichedByRef.keys()]

  return order.map((ref) => {
    const ef = enrichedByRef.get(ref) || {}
    const f  = findingByKey.get(ref) || {}
    return {
      ref,
      title:    f.title || f.summary || ef.note || ref,
      target:   f.target,
      port:     f.evidence?.port,
      service:  f.evidence?.service,
      severity: f.severity,
      cvss:     ef.cvss_score ?? f.cvss_score,
      technique: ef.mitre_technique || f.mitre_technique,
      cves:     ef.cve_ids || f.cve_ids || [],
      note:     ef.note,
    }
  })
}

export default function AnalysisView({ engagementId }) {
  const [analysis, setAnalysis] = useState(null)
  const [findings, setFindings] = useState([])
  const [loading,  setLoading]  = useState(true)
  const [launching, setLaunching] = useState(false)
  const [notFound, setNotFound] = useState(false)
  const [error,    setError]    = useState(null)

  const cargar = useCallback(async () => {
    if (!engagementId) return
    setLoading(true); setError(null); setNotFound(false)
    try {
      const [aRes, fRes] = await Promise.all([
        authedFetch(`/engagements/${engagementId}/analysis`),
        authedFetch(`/engagements/${engagementId}/findings`),
      ])
      if (fRes.ok) {
        const fData = await fRes.json()
        setFindings(fData.findings || [])
      }
      if (aRes.status === 404) {
        setAnalysis(null); setNotFound(true)
      } else if (aRes.ok) {
        setAnalysis(await aRes.json())
      } else {
        throw new Error(`HTTP ${aRes.status}`)
      }
    } catch (e) {
      setError(e.message || 'Error')
      setAnalysis(null)
    } finally {
      setLoading(false)
    }
  }, [engagementId])

  useEffect(() => { cargar() }, [cargar])

  const lanzarAnalisis = async () => {
    setLaunching(true)
    const tid = toast.loading('Lanzando AnalysisAgent — CVEs (NVD) + mapeo ATT&CK…')
    try {
      const res = await authedFetch(`/engagements/${engagementId}/analysis`, { method: 'POST' })
      const data = await res.json().catch(() => ({}))
      toast.dismiss(tid)
      if (!res.ok) {
        throw new Error(data?.detail || `HTTP ${res.status}`)
      }
      toast.success('Análisis completado.')
      await cargar()
    } catch (e) {
      toast.dismiss(tid)
      toast.error(`Error: ${e.message}. ¿Hay findings persistidos? Ejecuta el Scan primero.`)
    } finally {
      setLaunching(false)
    }
  }

  // ─── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-sm text-muted-foreground/70">
          Cargando análisis…
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <div className="flex items-center gap-2 rounded-md border border-destructive/40
                      bg-destructive/10 p-3 font-mono text-sm text-destructive">
        <AlertTriangle className="size-4 shrink-0" />
        No se pudo cargar el análisis: {error}
      </div>
    )
  }

  if (notFound || !analysis) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 py-16 text-center">
          <Brain className="size-12 text-muted-foreground/30" />
          <div className="text-lg font-semibold text-muted-foreground">
            Sin análisis para este engagement
          </div>
          <p className="max-w-md text-sm leading-relaxed text-muted-foreground/70">
            El <strong className="text-primary">AnalysisAgent</strong> enriquece los
            findings con CVEs reales (NVD), técnicas MITRE ATT&CK y arma las cadenas de
            ataque. Requiere findings persistidos (ejecuta el <strong>Scan</strong> antes).
          </p>
          <Button onClick={lanzarAnalisis} disabled={launching} size="lg" className="gap-2">
            <Play className={cn('size-4', launching && 'animate-pulse')} />
            {launching ? 'Analizando…' : 'Lanzar análisis'}
          </Button>
        </CardContent>
      </Card>
    )
  }

  const riskRows = buildRiskRows(analysis, findings)

  return (
    <div className="flex flex-col gap-6">

      {/* Toolbar + summary */}
      <div className="flex flex-wrap items-start gap-3">
        <div className="min-w-0 flex-1">
          {analysis.summary && (
            <div className="rounded-md border-l-4 border-l-primary bg-background p-3 text-sm text-muted-foreground">
              {analysis.summary}
            </div>
          )}
        </div>
        <Button variant="outline" size="sm" onClick={cargar} className="gap-1.5">
          <RefreshCw className="size-3.5" /> Actualizar
        </Button>
        <Button size="sm" onClick={lanzarAnalisis} disabled={launching} className="gap-1.5">
          <Play className={cn('size-3.5', launching && 'animate-pulse')} />
          {launching ? 'Analizando…' : 'Re-analizar'}
        </Button>
      </div>

      {/* Riesgo priorizado */}
      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <ListOrdered className="size-4 text-warning" />
          <h2 className="text-sm font-semibold text-foreground">Riesgo priorizado</h2>
          <Badge variant="outline" className="font-mono text-[10px]">{riskRows.length}</Badge>
        </div>
        <Card className="overflow-hidden">
          {riskRows.length === 0 ? (
            <CardContent className="py-10 text-center text-sm text-muted-foreground/70">
              El análisis no produjo findings enriquecidos.
            </CardContent>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">#</TableHead>
                  <TableHead className="w-24">Severidad</TableHead>
                  <TableHead>Finding</TableHead>
                  <TableHead>Host · Puerto</TableHead>
                  <TableHead className="w-24">MITRE</TableHead>
                  <TableHead className="w-16">CVSS</TableHead>
                  <TableHead>CVE</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {riskRows.map((r, i) => (
                  <TableRow key={r.ref}>
                    <TableCell className="font-mono text-xs font-bold text-muted-foreground">
                      {i + 1}
                    </TableCell>
                    <TableCell><SevBadge sev={r.severity} /></TableCell>
                    <TableCell className="max-w-[280px]">
                      <div className="truncate text-sm text-foreground">{r.title}</div>
                      {r.note && (
                        <div className="truncate text-[11px] text-muted-foreground/70">{r.note}</div>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      <div className="text-foreground">{r.target || '—'}</div>
                      {r.port && (
                        <div className="text-[10px] text-muted-foreground/60">
                          {r.port}{r.service ? `/${r.service}` : ''}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <MitreBadge technique={r.technique} />
                    </TableCell>
                    <TableCell><CvssScore score={r.cvss} /></TableCell>
                    <TableCell className="font-mono text-xs">
                      {r.cves.length > 0
                        ? r.cves.slice(0, 2).map((c) => (
                            <div key={c} className="text-primary">{c}</div>
                          ))
                        : <span className="text-muted-foreground/60">—</span>}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Card>
      </section>

      {/* Heatmap ATT&CK */}
      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="size-4 text-info" />
          <h2 className="text-sm font-semibold text-foreground">Cobertura MITRE ATT&CK</h2>
        </div>
        <AttackCoverageHeatmap enrichedFindings={analysis.enriched_findings || []} />
      </section>

      {/* Kill chains */}
      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <Brain className="size-4 text-primary" />
          <h2 className="text-sm font-semibold text-foreground">Vectores de ataque (kill chains)</h2>
          <Badge variant="outline" className="font-mono text-[10px]">
            {(analysis.attack_vectors || []).length}
          </Badge>
        </div>
        <KillChains vectors={analysis.attack_vectors || []} />
      </section>
    </div>
  )
}
