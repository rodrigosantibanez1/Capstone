// EngagementSetupView — "Nuevo Engagement": creación end-to-end
// (info general + scope + tácticas + ROE).
//
// Migrado a Tailwind v4 + shadcn (Card, Button, Input, Textarea, Label) + lucide-react.

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { CheckCircle2, Plus, AlertCircle } from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { ROUTES } from '@/lib/routes'
import TargetTagInput from '@/components/TargetTagInput'
import TacticsPicker  from '@/components/TacticsPicker'
import RoeBuilder, { DEFAULT_ROE } from '@/components/RoeBuilder'

import { Card, CardContent } from '@/components/ui/card'
import { Button }   from '@/components/ui/button'
import { Input }    from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label }    from '@/components/ui/label'
import { Badge }    from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const DEFAULT_TACTICS = ['TA0043', 'TA0001', 'TA0007']  // Recon + Initial Access + Discovery

// ─── Section card reutilizable ───────────────────────────────────────────────

function Section({ n, title, badge, hint, children }) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className={cn(
          'flex items-center gap-2',
          hint ? 'mb-1' : 'mb-4'
        )}>
          <div className="flex size-6 shrink-0 items-center justify-center
                          rounded-full bg-primary/15 text-sm font-bold text-primary">
            {n}
          </div>
          <span className="text-base font-bold text-foreground">{title}</span>
          {badge && (
            <Badge variant="outline"
              className="bg-destructive/15 text-destructive border-destructive/40
                         text-[10px] font-bold">
              {badge}
            </Badge>
          )}
        </div>
        {hint && (
          <div className="mb-4 ml-8 text-sm text-muted-foreground">
            {hint}
          </div>
        )}
        <div>{children}</div>
      </CardContent>
    </Card>
  )
}

// ─── Componente principal ────────────────────────────────────────────────────

export default function EngagementSetupView({ onCreated }) {
  const navigate = useNavigate()
  // Si no se pasa onCreated, default: llevar al operador DIRECTO a conversar con
  // el orquestador del engagement recién creado (Inicio con ese engagement ya
  // seleccionado en el panel del orquestador). Elimina la fricción de "crear →
  // volver a la pantalla de números → buscar en la tabla → abrir → pestaña".
  const _onCreated = onCreated || ((id) =>
    navigate(id ? ROUTES.homeWith(id) : ROUTES.home))

  const [nombre,        setNombre]    = useState('')
  const [descripcion,   setDesc]      = useState('')
  const [clienteNombre, setCliente]   = useState('')
  const [targets,       setTargets]   = useState([])
  const [scopeError,    setScopeError]= useState('')
  const [tactics,       setTactics]   = useState(DEFAULT_TACTICS)
  const [roe,           setRoe]       = useState(DEFAULT_ROE)
  const [enviando,      setEnviando]  = useState(false)
  const [exito,         setExito]     = useState(false)
  const [submitError,   setSubmitError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setScopeError(''); setSubmitError('')
    if (!nombre.trim()) {
      setSubmitError('El nombre del engagement es requerido')
      return
    }
    if (targets.length === 0) {
      setScopeError('Agrega al menos un target al scope')
      return
    }
    setEnviando(true)
    const tid = toast.loading(`Creando engagement "${nombre.trim()}"…`)
    try {
      const payload = {
        name:          nombre.trim(),
        description:   descripcion.trim() || null,
        client_name:   clienteNombre.trim() || null,
        scope_targets: targets.map((t) => ({ target_value: t.value, target_type: t.type })),
        roe,
        att_tactics:   tactics.length > 0 ? tactics : null,
      }
      const res = await authedFetch('/engagements', {
        method: 'POST',
        body: JSON.stringify(payload),
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.detail || `HTTP ${res.status}`)
      }
      const created = await res.json().catch(() => ({}))
      toast.dismiss(tid)
      toast.success(`Engagement "${nombre.trim()}" creado`)
      setExito(true)
      setTimeout(() => _onCreated(created?.id), 1500)
    } catch (err) {
      toast.dismiss(tid)
      toast.error(`Error al crear: ${err.message}`)
      setSubmitError(err.message || 'Error al crear el engagement')
    } finally {
      setEnviando(false)
    }
  }

  // ── Pantalla de éxito ──────────────────────────────────────────────────
  if (exito) return (
    <div className="flex h-[60vh] flex-col items-center justify-center gap-3">
      <CheckCircle2 className="size-12 text-success" />
      <div className="text-2xl font-bold text-success">Engagement creado</div>
      <div className="text-muted-foreground">Abriendo el orquestador…</div>
    </div>
  )

  return (
    <div className="flex flex-col gap-6">

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Nuevo Engagement</h1>
        <p className="mt-0.5 text-sm text-muted-foreground">
          Define el scope, las tácticas ATT&CK y las ROE antes de iniciar el pipeline.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-6">

        {/* ── 1. Info general ── */}
        <Section n={1} title="Información general"
          hint="Identifica el engagement y su contexto.">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[240px] space-y-1.5">
              <Label htmlFor="eng-name">Nombre del engagement *</Label>
              <Input id="eng-name" required value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Ej: Lab Metasploitable2 — Pentesting Q2 2026" />
            </div>
            <div className="flex-1 min-w-[180px] space-y-1.5">
              <Label htmlFor="eng-client">Cliente / Organización</Label>
              <Input id="eng-client" value={clienteNombre}
                onChange={(e) => setCliente(e.target.value)}
                placeholder="DUOC UC — Lab" />
            </div>
          </div>
          <div className="mt-4 space-y-1.5">
            <Label htmlFor="eng-desc">Descripción</Label>
            <Textarea id="eng-desc" value={descripcion}
              onChange={(e) => setDesc(e.target.value)}
              placeholder="Objetivo del análisis, alcance general, contexto…"
              rows={3}
              className="resize-y" />
          </div>
        </Section>

        {/* ── 2. Scope ── */}
        <Section n={2} title="Scope — Targets autorizados" badge="REQUERIDO"
          hint="IPs, CIDRs o dominios autorizados para el pipeline. El tipo se detecta automáticamente.">
          <TargetTagInput
            value={targets}
            onChange={(v) => { setTargets(v); setScopeError('') }}
            disabled={enviando}
          />
          {scopeError && (
            <div className="mt-2 flex items-center gap-1 text-sm text-destructive">
              <AlertCircle className="size-3.5" /> {scopeError}
            </div>
          )}
        </Section>

        {/* ── 3. ATT&CK ── */}
        <Section n={3} title="Tácticas ATT&CK habilitadas"
          hint="Solo las tácticas seleccionadas serán autorizadas. Mínimo recomendado: Reconnaissance + Discovery.">
          <TacticsPicker value={tactics} onChange={setTactics} disabled={enviando} />
        </Section>

        {/* ── 4. ROE ── */}
        <Section n={4} title="Rules of Engagement (ROE)"
          hint="Intensidad de escaneo, paths excluidos y límites de velocidad. La ejecución ocurre cuando el operador inicia el pipeline. El schema se valida antes de persistir.">
          <RoeBuilder value={roe} onChange={setRoe} mode="edit" />
        </Section>

        {/* Error de submit */}
        {submitError && (
          <div className="flex items-center gap-2 rounded-md border border-destructive/40
                          bg-destructive/10 p-3 font-mono text-sm text-destructive">
            <AlertCircle className="size-4 shrink-0" />
            {submitError}
          </div>
        )}

        {/* Botones — sticky bottom */}
        <div className="sticky bottom-0 z-10 -mx-10 flex justify-end gap-2 border-t border-border
                        bg-background px-10 py-4">
          <Button type="button" variant="ghost" disabled={enviando}
            onClick={() => _onCreated()}>
            Cancelar
          </Button>
          <Button type="submit"
            disabled={enviando || targets.length === 0 || !nombre.trim()}
            size="lg" className="gap-2">
            <Plus className="size-4" />
            {enviando ? 'Creando engagement…' : 'Crear Engagement'}
          </Button>
        </div>
      </form>
    </div>
  )
}
