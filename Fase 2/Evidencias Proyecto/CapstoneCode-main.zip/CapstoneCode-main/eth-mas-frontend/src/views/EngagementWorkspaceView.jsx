// EngagementWorkspaceView — Espacio de trabajo centrado en un engagement.
// Reemplaza 4-5 entradas planas del sidebar por una vista con tabs:
//   - Overview     (scope + ROE + tácticas)
//   - Pipeline     (orquestador + live stages)
//   - Surface Map  (recon consolidado)
//   - Findings     (hallazgos del scan)
//   - Reports      (generación de informes)
//
// El engagement activo se elige una vez con EngagementSelector y se propaga
// a todas las tabs (cada vista recibe `engagementId` + `embedded={true}`).

import { useState, useEffect, useCallback } from 'react'
import { useParams, useSearchParams, useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import {
  Target, Play, Network, Flag, FileText, Folder, Bot, Brain, Lock,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { ROUTES } from '@/lib/routes'
import EngagementSelector from '@/components/EngagementSelector'
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'

import EngagementsView       from './EngagementsView'
import OrchestratorChatView  from './OrchestratorChatView'
import PipelineView          from './PipelineView'
import SurfaceMapView      from './SurfaceMapView'
import HallazgosView       from './HallazgosView'
import AnalysisView        from './AnalysisView'
import { ReportesViewBody } from './ReportesView'

export default function EngagementWorkspaceView() {
  // engagementId viene del path: /workspace/:engagementId (puede ser undefined)
  const { engagementId: paramId } = useParams()
  const [searchParams, setSearchParams] = useSearchParams()
  const navigate = useNavigate()

  // Parseo a number (los params siempre vienen como string)
  const engagementId = paramId != null ? Number(paramId) : null

  const [meta, setMeta] = useState(null)
  const [closeConfirm, setCloseConfirm] = useState(false)
  const [closing, setClosing] = useState(false)

  // Tab persiste en ?tab=overview|pipeline|surface|findings|reports
  const tab = searchParams.get('tab') || 'overview'
  const setTab = (newTab) => {
    setSearchParams((prev) => {
      const p = new URLSearchParams(prev)
      if (newTab === 'overview') p.delete('tab')    // default → URL limpia
      else p.set('tab', newTab)
      return p
    }, { replace: true })
  }

  // Cambiar engagement = nueva URL (preserva tab actual)
  const selectEngagement = (id) => {
    const qs = tab !== 'overview' ? `?tab=${tab}` : ''
    navigate(`${ROUTES.workspaceFor(id)}${qs}`)
  }

  // Cargar metadata del engagement seleccionado (para mostrar en header)
  const refreshMeta = useCallback(() => {
    if (!engagementId) { setMeta(null); return }
    authedFetch(`/engagements/${engagementId}`)
      .then((r) => (r.ok ? r.json() : null))
      .then(setMeta)
      .catch(() => setMeta(null))
  }, [engagementId])

  useEffect(() => { refreshMeta() }, [refreshMeta])

  const onNuevoEngagement = () => navigate(ROUTES.engagementNew)

  // Cerrar engagement (BUG-2): única transición legal a 'completed' es desde
  // 'running'. El backend nunca cierra solo — el operador decide aquí.
  const confirmarCierre = async () => {
    setClosing(true)
    const tid = toast.loading('Cerrando engagement…')
    try {
      const res = await authedFetch(`/engagements/${engagementId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'completed' }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        throw new Error(
          typeof data?.detail === 'string' ? data.detail : `HTTP ${res.status}`,
        )
      }
      toast.dismiss(tid)
      toast.success('Engagement cerrado (completed)')
      refreshMeta()
    } catch (e) {
      toast.dismiss(tid)
      toast.error(`Error al cerrar: ${e.message}`)
    } finally {
      setClosing(false)
      setCloseConfirm(false)
    }
  }

  // ─── Render ──────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col gap-6">

      {/* Header global con selector */}
      <div className="flex flex-wrap items-start gap-4">
        <div className="min-w-0">
          <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
            <Folder className="size-6 text-primary" />
            Workspace
          </h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {meta
              ? <>Engagement <strong className="text-foreground">{meta.name}</strong> · {meta.status}</>
              : 'Selecciona un engagement para comenzar'}
          </p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {meta?.status === 'running' && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCloseConfirm(true)}
              className="gap-1.5 text-success border-success/40 hover:bg-success/10"
            >
              <Lock className="size-3.5" />
              Cerrar engagement
            </Button>
          )}
          <EngagementSelector
            value={engagementId}
            onChange={(id) => selectEngagement(id)}
            onCreateNew={onNuevoEngagement}
          />
        </div>
      </div>

      {/* Modal de confirmación de cierre (BUG-2) */}
      <Dialog open={closeConfirm} onOpenChange={(o) => { if (!o) setCloseConfirm(false) }}>
        <DialogContent className="sm:max-w-[420px] border-success/40">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-success">
              <Lock className="size-5" />
              Cerrar Engagement
            </DialogTitle>
            <DialogDescription className="leading-relaxed">
              Esta acción transiciona el engagement a <strong>completed</strong>,
              un estado terminal: no admitirá nuevas corridas del pipeline.
              Los findings y reportes ya generados se conservan. ¿Confirmas?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="ghost" onClick={() => setCloseConfirm(false)}>
              Cancelar
            </Button>
            <Button
              onClick={confirmarCierre}
              disabled={closing}
              className="gap-2 bg-success text-success-foreground hover:bg-success/90"
            >
              <Lock className="size-4" />
              {closing ? 'Cerrando…' : 'Sí, cerrar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Sin engagement seleccionado */}
      {!engagementId ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-16 text-center">
            <Folder className="size-10 text-muted-foreground/30" />
            <div className="text-sm font-semibold text-muted-foreground">
              Selecciona un engagement
            </div>
            <div className="max-w-md text-xs text-muted-foreground/70">
              Usa el selector arriba para elegir uno existente, o crea uno nuevo.
              Todas las sub-vistas (scope, pipeline, surface map, findings, reportes)
              operan sobre el engagement seleccionado.
            </div>
          </CardContent>
        </Card>
      ) : (
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="w-full justify-start overflow-x-auto">
            <TabsTrigger value="overview" className="gap-1.5">
              <Target className="size-3.5" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="orchestrator" className="gap-1.5">
              <Bot className="size-3.5" />
              Orquestador
            </TabsTrigger>
            <TabsTrigger value="pipeline" className="gap-1.5">
              <Play className="size-3.5" />
              Pipeline
            </TabsTrigger>
            <TabsTrigger value="surface" className="gap-1.5">
              <Network className="size-3.5" />
              Surface Map
            </TabsTrigger>
            <TabsTrigger value="findings" className="gap-1.5">
              <Flag className="size-3.5" />
              Findings
              {meta?.findings_count != null && meta.findings_count > 0 && (
                <Badge variant="outline" className="ml-1 text-[10px] font-mono px-1.5 py-0">
                  {meta.findings_count}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="analysis" className="gap-1.5">
              <Brain className="size-3.5" />
              Analysis
            </TabsTrigger>
            <TabsTrigger value="reports" className="gap-1.5">
              <FileText className="size-3.5" />
              Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <EngagementsView
              embedded
              forcedEngagementId={engagementId}
              onNuevoEngagement={onNuevoEngagement}
            />
          </TabsContent>

          <TabsContent value="orchestrator" className="mt-6">
            <OrchestratorChatView engagementId={engagementId} embedded />
          </TabsContent>

          <TabsContent value="pipeline" className="mt-6">
            <PipelineView
              engagementId={engagementId}
              embedded
              onEngagementUpdated={refreshMeta}
            />
          </TabsContent>

          <TabsContent value="surface" className="mt-6">
            <SurfaceMapView engagementId={engagementId} embedded />
          </TabsContent>

          <TabsContent value="findings" className="mt-6">
            <HallazgosView engagementId={engagementId} embedded />
          </TabsContent>

          <TabsContent value="analysis" className="mt-6">
            <AnalysisView engagementId={engagementId} embedded />
          </TabsContent>

          <TabsContent value="reports" className="mt-6">
            <ReportesViewBody engagementId={engagementId} embedded />
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}
