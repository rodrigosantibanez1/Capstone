// EngagementsView — "Scope Activo": gestión de targets del engagement
// seleccionado. Usa los componentes compartidos.
//
// Migrado a Tailwind v4 + shadcn + lucide-react + toast (sonner).

import { useState, useEffect, useCallback } from 'react'
import { toast } from 'sonner'
import {
  Target, AlertTriangle, ShieldCheck, Trash2, Plus,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import EngagementSelector from '@/components/EngagementSelector'
import TargetTagInput, { TARGET_TYPE_STYLE } from '@/components/TargetTagInput'
import RoeBuilder from '@/components/RoeBuilder'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge }  from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { cn } from '@/lib/utils'

export default function EngagementsView({
  onNuevoEngagement,
  embedded = false,
  forcedEngagementId = null,    // si viene del Workspace, fijar el engagement
} = {}) {
  const [engagementId, setEngagementId] = useState(forcedEngagementId)
  const [engagement,   setEngagement]   = useState(null)
  const [scopes,       setScopes]       = useState([])
  const [pendingAdds,  setPendingAdds]  = useState([])
  const [loading,      setLoading]      = useState(false)
  const [error,        setError]        = useState(null)
  const [saving,       setSaving]       = useState(false)

  // ── Cargar engagement + scopes ──────────────────────────────────────────
  const fetchData = useCallback(async () => {
    if (!engagementId) return
    setLoading(true); setError(null)
    try {
      const [engRes, scopeRes] = await Promise.all([
        authedFetch(`/engagements/${engagementId}`),
        authedFetch(`/engagements/${engagementId}/scope`),
      ])
      if (!engRes.ok)   throw new Error(`HTTP ${engRes.status}`)
      if (!scopeRes.ok) throw new Error(`HTTP ${scopeRes.status}`)
      setEngagement(await engRes.json())
      const scopeData = await scopeRes.json()
      setScopes(scopeData.data || [])
    } catch (e) {
      setError(e.message || 'Error')
      setEngagement(null); setScopes([])
    } finally {
      setLoading(false)
    }
  }, [engagementId])

  useEffect(() => { fetchData() }, [fetchData])

  // ── Guardar tags pendientes ─────────────────────────────────────────────
  const saveAll = async () => {
    if (pendingAdds.length === 0 || !engagementId) return
    setSaving(true)
    const tid = toast.loading(`Guardando ${pendingAdds.length} target(s)…`)
    let okCount = 0, failCount = 0
    for (const t of pendingAdds) {
      try {
        const res = await authedFetch(`/engagements/${engagementId}/scope`, {
          method: 'POST',
          body: JSON.stringify({ target_value: t.value, target_type: t.type }),
        })
        if (res.ok) okCount++; else failCount++
      } catch { failCount++ }
    }
    setSaving(false)
    setPendingAdds([])
    toast.dismiss(tid)
    if (failCount === 0) {
      toast.success(`${okCount} target${okCount > 1 ? 's' : ''} agregado${okCount > 1 ? 's' : ''} al scope.`)
    } else {
      toast.error(`${okCount} agregados, ${failCount} fallaron.`)
    }
    fetchData()
  }

  const deleteTarget = async (id) => {
    if (!confirm('¿Eliminar este target del scope?')) return
    try {
      const res = await authedFetch(`/engagements/${engagementId}/scope/${id}`, {
        method: 'DELETE',
      })
      if (res.ok) {
        toast.success('Target eliminado.')
        fetchData()
      } else {
        toast.error(`Error al eliminar (HTTP ${res.status}).`)
      }
    } catch (e) {
      toast.error(`Error: ${e.message}`)
    }
  }

  const isRunning = engagement?.status === 'running'

  return (
    <div className="flex flex-col gap-6">

      {/* Header (oculto en modo embedded — el Workspace ya muestra el contexto) */}
      {!embedded && (
        <div className="flex flex-wrap items-end gap-4">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
              <Target className="size-6 text-primary" />
              Scope Activo
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Gestión de targets autorizados del engagement seleccionado
            </p>
          </div>
          <div className="ml-auto">
            <EngagementSelector
              value={engagementId}
              onChange={(id) => setEngagementId(id)}
              onCreateNew={onNuevoEngagement}
            />
          </div>
        </div>
      )}

      {/* Sin engagement seleccionado */}
      {!engagementId && !loading && (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <Target className="size-8 text-muted-foreground/30" />
            <div className="text-sm font-semibold text-muted-foreground">
              Selecciona un engagement
            </div>
            <div className="text-xs text-muted-foreground/70">
              Usa el selector arriba o crea uno nuevo.
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error */}
      {error && (
        <div className="flex items-center gap-2 rounded-md border border-destructive/40
                        bg-destructive/10 p-3 font-mono text-sm text-destructive">
          <AlertTriangle className="size-4 shrink-0" />
          {error}
        </div>
      )}

      {engagementId && engagement && (
        <>
          {/* Stats */}
          <div className="flex flex-wrap gap-4">
            {[
              { label: 'Estado', value: engagement.status?.toUpperCase() || '—',
                className: isRunning ? 'text-warning' : 'text-foreground' },
              { label: 'Targets en scope', value: scopes.length,
                className: scopes.length > 0 ? 'text-success' : 'text-warning' },
              { label: 'Por guardar', value: pendingAdds.length,
                className: pendingAdds.length > 0 ? 'text-primary' : 'text-muted-foreground/60' },
              { label: 'Tácticas ATT&CK', value: (engagement.att_tactics || []).length,
                className: 'text-info' },
            ].map((s) => (
              <Card key={s.label} className="flex-1 min-w-[120px]">
                <CardContent className="p-4">
                  <div className="mb-1 text-[10px] text-muted-foreground/70">
                    {s.label}
                  </div>
                  <div className={cn('text-2xl font-extrabold leading-none', s.className)}>
                    {s.value}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Tag input */}
          <Card>
            <CardContent className="p-5 space-y-4">
              <div className="text-sm font-semibold text-foreground">
                Agregar targets al scope
              </div>
              <TargetTagInput
                value={pendingAdds}
                onChange={setPendingAdds}
                disabled={saving}
                placeholder="192.168.56.101, 192.168.56.0/24, vulnsite.com…"
              />
              {pendingAdds.length > 0 && (
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="ghost" onClick={() => setPendingAdds([])}
                    disabled={saving}>
                    Descartar
                  </Button>
                  <Button type="button" onClick={saveAll} disabled={saving} className="gap-1.5">
                    <Plus className="size-4" />
                    {saving ? 'Guardando…' : `Agregar ${pendingAdds.length} al scope`}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Tabla de scopes persistidos */}
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between border-b border-border
                            px-4 py-2.5">
              <span className="text-sm font-semibold text-foreground">
                Targets persistidos
              </span>
              <Badge variant="outline"
                className="bg-primary/15 text-primary border-primary/40 font-bold">
                {scopes.length}
              </Badge>
            </div>

            {loading ? (
              <CardContent className="py-10 text-center text-sm text-muted-foreground/70">
                Cargando scope…
              </CardContent>
            ) : scopes.length === 0 ? (
              <CardContent className="py-10 text-center text-muted-foreground">
                <div className="text-sm">
                  Aún no hay targets persistidos en el scope.
                </div>
                <div className="mt-1 text-xs text-muted-foreground/70">
                  Usa el input arriba para agregarlos.
                </div>
              </CardContent>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">ID</TableHead>
                    <TableHead>Target</TableHead>
                    <TableHead className="w-24">Tipo</TableHead>
                    <TableHead className="w-24 text-right">Acción</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scopes.map((obj) => {
                    const tipo = (obj.target_type || '').toLowerCase()
                    const badgeStyle = TARGET_TYPE_STYLE[tipo]?.class
                      || 'bg-muted text-muted-foreground border-border'
                    const label = TARGET_TYPE_STYLE[tipo]?.label || tipo.toUpperCase()
                    return (
                      <TableRow key={obj.id}>
                        <TableCell className="font-mono text-xs text-muted-foreground/70">
                          #{obj.id}
                        </TableCell>
                        <TableCell className="font-mono font-semibold text-foreground">
                          {obj.target_value}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline"
                            className={cn('font-mono uppercase tracking-wider text-[10px]', badgeStyle)}>
                            {label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="xs"
                            onClick={() => deleteTarget(obj.id)}
                            className="gap-1 border-destructive/40 text-destructive
                                       hover:bg-destructive/10 hover:text-destructive">
                            <Trash2 className="size-3" />
                            Eliminar
                          </Button>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            )}
          </Card>

          {/* Tácticas ATT&CK */}
          {engagement.att_tactics && engagement.att_tactics.length > 0 && (
            <Card>
              <CardContent className="p-5">
                <div className="text-sm font-semibold text-foreground">
                  Tácticas ATT&CK habilitadas
                </div>
                <div className="mt-1 mb-3 text-xs text-muted-foreground/70">
                  Solo estas tácticas son autorizadas en el engagement (read-only).
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {engagement.att_tactics.map((tid) => (
                    <Badge key={tid} variant="outline"
                      className="bg-info/15 text-info border-info/40 font-mono text-[10px] font-bold">
                      {tid}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* ROE read-only */}
          {engagement.roe && (
            <Card>
              <CardContent className="p-5">
                <div className="mb-3 flex items-center gap-2">
                  <span className="text-sm font-semibold text-foreground">
                    Rules of Engagement (ROE)
                  </span>
                  <Badge variant="outline" className="font-mono text-[10px]">
                    read-only
                  </Badge>
                  <span className="ml-auto text-xs text-muted-foreground/70">
                    Para modificar, crea un nuevo engagement
                  </span>
                </div>
                <Separator className="mb-4" />
                <RoeBuilder value={engagement.roe} mode="view" />
              </CardContent>
            </Card>
          )}

          {/* Scope enforcement banner */}
          <div className="flex items-start gap-3 rounded-md border border-border
                          border-l-4 border-l-warning bg-sidebar p-4">
            <ShieldCheck className="mt-0.5 size-5 shrink-0 text-warning" />
            <div>
              <div className="text-sm font-semibold text-warning">
                Scope Enforcement activo
              </div>
              <div className="mt-0.5 text-sm text-muted-foreground">
                Todas las acciones de los agentes son validadas contra este scope
                ANTES de ejecutarse. Targets fuera del scope son bloqueados
                automáticamente por{' '}
                <code className="font-mono text-primary">@enforce_scope</code>.
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
