// HallazgosView — Tabla de findings normalizados con filtros, paginación
// y badges de severidad/CVSS.
//
// Migrado a Tailwind v4 + shadcn (Card, Table, Select, Badge, Button) + lucide-react.

import { useState, useEffect, useCallback } from 'react'
import {
  Flag, RefreshCw, AlertTriangle, Search,
  ChevronLeft, ChevronRight,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input }  from '@/components/ui/input'
import { Badge }  from '@/components/ui/badge'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { cn } from '@/lib/utils'

const ENGAGEMENT_ID = 1
const POR_PAGINA = 10

// ─── Estilos por severidad ──────────────────────────────────────────────────

const SEV_STYLE = {
  critical: { class: 'bg-sev-critical/15 text-sev-critical border-sev-critical/40', label: 'CRITICAL' },
  high:     { class: 'bg-sev-high/15 text-sev-high border-sev-high/40',             label: 'HIGH' },
  medium:   { class: 'bg-sev-medium/15 text-sev-medium border-sev-medium/40',       label: 'MEDIUM' },
  low:      { class: 'bg-sev-low/15 text-sev-low border-sev-low/40',                label: 'LOW' },
  info:     { class: 'bg-muted text-muted-foreground border-border',                label: 'INFO' },
}

const MITRE_NAMES = {
  T1190: 'Exploit Public App', T1210: 'Exploit Remote Svc',
  T1078: 'Valid Accounts',     T1110: 'Brute Force',
  T1021: 'Remote Services',    T1083: 'File Discovery',
  T1040: 'Network Sniffing',   T1082: 'System Info',
}

function SevBadge({ sev }) {
  const s = SEV_STYLE[sev?.toLowerCase()] || SEV_STYLE.info
  return (
    <Badge variant="outline"
      className={cn('font-bold tracking-wider', s.class)}>
      {s.label}
    </Badge>
  )
}

function CvssScore({ score }) {
  if (score == null) return <span className="font-mono text-muted-foreground/60">—</span>
  const color = score >= 9 ? 'text-sev-critical'
              : score >= 7 ? 'text-sev-high'
              : score >= 4 ? 'text-sev-medium'
              : 'text-sev-low'
  return (
    <span className={cn('font-mono font-bold', color)}>
      {Number(score).toFixed(1)}
    </span>
  )
}

// ─── Vista ───────────────────────────────────────────────────────────────────

export default function HallazgosView({ engagementId = ENGAGEMENT_ID, embedded = false }) {
  const [findings, setFindings] = useState([])
  const [loading,  setLoading]  = useState(true)
  const [error,    setError]    = useState(null)
  const [filSev,   setFilSev]   = useState('todos')
  const [filStatus,setFilStatus]= useState('todos')
  const [busqueda, setBusqueda] = useState('')
  const [pagina,   setPagina]   = useState(1)

  const cargar = useCallback(async () => {
    setLoading(true); setError(null)
    try {
      const res = await authedFetch(`/engagements/${engagementId}/findings`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setFindings(data.findings || [])
    } catch (e) {
      setFindings([])
      setError(e.message || 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }, [engagementId])

  useEffect(() => { cargar() }, [cargar])

  // Filtros
  const filtrados = findings.filter((f) => {
    if (filSev    !== 'todos' && (f.severity || '').toLowerCase() !== filSev)   return false
    if (filStatus !== 'todos' && (f.status   || '').toLowerCase() !== filStatus) return false
    if (busqueda) {
      const q = busqueda.toLowerCase()
      return (
        (f.cve_ids || []).join(' ').toLowerCase().includes(q) ||
        (f.target  || '').toLowerCase().includes(q) ||
        (f.title   || '').toLowerCase().includes(q) ||
        (f.mitre_technique || '').toLowerCase().includes(q)
      )
    }
    return true
  })

  const totalPaginas = Math.max(1, Math.ceil(filtrados.length / POR_PAGINA))
  const items = filtrados.slice((pagina - 1) * POR_PAGINA, pagina * POR_PAGINA)

  return (
    <div className="flex flex-col gap-6">

      {/* Header (oculto en modo embedded) */}
      {!embedded ? (
        <div className="flex items-center gap-4">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
              <Flag className="size-6 text-warning" />
              Hallazgos
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Engagement #{engagementId}
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Button type="button" variant="outline" size="sm"
              onClick={cargar} disabled={loading} className="gap-1.5">
              <RefreshCw className={cn('size-3.5', loading && 'animate-spin')} />
              Actualizar
            </Button>
            <Badge variant="outline"
              className="bg-primary/15 text-primary border-primary/40 font-bold text-sm py-1 px-3">
              {findings.length} findings
            </Badge>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-end gap-2">
          <Button type="button" variant="outline" size="sm"
            onClick={cargar} disabled={loading} className="gap-1.5">
            <RefreshCw className={cn('size-3.5', loading && 'animate-spin')} />
            Actualizar
          </Button>
          <Badge variant="outline"
            className="bg-primary/15 text-primary border-primary/40 font-bold text-sm py-1 px-3">
            {findings.length} findings
          </Badge>
        </div>
      )}

      {/* Filtros */}
      <Card>
        <CardContent className="flex flex-wrap items-center gap-3 p-4">
          <Select value={filSev}
            onValueChange={(v) => { setFilSev(v); setPagina(1) }}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Severidad: Todos</SelectItem>
              {['critical', 'high', 'medium', 'low', 'info'].map((s) => (
                <SelectItem key={s} value={s}>{s.toUpperCase()}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filStatus}
            onValueChange={(v) => { setFilStatus(v); setPagina(1) }}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Estado: Todos</SelectItem>
              {['open', 'closed', 'false_positive'].map((s) => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="relative flex-1 min-w-[220px]">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5
                               -translate-y-1/2 text-muted-foreground/70" />
            <Input type="text"
              placeholder="Buscar CVE, host, título, MITRE…"
              value={busqueda}
              onChange={(e) => { setBusqueda(e.target.value); setPagina(1) }}
              className="pl-8"
            />
          </div>

          <span className="text-xs text-muted-foreground/70 whitespace-nowrap">
            {filtrados.length} resultado{filtrados.length !== 1 ? 's' : ''}
          </span>
        </CardContent>
      </Card>

      {/* Error banner */}
      {error && !loading && (
        <div className="flex items-center gap-2 rounded-md border border-destructive/40
                        bg-destructive/10 p-3 font-mono text-sm text-destructive">
          <AlertTriangle className="size-4 shrink-0" />
          No se pudo conectar al backend: {error}
        </div>
      )}

      {/* Tabla */}
      <Card className="overflow-hidden">
        {loading ? (
          <CardContent className="py-12 text-center text-sm text-muted-foreground/70">
            Cargando findings desde el backend…
          </CardContent>
        ) : !error && findings.length === 0 ? (
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <Flag className="size-8 text-muted-foreground/30" />
            <div className="text-sm font-semibold text-muted-foreground">
              Aún no hay findings para este engagement
            </div>
            <div className="text-xs text-muted-foreground/70">
              Ejecuta <code className="font-mono text-primary">POST /scan</code> desde
              la vista <strong>Pipeline</strong> para poblar la tabla.
            </div>
          </CardContent>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-24">Severidad</TableHead>
                <TableHead>CVE</TableHead>
                <TableHead>Host · Puerto</TableHead>
                <TableHead>Título</TableHead>
                <TableHead className="w-24">MITRE</TableHead>
                <TableHead className="w-16">CVSS</TableHead>
                <TableHead className="w-24">Estado</TableHead>
                <TableHead className="w-20">Tool</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="py-10 text-center text-muted-foreground/70">
                    Sin resultados para los filtros aplicados.
                  </TableCell>
                </TableRow>
              ) : (
                items.map((f, i) => {
                  const port = f.evidence?.port
                  const svc  = f.evidence?.service
                  // Preferimos cve_details (trae el confidence gate por CVE);
                  // excluimos los keyword-only (no aplicables). Fallback: cve_ids.
                  const cves = (Array.isArray(f.cve_details) && f.cve_details.length
                    ? f.cve_details
                        .filter((d) => (d.confidence || '').toLowerCase() !== 'keyword-only')
                        .map((d) => ({ id: d.cve_id, confirmed: (d.confidence || '').toLowerCase() === 'confirmed' }))
                    : (f.cve_ids || []).map((c) => ({ id: c, confirmed: false }))
                  ).slice(0, 2)
                  return (
                    <TableRow key={f._id || i}>
                      <TableCell><SevBadge sev={f.severity} /></TableCell>
                      <TableCell className="font-mono text-xs">
                        {cves.length > 0
                          ? cves.map((c) => (
                              <div key={c.id} className="flex items-center gap-1 text-primary">
                                <span>{c.id}</span>
                                <span
                                  title={c.confirmed ? 'Versión confirmada (CPE match)' : 'Sin confirmar (versión no validada)'}
                                  className={cn(
                                    'rounded-sm px-1 text-[9px] font-semibold uppercase',
                                    c.confirmed
                                      ? 'bg-success/15 text-success'
                                      : 'bg-warning/15 text-warning'
                                  )}>
                                  {c.confirmed ? '✓' : '?'}
                                </span>
                              </div>
                            ))
                          : <span className="text-muted-foreground/60">—</span>}
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        <div className="text-foreground">{f.target}</div>
                        {port && (
                          <div className="text-[10px] text-muted-foreground/60">
                            {port}/{svc}
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="max-w-[260px] text-sm text-muted-foreground">
                        {f.title}
                      </TableCell>
                      <TableCell>
                        {f.mitre_technique
                          ? (
                            <span
                              title={MITRE_NAMES[f.mitre_technique] || f.mitre_technique}
                              className="cursor-help rounded-sm border border-border
                                         bg-background px-2 py-0.5 font-mono text-xs text-muted-foreground">
                              {f.mitre_technique}
                            </span>
                          )
                          : <span className="text-muted-foreground/60">—</span>}
                      </TableCell>
                      <TableCell><CvssScore score={f.cvss_score} /></TableCell>
                      <TableCell>
                        <Badge variant="outline"
                          className={cn(
                            'font-semibold uppercase tracking-wider text-[10px]',
                            f.status === 'open'
                              ? 'bg-warning/15 text-warning border-warning/40'
                              : 'bg-success/15 text-success border-success/40'
                          )}>
                          {f.status || 'open'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-info">
                        {f.tool || 'nmap'}
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        )}
      </Card>

      {/* Paginación */}
      {totalPaginas > 1 && (
        <div className="flex items-center justify-end gap-3">
          <span className="text-xs text-muted-foreground/70">
            Página {pagina} de {totalPaginas}
          </span>
          <Button type="button" variant="outline" size="sm"
            disabled={pagina === 1}
            onClick={() => setPagina((p) => p - 1)}
            className="gap-1">
            <ChevronLeft className="size-3.5" /> Anterior
          </Button>
          <Button type="button" variant="outline" size="sm"
            disabled={pagina === totalPaginas}
            onClick={() => setPagina((p) => p + 1)}
            className="gap-1">
            Siguiente <ChevronRight className="size-3.5" />
          </Button>
        </div>
      )}
    </div>
  )
}
