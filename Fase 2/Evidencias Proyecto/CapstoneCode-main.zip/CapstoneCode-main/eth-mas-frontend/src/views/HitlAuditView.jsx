// HitlAuditView — Bitácora inmutable de decisiones HITL.
// Vista alternable tabla / timeline, filtros, export CSV.
//
// Migrado a Tailwind v4 + shadcn (Card, Select, Tabs, Table, Button) + lucide-react.

import { useState, useEffect } from 'react'
import { toast } from 'sonner'
import {
  Download, Filter, Table as TableIcon, List, ScrollText,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge }  from '@/components/ui/badge'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { cn } from '@/lib/utils'

// ─── Normalización ───────────────────────────────────────────────────────────

function normalise(r, engagementId) {
  return {
    id:           r.id ? `HITL-${String(r.id).padStart(3, '0')}` : '—',
    engagementId: engagementId ?? r.engagement_id ?? '—',
    ts:           r.decided_at || r.requested_at || '—',
    agente:       r.agent || '—',
    tool:         r.tool  || '—',
    riskLevel:    (r.risk_level || 'low').toUpperCase(),
    decision:     decisionLabel(r.decision),
    isPending:    r.decision == null,
    operador:     r.operator || (r.decision == null ? '—' : 'Sistema'),
    notas:        r.notes || '',
  }
}

function decisionLabel(val) {
  if (val == null) return 'PENDIENTE'
  const v = String(val).toUpperCase()
  if (v === 'APPROVED')      return 'APROBADO'
  if (v === 'AUTO-APPROVED') return 'AUTO-APROBADO'
  if (v === 'REJECTED')      return 'RECHAZADO'
  if (v === 'PENDING')       return 'PENDIENTE'
  return v
}

// ─── Badges ──────────────────────────────────────────────────────────────────

const RISK_STYLE = {
  CRITICAL: 'bg-destructive/15 text-destructive border-destructive/40',
  HIGH:     'bg-sev-high/15 text-sev-high border-sev-high/40',
  MEDIUM:   'bg-warning/15 text-warning border-warning/40',
  LOW:      'bg-info/15 text-info border-info/40',
}

function RiskBadge({ level }) {
  const cls = RISK_STYLE[level] || RISK_STYLE.LOW
  return (
    <Badge variant="outline"
      className={cn('font-mono uppercase tracking-wider text-[10px]', cls)}>
      {level}
    </Badge>
  )
}

function DecisionBadge({ decision }) {
  const isAuto    = decision === 'AUTO-APROBADO'
  const isAprob   = decision === 'APROBADO' || isAuto
  const isPending = decision === 'PENDIENTE'
  const cls = isPending
    ? 'bg-warning/15 text-warning border-warning/40'
    : isAprob
      ? 'bg-success/15 text-success border-success/40'
      : 'bg-destructive/15 text-destructive border-destructive/40'
  return (
    <Badge variant="outline"
      className={cn('font-mono uppercase tracking-wider text-[10px]', cls, isAuto && 'opacity-70')}>
      {decision}
    </Badge>
  )
}

// ─── Export CSV ──────────────────────────────────────────────────────────────

function descargarCSV(data) {
  const cols = ['ID','Engagement','Timestamp','Agente','Tool','Risk Level','Decisión','Operador','Notas']
  const rows = data.map((r) =>
    [r.id, r.engagementId, r.ts, r.agente, r.tool, r.riskLevel, r.decision, r.operador, r.notas]
      .map((v) => `"${String(v).replace(/"/g, '""')}"`)
      .join(',')
  )
  const csv  = [cols.join(','), ...rows].join('\n')
  const blob = new Blob([csv], { type: 'text/csv' })
  const url  = URL.createObjectURL(blob)
  const a    = document.createElement('a')
  a.href     = url
  a.download = 'hitl_audit.csv'
  a.click()
  URL.revokeObjectURL(url)
  toast.success(`CSV descargado: ${data.length} entradas`)
}

// ─── Vista ────────────────────────────────────────────────────────────────────

export default function HitlAuditView({ embedded = false } = {}) {
  const [audit,       setAudit]       = useState([])
  const [loading,     setLoading]     = useState(true)
  const [filAgente,   setFilAgente]   = useState('Todos')
  const [filRisk,     setFilRisk]     = useState('Todos')
  const [filDecision, setFilDecision] = useState('Todos')
  const [tab,         setTab]         = useState('tabla')

  useEffect(() => {
    const cargar = async () => {
      setLoading(true)
      try {
        const engRes = await authedFetch('/engagements')
        if (!engRes.ok) throw new Error(`HTTP ${engRes.status}`)
        const engs = await engRes.json()
        if (!engs.length) { setAudit([]); return }

        const perEng = await Promise.all(
          engs.map((eng) =>
            authedFetch(`/engagements/${eng.id}/hitl-actions`)
              .then((r) => (r.ok ? r.json() : []))
              .then((arr) => (Array.isArray(arr) ? arr.map((a) => normalise(a, eng.id)) : []))
              .catch(() => [])
          )
        )
        const flat = perEng.flat()
        flat.sort((a, b) => b.ts.localeCompare(a.ts))
        setAudit(flat)
      } catch {
        setAudit([])
      } finally {
        setLoading(false)
      }
    }
    cargar()
  }, [])

  // ── Filtros ──────────────────────────────────────────────────────────────
  const filtrados = audit.filter((r) => {
    if (filAgente   !== 'Todos' && r.agente    !== filAgente)   return false
    if (filRisk     !== 'Todos' && r.riskLevel !== filRisk)     return false
    if (filDecision !== 'Todos') {
      if (filDecision === 'APROBADO'  && !r.decision.includes('APROBADO'))  return false
      if (filDecision === 'RECHAZADO' && r.decision !== 'RECHAZADO')        return false
      if (filDecision === 'PENDIENTE' && r.decision !== 'PENDIENTE')        return false
    }
    return true
  })

  return (
    <div className="flex flex-col gap-6">

      {/* Header (oculto cuando se usa como tab embedded) */}
      {!embedded ? (
        <div className="flex items-start gap-4">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
              <ScrollText className="size-6 text-muted-foreground" />
              HITL Audit Log
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Bitácora inmutable de decisiones humanas
              {!loading && (
                <Badge variant="outline" className="ml-2 font-mono text-[10px]">
                  {audit.length} {audit.length === 1 ? 'entrada' : 'entradas'}
                </Badge>
              )}
            </p>
          </div>
          <Button
            type="button"
            variant="outline"
            onClick={() => descargarCSV(filtrados)}
            disabled={filtrados.length === 0}
            className="ml-auto gap-2 border-success/40 text-success hover:bg-success/10 hover:text-success"
          >
            <Download className="size-4" />
            Export CSV
          </Button>
        </div>
      ) : (
        <div className="flex items-center justify-end">
          <Button
            type="button" variant="outline"
            onClick={() => descargarCSV(filtrados)}
            disabled={filtrados.length === 0}
            className="gap-2 border-success/40 text-success hover:bg-success/10 hover:text-success"
          >
            <Download className="size-4" />
            Export CSV
          </Button>
        </div>
      )}

      {/* Filtros */}
      <Card>
        <CardContent className="flex flex-wrap items-center gap-3 p-4">
          <Filter className="size-4 text-muted-foreground/70" />

          <Select value={filAgente} onValueChange={setFilAgente}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Todos">Agente: Todos</SelectItem>
              {['ReconAgent', 'ScanAgent', 'AnalysisAgent', 'Sistema'].map((a) => (
                <SelectItem key={a} value={a}>{a}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filRisk} onValueChange={setFilRisk}>
            <SelectTrigger className="w-[160px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Todos">Riesgo: Todos</SelectItem>
              {['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map((r) => (
                <SelectItem key={r} value={r}>{r}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filDecision} onValueChange={setFilDecision}>
            <SelectTrigger className="w-[200px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Todos">Decisión: Todas</SelectItem>
              <SelectItem value="APROBADO">Aprobadas (incl. auto)</SelectItem>
              <SelectItem value="RECHAZADO">Rechazadas</SelectItem>
              <SelectItem value="PENDIENTE">Pendientes</SelectItem>
            </SelectContent>
          </Select>

          <span className="ml-auto text-xs text-muted-foreground/70">
            {loading
              ? 'Cargando…'
              : `${filtrados.length} de ${audit.length} entradas`}
          </span>
        </CardContent>
      </Card>

      {/* Estados vacíos / loading */}
      {loading ? (
        <Card>
          <CardContent className="py-10 text-center text-sm text-muted-foreground/70">
            Cargando bitácora HITL…
          </CardContent>
        </Card>
      ) : audit.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
            <ScrollText className="size-8 text-muted-foreground/30" />
            <div className="text-base font-semibold text-muted-foreground">
              Sin entradas HITL
            </div>
            <p className="max-w-md text-sm text-muted-foreground/70">
              El audit log se llena cuando los agentes ejecutan acciones con{' '}
              <code className="font-mono text-primary">risk_level ≥ medium</code>{' '}
              y un operador las aprueba o rechaza.
            </p>
          </CardContent>
        </Card>
      ) : (
        /* Tabs tabla / timeline */
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="mb-3">
            <TabsTrigger value="tabla" className="gap-1.5">
              <TableIcon className="size-3.5" /> Tabla
            </TabsTrigger>
            <TabsTrigger value="timeline" className="gap-1.5">
              <List className="size-3.5" /> Timeline
            </TabsTrigger>
          </TabsList>

          <TabsContent value="tabla" className="mt-0">
            <Card className="overflow-hidden">
              {filtrados.length === 0 ? (
                <CardContent className="py-10 text-center text-sm text-muted-foreground/70">
                  Sin resultados para los filtros aplicados.
                </CardContent>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Timestamp</TableHead>
                      <TableHead className="w-24">ID</TableHead>
                      <TableHead className="w-24">Engagement</TableHead>
                      <TableHead>Agente · Tool</TableHead>
                      <TableHead className="w-24">Riesgo</TableHead>
                      <TableHead className="w-32">Decisión</TableHead>
                      <TableHead>Operador</TableHead>
                      <TableHead>Notas</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtrados.map((r, i) => (
                      <TableRow key={i}>
                        <TableCell className="whitespace-nowrap font-mono text-xs text-muted-foreground/70">
                          {r.ts}
                        </TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground/70">
                          {r.id}
                        </TableCell>
                        <TableCell className="font-mono text-xs text-info">
                          #{r.engagementId}
                        </TableCell>
                        <TableCell>
                          <span className="text-foreground">{r.agente}</span>
                          <span className="px-1.5 text-muted-foreground/70">·</span>
                          <span className="font-mono text-xs text-info">{r.tool}</span>
                        </TableCell>
                        <TableCell><RiskBadge level={r.riskLevel} /></TableCell>
                        <TableCell><DecisionBadge decision={r.decision} /></TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {r.operador}
                        </TableCell>
                        <TableCell
                          className={cn(
                            'text-sm text-muted-foreground/70',
                            !r.notas && 'italic'
                          )}>
                          {r.notas || '—'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </Card>
          </TabsContent>

          <TabsContent value="timeline" className="mt-0">
            {filtrados.length === 0 ? (
              <Card>
                <CardContent className="py-10 text-center text-sm text-muted-foreground/70">
                  Sin resultados para los filtros aplicados.
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-0">
                {filtrados.map((r, i) => (
                  <TimelineEntry key={i} entry={r} isLast={i === filtrados.length - 1} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

// ─── Timeline entry ──────────────────────────────────────────────────────────

function TimelineEntry({ entry, isLast }) {
  const dotColor =
    entry.decision === 'PENDIENTE' ? 'bg-warning'
    : entry.decision === 'RECHAZADO' ? 'bg-destructive'
    : 'bg-success'

  return (
    <div className="flex gap-3">
      {/* Línea + dot */}
      <div className="flex w-5 shrink-0 flex-col items-center">
        <div className={cn('mt-4 size-3 shrink-0 rounded-full', dotColor)} />
        {!isLast && (
          <div className="my-1 w-0.5 flex-1 min-h-6 bg-border" />
        )}
      </div>

      {/* Card */}
      <div className="flex-1 pb-3">
        <Card>
          <CardContent className="p-4 space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-xs text-muted-foreground/70">{entry.ts}</span>
              <span className="font-mono text-xs text-info">#{entry.engagementId}</span>
              <DecisionBadge decision={entry.decision} />
              <RiskBadge level={entry.riskLevel} />
            </div>
            <div className="text-base text-foreground">
              <span className="font-semibold">{entry.agente}</span>
              <span className="px-1.5 text-muted-foreground/70">·</span>
              <span className="font-mono text-info">{entry.tool}</span>
            </div>
            <div className="text-sm text-muted-foreground/70">
              Operador: {entry.operador}
              {entry.notas && (
                <>
                  {' '}·{' '}
                  <span className="italic">&ldquo;{entry.notas}&rdquo;</span>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
