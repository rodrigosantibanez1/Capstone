// HitlConsoleView — Consola HITL unificada con tabs (Phase 1 IA).
// Reemplaza dos entradas del sidebar:
//   - "Consola HITL" (HitlView — cola pendiente)
//   - "HITL Audit Log" (HitlAuditView — bitácora)
//
// Las vistas internas se renderizan en modo `embedded` (sin su propio header).

import { useSearchParams } from 'react-router-dom'
import { Zap, ScrollText } from 'lucide-react'
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'

import HitlView      from './HitlView'
import HitlAuditView from './HitlAuditView'

import useHitlPending from '@/hooks/useHitlPending'

export default function HitlConsoleView() {
  const { count: pendingCount } = useHitlPending(5000)
  const [searchParams, setSearchParams] = useSearchParams()

  // Tab persiste en ?tab=pending|audit
  const tab = searchParams.get('tab') === 'audit' ? 'audit' : 'pending'
  const setTab = (v) => {
    setSearchParams((prev) => {
      const p = new URLSearchParams(prev)
      if (v === 'pending') p.delete('tab')
      else p.set('tab', v)
      return p
    }, { replace: true })
  }

  return (
    <div className="flex flex-col gap-6">

      {/* Header global */}
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
          <Zap className="size-6 text-warning" />
          Control HITL
        </h1>
        <p className="mt-0.5 text-sm text-muted-foreground">
          Cola de pendientes y bitácora de decisiones del operador
        </p>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="pending" className="gap-1.5">
            <Zap className="size-3.5" />
            Pendientes
            {pendingCount > 0 && (
              <Badge variant="outline"
                className="ml-1 bg-warning text-warning-foreground border-warning/60 px-1.5 py-0
                           text-[10px] font-bold">
                {pendingCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="audit" className="gap-1.5">
            <ScrollText className="size-3.5" />
            Auditoría
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-6">
          <HitlView embedded />
        </TabsContent>

        <TabsContent value="audit" className="mt-6">
          <HitlAuditView embedded />
        </TabsContent>
      </Tabs>
    </div>
  )
}
