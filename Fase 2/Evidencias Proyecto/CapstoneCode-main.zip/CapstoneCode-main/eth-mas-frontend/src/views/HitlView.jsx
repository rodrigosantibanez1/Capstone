// HitlView — Consola HITL: cola de pendientes + historial reciente.
// Polling adaptativo: 2.5 s cuando hay pendientes, 10 s si no.
//
// Migrado a Tailwind v4 + shadcn (Card, Button, Input, Badge, Table) + lucide-react.

import { useState, useEffect, useCallback, useRef } from 'react'
import { toast } from 'sonner'
import {
  Zap, Check, X, AlertCircle, ClipboardList, RefreshCw,
  Inbox, Trash2, PauseCircle, Info,
} from 'lucide-react'

import { authedFetch, API_BASE } from '@/lib/api'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input }  from '@/components/ui/input'
import { Badge }  from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { cn } from '@/lib/utils'

// ─── Config ───────────────────────────────────────────────────────────────────
// Si engagementId es null/undefined, la consola opera en modo "global" y agrega
// pendientes/historial de todos los engagements (rol de operador supervisor).
const POLL_FAST_MS  = 2500
const POLL_SLOW_MS  = 10000

// Fix 1.4 — Umbral en milisegundos para considerar una HITL PENDING como
// "zombi" candidata a expirar. Coincide con el default del endpoint backend
// /expire-pending (min_age_secs=600). El botón sólo aparece si hay al menos
// una pendiente más vieja que esto.
const ZOMBIE_THRESHOLD_MS = 10 * 60 * 1000   // 10 minutos

// ─── Estilos de badges ───────────────────────────────────────────────────────

const RISK_STYLE = {
  CRITICAL: 'bg-destructive/15 text-destructive border-destructive/40',
  HIGH:     'bg-sev-high/15 text-sev-high border-sev-high/40',
  MEDIUM:   'bg-warning/15 text-warning border-warning/40',
  LOW:      'bg-info/15 text-info border-info/40',
}

function RiskBadge({ level }) {
  const cls = RISK_STYLE[level?.toUpperCase()] || RISK_STYLE.LOW
  return (
    <Badge variant="outline"
      className={cn('font-mono tracking-wider uppercase text-[10px]', cls)}>
      {level?.toUpperCase()}
    </Badge>
  )
}

function DecisionBadge({ decision }) {
  const d   = decision?.toUpperCase() || ''
  const ok  = d.includes('APPROVED')
  const rej = d.includes('REJECTED')
  const cls = ok
    ? 'bg-success/15 text-success border-success/40'
    : rej
      ? 'bg-destructive/15 text-destructive border-destructive/40'
      : 'bg-warning/15 text-warning border-warning/40'
  return (
    <Badge variant="outline"
      className={cn('font-mono tracking-wider uppercase text-[10px]', cls)}>
      {d || '—'}
    </Badge>
  )
}

function fmtTs(ts) {
  if (!ts) return '—'
  try { return new Date(ts).toLocaleString('sv').replace('T', ' ') }
  catch { return ts }
}

// ─── Vista ────────────────────────────────────────────────────────────────────

export default function HitlView({ engagementId = null, embedded = false }) {
  const [pendientes, setPendientes] = useState([])
  const [historial,  setHistorial]  = useState([])
  const [loading,    setLoading]    = useState(true)
  const [notas,      setNotas]      = useState({})
  const [submitting, setSubmitting] = useState({})

  const pendingCountRef = useRef(0)
  useEffect(() => { pendingCountRef.current = pendientes.length }, [pendientes.length])

  // ── Cargar acciones HITL ──────────────────────────────────────────────────
  // Si engagementId está definido → modo single-engagement.
  // Si es null → modo global: agrega acciones de todos los engagements.
  const cargar = useCallback(async () => {
    try {
      let all = []
      if (engagementId != null) {
        const res = await authedFetch(`/engagements/${engagementId}/hitl-actions`)
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        const actions = await res.json()
        const list = Array.isArray(actions) ? actions : (actions.items || [])
        all = list.map((a) => ({ ...a, engagement_id: a.engagement_id ?? engagementId }))
      } else {
        const engRes = await fetch(`${API_BASE}/engagements`)
        if (!engRes.ok) throw new Error(`HTTP ${engRes.status}`)
        const engs = await engRes.json()
        const results = await Promise.all(
          engs.map((eng) =>
            authedFetch(`/engagements/${eng.id}/hitl-actions`)
              .then((r) => r.ok ? r.json() : [])
              .then((arr) => Array.isArray(arr)
                ? arr.map((a) => ({ ...a, engagement_id: a.engagement_id ?? eng.id }))
                : [])
              .catch(() => [])
          )
        )
        all = results.flat()
      }
      setPendientes(all.filter((a) => a.decision === 'PENDING'))
      setHistorial(
        all.filter((a) => a.decision !== 'PENDING')
           .sort((a, b) => new Date(b.decided_at || b.requested_at) - new Date(a.decided_at || a.requested_at))
      )
    } catch {
      setPendientes([])
      setHistorial([])
    } finally {
      setLoading(false)
    }
  }, [engagementId])

  // Polling adaptativo (recursivo)
  useEffect(() => {
    cargar()
    let timer
    const tick = async () => {
      await cargar()
      const next = pendingCountRef.current > 0 ? POLL_FAST_MS : POLL_SLOW_MS
      timer = setTimeout(tick, next)
    }
    timer = setTimeout(tick, POLL_FAST_MS)
    return () => clearTimeout(timer)
  }, [cargar])

  // ── Aprobar / Rechazar ────────────────────────────────────────────────────
  const decidir = async (action, decision) => {
    const id = action.id
    setSubmitting((p) => ({ ...p, [id]: true }))
    const tid = toast.loading(`${decision === 'APPROVED' ? 'Aprobando' : 'Rechazando'} ${action.tool}…`)
    try {
      const res = await authedFetch(`/hitl-actions/${id}/decision`, {
        method: 'PATCH',
        body: JSON.stringify({
          decision,
          operator: 'Admin User',
          notes: notas[id] || null,
        }),
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      setNotas((p) => { const n = { ...p }; delete n[id]; return n })
      toast.dismiss(tid)
      toast.success(`${decision === 'APPROVED' ? 'Aprobado' : 'Rechazado'}: ${action.agent} → ${action.tool}`)
      await cargar()
    } catch (err) {
      toast.dismiss(tid)
      toast.error(`Error al ${decision === 'APPROVED' ? 'aprobar' : 'rechazar'}: ${err.message}`)
    } finally {
      setSubmitting((p) => { const s = { ...p }; delete s[id]; return s })
    }
  }

  // ── Liberar zombis (Fix 1.4) ─────────────────────────────────────────────
  // Detecta HITL PENDING cuya requested_at es más antigua que el umbral.
  // Estas son típicamente huérfanas de un subprocess MCP muerto (reload de
  // uvicorn, restart de Docker, etc). El endpoint POST /expire-pending del
  // backend las marca como EXPIRED y libera al engagement para nuevos scans.
  const zombiePendings = pendientes.filter((p) => {
    if (!p.requested_at) return false
    const ageMs = Date.now() - new Date(p.requested_at).getTime()
    return ageMs >= ZOMBIE_THRESHOLD_MS
  })

  const liberarZombis = async () => {
    const total = zombiePendings.length
    if (total === 0) return
    if (!confirm(
      `Marcar como EXPIRED ${total} HITL pendiente(s) con más de 10 min de antigüedad?\n\n` +
      `Esto libera el engagement para nuevos scans. Útil cuando el subprocess MCP que las creó ya murió.`
    )) return

    // Engagements únicos afectados (en modo global pueden ser varios)
    const engagementIds = [...new Set(zombiePendings.map((z) => z.engagement_id).filter(Boolean))]
    const tid = toast.loading(`Liberando ${total} HITL zombi(s)…`)

    let okCount = 0
    let totalExpired = 0
    for (const engId of engagementIds) {
      try {
        const res = await authedFetch(
          `/engagements/${engId}/hitl-actions/expire-pending?min_age_secs=600`,
          { method: 'POST' },
        )
        if (res.ok) {
          const data = await res.json().catch(() => ({}))
          okCount++
          totalExpired += data.expired_count || 0
        }
      } catch { /* engagement no responde, continuar */ }
    }
    toast.dismiss(tid)
    if (okCount === engagementIds.length) {
      toast.success(`${totalExpired} HITL liberada(s) en ${okCount} engagement(s).`)
    } else {
      toast.error(
        `Liberadas ${totalExpired}; ${engagementIds.length - okCount} engagement(s) fallaron.`,
      )
    }
    await cargar()
  }

  // ─── Render ──────────────────────────────────────────────────────────────

  const pollLabel = pendientes.length > 0 ? `${POLL_FAST_MS / 1000}s` : `${POLL_SLOW_MS / 1000}s`

  return (
    <div className="flex flex-col gap-8">

      {/* Header (oculto en modo embedded — usado dentro de tabs) */}
      {!embedded && (
        <div className="flex items-center gap-4">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
              <Zap className="size-6 text-warning" />
              Consola HITL
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Human-In-The-Loop · Control de acciones de riesgo
            </p>
          </div>
        </div>
      )}

      {/* Toolbar — refresh + badge + liberar zombis */}
      <div className="flex items-center justify-end gap-2">
        <span className="text-xs text-muted-foreground/70">
          Auto-refresh {pollLabel}
          {pendientes.length > 0 && <span className="ml-1 text-warning font-mono">· live</span>}
        </span>
        <Button type="button" variant="outline" size="sm" onClick={cargar} className="gap-1.5">
          <RefreshCw className="size-3.5" />
          Actualizar
        </Button>
        {zombiePendings.length > 0 && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={liberarZombis}
            className="gap-1.5 border-destructive/40 text-destructive
                       hover:bg-destructive/10 hover:text-destructive"
            title={
              `Hay ${zombiePendings.length} HITL pendiente(s) con más de 10 min. ` +
              `Probablemente son huérfanas de un proceso MCP muerto. ` +
              `Click para marcarlas como EXPIRED.`
            }
          >
            <Trash2 className="size-3.5" />
            Liberar zombis ({zombiePendings.length})
          </Button>
        )}
        {pendientes.length > 0 && (
          <Badge variant="outline"
            className="bg-destructive/15 text-destructive border-destructive/40
                       font-bold text-sm gap-1.5 py-1 px-3">
            <AlertCircle className="size-3.5" />
            {pendientes.length} pendiente{pendientes.length > 1 ? 's' : ''}
          </Badge>
        )}
      </div>

      {/* Fix 4.2b — Banner contextual cuando hay pendientes "frescas".
          Las viejas (zombi >10 min) ya tienen su propio botón "Liberar zombis"
          arriba. Las frescas significan que un agente real las está esperando
          en este momento — comunicar el contrato al operador. */}
      {(() => {
        const freshCount = pendientes.length - zombiePendings.length
        if (freshCount <= 0) return null
        return (
          <Card className="border-l-4 border-l-warning bg-warning/5">
            <CardContent className="flex flex-wrap items-center gap-3 p-4">
              <PauseCircle className="size-5 shrink-0 text-warning" />
              <div className="min-w-0 flex-1 text-xs text-muted-foreground">
                <span className="font-semibold text-foreground">
                  Pipeline en pausa.
                </span>{' '}
                Hay {freshCount} acción{freshCount > 1 ? 'es' : ''} esperando tu decisión.
                El agente reanuda automáticamente apenas apruebes/rechaces.
                {' '}Aprobar dispara la herramienta real y normalmente abre la
                siguiente acción del playbook (nmap → nuclei → nikto → gobuster).
              </div>
              {zombiePendings.length > 0 && (
                <div className="flex items-center gap-1 rounded-md border border-border bg-background px-2 py-1
                                text-[10px] text-muted-foreground">
                  <Info className="size-3" />
                  {zombiePendings.length} adicional{zombiePendings.length > 1 ? 'es' : ''}{' '}
                  son zombi — usa "Liberar zombis"
                </div>
              )}
            </CardContent>
          </Card>
        )
      })()}

      {/* ─── Cola pendiente ──────────────────────────────────────────────── */}
      <section>
        <h2 className="mb-3 text-sm font-semibold text-foreground">
          Acciones pendientes de aprobación
        </h2>

        {loading ? (
          <Card>
            <CardContent className="py-10 text-center text-sm text-muted-foreground/70">
              Cargando…
            </CardContent>
          </Card>
        ) : pendientes.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
              <Check className="size-6 text-success" />
              <div className="text-sm text-muted-foreground">
                Sin acciones pendientes. El pipeline continúa automáticamente.
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="flex flex-col gap-3">
            {pendientes.map((accion) => {
              const isSub = submitting[accion.id]
              return (
                <PendingActionCard
                  key={accion.id}
                  accion={accion}
                  notes={notas[accion.id] || ''}
                  onNotesChange={(v) => setNotas((p) => ({ ...p, [accion.id]: v }))}
                  onApprove={() => decidir(accion, 'APPROVED')}
                  onReject={() => decidir(accion, 'REJECTED')}
                  submitting={isSub}
                />
              )
            })}
          </div>
        )}
      </section>

      {/* ─── Historial ───────────────────────────────────────────────────── */}
      <section>
        <div className="mb-3 flex items-center gap-2">
          <ClipboardList className="size-4 text-muted-foreground" />
          <h2 className="text-sm font-semibold text-foreground">
            Historial de decisiones
          </h2>
          <Badge variant="outline" className="text-[10px] font-mono">
            {historial.length}
          </Badge>
        </div>

        <Card className="overflow-hidden">
          {historial.length === 0 ? (
            <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
              <Inbox className="size-6 text-muted-foreground/40" />
              <div className="text-sm text-muted-foreground/70">
                Sin historial aún.
              </div>
            </CardContent>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16">ID</TableHead>
                  <TableHead className="w-20">Engagement</TableHead>
                  <TableHead>Agente · Tool</TableHead>
                  <TableHead className="w-24">Riesgo</TableHead>
                  <TableHead className="w-32">Decisión</TableHead>
                  <TableHead>Operador</TableHead>
                  <TableHead>Timestamp</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {historial.map((h) => (
                  <TableRow key={`${h.id}-${h.decided_at}`}>
                    <TableCell className="font-mono text-xs text-muted-foreground/70">
                      #{h.id}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground/70">
                      {h.engagement_id != null ? `#${h.engagement_id}` : '—'}
                    </TableCell>
                    <TableCell>
                      <span className="text-foreground">{h.agent}</span>
                      <span className="px-1.5 text-muted-foreground/70">·</span>
                      <span className="font-mono text-xs text-info">{h.tool}</span>
                    </TableCell>
                    <TableCell><RiskBadge level={h.risk_level} /></TableCell>
                    <TableCell><DecisionBadge decision={h.decision} /></TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {h.operator || '—'}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground/70">
                      {fmtTs(h.decided_at || h.requested_at)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Card>
      </section>
    </div>
  )
}

// ─── Card de acción pendiente (extraído para legibilidad) ────────────────────

function PendingActionCard({
  accion, notes, onNotesChange, onApprove, onReject, submitting,
}) {
  const riskKey = accion.risk_level?.toUpperCase() || 'LOW'

  return (
    <Card className={cn(
      'border-l-4',
      riskKey === 'CRITICAL' || riskKey === 'HIGH'
        ? 'border-l-destructive'
        : riskKey === 'MEDIUM'
          ? 'border-l-warning'
          : 'border-l-info'
    )}>
      <CardContent className="p-5 space-y-3">

        {/* Cabecera */}
        <div className="flex flex-wrap items-center gap-3">
          <RiskBadge level={riskKey} />
          <span className="text-base font-bold text-foreground">{accion.agent}</span>
          <span className="text-muted-foreground/70">·</span>
          <code className="rounded-sm bg-info/15 px-2 py-0.5 font-mono text-sm text-info">
            {accion.tool}
          </code>
          <div className="ml-auto font-mono text-xs text-muted-foreground/70">
            {accion.engagement_id != null && (
              <span className="mr-2 rounded-sm border border-border bg-background px-1.5 py-0.5">
                eng #{accion.engagement_id}
              </span>
            )}
            #{accion.id} · {fmtTs(accion.requested_at)}
          </div>
        </div>

        {/* Parámetros */}
        <div className="flex flex-wrap gap-3 rounded-md border border-border bg-background
                        px-3 py-2 font-mono text-xs text-muted-foreground">
          {Object.keys(accion.params || {}).length === 0 ? (
            <span className="italic">Sin parámetros</span>
          ) : (
            Object.entries(accion.params || {}).map(([k, v]) => (
              <span key={k}>
                <span className="text-muted-foreground/70">{k}:</span>{' '}
                <span className="text-foreground">{JSON.stringify(v)}</span>
              </span>
            ))
          )}
        </div>

        <Separator />

        {/* Notas + botones */}
        <div className="flex flex-wrap items-end gap-3">
          <div className="min-w-[240px] flex-1">
            <label htmlFor={`notes-${accion.id}`}
              className="mb-1 block text-xs text-muted-foreground/70">
              Notas del operador (opcional):
            </label>
            <Input
              id={`notes-${accion.id}`}
              type="text"
              placeholder="Ej: Aprobado para ventana de mantenimiento…"
              value={notes}
              onChange={(e) => onNotesChange(e.target.value)}
              disabled={submitting}
            />
          </div>
          <Button
            type="button"
            onClick={onApprove}
            disabled={submitting}
            className="gap-1.5 bg-success text-success-foreground hover:bg-success/90"
          >
            <Check className="size-4" />
            {submitting ? '…' : 'Aprobar'}
          </Button>
          <Button
            type="button"
            variant="destructive"
            onClick={onReject}
            disabled={submitting}
            className="gap-1.5"
          >
            <X className="size-4" />
            {submitting ? '…' : 'Rechazar'}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
