// HomeView — Pantalla de Inicio orientada al ORQUESTADOR (rediseño 2026-07).
//
// Tres franjas, de arriba hacia abajo:
//   1) Orquestador (protagonista): selector de engagement + "Nuevo" + chat en
//      vivo embebido del engagement elegido. Es lo primero que ve el operador.
//   2) Directorio de engagements: lista/registro limpio. "Conversar" lleva el
//      engagement al panel del orquestador de arriba; "Abrir" va al espacio
//      de trabajo completo.
//   3) Métricas (secundarias): un gráfico interactivo de hallazgos por
//      severidad + cifras clave compactas. Dejan de ser el protagonista.
//
// Nada se "abre solo": el operador elige explícitamente. El engagement puede
// venir preseleccionado por la URL (?eng=ID), p.ej. justo tras crearlo.

import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { toast } from 'sonner'
import {
  Bot, RefreshCw, Plus, AlertTriangle, Ban, Target,
  Play, Circle, Pause, CirclePlay, CheckCircle2, XCircle,
  MessageSquare, FolderOpen, BarChart3, AlertOctagon,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { ROUTES } from '@/lib/routes'
import useHitlPending from '@/hooks/useHitlPending'
import EngagementSelector from '@/components/EngagementSelector'
import OrchestratorChatView from './OrchestratorChatView'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge }  from '@/components/ui/badge'
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetFooter,
} from '@/components/ui/sheet'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { ScrollArea } from '@/components/ui/scroll-area'
import { cn } from '@/lib/utils'

// ─── Status badges ───────────────────────────────────────────────────────────

const STATUS_META = {
  running:   { color: 'bg-primary/15 text-primary border-primary/40',           Icon: CirclePlay,    label: 'Running' },
  pending:   { color: 'bg-info/15 text-info border-info/40',                    Icon: Circle,        label: 'Pending' },
  paused:    { color: 'bg-warning/15 text-warning border-warning/40',           Icon: Pause,         label: 'Paused' },
  completed: { color: 'bg-success/15 text-success border-success/40',           Icon: CheckCircle2,  label: 'Completed' },
  aborted:   { color: 'bg-destructive/15 text-destructive border-destructive/40', Icon: XCircle,     label: 'Aborted' },
}

// Severidades (orden de mayor a menor) con su variable de color del proyecto.
const SEVERITIES = [
  { key: 'critical', label: 'Crítico', colorVar: 'var(--sev-critical)' },
  { key: 'high',     label: 'Alto',    colorVar: 'var(--sev-high)' },
  { key: 'medium',   label: 'Medio',   colorVar: 'var(--sev-medium)' },
  { key: 'low',      label: 'Bajo',    colorVar: 'var(--sev-low)' },
  { key: 'info',     label: 'Info',    colorVar: 'var(--sev-info)' },
]

function EstadoBadge({ estado }) {
  const m = STATUS_META[estado] || {
    color: 'bg-muted text-muted-foreground border-border', Icon: Circle, label: estado || '—',
  }
  const Icon = m.Icon
  return (
    <Badge variant="outline"
      className={cn('gap-1 font-mono uppercase tracking-wider text-[10px] whitespace-nowrap', m.color)}>
      <Icon className="size-3" />
      {m.label}
    </Badge>
  )
}

function fmtDate(ts) {
  if (!ts) return '—'
  try {
    return new Date(ts).toLocaleString('es-CL', {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    })
  } catch { return ts }
}

// ─── Gráfico interactivo de severidad (dibujado a mano, sin dependencias) ─────
// Dona SVG: cada segmento es un círculo con stroke-dasharray. Al pasar el mouse
// (o el foco por teclado) sobre un segmento o su leyenda, se resalta y el centro
// muestra su detalle. Ver docs/mejoras-futuras-frontend.md para la alternativa
// con librería de gráficos (Recharts) documentada como mejora futura.

function SeverityDonut({ agg }) {
  const [active, setActive] = useState(null)

  const total = agg?.total || 0
  const segments = SEVERITIES
    .map((s) => ({ ...s, value: agg?.[s.key] || 0 }))
    .filter((s) => s.value > 0)

  // Geometría de la dona
  const size = 168, stroke = 22, r = (size - stroke) / 2, cx = size / 2, cy = size / 2
  const circ = 2 * Math.PI * r

  if (total === 0) {
    return (
      <div className="flex min-h-[168px] flex-1 flex-col items-center justify-center gap-2">
        <BarChart3 className="size-8 text-muted-foreground/30" />
        <div className="text-sm text-muted-foreground/70">
          Aún no hay hallazgos — ejecuta el pipeline completo
        </div>
      </div>
    )
  }

  const activeSeg = segments.find((s) => s.key === active)

  // Offsets acumulados precomputados de forma funcional (sin mutar variables
  // durante el render). n ≤ 5, así que el slice+reduce es trivial.
  const arcs = segments.map((s, i) => {
    const len = (s.value / total) * circ
    const prevLen = segments
      .slice(0, i)
      .reduce((a, x) => a + (x.value / total) * circ, 0)
    return { ...s, len, offset: -prevLen }
  })

  return (
    <div className="flex flex-wrap items-center gap-6">
      {/* Dona */}
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} role="img"
          aria-label={`Hallazgos por severidad, ${total} en total`}>
          {/* Pista de fondo */}
          <circle cx={cx} cy={cy} r={r} fill="none"
            stroke="var(--color-border, #2a2d34)" strokeWidth={stroke} opacity={0.35} />
          {arcs.map((s) => {
            const dim = active && active !== s.key
            return (
              <circle
                key={s.key}
                cx={cx} cy={cy} r={r} fill="none"
                stroke={s.colorVar}
                strokeWidth={active === s.key ? stroke + 4 : stroke}
                strokeDasharray={`${s.len} ${circ - s.len}`}
                strokeDashoffset={s.offset}
                transform={`rotate(-90 ${cx} ${cy})`}
                className="cursor-pointer transition-all duration-200"
                style={{ opacity: dim ? 0.25 : 1 }}
                onMouseEnter={() => setActive(s.key)}
                onMouseLeave={() => setActive(null)}
                tabIndex={0}
                onFocus={() => setActive(s.key)}
                onBlur={() => setActive(null)}
              >
                <title>{`${s.label}: ${s.value} (${Math.round((s.value / total) * 100)}%)`}</title>
              </circle>
            )
          })}
        </svg>
        {/* Centro: total, o el detalle del segmento activo */}
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-3xl font-extrabold leading-none text-foreground">
            {activeSeg ? activeSeg.value : total}
          </div>
          <div className="mt-0.5 text-[11px] uppercase tracking-wider text-muted-foreground/70">
            {activeSeg ? activeSeg.label : 'hallazgos'}
          </div>
        </div>
      </div>

      {/* Leyenda interactiva */}
      <ul className="flex min-w-[180px] flex-1 flex-col gap-1.5">
        {segments.map((s) => {
          const pct = Math.round((s.value / total) * 100)
          const dim = active && active !== s.key
          return (
            <li key={s.key}>
              <button
                type="button"
                onMouseEnter={() => setActive(s.key)}
                onMouseLeave={() => setActive(null)}
                onFocus={() => setActive(s.key)}
                onBlur={() => setActive(null)}
                className={cn(
                  'flex w-full items-center gap-2.5 rounded-md px-2 py-1 text-left transition-colors',
                  'hover:bg-accent focus-visible:bg-accent focus-visible:outline-none',
                  dim && 'opacity-40',
                )}
              >
                <span className="size-3 shrink-0 rounded-sm" style={{ background: s.colorVar }} />
                <span className="flex-1 text-sm text-foreground">{s.label}</span>
                <span className="font-mono text-sm font-bold text-foreground">{s.value}</span>
                <span className="w-10 text-right font-mono text-xs text-muted-foreground/70">{pct}%</span>
              </button>
            </li>
          )
        })}
      </ul>
    </div>
  )
}

// ─── Cifra compacta ──────────────────────────────────────────────────────────

function StatFigure({ label, value, Icon, color, loading }) {
  return (
    <div className="flex items-center gap-3 rounded-md border border-border bg-background px-3 py-2.5">
      {Icon && <Icon className={cn('size-4 shrink-0', color)} />}
      <div className="min-w-0">
        <div className={cn('text-lg font-extrabold leading-none', color)}>
          {loading ? <span className="opacity-30">—</span> : value}
        </div>
        <div className="mt-0.5 truncate text-[11px] text-muted-foreground/70">{label}</div>
      </div>
    </div>
  )
}

// ─── Drawer detalle ──────────────────────────────────────────────────────────

function DrawerDetalle({ eng, onClose, onAbort, onOpenWorkspace }) {
  return (
    <Sheet open={!!eng} onOpenChange={(o) => { if (!o) onClose?.() }}>
      <SheetContent side="right"
        className="w-[460px] max-w-[90vw] sm:max-w-[90vw] p-0 flex flex-col gap-0 bg-sidebar">
        <SheetHeader className="border-b border-border p-6">
          <SheetTitle>{eng.name}</SheetTitle>
          <SheetDescription>
            ID #{eng.id} · {eng.client_name || 'Sin cliente'}
          </SheetDescription>
        </SheetHeader>

        <ScrollArea className="flex-1">
          <div className="flex flex-col gap-6 p-6">
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Estado',      value: <EstadoBadge estado={eng.status} /> },
                { label: 'Scope',       value: `${eng.scope_count || 0} targets`, className: 'text-info' },
                { label: 'Creado',      value: fmtDate(eng.created_at), mono: true },
                { label: 'Actualizado', value: fmtDate(eng.updated_at), mono: true },
              ].map((s, i) => (
                <Card key={i}>
                  <CardContent className="p-3">
                    <div className="mb-1 text-[10px] text-muted-foreground/70">{s.label}</div>
                    <div className={cn(
                      'text-sm font-semibold text-foreground',
                      s.mono && 'font-mono',
                      s.className,
                    )}>
                      {s.value}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {eng.description && (
              <div>
                <div className="mb-1.5 text-sm font-semibold text-muted-foreground">
                  Descripción
                </div>
                <div className="text-sm leading-relaxed text-muted-foreground">
                  {eng.description}
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        <SheetFooter className="border-t border-border p-6">
          <div className="flex w-full gap-2">
            <Button onClick={() => onOpenWorkspace?.(eng.id)} className="flex-1 gap-2">
              <Target className="size-4" />
              Abrir workspace
            </Button>
            {(eng.status === 'running' || eng.status === 'paused') && (
              <Button variant="destructive" className="gap-2" onClick={() => onAbort(eng.id)}>
                <Ban className="size-4" />
                Abort
              </Button>
            )}
          </div>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}

// ─── Vista principal ─────────────────────────────────────────────────────────

export default function HomeView() {
  const navigate = useNavigate()
  const [searchParams, setSearchParams] = useSearchParams()
  const heroRef = useRef(null)

  const onNuevoEngagement = () => navigate(ROUTES.engagementNew)
  const onOpenWorkspace   = (id) => navigate(ROUTES.workspaceFor(id))

  // Engagement elegido para el panel del orquestador. La URL (?eng=ID) es la
  // única fuente de verdad: puede venir preseleccionado (p.ej. justo tras
  // crearlo) y es compartible. Sin param → null (no se abre nada solo).
  const engParam = searchParams.get('eng')
  const selectedEng = engParam ? Number(engParam) : null

  // Elegir un engagement en el panel: refleja en la URL sin recargar.
  const pickForOrchestrator = useCallback((id) => {
    setSearchParams((prev) => {
      const p = new URLSearchParams(prev)
      if (id) p.set('eng', String(id)); else p.delete('eng')
      return p
    }, { replace: true })
  }, [setSearchParams])

  // Elegir desde la tabla → llevar al panel de arriba y subir la vista.
  const conversarCon = useCallback((id) => {
    pickForOrchestrator(id)
    requestAnimationFrame(() =>
      heroRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }))
  }, [pickForOrchestrator])

  const [engagements,  setEngagements]  = useState([])
  const [loading,      setLoading]      = useState(true)
  const [error,        setError]        = useState(null)
  const [lastFetch,    setLastFetch]    = useState(null)
  const [detalle,      setDetalle]      = useState(null)
  const [abortConfirm, setAbortConfirm] = useState(null)
  const [sevAgg,       setSevAgg]       = useState(null)

  const { count: hitlPending } = useHitlPending(8000)

  const cargar = async () => {
    setLoading(true); setError(null)
    try {
      const res = await authedFetch('/engagements')
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const engs = await res.json()
      setEngagements(engs)
      setLastFetch(new Date().toLocaleTimeString('es-CL'))

      // Agregar findings por severidad de todos los engagements en paralelo.
      const agg = { critical: 0, high: 0, medium: 0, low: 0, info: 0, total: 0 }
      const results = await Promise.all(
        engs.map((e) =>
          authedFetch(`/engagements/${e.id}/findings`)
            .then((r) => (r.ok ? r.json() : null))
            .then((d) => d?.findings || [])
            .catch(() => [])
        )
      )
      for (const list of results) {
        for (const f of list) {
          const sev = (f.severity || 'info').toLowerCase()
          if (agg[sev] != null) agg[sev] += 1
          agg.total += 1
        }
      }
      setSevAgg(agg)
    } catch {
      setError('Backend no disponible. Inicia el servidor con uvicorn.')
      setEngagements([])
      setSevAgg(null)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { cargar() }, [])

  // Cifras derivadas
  const activeCount       = engagements.filter((e) => e.status === 'running').length
  const totalScopeTargets = engagements.reduce((s, e) => s + (e.scope_count || 0), 0)
  const pendingCount      = engagements.filter((e) => e.status === 'pending').length
  const criticalCount     = sevAgg ? sevAgg.critical : 0

  // Abortar
  const confirmarAbort = async () => {
    const tid = toast.loading('Abortando engagement…')
    try {
      const res = await authedFetch(`/engagements/${abortConfirm}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'aborted' }),
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      toast.dismiss(tid)
      toast.success('Engagement abortado')
      await cargar()
      if (detalle?.id === abortConfirm) setDetalle(null)
    } catch (err) {
      toast.dismiss(tid)
      toast.error(`Error al abortar: ${err.message}`)
    } finally {
      setAbortConfirm(null)
    }
  }

  const selectedMeta = engagements.find((e) => e.id === selectedEng)

  // ── Render ───────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col gap-8">

      {/* ══ Franja 1 · ORQUESTADOR (protagonista) ══════════════════════════ */}
      <section ref={heroRef} className="flex flex-col gap-4 scroll-mt-4">
        <div className="flex flex-wrap items-start gap-4">
          <div className="min-w-0">
            <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
              <Bot className="size-6 text-primary" />
              Orquestador
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              {selectedMeta
                ? <>Conversando con <strong className="text-foreground">{selectedMeta.name}</strong> · {selectedMeta.status}</>
                : 'Elige un engagement para conversar, o crea uno nuevo'}
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <EngagementSelector
              value={selectedEng}
              onChange={(id) => pickForOrchestrator(id)}
              onCreateNew={onNuevoEngagement}
            />
            <Button onClick={onNuevoEngagement} className="gap-2">
              <Plus className="size-4" />
              Nuevo
            </Button>
          </div>
        </div>

        {error && (
          <div className="flex items-center gap-2 rounded-md border border-warning/40
                          bg-warning/10 p-3 text-sm text-warning">
            <AlertTriangle className="size-4 shrink-0" />
            {error}
          </div>
        )}

        {selectedEng ? (
          <div className="flex flex-col gap-2">
            <div className="flex justify-end">
              <Button variant="outline" size="sm" className="gap-1.5"
                onClick={() => navigate(ROUTES.orchestratorFor(selectedEng))}>
                <FolderOpen className="size-3.5" />
                Abrir espacio de trabajo completo
              </Button>
            </div>
            {/* Chat en vivo del engagement elegido (misma pieza del workspace) */}
            <OrchestratorChatView key={selectedEng} engagementId={selectedEng} embedded />
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
              <Bot className="size-10 text-muted-foreground/30" />
              <div className="text-sm font-semibold text-muted-foreground">
                Ningún engagement seleccionado
              </div>
              <div className="max-w-md text-xs text-muted-foreground/70">
                Elige uno del selector de arriba (o de la lista de abajo) para
                conversar con el orquestador. Si es tu primera vez, crea un
                engagement nuevo.
              </div>
              <Button onClick={onNuevoEngagement} className="mt-1 gap-2">
                <Plus className="size-4" />
                Crear engagement
              </Button>
            </CardContent>
          </Card>
        )}
      </section>

      {/* ══ Franja 2 · DIRECTORIO de engagements ═══════════════════════════ */}
      <Card className="overflow-hidden">
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <span className="text-base font-semibold text-foreground">
            Engagements
          </span>
          <div className="flex items-center gap-2">
            {lastFetch && (
              <span className="text-xs text-muted-foreground/70">
                {loading ? 'Cargando…' : `${engagements.length} · act. ${lastFetch}`}
              </span>
            )}
            <Button variant="outline" size="sm" onClick={cargar}
              disabled={loading} className="gap-1.5">
              <RefreshCw className={cn('size-3.5', loading && 'animate-spin')} />
              Actualizar
            </Button>
          </div>
        </div>

        {loading ? (
          <CardContent className="py-10 text-center text-sm text-muted-foreground/70">
            Cargando engagements desde API…
          </CardContent>
        ) : engagements.length === 0 ? (
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <FolderOpen className="size-8 text-muted-foreground/30" />
            <div className="text-sm font-semibold text-muted-foreground">
              Sin engagements creados aún
            </div>
            <div className="text-xs text-muted-foreground/70">
              Crea el primero con el botón <strong>Nuevo</strong> de arriba.
            </div>
          </CardContent>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-16">ID</TableHead>
                <TableHead>Nombre</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead className="w-36">Estado</TableHead>
                <TableHead className="w-20 text-center">Scope</TableHead>
                <TableHead>Creado</TableHead>
                <TableHead className="w-56 text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {engagements.map((eng) => (
                <TableRow
                  key={eng.id}
                  onClick={() => conversarCon(eng.id)}
                  aria-selected={eng.id === selectedEng}
                  className={cn(
                    'cursor-pointer transition-colors hover:bg-accent',
                    eng.id === selectedEng && 'bg-primary/5',
                  )}
                >
                  <TableCell className="font-mono text-xs text-muted-foreground/70">
                    #{eng.id}
                  </TableCell>
                  <TableCell className="font-semibold text-foreground">{eng.name}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {eng.client_name || '—'}
                  </TableCell>
                  <TableCell><EstadoBadge estado={eng.status} /></TableCell>
                  <TableCell className="text-center font-mono font-bold text-info">
                    {eng.scope_count ?? 0}
                  </TableCell>
                  <TableCell className="whitespace-nowrap font-mono text-xs text-muted-foreground/70">
                    {fmtDate(eng.created_at)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button size="xs"
                        className="gap-1"
                        onClick={(e) => { e.stopPropagation(); conversarCon(eng.id) }}>
                        <MessageSquare className="size-3" />
                        Conversar
                      </Button>
                      <Button variant="outline" size="xs"
                        onClick={(e) => { e.stopPropagation(); onOpenWorkspace(eng.id) }}>
                        Abrir
                      </Button>
                      <Button variant="outline" size="xs"
                        onClick={(e) => { e.stopPropagation(); setDetalle(eng) }}>
                        Detalle
                      </Button>
                      {(eng.status === 'running' || eng.status === 'paused') && (
                        <Button variant="outline" size="xs"
                          onClick={(e) => { e.stopPropagation(); setAbortConfirm(eng.id) }}
                          className="gap-1 border-destructive/40 text-destructive
                                     hover:bg-destructive/10 hover:text-destructive">
                          <Ban className="size-3" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>

      {/* ══ Franja 3 · MÉTRICAS (secundarias) ══════════════════════════════ */}
      <Card>
        <CardContent className="flex flex-col gap-5 p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-base font-semibold text-foreground">
              <BarChart3 className="size-4 text-muted-foreground" />
              Métricas
            </div>
            {sevAgg && sevAgg.total > 0 && (
              <span className="font-mono text-xs text-muted-foreground/70">
                {sevAgg.total} hallazgos en total
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-x-10 gap-y-6">
            {/* Gráfico interactivo */}
            <div className="min-w-[300px] flex-[2]">
              <SeverityDonut agg={sevAgg} />
            </div>

            {/* Cifras clave */}
            <div className="grid flex-1 grid-cols-2 gap-3 min-w-[260px]">
              <StatFigure label="Engagements activos" value={activeCount}       Icon={Play}         color="text-primary"  loading={loading} />
              <StatFigure label="Pendientes"          value={pendingCount}      Icon={Circle}       color="text-info"     loading={loading} />
              <StatFigure label="Targets en scope"    value={totalScopeTargets} Icon={Target}       color="text-success"  loading={loading} />
              <StatFigure label="Hallazgos críticos"  value={criticalCount}     Icon={AlertOctagon} color={criticalCount > 0 ? 'text-sev-critical' : 'text-muted-foreground'} loading={loading} />
              <StatFigure label="HITL pendientes"     value={hitlPending}       Icon={AlertTriangle} color={hitlPending > 0 ? 'text-warning' : 'text-muted-foreground'} loading={loading} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Drawer detalle */}
      {detalle && (
        <DrawerDetalle eng={detalle}
          onClose={() => setDetalle(null)}
          onAbort={setAbortConfirm}
          onOpenWorkspace={(id) => { setDetalle(null); onOpenWorkspace(id) }}
        />
      )}

      {/* Modal abort */}
      <Dialog open={!!abortConfirm} onOpenChange={(o) => { if (!o) setAbortConfirm(null) }}>
        <DialogContent className="sm:max-w-[420px] border-destructive/40">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="size-5" />
              Abort Engagement
            </DialogTitle>
            <DialogDescription className="leading-relaxed">
              Esta acción detiene el pipeline inmediatamente y cambia el estado a{' '}
              <strong>aborted</strong>. Los findings ya persistidos se conservan.
              ¿Confirmas?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="ghost" onClick={() => setAbortConfirm(null)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmarAbort} className="gap-2">
              <Ban className="size-4" />
              Sí, abortar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
