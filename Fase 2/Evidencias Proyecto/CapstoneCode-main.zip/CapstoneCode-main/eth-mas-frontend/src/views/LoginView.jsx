// LoginView — Pantalla de login del prototipo académico.
// Actualmente desactivada en App.jsx (auto-login). Migrada por consistencia visual.

import { useState } from 'react'
import { LogIn, Shield, AlertTriangle } from 'lucide-react'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input }  from '@/components/ui/input'
import { Label }  from '@/components/ui/label'
import { Badge }  from '@/components/ui/badge'

export default function LoginView({ onLogin }) {
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [loading,  setLoading]  = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      onLogin?.()
    }, 800)
  }

  return (
    <div className="flex h-screen w-screen items-center justify-center bg-background">
      <Card className="w-[420px] max-w-[92vw]">
        <CardContent className="p-10 space-y-6">

          {/* Logo */}
          <div className="space-y-2 text-center">
            <div className="font-mono text-4xl font-extrabold tracking-[3px] text-primary">
              ETH-MAS
            </div>
            <div className="text-sm text-muted-foreground">
              Ethical Hacking Multi-Agent System
            </div>
            <Badge variant="outline" className="font-mono text-[10px]">
              v0.1 · academic prototype
            </Badge>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="login-email">Email</Label>
              <Input id="login-email" type="email" required
                value={email} onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@eth-mas.cl" autoFocus />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="login-pass">Contraseña</Label>
              <Input id="login-pass" type="password" required
                value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder="•••••••••" />
            </div>

            <Button type="submit" size="lg" disabled={loading}
              className="w-full gap-2">
              <LogIn className="size-4" />
              {loading ? 'Verificando…' : 'Ingresar'}
            </Button>
          </form>

          {/* Warning de prototipo */}
          <div className="flex items-start gap-2 rounded-md border border-warning/40
                          bg-warning/10 p-3 text-xs leading-relaxed text-warning">
            <Shield className="mt-0.5 size-3.5 shrink-0" />
            <div>
              <strong>Auth simulada</strong> — este login es decorativo. En este
              prototipo académico, las credenciales NO se validan contra un backend.
              La auth real entre frontend ↔ API se hace vía{' '}
              <code className="font-mono">X-API-Key</code> (ver botón ⚙ del top bar).
            </div>
          </div>

          {/* Hint si email está vacío y submit se intenta */}
          {!loading && email === '' && password !== '' && (
            <div className="flex items-center gap-1 text-xs text-destructive">
              <AlertTriangle className="size-3" />
              Email requerido
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
