// OrchestratorChatView — Chat del operador con el Orquestador (Bloque A, ADR-005).
//
// El operador conversa en lenguaje natural; el Orquestador (LLM) arma un PLAN o
// EJECUTA delegando en los 4 workers vía el ejecutor seguro. Dos modos:
//   - Plan    → preview: muestra qué haría sin ejecutar nada (POST mode=plan, 200).
//   - Ejecutar→ delega de verdad en background (POST mode=execute, 202).
//
// Los turnos se cargan con GET /orchestrator/conversation y se actualizan en vivo
// por SSE /orchestrator/stream (mismo patrón que PipelineView). El scope y el HITL
// son control EN CÓDIGO: el orquestador no los aprueba por chat — si un worker
// queda waiting_hitl, el chat deriva a la consola HITL.

import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import {
  Send, Bot, User, Cpu, AlertTriangle, Wifi, WifiOff,
  Eye, ListChecks, Zap, PauseCircle, Play, Search, Radar, Brain, FileText,
} from 'lucide-react'

import { authedFetch, API_BASE } from '@/lib/api'
import { ROUTES } from '@/lib/routes'
import ActivityConsole from '@/components/ActivityConsole'

import { Card, CardContent } from '@/components/ui/card'
import { Button }    from '@/components/ui/button'
import { Badge }     from '@/components/ui/badge'
import { Textarea }  from '@/components/ui/textarea'
import { cn }        from '@/lib/utils'

// Prompts rápidos — al hacer click rellenan el input y lo enfocan (no envían).
// Doble función: bajan la fricción del "¿qué escribo?" y comunican de forma
// implícita qué sabe hacer el orquestador (transparencia de capacidades).
const QUICK_PROMPTS = [
  { icon: Search,   label: 'Escanear un host',  text: 'escanea 10.42.0.10 en modo sigiloso' },
  { icon: Radar,    label: 'Recon del scope',   text: 'haz reconocimiento del scope del engagement' },
  { icon: Brain,    label: 'Analizar findings', text: 'analiza los findings y prioriza el riesgo' },
  { icon: FileText, label: 'Generar reporte',   text: 'genera el reporte técnico y ejecutivo' },
]

const STATUS_BADGE = {
  completed:    'text-success bg-success/15 border-success/40',
  waiting_hitl: 'text-warning bg-warning/15 border-warning/40',
  failed:       'text-destructive bg-destructive/15 border-destructive/40',
  skipped:      'text-muted-foreground bg-muted border-border',
  partial:      'text-info bg-info/15 border-info/40',
}

// ─── Bubble de un turno de conversación ──────────────────────────────────────

function TurnBubble({ turn, onOpenHitl, onExecutePlan }) {
  const role = turn.role
  const meta = turn.meta || {}
  const isOperator = role === 'operator'
  const isSystem   = role === 'system'
  const isPlan     = meta.kind === 'plan'

  const Icon = isOperator ? User : isSystem ? AlertTriangle : meta.kind === 'delegation' ? Cpu : Bot
  const label = isOperator
    ? 'Operador'
    : isSystem
      ? 'Sistema'
      : meta.kind === 'plan'
        ? 'Orquestador · plan'
        : meta.kind === 'delegation'
          ? `Orquestador → ${meta.agent || 'worker'}`
          : 'Orquestador'

  const pendingHitl = Array.isArray(meta.pending_hitl_ids) ? meta.pending_hitl_ids : []

  return (
    <div className={cn('flex gap-2.5', isOperator && 'flex-row-reverse')}>
      <div className={cn(
        'flex size-7 shrink-0 items-center justify-center rounded-full border',
        isOperator
          ? 'border-primary/40 bg-primary/15 text-primary'
          : isSystem
            ? 'border-destructive/40 bg-destructive/15 text-destructive'
            : 'border-border bg-card text-muted-foreground'
      )}>
        <Icon className="size-3.5" />
      </div>

      <div className={cn('min-w-0 max-w-[80%] space-y-1', isOperator && 'items-end text-right')}>
        <div className="flex items-center gap-2 text-[11px] text-muted-foreground/70">
          <span>{label}</span>
          {meta.kind === 'plan' && (
            <Badge variant="outline" className="gap-1 px-1.5 py-0 text-[10px]">
              <ListChecks className="size-2.5" /> preview
            </Badge>
          )}
          {meta.status && (
            <Badge variant="outline" className={cn(
              'px-1.5 py-0 font-mono text-[10px] uppercase',
              STATUS_BADGE[meta.status] || 'text-muted-foreground border-border'
            )}>
              {meta.status}
            </Badge>
          )}
        </div>

        <Card className={cn(
          isOperator ? 'bg-primary/10 border-primary/30' : isSystem ? 'bg-destructive/5 border-destructive/30' : 'bg-card'
        )}>
          <CardContent className="px-3 py-2">
            <div className="whitespace-pre-wrap break-words text-sm text-foreground">
              {turn.content}
            </div>

            {pendingHitl.length > 0 && (
              <div className="mt-2 flex items-center gap-2 rounded-md border border-warning/40
                              border-dashed bg-warning/10 px-2 py-1.5 text-xs text-warning">
                <PauseCircle className="size-3.5 shrink-0" />
                <span className="flex-1 text-left">
                  Esperando aprobación HITL (#{pendingHitl.join(', #')}).
                </span>
                <Button type="button" size="xs" variant="outline"
                  className="gap-1 text-warning"
                  onClick={onOpenHitl}>
                  <Eye className="size-3" /> Consola HITL
                </Button>
              </div>
            )}

            {/* Un plan es solo preview: no ejecutó nada. Atajo para delegarlo de
                verdad sin reescribir la instrucción (cura el "respondió pero no
                ejecutó"). */}
            {isPlan && onExecutePlan && (
              <div className="mt-2 flex items-center gap-2 rounded-md border border-warning/40
                              border-dashed bg-warning/10 px-2 py-1.5 text-xs text-warning">
                <Play className="size-3.5 shrink-0" />
                <span className="flex-1 text-left">
                  Esto es un preview — todavía no se ejecutó nada.
                </span>
                <Button type="button" size="xs"
                  className="gap-1 bg-warning text-warning-foreground hover:bg-warning/90"
                  onClick={onExecutePlan}>
                  <Play className="size-3" /> Ejecutar este plan
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// ─── Vista principal ─────────────────────────────────────────────────────────

export default function OrchestratorChatView({ engagementId = 1, embedded = false }) {
  const [turns,      setTurns]      = useState([])
  const [input,      setInput]      = useState('')
  const [mode,       setMode]       = useState('plan')   // 'plan' | 'execute'
  const [sending,    setSending]    = useState(false)
  const [connStatus, setConnStatus] = useState('connecting')
  const esRef     = useRef(null)
  const seenRef   = useRef(new Set())     // _id de turnos ya renderizados (dedup)
  const bottomRef = useRef(null)
  const inputRef  = useRef(null)
  const lastMsgRef = useRef('')           // última instrucción enviada (para "Ejecutar este plan")
  const navigate  = useNavigate()

  const goHitl = useCallback(() => navigate(ROUTES.hitl), [navigate])

  // Un chip rellena el input (sin enviar) y enfoca para que el operador edite
  // y elija Plan/Ejecutar. Coloca el cursor al final.
  const pickPrompt = useCallback((text) => {
    setInput(text)
    requestAnimationFrame(() => {
      const el = inputRef.current
      if (el) { el.focus(); el.setSelectionRange(text.length, text.length) }
    })
  }, [])

  // Merge de turnos dedupeado por _id (GET inicial + SSE incremental).
  const mergeTurns = useCallback((incoming) => {
    const fresh = incoming.filter((t) => {
      const id = t._id || `${t.role}-${t.created_at}-${(t.content || '').slice(0, 24)}`
      if (seenRef.current.has(id)) return false
      seenRef.current.add(id)
      return true
    })
    if (fresh.length) setTurns((prev) => [...prev, ...fresh])
  }, [])

  // ── Carga inicial de la conversación ───────────────────────────────────────
  const fetchConversation = useCallback(async () => {
    try {
      const res = await authedFetch(`/engagements/${engagementId}/orchestrator/conversation`)
      if (!res.ok) return
      const data = await res.json()
      mergeTurns(data.turns || [])
    } catch { /* offline — el SSE reintenta */ }
  }, [engagementId, mergeTurns])

  // ── SSE en vivo ────────────────────────────────────────────────────────────
  useEffect(() => {
    // Reset al cambiar de engagement
    seenRef.current = new Set()
    setTurns([])
    if (esRef.current) { esRef.current.close(); esRef.current = null }

    let cancelled = false
    fetchConversation()

    try {
      // El endpoint SSE es abierto (igual que /agent-runs/stream): EventSource no
      // puede setear headers y el stream no exige X-API-Key.
      const url = `${API_BASE}/engagements/${engagementId}/orchestrator/stream`
      const es = new EventSource(url)
      esRef.current = es

      es.addEventListener('hello', () => { if (!cancelled) setConnStatus('live') })
      es.addEventListener('turn', (ev) => {
        if (cancelled) return
        try { mergeTurns([JSON.parse(ev.data)]) } catch { /* ignore */ }
        setConnStatus('live')
      })
      es.onerror = () => {
        if (cancelled) return
        setConnStatus('offline')
      }
    } catch {
      setConnStatus('offline')
    }

    return () => {
      cancelled = true
      if (esRef.current) { esRef.current.close(); esRef.current = null }
    }
  }, [engagementId, fetchConversation, mergeTurns])

  // Auto-scroll al último turno
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [turns])

  // ── Enviar mensaje ─────────────────────────────────────────────────────────
  // postMessage centraliza el POST para que tanto el envío normal como el atajo
  // "Ejecutar este plan" compartan el mismo manejo de 202/200/errores.
  const postMessage = useCallback(async (message, sendMode) => {
    if (!message || sending) return
    setSending(true)
    try {
      const res = await authedFetch(`/engagements/${engagementId}/orchestrator`, {
        method: 'POST',
        body: JSON.stringify({ message, mode: sendMode }),
      })
      const data = await res.json().catch(() => ({}))

      if (res.status === 202 || data.status === 'queued') {
        toast.success('Orquestador ejecutando — el avance aparece en el chat.')
        setInput('')
      } else if (res.ok) {
        // Plan: el turno se persiste server-side y llega por SSE; refrescamos
        // como red de seguridad por si el SSE está caído.
        setInput('')
        fetchConversation()
      } else {
        throw new Error(data?.detail?.message || data?.detail || `HTTP ${res.status}`)
      }
    } catch (e) {
      toast.error(`Error: ${e.message}`)
    } finally {
      setSending(false)
    }
  }, [engagementId, sending, fetchConversation])

  const send = useCallback(() => {
    const message = input.trim()
    if (!message) return
    lastMsgRef.current = message
    postMessage(message, mode)
  }, [input, mode, postMessage])

  // Atajo del bubble de plan: re-delega la última instrucción en modo execute.
  const executePlan = useCallback(() => {
    const message = lastMsgRef.current
    if (!message) {
      toast.error('No tengo la instrucción a ejecutar; reescríbela y usa "Ejecutar".')
      return
    }
    setMode('execute')
    postMessage(message, 'execute')
  }, [postMessage])

  const onKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      send()
    }
  }

  // ── Render ───────────────────────────────────────────────────────────────
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_minmax(280px,340px)]">
      <div className="flex min-w-0 flex-col gap-4">
      {!embedded && (
        <div className="flex items-center gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
              <Bot className="size-6 text-primary" />
              Orquestador
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Chat del operador · Engagement #{engagementId}
            </p>
          </div>
          <ConnBadge status={connStatus} className="ml-auto" />
        </div>
      )}

      {/* Aviso de guardarraíl */}
      <div className="flex items-start gap-2 rounded-md border border-border bg-card/50 px-3 py-2
                      text-xs text-muted-foreground">
        <Zap className="mt-0.5 size-3.5 shrink-0 text-primary" />
        <span>
          El scope y el HITL son control en código. El orquestador <strong>planifica y delega</strong>,
          pero no aprueba acciones de riesgo por chat: esas se aprueban en la{' '}
          <button type="button" onClick={goHitl} className="text-primary underline-offset-2 hover:underline">
            consola HITL
          </button>.
        </span>
        {embedded && <ConnBadge status={connStatus} className="ml-auto" />}
      </div>

      {/* Mensajes — aria-live para que los lectores de pantalla anuncien los
          turnos que llegan por SSE en vivo. */}
      <Card>
        <CardContent
          className="flex max-h-[55vh] min-h-[280px] flex-col gap-4 overflow-y-auto p-4"
          aria-live="polite"
          aria-relevant="additions text"
          aria-busy={sending}
        >
          {turns.length === 0 ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-4 py-8 text-center">
              <Bot className="size-8 text-muted-foreground/30" />
              <div className="space-y-1">
                <div className="text-sm font-medium text-foreground">
                  Sin conversación todavía
                </div>
                <div className="text-xs text-muted-foreground/70">
                  Escribe una instrucción en lenguaje natural o usa un atajo:
                </div>
              </div>

              {/* Micro-capacidades — qué sabe hacer el orquestador (transparencia) */}
              <div className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1
                              text-[11px] text-muted-foreground/70">
                <span className="font-medium text-muted-foreground">Puede:</span>
                {['recon', 'escaneo', 'análisis', 'reporte'].map((cap, i) => (
                  <span key={cap} className="flex items-center gap-2">
                    {i > 0 && <span className="text-muted-foreground/40">·</span>}
                    {cap}
                  </span>
                ))}
              </div>

              <QuickPrompts onPick={pickPrompt} />
            </div>
          ) : (
            turns.map((t, i) => (
              <TurnBubble key={t._id || i} turn={t} onOpenHitl={goHitl} onExecutePlan={executePlan} />
            ))
          )}
          <div ref={bottomRef} />
        </CardContent>
      </Card>

      {/* Input + modo */}
      <Card>
        <CardContent className="flex flex-col gap-2 p-3">
          {/* Chips siempre accesibles una vez iniciada la conversación
              (cuando está vacía ya se muestran en el empty state). */}
          {turns.length > 0 && <QuickPrompts onPick={pickPrompt} compact />}

          <Textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Escribe tu instrucción para el orquestador… (Enter envía, Shift+Enter salto de línea)"
            className="min-h-[64px] resize-none"
            disabled={sending}
          />
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
            <ModeToggle mode={mode} setMode={setMode} disabled={sending} />
            <span className="text-[11px] text-muted-foreground/70">
              {mode === 'plan'
                ? 'Preview: muestra el plan sin ejecutar nada.'
                : 'Delega de verdad en los workers (acción real, en background).'}
            </span>
            <Button
              type="button"
              onClick={send}
              disabled={sending || !input.trim()}
              className={cn(
                'ml-auto gap-2',
                mode === 'execute' && 'bg-warning text-warning-foreground hover:bg-warning/90',
              )}
            >
              {mode === 'plan' ? <Send className="size-4" /> : <Play className="size-4" />}
              {sending ? 'Enviando…' : mode === 'plan' ? 'Planificar' : 'Ejecutar'}
            </Button>
          </div>
        </CardContent>
      </Card>
      </div>

      {/* Cuadro lateral de actividad en vivo — narración simple de lo que hace el
          sistema (frases generadas en backend: services/narration.py). Sticky en
          desktop; se apila debajo del chat en pantallas chicas. */}
      <aside className="lg:sticky lg:top-4 lg:self-start">
        <ActivityConsole engagementId={engagementId} />
      </aside>
    </div>
  )
}

// ─── Quick prompts (chips) ───────────────────────────────────────────────────
// Botones reales (focusables, Enter activa, foco visible) — cumplen WCAG 2.4.7.

function QuickPrompts({ onPick, compact = false }) {
  return (
    <div className={cn('flex flex-wrap gap-2', compact ? 'justify-start' : 'justify-center')}>
      {QUICK_PROMPTS.map((p) => {
        const Icon = p.icon
        return (
          <Button
            key={p.label}
            type="button"
            variant="outline"
            size={compact ? 'xs' : 'sm'}
            onClick={() => onPick(p.text)}
            title={`Rellena: "${p.text}"`}
            className="gap-1.5 text-muted-foreground hover:text-foreground"
          >
            <Icon className="size-3.5" />
            {p.label}
          </Button>
        )
      })}
    </div>
  )
}

// ─── Mode toggle (plan / execute) ────────────────────────────────────────────
// Propose-and-commit: Plan es preview inocuo; Ejecutar es el commit real, por eso
// se marca con acento de advertencia al estar activo.

function ModeToggle({ mode, setMode, disabled }) {
  const opts = [
    { id: 'plan',    label: 'Plan',     Icon: ListChecks, activeCls: 'bg-primary text-primary-foreground' },
    { id: 'execute', label: 'Ejecutar', Icon: Play,       activeCls: 'bg-warning text-warning-foreground' },
  ]
  return (
    <div role="group" aria-label="Modo del orquestador"
      className="inline-flex rounded-md border border-border p-0.5">
      {opts.map((m) => {
        const active = mode === m.id
        const Icon = m.Icon
        return (
          <button
            key={m.id}
            type="button"
            disabled={disabled}
            aria-pressed={active}
            onClick={() => setMode(m.id)}
            className={cn(
              'flex items-center gap-1.5 rounded px-3 py-1.5 text-xs font-medium transition-colors',
              active ? m.activeCls : 'text-muted-foreground hover:text-foreground',
              disabled && 'cursor-not-allowed opacity-60'
            )}
          >
            <Icon className="size-3.5" />
            {m.label}
          </button>
        )
      })}
    </div>
  )
}

// ─── Connection badge ────────────────────────────────────────────────────────

function ConnBadge({ status, className }) {
  const meta = {
    live:       { icon: Wifi,    color: 'text-success bg-success/15 border-success/40',         label: 'live' },
    connecting: { icon: Wifi,    color: 'text-warning bg-warning/15 border-warning/40',         label: 'connecting' },
    offline:    { icon: WifiOff, color: 'text-destructive bg-destructive/15 border-destructive/40', label: 'offline' },
  }[status] || { icon: Wifi, color: 'text-muted-foreground bg-muted border-border', label: status }
  const Icon = meta.icon
  return (
    <Badge variant="outline" className={cn('gap-1.5 font-mono text-xs uppercase tracking-wider', meta.color, className)}>
      <Icon className="size-3" />
      {meta.label}
    </Badge>
  )
}
