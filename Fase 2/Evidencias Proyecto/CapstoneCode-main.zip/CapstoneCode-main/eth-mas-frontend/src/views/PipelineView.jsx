// PipelineView — Orquestación end-to-end del pipeline ETH-MAS.
// Suscribe a SSE /pipeline-runs/stream, muestra stepper de stages y permite
// drill-down a cada AgentRun via RunDetailDrawer.
//
// Migrado a Tailwind v4 + shadcn (Card, Button, Checkbox, Badge) + lucide-react.

import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import {
  Play, Eye, ArrowRight, Wifi, WifiOff, AlertTriangle, Clock,
  Zap, PauseCircle, ChevronDown, CheckCircle2, Lock,
} from 'lucide-react'

import { authedFetch, API_BASE } from '@/lib/api'
import { ROUTES } from '@/lib/routes'
import RunDetailDrawer, {
  STATUS_COLOR, STATUS_ICON_COMPONENT,
  fmtMs, fmtDateTime, durationOf,
} from '@/components/RunDetailDrawer'
import HitlView from './HitlView'

import { Card, CardContent } from '@/components/ui/card'
import { Button }    from '@/components/ui/button'
import { Checkbox }  from '@/components/ui/checkbox'
import { Badge }     from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { cn }        from '@/lib/utils'

// Pipeline completo de 4 stages goal-driven (ADR-005): Recon → Scan → Analysis → Report.
// Debe mantenerse alineado con DEFAULT_STAGES de pipeline_controller.py (backend).
const DEFAULT_STAGES = ['ReconAgent', 'ScanAgent', 'AnalysisAgent', 'ReporterAgent']

// El tab Pipeline debe mostrar el assessment COMPLETO, no la última corrida sin más:
// re-ejecutar Analysis o Reporter (desde otras tabs) crea pipeline_runs de 1 stage
// que, por recencia, tapaban la corrida 4/4. Elegimos la corrida "representativa":
// la de más stages, desempatando por más reciente.
function pickRepresentativeRun(runs) {
  if (!runs || runs.length === 0) return null
  return [...runs].sort((a, b) => {
    const sa = a.stages?.length || 0
    const sb = b.stages?.length || 0
    if (sb !== sa) return sb - sa
    return new Date(b.started_at || 0) - new Date(a.started_at || 0)
  })[0]
}

// ¿La corrida entrante (SSE) debe reemplazar a la mostrada? Una corrida activa
// siempre gana (progreso en vivo); si no, solo gana si tiene >= stages, para que
// un run de 1 stage no tape el assessment completo ya visible.
function shouldReplaceRun(prev, next) {
  if (!next) return false
  if (!prev) return true
  if (next.status === 'running' || next.status === 'waiting_hitl') return true
  return (next.stages?.length || 0) >= (prev.stages?.length || 0)
}

// ─── StageCard ───────────────────────────────────────────────────────────────

function StageCard({ stage, idx, isLast, onOpenRun }) {
  const colorClass = STATUS_COLOR[stage.status] || 'text-muted-foreground'
  const Icon       = STATUS_ICON_COMPONENT[stage.status]
  const dur        = durationOf(stage)
  const isRunning  = stage.status === 'running'

  return (
    <>
      <Card className={cn(
        'flex-1 min-w-[180px] transition-shadow',
        isRunning && 'ring-2 ring-warning/40 ring-offset-2 ring-offset-background'
      )}>
        <CardContent className="px-4 py-3 space-y-2">
          <div className="flex items-center gap-2">
            <div className={cn(
              'flex size-7 shrink-0 items-center justify-center rounded-full border-2',
              stage.status === 'pending'
                ? 'bg-background text-muted-foreground border-border'
                : cn('bg-current/15', colorClass)
            )}>
              {stage.status === 'pending' || !Icon
                ? <span className="text-xs font-bold">{idx + 1}</span>
                : <Icon className={cn('size-3.5', colorClass)} />}
            </div>
            <div className="text-sm font-bold text-foreground">{stage.agent}</div>
          </div>

          <div className="flex items-center gap-1.5">
            <span className={cn(
              'font-mono text-[10px] uppercase tracking-wider',
              colorClass
            )}>
              {stage.status}
            </span>
            {dur != null && (
              <span className="font-mono text-[10px] text-muted-foreground/70">
                · {fmtMs(dur)}
              </span>
            )}
          </div>

          {stage.summary && (
            <div className="text-[11px] leading-snug text-muted-foreground">
              {stage.summary}
            </div>
          )}

          {stage.error && (
            <div
              title={stage.error}
              className="flex items-center gap-1 truncate font-mono text-[11px] text-destructive"
            >
              <AlertTriangle className="size-3 shrink-0" />
              <span className="truncate">{stage.error}</span>
            </div>
          )}

          {stage.agent_run_id && (
            <Button
              type="button"
              variant="outline"
              size="xs"
              onClick={() => onOpenRun(stage.agent_run_id)}
              className="gap-1 text-primary"
            >
              <Eye className="size-3" /> Ver run
            </Button>
          )}
        </CardContent>
      </Card>

      {!isLast && (
        <div className={cn(
          'mx-1 my-auto h-0.5 w-6 shrink-0',
          stage.status === 'completed' ? 'bg-success' : 'bg-border'
        )} />
      )}
    </>
  )
}

// ─── Vista principal ──────────────────────────────────────────────────────────

export default function PipelineView({ engagementId = 1, embedded = false, onEngagementUpdated }) {
  const [pipeline,   setPipeline]    = useState(null)
  const [connStatus, setConnStatus]  = useState('connecting')   // connecting | live | idle | offline
  const [launching,  setLaunching]   = useState(false)
  const [openRunId,  setOpenRunId]   = useState(null)
  const [stagesSelected, setStagesSelected] = useState(DEFAULT_STAGES)
  const [hitlOpen, setHitlOpen] = useState(true)
  const [engStatus, setEngStatus] = useState(null)   // status del engagement (BUG-2)
  const [closing,   setClosing]   = useState(false)
  const esRef   = useRef(null)
  const pollRef = useRef(null)
  const navigate = useNavigate()

  // ── Status del engagement (BUG-2: ciclo de vida) ─────────────────────────
  // El pipeline NO cierra el engagement automáticamente (un engagement admite
  // N pipelines: re-scans, re-análisis). En su lugar, cuando el último
  // pipeline terminó completed e incluyó al ReporterAgent, sugerimos el
  // cierre manual (RUNNING → COMPLETED via PATCH /status).
  const fetchEngStatus = useCallback(async () => {
    try {
      const res = await authedFetch(`/engagements/${engagementId}`)
      if (!res.ok) return
      const data = await res.json()
      setEngStatus(data?.status || null)
    } catch { /* ignore */ }
  }, [engagementId])

  useEffect(() => {
    fetchEngStatus()
    // B1 — al llegar el pipeline a un estado terminal, el backend ya pudo cerrar
    // el engagement (un assessment completo cierra RUNNING→COMPLETED antes del
    // ReporterAgent). Avisar al workspace para que su header no quede stale en
    // "pending"/"running" mientras los PDFs ya dicen "completed".
    if (['completed', 'failed', 'aborted'].includes(pipeline?.status)) {
      onEngagementUpdated?.()
    }
  }, [fetchEngStatus, pipeline?.status, onEngagementUpdated])

  const closeEngagement = async () => {
    setClosing(true)
    const tid = toast.loading('Cerrando engagement…')
    try {
      const res = await authedFetch(`/engagements/${engagementId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'completed' }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        throw new Error(
          typeof data?.detail === 'string' ? data.detail : `HTTP ${res.status}`,
        )
      }
      toast.dismiss(tid)
      toast.success('Engagement cerrado (completed)')
      setEngStatus('completed')
      onEngagementUpdated?.()
    } catch (e) {
      toast.dismiss(tid)
      toast.error(`Error al cerrar: ${e.message}`)
    } finally {
      setClosing(false)
    }
  }

  // ── REST snapshot inicial ────────────────────────────────────────────────
  const fetchLatest = useCallback(async () => {
    try {
      // Traemos varias y elegimos la representativa (assessment completo), no la
      // última cronológica — que puede ser un re-Analysis/Reporter de 1 stage.
      const res = await authedFetch(`/engagements/${engagementId}/pipeline-runs?limit=20`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      const rep = pickRepresentativeRun(data.pipeline_runs || [])
      setPipeline(rep)
      setConnStatus(rep ? 'live' : 'idle')
    } catch {
      setConnStatus('offline')
    }
  }, [engagementId])

  // ── Conexión SSE ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (esRef.current)   { esRef.current.close();   esRef.current = null }
    if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null }

    let cancelled = false
    fetchLatest()

    try {
      const url = `${API_BASE}/engagements/${engagementId}/pipeline-runs/stream`
      const es  = new EventSource(url)
      esRef.current = es

      es.addEventListener('hello', () => {
        if (!cancelled) setConnStatus('live')
      })

      es.addEventListener('pipeline', (ev) => {
        if (cancelled) return
        try {
          const data = JSON.parse(ev.data)
          if (data && data.status === 'idle') {
            // Sin pipeline activo: NO borramos la corrida representativa ya
            // mostrada (el operador sigue viendo el assessment completo).
            setConnStatus('idle')
          } else {
            // No dejamos que un run de 1 stage tape el assessment completo;
            // una corrida activa sí gana (progreso en vivo).
            setPipeline((prev) => (shouldReplaceRun(prev, data) ? data : prev))
            setConnStatus('live')
          }
        } catch { /* ignore */ }
      })

      es.addEventListener('end', () => {
        es.close()
        esRef.current = null
        pollRef.current = setInterval(fetchLatest, 5000)
      })

      es.onerror = () => {
        if (cancelled) return
        es.close()
        esRef.current = null
        setConnStatus('offline')
        pollRef.current = setInterval(fetchLatest, 3000)
      }
    } catch {
      setConnStatus('offline')
      pollRef.current = setInterval(fetchLatest, 3000)
    }

    return () => {
      cancelled = true
      if (esRef.current)   { esRef.current.close();   esRef.current = null }
      if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null }
    }
  }, [engagementId, fetchLatest])

  // ── Lanzar pipeline ──────────────────────────────────────────────────────
  // Fix 2.4 — el backend ahora responde 202 Accepted con status='queued' y
  // ejecuta el pipeline en background. El progreso real viene por SSE.
  // 409 = hay HITL pendientes preexistentes que bloquean el lanzamiento.
  const launchPipeline = async () => {
    setLaunching(true)
    const loadingId = toast.loading(`Lanzando pipeline (${stagesSelected.join(' → ')})…`)
    try {
      const res = await authedFetch(`/engagements/${engagementId}/pipeline`, {
        method: 'POST',
        body: JSON.stringify({ stages: stagesSelected, stop_on_failure: true }),
      })
      const data = await res.json().catch(() => ({}))
      toast.dismiss(loadingId)

      if (res.status === 202 || data.status === 'queued') {
        toast.success('Pipeline encolado — sigue el progreso en el stepper.')
        fetchLatest()
        return
      }

      if (res.status === 409) {
        // Dos causas posibles: HITL pendientes (detail dict con ids) o
        // engagement en estado terminal (detail string).
        const ids = data?.detail?.pending_hitl_ids
        if (Array.isArray(ids) && ids.length > 0) {
          toast.error(
            `Bloqueado: hay ${ids.length} HITL pendiente(s) (#${ids.join(', #')}). ` +
            `Resolver antes de lanzar.`,
            {
              action: { label: 'Ir a HITL', onClick: () => navigate(ROUTES.hitl) },
            },
          )
        } else {
          toast.error(
            typeof data?.detail === 'string'
              ? data.detail
              : 'Bloqueado: el engagement no admite lanzar el pipeline en su estado actual.',
          )
        }
        return
      }

      if (!res.ok) {
        throw new Error(
          data?.detail?.message || data?.detail || data?.message || `HTTP ${res.status}`,
        )
      }

      // Compatibilidad con respuesta legacy (200 con dict del pipeline completo)
      if (data.status === 'completed') {
        toast.success(`Pipeline ${data.status}: ${data.summary}`)
      } else if (data.status === 'waiting_hitl') {
        toast.warning(
          `Pipeline pausado esperando HITL: ${data.summary}`,
          { action: { label: 'Ir a HITL', onClick: () => navigate(ROUTES.hitl) } },
        )
      } else {
        toast.error(`Pipeline ${data.status}: ${data.summary}`)
      }
      fetchLatest()
    } catch (e) {
      toast.dismiss(loadingId)
      toast.error(`Error: ${e.message}`)
    } finally {
      setLaunching(false)
    }
  }

  const toggleStage = (stage) => {
    setStagesSelected((prev) =>
      prev.includes(stage) ? prev.filter((s) => s !== stage) : [...prev, stage]
    )
  }

  // ── Estado derivado ──────────────────────────────────────────────────────
  const stages    = pipeline?.stages || stagesSelected.map((agent) => ({ agent, status: 'pending' }))
  const isRunning = pipeline?.status === 'running'
  const pipDur    = durationOf(pipeline) || 0
  const runningStage = stages.find((s) => s.status === 'running')

  // Sugerencia de cierre (BUG-2): pipeline completed que incluyó ReporterAgent
  // exitoso + engagement todavía running (única transición legal a completed).
  const reporterDone = (pipeline?.stages || []).some(
    (s) => s.agent === 'ReporterAgent' && s.status === 'completed',
  )
  const suggestClose =
    pipeline?.status === 'completed' && reporterDone && engStatus === 'running'

  // ── Render ───────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col gap-8">

      {/* Header (oculto en modo embedded; el Workspace ya muestra el engagement) */}
      {!embedded ? (
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Pipeline</h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Orquestación end-to-end · Engagement #{engagementId}
            </p>
          </div>
          <ConnectionBadge status={connStatus} isRunning={isRunning} className="ml-auto" />
        </div>
      ) : (
        <div className="flex justify-end">
          <ConnectionBadge status={connStatus} isRunning={isRunning} />
        </div>
      )}

      {/* Launch controls */}
      <Card>
        <CardContent className="flex flex-wrap items-center gap-3 p-5">
          <div className="text-sm text-muted-foreground">Stages:</div>
          {DEFAULT_STAGES.map((s) => {
            const on = stagesSelected.includes(s)
            return (
              <label
                key={s}
                className={cn(
                  'flex items-center gap-2 rounded-md border px-2.5 py-1 text-sm transition-colors',
                  on
                    ? 'border-primary bg-primary/10 text-primary font-medium'
                    : 'border-border text-muted-foreground hover:bg-accent hover:text-foreground',
                  isRunning ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'
                )}
              >
                <Checkbox
                  checked={on}
                  disabled={isRunning}
                  onCheckedChange={() => toggleStage(s)}
                />
                {s}
              </label>
            )
          })}

          <Button
            type="button"
            onClick={launchPipeline}
            disabled={launching || isRunning || stagesSelected.length === 0}
            size="lg"
            className="ml-auto gap-2"
          >
            <Play className="size-4" />
            {launching ? 'Lanzando…' : isRunning ? 'Pipeline en curso' : 'Lanzar Pipeline'}
          </Button>
        </CardContent>
      </Card>

      {/* Fix 4.2a — Banner waiting_hitl.
          Cuando el pipeline está pausado esperando aprobación, mostramos un
          banner explícito con CTA al tab/ruta de HITL. Antes el operador veía
          el stepper en "waiting_hitl" sin saber qué hacer. */}
      {pipeline?.status === 'waiting_hitl' && (
        <Card className="border-l-4 border-l-warning bg-warning/5">
          <CardContent className="flex flex-wrap items-center gap-4 p-4">
            <PauseCircle className="size-6 shrink-0 text-warning" />
            <div className="min-w-0 flex-1">
              <div className="text-sm font-semibold text-foreground">
                Pipeline pausado esperando aprobación HITL
              </div>
              <div className="mt-0.5 text-xs text-muted-foreground">
                Una stage devolvió status <code className="font-mono">waiting_hitl</code>.
                Aprueba o rechaza las acciones pendientes para que el pipeline continúe
                automáticamente.
                {pipeline.summary && (
                  <span className="ml-1 text-muted-foreground/70">— {pipeline.summary}</span>
                )}
              </div>
            </div>
            <Button
              type="button"
              size="sm"
              className="gap-1.5 bg-warning text-warning-foreground hover:bg-warning/90"
              onClick={() => navigate(ROUTES.hitl)}
            >
              <Zap className="size-3.5" />
              Ver acciones pendientes
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Sugerencia de cierre (BUG-2) — el pipeline completo con reporte
          generado no cierra el engagement automáticamente (puede haber
          re-scans). Se ofrece el cierre manual al operador. */}
      {suggestClose && (
        <Card className="border-l-4 border-l-success bg-success/5">
          <CardContent className="flex flex-wrap items-center gap-4 p-4">
            <CheckCircle2 className="size-6 shrink-0 text-success" />
            <div className="min-w-0 flex-1">
              <div className="text-sm font-semibold text-foreground">
                Pipeline completo — reportes generados
              </div>
              <div className="mt-0.5 text-xs text-muted-foreground">
                El ReporterAgent terminó. Si el engagement ya no necesita más
                corridas, puedes cerrarlo (<code className="font-mono">running → completed</code>).
                El cierre es terminal: un engagement cerrado no admite nuevos pipelines.
              </div>
            </div>
            <Button
              type="button"
              size="sm"
              disabled={closing}
              onClick={closeEngagement}
              className="gap-1.5 bg-success text-success-foreground hover:bg-success/90"
            >
              <Lock className="size-3.5" />
              {closing ? 'Cerrando…' : 'Cerrar engagement'}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Pipeline meta */}
      {pipeline && (
        <Card>
          <CardContent className="p-5">
            <div className="grid grid-cols-[repeat(auto-fit,minmax(140px,1fr))] gap-4">
              {[
                {
                  label: 'Status', value: pipeline.status,
                  className: STATUS_COLOR[pipeline.status],
                },
                { label: 'Pipeline ID',  value: pipeline._id, mono: true },
                { label: 'Triggered by', value: pipeline.triggered_by || 'operator' },
                {
                  label: 'Stages',
                  value: `${stages.filter((s) => s.status === 'completed').length}/${stages.length} ok`,
                },
                { label: 'Duración', value: fmtMs(pipDur), mono: true },
                { label: 'Inicio',   value: fmtDateTime(pipeline.started_at),  mono: true },
                { label: 'Fin',      value: fmtDateTime(pipeline.finished_at), mono: true },
              ].map((f) => (
                <div key={f.label}>
                  <div className="mb-1 text-[10px] text-muted-foreground/70">{f.label}</div>
                  <div className={cn(
                    'truncate text-sm font-semibold text-foreground',
                    f.mono && 'font-mono',
                    f.className,
                  )}>
                    {f.value ?? '—'}
                  </div>
                </div>
              ))}
            </div>

            {pipeline.summary && (
              <>
                <Separator className="my-3" />
                <div className="text-sm text-muted-foreground">
                  <span className="text-muted-foreground/70">Summary:</span> {pipeline.summary}
                </div>
              </>
            )}

            {pipeline.error && (
              <>
                <Separator className="my-3" />
                <div className="flex items-start gap-2 font-mono text-sm text-destructive">
                  <AlertTriangle className="mt-0.5 size-4 shrink-0" />
                  <span>{pipeline.error}</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      )}

      {/* Stepper */}
      <div className="flex flex-wrap items-stretch gap-1">
        {stages.map((stage, i) => (
          <StageCard
            key={`${stage.agent}-${i}`}
            stage={stage}
            idx={i}
            isLast={i === stages.length - 1}
            onOpenRun={setOpenRunId}
          />
        ))}
      </div>

      {/* Vacío */}
      {!pipeline && (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <Play className="size-8 text-muted-foreground/30" />
            <div className="text-sm text-muted-foreground">
              Sin pipeline runs registrados
            </div>
            <div className="text-xs text-muted-foreground/70">
              Selecciona las stages y presiona <strong>Lanzar Pipeline</strong> para iniciar
              la cadena Recon → Scan → Analysis → Report.
            </div>
          </CardContent>
        </Card>
      )}

      {/* CTA cuando hay stage en ejecución */}
      {runningStage && runningStage.agent_run_id && (
        <div className="flex items-center gap-3 rounded-md border border-warning/40
                        border-dashed bg-warning/10 p-3 text-sm text-warning">
          <Clock className="size-4 shrink-0 animate-pulse" />
          <span className="flex-1">
            <strong>{runningStage.agent}</strong> está ejecutándose.
            Abre el live terminal para ver el log de tool calls en vivo.
          </span>
          <Button
            type="button"
            onClick={() => setOpenRunId(runningStage.agent_run_id)}
            size="sm"
            className="gap-1 bg-warning text-warning-foreground hover:bg-warning/90"
          >
            <Eye className="size-3.5" />
            Abrir live terminal
            <ArrowRight className="size-3.5" />
          </Button>
        </div>
      )}

      {/* HITL en contexto — aprobación embebida dentro del Pipeline.
          Cuando una stage gatilla una acción de riesgo, el operador aprueba/rechaza
          aquí mismo sin salir del flujo. Filtrado al engagement activo. */}
      <Card className="overflow-hidden">
        <button
          type="button"
          onClick={() => setHitlOpen((o) => !o)}
          className="flex w-full items-center gap-2 px-5 py-3 text-left transition-colors hover:bg-accent"
        >
          <Zap className="size-4 text-warning" />
          <span className="text-sm font-semibold text-foreground">Aprobaciones HITL</span>
          <span className="text-xs text-muted-foreground/70">· engagement #{engagementId}</span>
          <ChevronDown className={cn(
            'ml-auto size-4 text-muted-foreground/70 transition-transform',
            !hitlOpen && '-rotate-90',
          )} />
        </button>
        {hitlOpen && (
          <CardContent className="border-t border-border pt-4">
            <HitlView engagementId={engagementId} embedded />
          </CardContent>
        )}
      </Card>

      {/* Drawer */}
      <RunDetailDrawer runId={openRunId} onClose={() => setOpenRunId(null)} />
    </div>
  )
}

// ─── ConnectionBadge ─────────────────────────────────────────────────────────

function ConnectionBadge({ status, isRunning, className }) {
  const meta = {
    live:       isRunning
                  ? { icon: Wifi,      color: 'text-success bg-success/15 border-success/40', label: 'live' }
                  : { icon: Wifi,      color: 'text-success bg-success/15 border-success/40', label: 'connected' },
    idle:       { icon: Wifi,      color: 'text-muted-foreground bg-muted border-border',  label: 'idle' },
    offline:    { icon: WifiOff,   color: 'text-destructive bg-destructive/15 border-destructive/40', label: 'offline' },
    connecting: { icon: Wifi,      color: 'text-warning bg-warning/15 border-warning/40',   label: 'connecting' },
  }[status] || { icon: Wifi, color: 'text-muted-foreground bg-muted border-border', label: status }

  const Icon = meta.icon
  return (
    <Badge variant="outline"
      className={cn(
        'gap-1.5 font-mono uppercase tracking-wider text-xs',
        meta.color,
        className
      )}
    >
      <Icon className="size-3" />
      {meta.label}
    </Badge>
  )
}
