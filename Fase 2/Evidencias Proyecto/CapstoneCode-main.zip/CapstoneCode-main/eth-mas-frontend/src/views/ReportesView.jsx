// ReportesView — Generación y descarga de informes de pentesting.
//
// Migrado a Tailwind v4 + shadcn (Card, Select, Button, Checkbox) + lucide-react.

import { useState, useEffect, useCallback } from 'react'
import {
  FileText, Play, Download, Eye, Hourglass, AlertOctagon,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { Card, CardContent } from '@/components/ui/card'
import { Button }   from '@/components/ui/button'
import { Badge }    from '@/components/ui/badge'
import { Label }    from '@/components/ui/label'
import { Input }    from '@/components/ui/input'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'

const TYPE_LABELS = { technical: 'Técnico', executive: 'Ejecutivo' }

const fmtDate = (iso) => {
  if (!iso) return '—'
  const d = new Date(iso)
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString('es-CL', { hour12: false })
}

const fmtSize = (bytes) =>
  (typeof bytes === 'number' ? `${(bytes / 1024).toFixed(0)} KB` : '—')

// ─── Export embedded body (sin header) para uso en Workspace ─────────────────

// Props:
//   engagementId : number   (opcional) — si viene, hereda el engagement del
//                  Workspace y NO muestra su propio selector.
//   embedded     : bool     — modo dentro del Workspace.
export function ReportesViewBody({ engagementId = null, embedded = false }) {
  const [engagements, setEngagements] = useState([])
  // En modo embedded el engagement lo fija el Workspace; si no, selector propio.
  const [selectedEngState, setSelectedEng] = useState('')
  const selectedEng = embedded && engagementId != null
    ? String(engagementId)
    : selectedEngState
  const [generando,   setGenerando]   = useState(false)
  const [error,       setError]       = useState(null)
  const [nombre,      setNombre]      = useState('')   // nombre base que el operador asigna al reporte
  const [reportes,    setReportes]    = useState([])   // GET /reports → [{file_id,filename,type,length,upload_date,…}]

  // Cargar engagements solo cuando hay selector propio (no embebido).
  useEffect(() => {
    if (embedded) return
    authedFetch('/engagements')
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => setEngagements(Array.isArray(data) ? data : []))
      .catch(() => setEngagements([]))
  }, [embedded])

  // Histórico real desde GridFS (incluye reportes generados por pipeline).
  const fetchReportes = useCallback(async (engId) => {
    if (!engId) { setReportes([]); return }
    try {
      const res = await authedFetch(`/engagements/${engId}/reports`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setReportes(Array.isArray(data.reports) ? data.reports : [])
    } catch { setReportes([]) }
  }, [])

  useEffect(() => { fetchReportes(selectedEng) }, [selectedEng, fetchReportes])

  const fetchPdf = useCallback(async (engId, fileId) => {
    const res = await authedFetch(`/engagements/${engId}/report?file_id=${fileId}`)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    return res.blob()
  }, [])

  const downloadPdf = useCallback(async (engId, rep) => {
    try {
      const blob = await fetchPdf(engId, rep.file_id)
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url; a.download = rep.filename || `eng_${engId}_${rep.type}.pdf`
      document.body.appendChild(a); a.click(); a.remove()
      URL.revokeObjectURL(url)
    } catch (e) { setError(`No se pudo descargar el PDF: ${e.message}`) }
  }, [fetchPdf])

  const previewPdf = useCallback(async (engId, rep) => {
    try {
      const blob = await fetchPdf(engId, rep.file_id)
      window.open(URL.createObjectURL(blob), '_blank')
    } catch (e) { setError(`No se pudo abrir el PDF: ${e.message}`) }
  }, [fetchPdf])

  const iniciarGeneracion = useCallback(async () => {
    if (!selectedEng) { setError('Selecciona un engagement primero.'); return }
    setGenerando(true); setError(null)
    try {
      const res = await authedFetch(`/engagements/${selectedEng}/report`, {
        method: 'POST',
        body: JSON.stringify({ name: nombre.trim() || null }),
      })
      if (!res.ok) {
        const detail = await res.json().catch(() => ({}))
        throw new Error(detail.detail || `HTTP ${res.status}`)
      }
      const data = await res.json()
      const status = data?.report_result?.status
      if (status === 'failed') {
        throw new Error('El ReporterAgent falló (revisar que exista análisis previo).')
      }
      await fetchReportes(selectedEng)
    } catch (e) {
      setError(e.message || 'Error generando el reporte')
    } finally {
      setGenerando(false)
    }
  }, [selectedEng, nombre, fetchReportes])

  return (
    <div className="flex flex-col gap-6">

      {/* Generador */}
      <Card>
        <CardContent className="p-5 space-y-5">
          <div className="text-base font-semibold text-foreground">
            Generar nuevo reporte
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-[2fr_2fr_auto]">

            {/* Campos */}
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="rep-engagement">Engagement</Label>
                {embedded ? (
                  // En el Workspace el engagement viene heredado: sin selector propio.
                  <div id="rep-engagement"
                    className="flex h-9 items-center rounded-md border border-border
                               bg-background px-3 font-mono text-sm text-muted-foreground">
                    {engagementId != null
                      ? <>#{engagementId} <span className="ml-1 text-muted-foreground/60">· del workspace</span></>
                      : 'Selecciona un engagement en el workspace'}
                  </div>
                ) : (
                  <Select value={selectedEng} onValueChange={setSelectedEng}>
                    <SelectTrigger id="rep-engagement">
                      <SelectValue placeholder="Selecciona un engagement…" />
                    </SelectTrigger>
                    <SelectContent>
                      {engagements.length === 0 ? (
                        <SelectItem value="__placeholder" disabled>
                          Sin engagements cargados
                        </SelectItem>
                      ) : (
                        engagements.map((e) => (
                          <SelectItem key={e.id} value={String(e.id)}>
                            #{e.id} · {e.name}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>

            {/* Nombre del reporte (opcional) */}
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="rep-nombre">Nombre del reporte <span className="text-muted-foreground/60">(opcional)</span></Label>
                <Input
                  id="rep-nombre"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  placeholder="Ej: Auditoría ACME — Junio 2026"
                  maxLength={120}
                />
                <div className="text-[11px] text-muted-foreground/70">
                  Se aplica a ambos PDFs con su sufijo: <span className="font-mono">«{(nombre.trim() || 'Auditoría ACME')} — Técnico.pdf»</span>.
                  Sin nombre, se usa el genérico. El <strong>ReporterAgent</strong> genera
                  técnico y ejecutivo en una corrida (requiere análisis previo).
                </div>
              </div>
            </div>

            {/* Botón */}
            <div className="flex flex-col justify-end gap-1.5">
              <Button onClick={iniciarGeneracion} disabled={generando || !selectedEng}
                size="lg" className="gap-2">
                {generando
                  ? <><Hourglass className="size-4 animate-spin" /> Generando…</>
                  : <><Play className="size-4" /> Generar reportes</>}
              </Button>
              <div className="text-center text-xs text-muted-foreground/70">
                ReporterAgent · ~30-90 s (LLM + render)
              </div>
            </div>
          </div>

          {/* Estado de generación (sin % falso: el render no reporta progreso) */}
          {generando && (
            <div className="rounded-md border border-border bg-background p-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Hourglass className="size-4 animate-spin text-primary" />
                ReporterAgent procesando — narrativa + render técnico/ejecutivo…
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-border">
                <div className="h-full w-1/3 animate-pulse rounded-full bg-primary" />
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2 rounded-md border border-destructive/40
                            bg-destructive/10 p-3 text-sm font-mono text-destructive">
              <AlertOctagon className="size-4 shrink-0" />
              {error}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tabla de reportes */}
      <Card className="overflow-hidden">
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <span className="text-base font-semibold text-foreground">
            Reportes disponibles
          </span>
          <Badge variant="outline"
            className="bg-primary/15 text-primary border-primary/40 font-bold">
            {reportes.length} archivos
          </Badge>
        </div>

        {reportes.length === 0 ? (
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <FileText className="size-8 text-muted-foreground/30" />
            <div className="text-sm font-semibold text-muted-foreground">
              {selectedEng
                ? 'Sin reportes generados aún para este engagement'
                : 'Selecciona un engagement para ver sus reportes'}
            </div>
            <div className="text-xs text-muted-foreground/70">
              Los reportes generados (manual o vía pipeline) aparecen aquí automáticamente.
            </div>
          </CardContent>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Reporte</TableHead>
                <TableHead className="w-32">Tipo</TableHead>
                <TableHead>Generado</TableHead>
                <TableHead className="w-24">Tamaño</TableHead>
                <TableHead className="w-48">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reportes.map((r) => (
                <TableRow key={r.file_id}>
                  <TableCell className="font-mono text-sm text-muted-foreground">
                    {r.filename || `eng_${selectedEng}_${r.type}.pdf`}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={
                      r.type === 'executive'
                        ? 'bg-info/15 text-info border-info/40'
                        : 'bg-primary/15 text-primary border-primary/40'
                    }>
                      {TYPE_LABELS[r.type] || r.type}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground/70">
                    {fmtDate(r.upload_date || r.generated_at)}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground/70">
                    {fmtSize(r.length)}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="outline" size="xs"
                        onClick={() => downloadPdf(selectedEng, r)}
                        className="gap-1 border-primary/40 text-primary
                                   hover:bg-primary/10 hover:text-primary">
                        <Download className="size-3" />
                        PDF
                      </Button>
                      <Button variant="outline" size="xs"
                        onClick={() => previewPdf(selectedEng, r)}
                        className="gap-1">
                        <Eye className="size-3" />
                        Preview
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  )
}

// ─── Vista standalone (con header) ───────────────────────────────────────────

export default function ReportesView() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
          <FileText className="size-6 text-primary" />
          Reportes
        </h1>
        <p className="mt-0.5 text-sm text-muted-foreground">
          Generación y descarga de informes de pentesting
        </p>
      </div>
      <ReportesViewBody />
    </div>
  )
}
