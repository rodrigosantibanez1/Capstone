// SurfaceMapView — Mapa de superficie consolidado post-Recon.
// Stats + hosts (cards expandibles con puertos) + DNS + WHOIS + Emails OSINT.
//
// Migrado a Tailwind v4 + shadcn (Card, Table, Badge, Button) + lucide-react.

import { useState, useEffect, useCallback } from 'react'
import {
  Network, RefreshCw, Server, ChevronDown, ChevronUp,
  CheckCircle2, AlertTriangle, Mail, Globe, FileText,
} from 'lucide-react'

import { authedFetch } from '@/lib/api'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge }  from '@/components/ui/badge'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { cn } from '@/lib/utils'

const ENGAGEMENT_ID = 1

// Color por servicio — usamos clases Tailwind por categoría de riesgo
const SVC_CLASS = {
  ftp:      'text-warning border-warning/40 bg-warning/10',
  ssh:      'text-success border-success/40 bg-success/10',
  telnet:   'text-destructive border-destructive/40 bg-destructive/10',
  http:     'text-primary border-primary/40 bg-primary/10',
  smb:      'text-warning border-warning/40 bg-warning/10',
  exec:     'text-destructive border-destructive/40 bg-destructive/10',
  login:    'text-destructive border-destructive/40 bg-destructive/10',
  mysql:    'text-info border-info/40 bg-info/10',
  postgres: 'text-info border-info/40 bg-info/10',
  irc:      'text-muted-foreground border-border bg-muted',
  ajp13:    'text-muted-foreground border-border bg-muted',
}

function PuertoBadge({ p }) {
  const cls = SVC_CLASS[p.servicio] || 'text-muted-foreground border-border bg-muted'
  return (
    <span className={cn(
      'inline-flex items-center gap-1 rounded-sm border px-2 py-0.5',
      cls
    )}>
      <span className="font-mono text-sm font-bold">{p.puerto}</span>
      <span className="text-[10px] text-muted-foreground/70">/</span>
      <span className="text-xs text-muted-foreground">{p.servicio}</span>
    </span>
  )
}

function HostCard({ ip, dns, puertos }) {
  const [abierto, setAbierto] = useState(true)
  const aRecords     = dns?.A || []
  const totalPuertos = puertos?.length || 0

  return (
    <Card className="overflow-hidden">
      <button type="button"
        onClick={() => setAbierto(!abierto)}
        className={cn(
          'flex w-full items-center gap-3 p-4 text-left transition-colors hover:bg-accent/30',
          abierto && 'border-b border-border'
        )}
      >
        <Server className="size-5 shrink-0 text-info" />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="font-mono text-base font-bold text-foreground">{ip}</span>
            {aRecords.length > 0 && aRecords[0] !== ip && (
              <span className="text-sm text-muted-foreground">→ {aRecords[0]}</span>
            )}
            <Badge variant="outline"
              className="bg-success/15 text-success border-success/40 gap-1 text-[10px] font-bold">
              <CheckCircle2 className="size-3" />
              En scope
            </Badge>
          </div>
          <div className="mt-0.5 text-xs text-muted-foreground/70">
            {totalPuertos > 0 ? (
              <>{totalPuertos} puertos abiertos · <span className="text-info">nmap_scan</span></>
            ) : (
              <span className="text-warning">Sin scan aún — ejecutar POST /scan</span>
            )}
          </div>
        </div>
        {abierto
          ? <ChevronUp   className="size-4 text-muted-foreground/70" />
          : <ChevronDown className="size-4 text-muted-foreground/70" />}
      </button>

      {abierto && puertos && puertos.length > 0 && (
        <CardContent className="p-4 space-y-3">
          <div className="text-sm font-semibold text-muted-foreground">
            Puertos / Servicios detectados
          </div>
          <div className="flex flex-wrap gap-1.5">
            {puertos.map((p) => <PuertoBadge key={p.puerto} p={p} />)}
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-24">Puerto</TableHead>
                  <TableHead className="w-24">Protocolo</TableHead>
                  <TableHead>Servicio</TableHead>
                  <TableHead>Versión</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {puertos.map((p) => (
                  <TableRow key={p.puerto}>
                    <TableCell className={cn(
                      'font-mono font-bold',
                      SVC_CLASS[p.servicio]?.split(' ')[0] || 'text-muted-foreground'
                    )}>
                      {p.puerto}
                    </TableCell>
                    <TableCell className="text-muted-foreground/70">{p.proto}</TableCell>
                    <TableCell className="text-muted-foreground">{p.servicio}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {p.version || '—'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      )}
    </Card>
  )
}

// ─── Vista principal ─────────────────────────────────────────────────────────

export default function SurfaceMapView({ engagementId = ENGAGEMENT_ID, embedded = false }) {
  const [data,     setData]    = useState(null)
  const [loading,  setLoading] = useState(true)
  const [error,    setError]   = useState(null)
  const [notFound, setNotFound]= useState(false)

  const cargar = useCallback(async () => {
    setLoading(true); setError(null); setNotFound(false)
    try {
      const res = await authedFetch(`/engagements/${engagementId}/surface-map`)
      if (res.status === 404) {
        setNotFound(true); setData(null); return
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const json = await res.json()
      setData(json)
    } catch (e) {
      setData(null)
      setError(e.message || 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }, [engagementId])

  useEffect(() => { cargar() }, [cargar])

  // ── Loading ─────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="py-16 text-center text-sm text-muted-foreground/70">
        Cargando surface map…
      </div>
    )
  }

  // ── Error ───────────────────────────────────────────────────────────────
  if (error) {
    return (
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
            <Network className="size-6 text-info" />
            Surface Map
          </h1>
          <Button variant="outline" size="sm" onClick={cargar} className="ml-auto gap-1.5">
            <RefreshCw className="size-3.5" />
            Reintentar
          </Button>
        </div>
        <div className="flex items-center gap-2 rounded-md border border-destructive/40
                        bg-destructive/10 p-3 font-mono text-sm text-destructive">
          <AlertTriangle className="size-4 shrink-0" />
          No se pudo conectar al backend: {error}
        </div>
      </div>
    )
  }

  // ── 404 — sin recon aún ────────────────────────────────────────────────
  if (notFound || !data) {
    return (
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
            <Network className="size-6 text-info" />
            Surface Map
          </h1>
          <Button variant="outline" size="sm" onClick={cargar} className="ml-auto gap-1.5">
            <RefreshCw className="size-3.5" />
            Actualizar
          </Button>
        </div>
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-16 text-center">
            <Network className="size-10 text-muted-foreground/30" />
            <div className="text-sm font-semibold text-muted-foreground">
              Sin surface map para este engagement
            </div>
            <div className="text-xs text-muted-foreground/70">
              Lanza <code className="font-mono text-primary">POST /recon</code> desde{' '}
              <strong>Pipeline</strong> para poblar.
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // ── Datos ───────────────────────────────────────────────────────────────
  const hosts    = data.hosts_discovered || []
  const emails   = data.emails_osint     || []
  const newVs    = data.new_vs_scope     || []
  const dnsMap   = data.dns_records      || {}
  const whoisMap = data.whois_data       || {}

  return (
    <div className="flex flex-col gap-6">

      {/* Header (oculto en modo embedded) */}
      {!embedded ? (
        <div className="flex items-center gap-4">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold text-foreground">
              <Network className="size-6 text-info" />
              Surface Map
            </h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Mapa de superficie consolidado post-Recon · Engagement #{engagementId}
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={cargar} className="ml-auto gap-1.5">
            <RefreshCw className="size-3.5" />
            Actualizar
          </Button>
        </div>
      ) : (
        <div className="flex justify-end">
          <Button variant="outline" size="sm" onClick={cargar} className="gap-1.5">
            <RefreshCw className="size-3.5" />
            Actualizar
          </Button>
        </div>
      )}

      {/* Stats */}
      <div className="flex flex-wrap gap-4">
        {[
          { label: 'Hosts descubiertos', value: hosts.length,  className: 'text-foreground' },
          { label: 'Puertos abiertos',   value: '—',           className: 'text-warning' },
          { label: 'Emails OSINT',       value: emails.length, className: 'text-muted-foreground' },
          { label: 'Nuevos vs scope',    value: newVs.length,
            className: newVs.length > 0 ? 'text-destructive' : 'text-info' },
        ].map((s) => (
          <Card key={s.label} className="flex-1 min-w-[120px]">
            <CardContent className="p-4">
              <div className="mb-1 text-[10px] text-muted-foreground/70">{s.label}</div>
              <div className={cn('text-3xl font-extrabold leading-none', s.className)}>
                {s.value}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Scope diff banner */}
      {newVs.length === 0 ? (
        <div className="flex items-center gap-3 rounded-md border border-success/40 bg-success/10 p-3">
          <CheckCircle2 className="size-5 shrink-0 text-success" />
          <div>
            <div className="text-sm font-semibold text-success">
              Sin hosts fuera de scope
            </div>
            <div className="text-sm text-muted-foreground">
              Todos los hosts descubiertos ({hosts.length}) están dentro del scope autorizado.
            </div>
          </div>
        </div>
      ) : (
        <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 space-y-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-destructive">
            <AlertTriangle className="size-4" />
            {newVs.length} host(s) descubiertos fuera del scope original
          </div>
          <div className="flex flex-wrap gap-1">
            {newVs.map((h) => (
              <span key={h}
                className="rounded-sm bg-destructive/15 px-2 py-0.5 font-mono text-sm text-destructive">
                {h}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Hosts */}
      <div>
        <div className="mb-3 text-base font-semibold text-foreground">
          Hosts descubiertos ({hosts.length})
        </div>
        {hosts.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-sm text-muted-foreground/70">
              Sin hosts en el surface map. Ejecutar POST /recon para poblar.
            </CardContent>
          </Card>
        ) : (
          <div className="flex flex-col gap-3">
            {hosts.map((ip) => (
              <HostCard key={ip} ip={ip} dns={dnsMap[ip]} puertos={[]} />
            ))}
          </div>
        )}
      </div>

      {/* DNS + WHOIS + Emails */}
      <div className="flex flex-wrap gap-4">

        {/* DNS */}
        <Card className="flex-1 min-w-[280px]">
          <CardContent className="p-5">
            <div className="mb-3 flex items-center gap-2 text-base font-semibold text-foreground">
              <Globe className="size-4 text-info" />
              Registros DNS
            </div>
            {Object.keys(dnsMap).length === 0 ? (
              <div className="text-sm text-muted-foreground/70">Sin datos DNS.</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Target</TableHead>
                    <TableHead className="w-20">Tipo</TableHead>
                    <TableHead>Valores</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(dnsMap).flatMap(([target, types]) =>
                    Object.entries(types).filter(([, vals]) => vals.length > 0).map(([rtype, vals]) => (
                      <TableRow key={`${target}-${rtype}`}>
                        <TableCell className="font-mono text-xs text-muted-foreground/70">
                          {target}
                        </TableCell>
                        <TableCell className="font-mono font-bold text-primary">
                          {rtype}
                        </TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">
                          {vals.join(', ')}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* WHOIS */}
        <Card className="flex-1 min-w-[280px]">
          <CardContent className="p-5">
            <div className="mb-3 flex items-center gap-2 text-base font-semibold text-foreground">
              <FileText className="size-4 text-info" />
              WHOIS
            </div>
            {Object.keys(whoisMap).length === 0 ? (
              <div className="text-sm text-muted-foreground/70">Sin datos WHOIS.</div>
            ) : (
              Object.entries(whoisMap).map(([target, w]) => (
                <div key={target} className="space-y-1">
                  <div className="mb-1 font-mono text-xs text-info">{target}</div>
                  {Object.entries(w).map(([k, v]) => (
                    <div key={k}
                      className="flex justify-between border-b border-border pb-1 last:border-0">
                      <span className="text-sm capitalize text-muted-foreground/70">{k}</span>
                      <span className="max-w-[200px] text-right text-sm text-muted-foreground">
                        {Array.isArray(v) ? v.join(', ') || '—' : v || '—'}
                      </span>
                    </div>
                  ))}
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Emails OSINT */}
        <Card className="flex-1 min-w-[240px]">
          <CardContent className="p-5">
            <div className="mb-3 flex items-center gap-2 text-base font-semibold text-foreground">
              <Mail className="size-4 text-info" />
              Emails OSINT
              <span className="text-xs font-normal text-muted-foreground/70">(theHarvester)</span>
            </div>
            {emails.length === 0 ? (
              <div className="text-sm italic text-muted-foreground/70">
                Sin resultados — red de laboratorio aislada, sin presencia en fuentes OSINT públicas.
              </div>
            ) : (
              <div className="space-y-1">
                {emails.map((e) => (
                  <div key={e} className="font-mono text-sm text-info">{e}</div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
