# Graph Report - CapstoneCode  (2026-06-30)

## Corpus Check
- 166 files · ~227,039 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1772 nodes · 2683 edges · 136 communities (116 shown, 20 thin omitted)
- Extraction: 87% EXTRACTED · 13% INFERRED · 0% AMBIGUOUS · INFERRED: 353 edges (avg confidence: 0.68)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `c2c96455`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]
- [[_COMMUNITY_Community 3|Community 3]]
- [[_COMMUNITY_Community 4|Community 4]]
- [[_COMMUNITY_Community 5|Community 5]]
- [[_COMMUNITY_Community 6|Community 6]]
- [[_COMMUNITY_Community 7|Community 7]]
- [[_COMMUNITY_Community 8|Community 8]]
- [[_COMMUNITY_Community 9|Community 9]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]
- [[_COMMUNITY_Community 15|Community 15]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 18|Community 18]]
- [[_COMMUNITY_Community 19|Community 19]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 22|Community 22]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]
- [[_COMMUNITY_Community 36|Community 36]]
- [[_COMMUNITY_Community 37|Community 37]]
- [[_COMMUNITY_Community 38|Community 38]]
- [[_COMMUNITY_Community 39|Community 39]]
- [[_COMMUNITY_Community 40|Community 40]]
- [[_COMMUNITY_Community 41|Community 41]]
- [[_COMMUNITY_Community 42|Community 42]]
- [[_COMMUNITY_Community 43|Community 43]]
- [[_COMMUNITY_Community 44|Community 44]]
- [[_COMMUNITY_Community 45|Community 45]]
- [[_COMMUNITY_Community 46|Community 46]]
- [[_COMMUNITY_Community 47|Community 47]]
- [[_COMMUNITY_Community 48|Community 48]]
- [[_COMMUNITY_Community 49|Community 49]]
- [[_COMMUNITY_Community 50|Community 50]]
- [[_COMMUNITY_Community 51|Community 51]]
- [[_COMMUNITY_Community 52|Community 52]]
- [[_COMMUNITY_Community 53|Community 53]]
- [[_COMMUNITY_Community 54|Community 54]]
- [[_COMMUNITY_Community 55|Community 55]]
- [[_COMMUNITY_Community 56|Community 56]]
- [[_COMMUNITY_Community 57|Community 57]]
- [[_COMMUNITY_Community 58|Community 58]]
- [[_COMMUNITY_Community 59|Community 59]]
- [[_COMMUNITY_Community 60|Community 60]]
- [[_COMMUNITY_Community 61|Community 61]]
- [[_COMMUNITY_Community 62|Community 62]]
- [[_COMMUNITY_Community 63|Community 63]]
- [[_COMMUNITY_Community 64|Community 64]]
- [[_COMMUNITY_Community 65|Community 65]]
- [[_COMMUNITY_Community 66|Community 66]]
- [[_COMMUNITY_Community 67|Community 67]]
- [[_COMMUNITY_Community 68|Community 68]]
- [[_COMMUNITY_Community 69|Community 69]]
- [[_COMMUNITY_Community 70|Community 70]]
- [[_COMMUNITY_Community 71|Community 71]]
- [[_COMMUNITY_Community 72|Community 72]]
- [[_COMMUNITY_Community 73|Community 73]]
- [[_COMMUNITY_Community 74|Community 74]]
- [[_COMMUNITY_Community 75|Community 75]]
- [[_COMMUNITY_Community 76|Community 76]]
- [[_COMMUNITY_Community 77|Community 77]]
- [[_COMMUNITY_Community 78|Community 78]]
- [[_COMMUNITY_Community 79|Community 79]]
- [[_COMMUNITY_Community 80|Community 80]]
- [[_COMMUNITY_Community 81|Community 81]]
- [[_COMMUNITY_Community 82|Community 82]]
- [[_COMMUNITY_Community 83|Community 83]]
- [[_COMMUNITY_Community 90|Community 90]]
- [[_COMMUNITY_Community 91|Community 91]]
- [[_COMMUNITY_Community 92|Community 92]]
- [[_COMMUNITY_Community 93|Community 93]]
- [[_COMMUNITY_Community 99|Community 99]]
- [[_COMMUNITY_Community 100|Community 100]]
- [[_COMMUNITY_Community 101|Community 101]]
- [[_COMMUNITY_Community 102|Community 102]]
- [[_COMMUNITY_Community 103|Community 103]]
- [[_COMMUNITY_Community 104|Community 104]]
- [[_COMMUNITY_Community 105|Community 105]]
- [[_COMMUNITY_Community 106|Community 106]]
- [[_COMMUNITY_Community 107|Community 107]]
- [[_COMMUNITY_Community 108|Community 108]]
- [[_COMMUNITY_Community 109|Community 109]]
- [[_COMMUNITY_Community 110|Community 110]]
- [[_COMMUNITY_Community 111|Community 111]]
- [[_COMMUNITY_Community 112|Community 112]]
- [[_COMMUNITY_Community 113|Community 113]]
- [[_COMMUNITY_Community 114|Community 114]]
- [[_COMMUNITY_Community 115|Community 115]]
- [[_COMMUNITY_Community 116|Community 116]]
- [[_COMMUNITY_Community 117|Community 117]]
- [[_COMMUNITY_Community 118|Community 118]]
- [[_COMMUNITY_Community 119|Community 119]]
- [[_COMMUNITY_Community 120|Community 120]]
- [[_COMMUNITY_Community 121|Community 121]]
- [[_COMMUNITY_Community 122|Community 122]]
- [[_COMMUNITY_Community 123|Community 123]]
- [[_COMMUNITY_Community 124|Community 124]]
- [[_COMMUNITY_Community 125|Community 125]]
- [[_COMMUNITY_Community 126|Community 126]]
- [[_COMMUNITY_Community 128|Community 128]]
- [[_COMMUNITY_Community 129|Community 129]]
- [[_COMMUNITY_Community 130|Community 130]]
- [[_COMMUNITY_Community 131|Community 131]]
- [[_COMMUNITY_Community 132|Community 132]]
- [[_COMMUNITY_Community 133|Community 133]]
- [[_COMMUNITY_Community 134|Community 134]]

## God Nodes (most connected - your core abstractions)
1. `cn()` - 97 edges
2. `utc_now()` - 40 edges
3. `PipelineController` - 32 edges
4. `BaseAgent` - 30 edges
5. `AgentResult` - 28 edges
6. `AgentContext` - 27 edges
7. `is_target_in_scope()` - 24 edges
8. `AnalysisAgent` - 22 edges
9. `ScanAgent` - 22 edges
10. `normalize_nikto_findings()` - 21 edges

## Surprising Connections (you probably didn't know these)
- `ScopeCreate` --uses--> `EngagementStatus`  [INFERRED]
  eth-mas-backend/routers/scope.py → eth-mas-backend/models.py
- `Session` --uses--> `PipelineController`  [INFERRED]
  eth-mas-backend/services/orchestrator_agent.py → eth-mas-backend/services/pipeline_controller.py
- `AppShell()` --calls--> `cn()`  [INFERRED]
  eth-mas-frontend/src/App.jsx → eth-mas-frontend/src/lib/utils.js
- `ActivityConsole()` --calls--> `cn()`  [INFERRED]
  eth-mas-frontend/src/components/ActivityConsole.jsx → eth-mas-frontend/src/lib/utils.js
- `EngagementSelector()` --calls--> `cn()`  [INFERRED]
  eth-mas-frontend/src/components/EngagementSelector.jsx → eth-mas-frontend/src/lib/utils.js

## Import Cycles
- 1-file cycle: `eth-mas-backend/main.py -> eth-mas-backend/main.py`
- 1-file cycle: `eth-mas-backend/utils.py -> eth-mas-backend/utils.py`
- 1-file cycle: `eth-mas-backend/routers/__init__.py -> eth-mas-backend/routers/__init__.py`

## Communities (136 total, 20 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.07
Nodes (33): AnalysisDoc, _compact_findings(), _parse_analysis_json(), Reduce los findings al subset que el LLM necesita para razonar., Extrae el JSON del análisis del texto final del LLM. Tolera bloque ```json```, Reduce los findings al subset que el LLM necesita para razonar., Extrae el JSON del análisis del texto final del LLM. Tolera bloque ```json```, _analysis_has_data() (+25 more)

### Community 1 - "Community 1"
Cohesion: 0.06
Nodes (32): ApiKeyModal(), cn(), Card(), CardAction(), CardContent(), CardDescription(), CardFooter(), CardHeader() (+24 more)

### Community 2 - "Community 2"
Cohesion: 0.14
Nodes (34): Session, _extract_host(), is_target_in_scope(), scope_validator.py — Validación de target ∈ scope autorizado ==================, Normaliza un target llegado del LLM a su forma "host pelado":       http://10.4, Verifica si un target encontrado por el agente está dentro del scope     autori, _mk_db(), _mk_scope() (+26 more)

### Community 3 - "Community 3"
Cohesion: 0.13
Nodes (23): intensity_policy(), normalize_intensity(), scan_policy.py — Política de intensidad + continuidad del ScanAgent (Bloque D), Devuelve la ScanPolicy para una intensidad de ROE. Tolera None/desconocido, Lista de severidades nuclei permitidas hasta `max_severity` (inclusive)., Firma canónica determinista de una tool-call (tool + target + params     releva, Reconstruye el set de firmas de las tool-calls YA ejecutadas a partir de     lo, Normaliza el string de intensidad a una clave conocida (default MODERATE). (+15 more)

### Community 4 - "Community 4"
Cohesion: 0.05
Nodes (61): _attack_lookup(), attack_technique_lookup(), _build_virtual_match(), _cve_cache_col(), cve_lookup(), _has_concrete_version(), _nvd_get(), _parse_cpe() (+53 more)

### Community 5 - "Community 5"
Cohesion: 0.08
Nodes (30): BackgroundTasks, Request, Session, _check_pending_hitl_or_409(), get_analysis(), get_engagement_pipeline_runs(), get_findings(), get_surface_map() (+22 more)

### Community 6 - "Community 6"
Cohesion: 0.06
Nodes (33): dependencies, class-variance-authority, clsx, lucide-react, next-themes, radix-ui, react, react-dom (+25 more)

### Community 7 - "Community 7"
Cohesion: 0.06
Nodes (53): datetime, Engine, _expire_orphan_pending_hitl(), lifespan(), main.py — ETH-MAS FastAPI application v0.5.0 ==================================, Inicializa recursos al arrancar y los libera al apagar.     - Crea índices Mong, Marca como EXPIRED todas las HitlAction PENDING con requested_at anterior     a, Session (+45 more)

### Community 8 - "Community 8"
Cohesion: 0.13
Nodes (21): normalize_nikto_findings(), Parsea la salida de nikto al formato canónico. Detecta el formato:        - CS, Tests para services/findings_service.normalize_*  Cubre los normalizadores de, nikto 2.5.x emite list[dict]. Reproduce H-5b del lab E2E., Hipotético: nikto -h con múltiples targets en list[dict]., CSV con solo el banner y filas de host vacías → sin findings., nikto < 2.5: emite dict directo., test_nikto_bad_json_returns_empty() (+13 more)

### Community 9 - "Community 9"
Cohesion: 0.07
Nodes (26): 1. ⚠️ Advertencia de seguridad — leer antes de levantar el lab, 2.1 Alternativas si la imagen oficial falla, 2. Imágenes utilizadas (pineadas por digest), 3.1 Levantar todo el stack + lab, 3.2 Levantar sólo el lab (asume stack base ya corriendo), 3.3 Bajar el lab (deja el stack en pie), 3.4 Limpiar el lab al terminar (recomendado al cerrar el sprint), 3.5 Verificar que el lab arrancó bien (+18 more)

### Community 10 - "Community 10"
Cohesion: 0.08
Nodes (25): 0. Mapa de dependencias, Aceptación, Aceptación, Aceptación, Aceptación, Aceptación, Aceptación, Archivos entregados (+17 more)

### Community 11 - "Community 11"
Cohesion: 0.13
Nodes (19): pipeline_runs_col(), Colección 'pipeline_runs' — orquestación end-to-end por el Controller., get_single_pipeline_run(), Detalle de un pipeline run con todas sus stages., append_stage(), get_latest_pipeline(), get_pipeline(), list_pipelines() (+11 more)

### Community 12 - "Community 12"
Cohesion: 0.14
Nodes (14): normalize_gobuster_findings(), Parsea la salida de gobuster y la convierte al formato canónico.      Dir outp, 3xx debe persistirse (sólo 4xx+ se filtra)., Reproducción exacta del hallazgo H-4: gobuster --no-color igual emite     \\x1b, Variante: sequencias SGR (`\\x1b[31m`) también deben sanitizarse., test_gobuster_dir_basic(), test_gobuster_dir_filters_4xx(), test_gobuster_dir_handles_redirect_301() (+6 more)

### Community 13 - "Community 13"
Cohesion: 0.08
Nodes (23): 1. Versionado y releases, 2. Tablero maestro — HU × Progreso, 3. Lectura del cruce — ¿dónde está parado el proyecto?, 4. Criterios de cada release (HU como checklist), 5. Ruta crítica al 100% (reordenada), 6. Pendiente para "100% con targets del operador", 7. Riesgos al release final, 8. Definition of Done de un release (+15 more)

### Community 14 - "Community 14"
Cohesion: 0.18
Nodes (19): AsyncIOMotorClient, AsyncIOMotorCollection, agent_rationales_col(), analysis_col(), ensure_indexes(), findings_col(), get_mongo_client(), get_mongo_db() (+11 more)

### Community 15 - "Community 15"
Cohesion: 0.10
Nodes (20): Cambios necesarios, Convenciones operativas, Cuándo justifica implementarlo, Cómo se cargan, Diseño propuesto, Diseño propuesto, Endpoints útiles, Estado actual — Nivel 1 (implementado) (+12 more)

### Community 16 - "Community 16"
Cohesion: 0.10
Nodes (20): 0. TL;DR, 1.1 NMAP — puertos (la existencia del puerto es siempre ✅; el juicio es sobre la correlación CVE/severidad), 1.2 NIKTO — HTTP sobre :80 y :8000, 1.3 Resumen cuantitativo, 1. Tabla de veredictos por finding, 2. Plan de corrección / hardening — priorizado por riesgo REAL, 3. Mejoras al sistema ETH-MAS (lo que esta corrida dejó en evidencia), 4. Apéndice — verificación NVD (consultas directas, 2026-06-10) (+12 more)

### Community 17 - "Community 17"
Cohesion: 0.20
Nodes (10): RuntimeError, AnthropicKeyError, get_anthropic_key(), mark_anthropic_failure(), mark_anthropic_success(), anthropic_health.py — Validación y monitoreo de ANTHROPIC_API_KEY (Nivel 1) ===, Llamado por los agentes cuando reciben 401 en runtime.     Invalida el cache pa, Llamado por los agentes cuando completan una llamada exitosamente.     Refresca (+2 more)

### Community 18 - "Community 18"
Cohesion: 0.18
Nodes (12): AgentContext, AgentResult, Session, ScanPolicy, Deriva la banda de parámetros desde el ROE, con override liviano si el, Reconstruye las firmas tool/target/params YA ejecutadas en runs         previos, Mensaje 'user' inicial: objetivo + contexto de continuidad. Concreto,         n, Resumen del estado previo (surface_map + findings) para dar continuidad (+4 more)

### Community 19 - "Community 19"
Cohesion: 0.09
Nodes (11): ConnBadge(), OrchestratorChatView(), QUICK_PROMPTS, QuickPrompts(), STATUS_BADGE, TurnBubble(), ReportesViewBody(), TYPE_LABELS (+3 more)

### Community 20 - "Community 20"
Cohesion: 0.17
Nodes (15): _compose_context(), _fallback_narrative(), Narrativa mínima determinística si el LLM no está disponible., Arma el contexto del template (determinístico). Sin LLM ni I/O., Narrativa mínima determinística si el LLM no está disponible., Arma el contexto del template (determinístico). Sin LLM ni I/O., Tests del ReporterAgent (Bloque C) — helpers puros, sin LLM/Mongo/WeasyPrint., test_compose_context_groups_and_stats() (+7 more)

### Community 21 - "Community 21"
Cohesion: 0.22
Nodes (6): auth.py — Auth X-API-Key (HU-22) ================================ Política: op, Valida X-API-Key solo si ETH_MAS_API_KEY está seteada. Si no, no-op., verify_api_key(), FastAPI, routers/health.py — Health · root + servicios externos ========================, routers — paquete de APIRouters por dominio (Sesión D, refactor de main.py) ===

### Community 22 - "Community 22"
Cohesion: 0.33
Nodes (5): DecisionBadge(), fmtTs(), PendingActionCard(), RISK_STYLE, RiskBadge()

### Community 23 - "Community 23"
Cohesion: 0.16
Nodes (17): FindingDoc, Hallazgo individual normalizado de ScanAgent.     Un documento por hallazgo (pu, Any, FindingDoc, _build_finding_doc(), _compute_dedup_key(), _parse_nikto_csv(), persist_finding() (+9 more)

### Community 24 - "Community 24"
Cohesion: 0.11
Nodes (17): aliases, components, hooks, lib, ui, utils, iconLibrary, rsc (+9 more)

### Community 25 - "Community 25"
Cohesion: 0.06
Nodes (27): useHitlPending(), apiEvents, authedFetch(), authedJson(), getApiKey(), isUsingDefaultKey(), setApiKey(), AgentRunsView (+19 more)

### Community 26 - "Community 26"
Cohesion: 0.16
Nodes (15): durationOf(), fmtDateTime(), fmtMs(), fmtTime(), RunDetailDrawer(), STATUS_BG, STATUS_COLOR, STATUS_ICON (+7 more)

### Community 27 - "Community 27"
Cohesion: 0.23
Nodes (9): Documento consolidado de la fase de reconocimiento.     Un documento por engage, SurfaceMapDoc, AgentContext, AgentResult, Session, _looks_like_ip_or_cidr(), recon_agent.py — ReconAgent · ETH-MAS (Bloque D, ADR-005) =====================, Heurística barata: ¿el target es una IP/CIDR (no un dominio)? Sin lookups. (+1 more)

### Community 28 - "Community 28"
Cohesion: 0.13
Nodes (21): Session, analysis_model(), _model(), model_for(), orchestrator_model(), agent_config.py — Tiering de modelos por agente · ETH-MAS (Bloque 0, ADR-005) =, Lee el modelo de un env var con fallback seguro., Resuelve el modelo dado el nombre canónico del agente (AGENT_NAMES). (+13 more)

### Community 29 - "Community 29"
Cohesion: 0.09
Nodes (30): agent_runs_col(), Colección 'agent_runs' — log de ejecución de agentes., begin_tool_call(), end_tool_call(), finish_run(), get_latest_run(), get_run(), list_runs() (+22 more)

### Community 30 - "Community 30"
Cohesion: 0.12
Nodes (15): 1. Configuración del engagement, 2. Timeline del pipeline run `6a28e454…`, 3.1 Scope enforcement (HU-02), 3.2 HITL — registro de decisiones (HU-09), 3.3 ⚠️ Caso HITL #101 — aprobación fuera de ventana (no es bug), 3. Controles de seguridad ejercitados, 4. Ejecución de herramientas (ScanAgent), 5.1 NMAP — superficie de puertos (host Windows) (+7 more)

### Community 31 - "Community 31"
Cohesion: 0.13
Nodes (14): 1. Resumen, 2. Bugs corregidos, 3.1 Gate de confianza CVE (determinístico), 3.2 Sonda soft-200 (catch-all) — `services` Security MCP, 3.3 Refinamiento determinístico de scanners web, 3. Capas de robustez nuevas, 4.1 Antes / Después (findings sospechosos), 4.2 Reporte regenerado (+6 more)

### Community 32 - "Community 32"
Cohesion: 0.13
Nodes (14): 1. Estado general, 2.1 Fix de Nikto (cierra el reporte del operador), 2.2 Respuesta a la crítica del profesor → ADR-005, 2.3 Bloque 0 — Contratos compartidos *(en `main`, commit `cc8e856`)*, 2.4 Bloque E — Ejecutor seguro *(rama `feature/block-e-executor`, commit `dc7716b`)*, 2.5 Fix de entorno (Windows / Docker), 2. Lo hecho esta sesión, 3. Verificación (+6 more)

### Community 33 - "Community 33"
Cohesion: 0.13
Nodes (19): BackgroundTasks, Request, Session, orchestrator_message(), OrchestratorMessageRequest, routers/orchestrator.py — Bloque A · Orquestador conversacional (ADR-005 §3.3), SSE del chat: emite cada turno NUEVO de la conversación (operador, orquestador,, SSE del chat: emite cada turno NUEVO de la conversación (operador, orquestador, (+11 more)

### Community 34 - "Community 34"
Cohesion: 0.13
Nodes (17): Any, orchestrator_conversation(), Devuelve la conversación operador↔orquestador en orden cronológico., Devuelve la conversación operador↔orquestador en orden cronológico., _clean(), blackboard.py — Estado compartido del engagement · ETH-MAS (Bloque 0, ADR-005), Append de un rationale de agente. Append-only (no upsert): cada corrida     dej, Últimos rationales del engagement, más recientes primero. (+9 more)

### Community 35 - "Community 35"
Cohesion: 0.15
Nodes (12): 1. Contexto y problema, 2. Fuerzas / requisitos, 3.1 Contrato de agente (lo comparten los 4), 3.2 Los 4 workers, goal-driven, 3.3 Orquestador, 3.4 Blackboard (estado compartido), 3.5 Tiering de modelos, 3. Decisión (+4 more)

### Community 36 - "Community 36"
Cohesion: 0.24
Nodes (12): EngagementCreate, EngagementStatusUpdate, EngagementStatus, Estados posibles de un engagement (§4.3 CLAUDE.md)., Session, create_engagement(), get_engagement(), list_engagements() (+4 more)

### Community 37 - "Community 37"
Cohesion: 0.22
Nodes (11): compose_operator_directive(), extract_delegation(), Compone el `operator_directive` que el ejecutor threadea al AgentContext., Mapea un `tool_use` de worker que eligió el LLM a los argumentos concretos del, Tests del Bloque A — helpers puros del Orquestador (sin API ni BD).  Cubren el, test_compose_directive_includes_report_type(), test_compose_directive_none_when_empty(), test_compose_directive_only_intensity_is_deterministic() (+3 more)

### Community 38 - "Community 38"
Cohesion: 0.06
Nodes (41): BaseModel, AgentRationaleDoc, ConversationTurnDoc, Registro del 'por qué' de una corrida de agente (ADR-005 §3.1). Append-only;, Registro del 'por qué' de una corrida de agente (ADR-005 §3.1). Append-only;, Un turno de la conversación operador↔orquestador (Bloque A). Append-only., Un turno de la conversación operador↔orquestador (Bloque A). Append-only., EngagementCreate (+33 more)

### Community 39 - "Community 39"
Cohesion: 0.11
Nodes (18): Ejecuta el pipeline completo., ¿Esta corrida es un pipeline real de evaluación (no un single-stage         sue, B1 — transiciona el engagement RUNNING → COMPLETED al cerrar el         pipelin, Ejecuta el pipeline completo., Ejecuta EXACTAMENTE un agente con un objetivo + directiva explícitos y el, Ejecuta EXACTAMENTE un agente con un objetivo + directiva explícitos y el, Resumen corto de la stage para frontend / pipeline_runs., Resumen corto de la stage para frontend / pipeline_runs. (+10 more)

### Community 40 - "Community 40"
Cohesion: 0.26
Nodes (12): AttackCoverageHeatmap(), buildCells(), cvssCellClass(), MITRE_TECHNIQUES, mitreUrl(), SEV_BADGE, TACTIC_ORDER, techniqueDesc() (+4 more)

### Community 41 - "Community 41"
Cohesion: 0.10
Nodes (19): 0. Resumen ejecutivo, 1. Estrategia: dos pistas, 2. Punto de partida — reporte de bugs del operador (B1–B8), 3. Lo que se hizo, sesión por sesión, 4. Validación end-to-end (los números para la defensa), 5. Notas operativas / riesgos conocidos, 6. Estado de release (git), 7. Pista 2 — Variante A / GCP real (lo que haremos) (+11 more)

### Community 42 - "Community 42"
Cohesion: 0.29
Nodes (6): AgentRunDoc, mongo_schemas.py — Schemas Pydantic para colecciones MongoDB (Sprint 2) =======, Entrada en el log de tool calls de un agente., Log completo de ejecución de un agente.     Persiste cada run para trazabilidad, Log completo de ejecución de un agente.     Persiste cada run para trazabilidad, ToolCallEntry

### Community 43 - "Community 43"
Cohesion: 0.21
Nodes (11): Session, HitlDecision, decide_hitl_action(), expire_pending_hitl(), get_hitl_action(), list_hitl_actions(), routers/hitl.py — E4 · HITL (HU-09, HU-10) ====================================, Fix 1.3 — Libera HITL zombis sin esperar al reinicio del backend.      Marca c (+3 more)

### Community 44 - "Community 44"
Cohesion: 0.21
Nodes (9): AgentContext, AgentResult, AgentResult, Ejecuta el agente sobre el contexto dado y devuelve su resultado., Ejecuta el agente sobre el contexto dado y devuelve su resultado., Salida de `BaseAgent.run()`. El `rationale` es OBLIGATORIO (ADR-005 §3.1):, Salida de `BaseAgent.run()`. El `rationale` es OBLIGATORIO (ADR-005 §3.1):, Saneo del nombre que da el operador para usarlo como filename: quita         ca (+1 more)

### Community 45 - "Community 45"
Cohesion: 0.20
Nodes (11): AnalysisDoc, Salida consolidada del AnalysisAgent (Bloque B). Un doc por engagement (upsert)., Salida consolidada del AnalysisAgent (Bloque B). Un doc por engagement (upsert)., AgentContext, AgentResult, AnalysisAgent, _last_text(), Turno de cierre sin tools. Se usa cuando el loop agotó el budget todavía (+3 more)

### Community 46 - "Community 46"
Cohesion: 0.18
Nodes (10): 1. Contexto, 2. Estado de integración, 3. Entregables por bloque, 4. Cómo validar, 5. Funcionalidad disponible, 6. Pendientes y puntos de atención, 7. Recomendaciones, Puesta en marcha (+2 more)

### Community 47 - "Community 47"
Cohesion: 0.20
Nodes (8): _max_severity(), Degrada findings nikto/gobuster no fiables a info + status=false_positive, Degrada findings nikto/gobuster no fiables a info + status=false_positive, Banda de severidad CVSS v3 (NVD): 9.0+ critical, 7.0+ high, 4.0+ medium,     0., Devuelve la mayor de dos severidades (nunca degrada la observada)., _severity_from_cvss(), test_max_severity_never_degrades(), test_severity_from_cvss_bands()

### Community 48 - "Community 48"
Cohesion: 0.17
Nodes (13): AgentContext, AgentResult, AgentContext, Entrada de `BaseAgent.run()`. Reemplaza el patrón actual donde cada agente, Shortcut: lista de target_value (lo que la mayoría de tools necesita)., Shortcut: lista de target_value (lo que la mayoría de tools necesita)., _EchoAgent, _patch() (+5 more)

### Community 49 - "Community 49"
Cohesion: 0.20
Nodes (11): _build_system_prompt(), _collapse_consecutive(), _history_to_messages(), orchestrator_agent.py — Orquestador conversacional · ETH-MAS (Bloque A, ADR-005), Catálogo legible de los workers para el system prompt (modo plan)., Reconstruye una historia simple user/assistant para dar continuidad al LLM., Reconstruye una historia simple user/assistant para dar continuidad al LLM., La API de Anthropic exige roles alternados. Fusiona turnos consecutivos del (+3 more)

### Community 50 - "Community 50"
Cohesion: 0.18
Nodes (6): DialogContent(), DialogDescription(), DialogFooter(), DialogHeader(), DialogOverlay(), DialogTitle()

### Community 51 - "Community 51"
Cohesion: 0.12
Nodes (9): DropdownMenuCheckboxItem(), DropdownMenuContent(), DropdownMenuItem(), DropdownMenuLabel(), DropdownMenuRadioItem(), DropdownMenuSeparator(), DropdownMenuShortcut(), DropdownMenuSubContent() (+1 more)

### Community 52 - "Community 52"
Cohesion: 0.18
Nodes (6): SheetContent(), SheetDescription(), SheetFooter(), SheetHeader(), SheetOverlay(), SheetTitle()

### Community 53 - "Community 53"
Cohesion: 0.24
Nodes (10): AsyncExitStack, ClientSession, Any, call_mcp_tool_from_gemini(), load_mcp_tools_for_gemini(), mcp_gemini_bridge.py — Adaptador MCP tools → Gemini FunctionDeclaration =======, Conecta al MCP server vía stdio y convierte sus tools a FunctionDeclaration de G, Ejecuta un FunctionCall de Gemini en el MCP server.     Retorna el resultado co (+2 more)

### Community 54 - "Community 54"
Cohesion: 0.20
Nodes (6): DAYS, DEFAULT_ROE, HITL_OPTS, INTENSITY_OPTS, RoeBuilder(), VisualForm()

### Community 55 - "Community 55"
Cohesion: 0.20
Nodes (9): Alternativa Gemini para ReconAgent (y futuros agentes), Diferencias clave Claude vs Gemini para este agente, Integración en `run()`:, Paso 1 — Dependencias adicionales, Paso 2 — Variables de entorno, Paso 3 — Bridge MCP → Gemini, Paso 4 — ReconAgent en modo Gemini, ¿Por qué Haiku por defecto y no Gemini? (+1 more)

### Community 56 - "Community 56"
Cohesion: 0.20
Nodes (9): compilerOptions, baseUrl, jsx, module, moduleResolution, paths, target, include (+1 more)

### Community 57 - "Community 57"
Cohesion: 0.21
Nodes (9): Any, append_conversation(), Append de un turno de conversación. role ∈ {operator, orchestrator, system}., Procesa un mensaje del operador. Persiste el turno del operador y la(s), Bloque de texto con el scope autorizado + ROE del engagement, para         grou, Procesa un mensaje del operador. Persiste el turno del operador y la(s), Concatena los bloques de texto de una respuesta Anthropic., Concatena los bloques de texto de una respuesta Anthropic. (+1 more)

### Community 58 - "Community 58"
Cohesion: 0.13
Nodes (19): Session, _content_disposition(), download_report(), launch_report(), list_reports(), routers/reports.py — E6 · Reportería (HU-14) ==================================, Descarga un PDF desde GridFS. Sin `file_id` baja el más reciente del tipo     p, Arma un header Content-Disposition seguro para nombres no-ASCII.      Los head (+11 more)

### Community 59 - "Community 59"
Cohesion: 0.31
Nodes (8): Session, add_scope_target(), delete_scope_target(), get_scopes(), routers/scope.py — E1 · Scope targets (HU-01, HU-02) ==========================, Verifica si un target esta autorizado en el scope del engagement. (HU-02), validate_target(), ScopeCreate

### Community 60 - "Community 60"
Cohesion: 0.09
Nodes (23): ABC, AgentResult, Session, BaseAgent, agent_base.py — Contrato común de agentes · ETH-MAS (Bloque 0, ADR-005) =======, Interfaz común de los 4 workers. Constructor alineado con los agentes     actua, Interfaz común de los 4 workers. Constructor alineado con los agentes     actua, PipelineController (+15 more)

### Community 61 - "Community 61"
Cohesion: 0.18
Nodes (16): narrate_run_start(), narrate_tool_start(), narration.py — Narración legible del pipeline en vivo (cuadro de actividad) ===, Frase legible para el inicio de una tool call.      Ej: narrate_tool_start("nm, Frase legible para el arranque de un agente.      Ej: narrate_run_start("Recon, test_narration.py — Narración legible del pipeline (services/narration.py) ====, test_run_start_agente_desconocido_no_rompe(), test_run_start_recon_pluraliza_objetivos() (+8 more)

### Community 62 - "Community 62"
Cohesion: 0.25
Nodes (6): DecisionBadge(), decisionLabel(), normalise(), RISK_STYLE, RiskBadge(), TimelineEntry()

### Community 63 - "Community 63"
Cohesion: 0.36
Nodes (7): Any, _jinja_env(), report_renderer.py — Render determinístico de reportes · ETH-MAS (Bloque C, ADR-, Renderiza el template a HTML (sin PDF). Testeable si jinja2 está instalado., Renderiza el template a un PDF (bytes). Requiere weasyprint + libs de sistema., render_html(), render_pdf()

### Community 64 - "Community 64"
Cohesion: 0.12
Nodes (16): 0. Resumen ejecutivo técnico, 1.1.1 vsftpd 2.3.4 — backdoor "smiley" · puerto 21/tcp, 1.1.2 UnrealIRCd 3.2.8.1 — backdoor · puertos 6667, 6697/tcp, 1.1.3 distccd 2.x — RCE distribuido · puerto 3632/tcp, 1.1.4 Samba 3.0.20 — `username map script` · puertos 139, 445/tcp, 1.1 Vulnerabilidades con CVE confirmada, 1.2 Vulnerabilidades por backdoor / mala configuración (sin CVE — el "riesgo" es la exposición), 1.3 Servicios obsoletos (superficie, sin explotación trivial garantizada) (+8 more)

### Community 65 - "Community 65"
Cohesion: 0.33
Nodes (5): CvssScore(), HallazgosView(), MITRE_NAMES, SEV_STYLE, SevBadge()

### Community 66 - "Community 66"
Cohesion: 0.38
Nodes (6): Base, Engagement, HitlAction, Registro inmutable de cada decisión HITL (HU-09 y HU-10)., ScopeTarget, TargetType

### Community 67 - "Community 67"
Cohesion: 0.33
Nodes (5): alembic/env.py — entorno de migración Alembic.  Cambios (auditoría 2026-05-20,, Modo offline: genera SQL sin conectarse a la BD., Modo online: conecta y ejecuta migraciones contra la BD real., run_migrations_offline(), run_migrations_online()

### Community 68 - "Community 68"
Cohesion: 0.40
Nodes (5): Tabs(), TabsContent(), TabsList(), tabsListVariants, TabsTrigger()

### Community 69 - "Community 69"
Cohesion: 0.12
Nodes (15): 10. Relación con el resto de la documentación, 1. Contexto y por qué esta forma, 2. Arquitectura objetivo — dos planos, 3. Conectividad: patrón job-pull (NAT-friendly), 4. Las dos particiones del plano de escaneo (ambas documentadas), 5. Ruta al LLM, 6. Aislamiento del lab (clave de la defensa), 7. Costo (orden de magnitud, mensual) (+7 more)

### Community 70 - "Community 70"
Cohesion: 0.12
Nodes (15): 0. Pre-demo (5–10 min antes) — checklist rápido, 1.1 Problema y propuesta (2 min), 1.2 Las 3 garantías de identidad técnica (3 min) — *el corazón del proyecto*, 1.3 Arquitectura (3 min), 1.4 Rigor y calidad (2 min), 2.1 Crear engagement + scope por el **chat del orquestador** (2 min), 2.2 Scope enforcement en vivo (1 min), 2.3 Ejecutar + SSE + HITL (3 min) (+7 more)

### Community 71 - "Community 71"
Cohesion: 0.40
Nodes (4): COLORS, FONT, RADIUS, SPACING

### Community 73 - "Community 73"
Cohesion: 0.50
Nodes (4): AnalysisView(), buildRiskRows(), CvssScore(), SevBadge()

### Community 76 - "Community 76"
Cohesion: 0.50
Nodes (3): Expanding the ESLint configuration, React Compiler, React + Vite

### Community 77 - "Community 77"
Cohesion: 0.22
Nodes (8): classify_severity(), normalize_nmap_findings(), normalize_nuclei_findings(), Parsea la salida JSONL de nuclei (-j flag) al formato canónico.     Cada línea, Clasifica la severidad de un puerto/servicio abierto.     Usado por normalize_n, Convierte raw findings de nmap_service.parse_nmap_xml() al formato canónico., test_nuclei_ignores_blank_and_invalid_lines(), test_nuclei_jsonl_basic()

### Community 92 - "Community 92"
Cohesion: 0.12
Nodes (15): 1) Backend — endpoint de snapshot read-only, 2) Backend — generador de timeline (módulo puro, testeable), 3) Frontend — Replay Player (ruta nueva), Arquitectura recomendada, Contexto a cargar primero (leer estos archivos, en este orden), Criterios de aceptación, Entregables, Fuera de alcance (no hacer) (+7 more)

### Community 93 - "Community 93"
Cohesion: 0.19
Nodes (14): Exception, parse_nmap_xml(), Ejecuta nmap con detección de versiones sobre el target.      Args:         t, Parsea la salida XML de nmap y devuelve una lista de findings (un dict por, run_nmap_scan(), Tests de services/nmap_service.parse_nmap_xml — parser puro del XML de nmap. Cu, test_parse_host_without_address_discarded(), test_parse_host_without_ports() (+6 more)

### Community 99 - "Community 99"
Cohesion: 0.14
Nodes (13): 0. Preparar el entorno, 1. Crear un engagement y correr el pipeline completo, 2. Qué verificar (uno por fix), 3. Resumen rápido, ✅ B1 — El PDF ya no dice "running", ✅ B2 — Severidad coherente con el CVSS, ✅ B3 — Vectores "CRITICAL" aclarados, ✅ B4 — Confianza de cada CVE visible (+5 more)

### Community 100 - "Community 100"
Cohesion: 0.19
Nodes (13): _exec_risk_label(), Convierte el título técnico de un finding en una etiqueta de riesgo apta     pa, Tests de los fixes de bugs de reportes/análisis/orquestador (B1-B8, 2026-06-15)., B7 (S1) — el tag de herramienta [Nuclei]/[Nikto] no debe llegar al ejecutivo., B7 (S1) — un título que es sólo el nombre técnico del servicio se traduce., B7 (S6) — mensajes nikto/nuclei (inglés) → frase de negocio en español.     Los, Un mensaje web conocido no debe dejar la frase inglesa cruda en el ejecutivo., test_exec_risk_label_maps_service_names_to_business() (+5 more)

### Community 101 - "Community 101"
Cohesion: 0.15
Nodes (12): 1.1 Diagnóstico inicial, 1.2 Bug de nombre de variable de entorno (modelos), 1.3 Precedencia de los dos `.env`, 1.4 Gotcha de cliente (no es bug del producto), 1. Fixes de configuración (gotchas de arranque), 2. Orquestador conversacional con factibilidad *grounded*, 3. Narración legible del pipeline (backend), 4. Cuadro de actividad en vivo (frontend) (+4 more)

### Community 102 - "Community 102"
Cohesion: 0.15
Nodes (13): _canonical_technique(), _normalize_enriched_for_doc(), B5 — determinismo del enriched_findings que se persiste en el AnalysisDoc., Técnica ATT&CK determinística para un finding de servicio/puerto conocido., La misma entrada siempre da la misma técnica (la base de la estabilidad B5)., La técnica del LLM se reemplaza por la canónica del puerto/servicio.     Cierra, Cubre TODOS los findings de origen (los omitidos por el LLM entran con     técn, test_canonical_technique_is_stable() (+5 more)

### Community 103 - "Community 103"
Cohesion: 0.17
Nodes (11): 10. Resumen ejecutivo (qué dice el grafo de la salud del sistema), 1. Vista de capas (arquitectura general), 2. Pipeline de pentesting (orden canónico + HITL transversal), 3. Contrato de agentes (Bloque 0, ADR-005), 4. Modelo de datos (dual-store), 5. Flujo de un request (router → servicio → MCP → tool), 6. Gate de confianza CVE (hardening 2026-06-11), 7. Máquina de estados HITL (+3 more)

### Community 104 - "Community 104"
Cohesion: 0.17
Nodes (11): A.1 Metasploitable2 (`10.42.0.10`) — engagement #26, A.2 DVWA (`10.42.0.20`) — engagement #27, A.3 Disciplina de falsos positivos (de #24, transversal), B.1 Metadatos de la corrida fresca, B.2 Cobertura vs. línea base, B.3 Métricas finales, B.4 Conclusión del contraste, B.5 Incidencias y fixes durante la corrida (+3 more)

### Community 105 - "Community 105"
Cohesion: 0.17
Nodes (11): 0. Cómo leer este grafo (qué es cada cosa), 1. Resumen (traducido), 2. God nodes (los más conectados = tus abstracciones centrales), 3. Conexiones sorprendentes (las que probablemente no sabías), 4. Ciclos de import, 5. Brechas de conocimiento (Knowledge Gaps), 6. Preguntas que este grafo está en posición única de responder, 7. Mapa comunidad → módulo del sistema (lo más útil) (+3 more)

### Community 106 - "Community 106"
Cohesion: 0.18
Nodes (10): 0. Pre-demo (5-10 min antes) — checklist, 1. Contexto (1 min), 2. Crear engagement + scope + ROE (2 min), 3. Scope enforcement (1 min), 4. Pipeline + HITL en vivo (2 min), 5. Resultados sobre #26 (pre-corrido) (3-4 min), 6. (Opcional) DVWA #27 (1 min), 7. Cierre (1 min) (+2 more)

### Community 107 - "Community 107"
Cohesion: 0.18
Nodes (10): 0. TL;DR, 1. Estado de la rama `release/v0.4`, 2. Bugs encontrados y corregidos, 3. Cómo levantar el sistema (paso a paso), 4. ⭐ Ver el engagement de demo ya persistido (#37), 5. Cómo correr la demo (flujo conversacional), 6. Resultados del contraste vs. línea base, 7. Notas y pendientes (+2 more)

### Community 108 - "Community 108"
Cohesion: 0.20
Nodes (9): 0. Pre-requisitos (una vez), 1. Levantar el stack + lab, 2. Salud del backend, 3. Smoke test automatizado (cableado, sin scans activos), 4. Verificación manual en la UI — chat del orquestador, 5. Persistencia (confirmar que quedó todo guardado), 6. Cierre, Checklist de verificación — Engagement vía orquestador (v0.4) (+1 more)

### Community 109 - "Community 109"
Cohesion: 0.20
Nodes (9): 1. Pruebas automatizadas, 2. Validación end-to-end (pipeline 4/4 real), 3. Calidad del análisis (AnalysisAgent), 4. Calidad de los reportes, 5. Performance (pipeline 4/4), 6. CI (INFRA-02), 7. Limitaciones honestas, Cobertura (pytest-cov sobre `services/`) (+1 more)

### Community 110 - "Community 110"
Cohesion: 0.22
Nodes (8): CIFRAS (banda inferior, 3 KPIs), CUERPO (tabla central — 4 CVE "ancla" del lab), MENSAJE CLAVE (caja destacada), Notas para el orador (no van en la slide), Slide 14 — Contraste: línea base del lab vs. ETH-MAS, Subtítulo, Sugerencia de layout (PowerPoint), TÍTULO

### Community 111 - "Community 111"
Cohesion: 0.22
Nodes (9): PipelineRunDoc, Una etapa del pipeline orquestado por el Controller., Una etapa del pipeline orquestado por el Controller., Log de la ejecución end-to-end del pipeline orquestado por PipelineController., Log de la ejecución end-to-end del pipeline orquestado por PipelineController., StageEntry, Crea el PipelineRunDoc con todas las stages en status='pending'.     Retorna el, Crea el PipelineRunDoc con todas las stages en status='pending'.     Retorna el (+1 more)

### Community 112 - "Community 112"
Cohesion: 0.22
Nodes (8): Request, get_engagement_agent_runs(), get_single_agent_run(), routers/observability.py — Observabilidad · AgentRuns (Capa 1, HU-23) =========, Lista los runs de agentes (Recon/Scan) del engagement, ordenados desc por     s, Detalle completo de un run específico (tools_called + output_preview)., SSE: emite el run más reciente del engagement cada ~1.5s mientras esté     acti, stream_agent_runs()

### Community 114 - "Community 114"
Cohesion: 0.22
Nodes (9): _clean_list(), _parse_narrative_json(), Extrae el JSON de narrativa del texto del LLM; fallback determinístico., Extrae el JSON de narrativa del texto del LLM; fallback determinístico., Saneo de listas para el render (B6): descarta None/vacíos/whitespace.     Evita, test_clean_list_drops_none_and_blanks(), test_parse_narrative_executive_narrative_present_and_fallback(), test_parse_narrative_executive_recommendations_fallback() (+1 more)

### Community 115 - "Community 115"
Cohesion: 0.25
Nodes (7): 0. Antes de empezar (con público o 5 min antes), 1. Apertura (1 min) — sin tocar nada, 2. Demo en vivo con el orquestador (4–5 min), 3. Salto a la corrida completa persistida — #37 (3–4 min), 4. Cierre (30 s), Plan de respaldo (si algo falla), Run-sheet de la demo en vivo — ETH-MAS (release/v0.4)

### Community 116 - "Community 116"
Cohesion: 0.25
Nodes (7): El argumento de fondo (para decir en voz alta), Los tres scripts, Números esperados (referencia del deck), Qué prueba cada sección y a qué corresponde en el front, Requisitos, Scripts de verificación por consola — ETH-MAS, Uso típico (defensa)

### Community 117 - "Community 117"
Cohesion: 0.25
Nodes (6): Compacta el dict de `run_single_stage` para devolvérselo al LLM como     tool_r, Crea (lazy, en la 1ª delegación) el pipeline_run compartido de la sesión., Ejecuta un worker a través del ejecutor seguro y narra la delegación., Ejecuta un worker a través del ejecutor seguro y narra la delegación., _summarize_worker_result(), test_summarize_worker_result_trims_payload()

### Community 118 - "Community 118"
Cohesion: 0.29
Nodes (3): ActivityConsole(), TERMINAL_BAD, TERMINAL_OK

### Community 119 - "Community 119"
Cohesion: 0.29
Nodes (6): Calendario, Contexto que sostiene el plan, Estrategia: dos pistas, ETH-MAS — Plan de cierre para la presentación evaluada (vie 2026-06-19), Pista 1 — Red de seguridad (on-prem + arquitectura), Pista 2 — Variante A / GCP real (post-lock de Pista 1)

### Community 120 - "Community 120"
Cohesion: 0.29
Nodes (6): 1. Contexto en una frase, 2. Los dos sistemas evaluados, 3. Hallazgos clave (traducidos a impacto de negocio), 4. Por qué esto importa para la evaluación, 5. Conclusión, Reporte ejecutivo — Laboratorio de evaluación ETH-MAS (v0.4)

### Community 121 - "Community 121"
Cohesion: 0.33
Nodes (5): _applicable_cves(), _is_reportable(), reporter_agent.py — ReporterAgent · ETH-MAS Sprint 3 (Bloque C, ADR-005) ======, CVEs reportables de un finding: excluye los 'keyword-only' (no aplicables,, Excluye del reporte los findings marcados false_positive (catch-all / FP fuerte)

### Community 122 - "Community 122"
Cohesion: 0.53
Nodes (4): smoke_engagement.sh script, ko(), ok(), step()

### Community 123 - "Community 123"
Cohesion: 0.40
Nodes (5): B7 — quita jerga técnica de la narrativa EJECUTIVA por si el LLM no obedeció, _strip_exec_jargon(), B7 (S1) — la red de seguridad de la narrativa también barre [Nikto]/[Nuclei]., test_strip_exec_jargon(), test_strip_exec_jargon_removes_bracket_tags()

### Community 124 - "Community 124"
Cohesion: 0.50
Nodes (4): _exec_asset(), B7 — Activo en términos simples para el ejecutivo: host sin esquema, puerto, B7 (S1) — la columna Activo muestra el host limpio, no la URL cruda., test_exec_asset_strips_scheme_port_path()

### Community 128 - "Community 128"
Cohesion: 0.67
Nodes (3): orchestrator_tools(), Lista completa de tools que ve el LLM en modo execute: los 4 workers     (agent, test_orchestrator_tools_has_four_workers_plus_two_reads()

## Knowledge Gaps
- **429 isolated node(s):** `allow`, `TargetType`, `AsyncIOMotorClient`, `HitlDecision`, `Request` (+424 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **20 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `utc_now()` connect `Community 7` to `Community 33`, `Community 4`, `Community 5`, `Community 36`, `Community 39`, `Community 43`, `Community 11`, `Community 45`, `Community 44`, `Community 17`, `Community 18`, `Community 27`, `Community 29`?**
  _High betweenness centrality (0.066) - this node is a cross-community bridge._
- **Why does `PipelineController` connect `Community 60` to `Community 33`, `Community 100`, `Community 5`, `Community 39`, `Community 44`, `Community 45`, `Community 18`, `Community 117`, `Community 57`, `Community 58`, `Community 27`, `Community 28`?**
  _High betweenness centrality (0.023) - this node is a cross-community bridge._
- **Why does `datetime` connect `Community 7` to `Community 38`, `Community 42`, `Community 11`, `Community 17`, `Community 23`, `Community 29`?**
  _High betweenness centrality (0.023) - this node is a cross-community bridge._
- **Are the 96 inferred relationships involving `cn()` (e.g. with `MitreBadge()` and `ActivityConsole()`) actually correct?**
  _`cn()` has 96 INFERRED edges - model-reasoned connections that need verification._
- **Are the 37 inferred relationships involving `utc_now()` (e.g. with `_expire_orphan_pending_hitl()` and `cve_lookup()`) actually correct?**
  _`utc_now()` has 37 INFERRED edges - model-reasoned connections that need verification._
- **Are the 16 inferred relationships involving `PipelineController` (e.g. with `BackgroundTasks` and `Request`) actually correct?**
  _`PipelineController` has 16 INFERRED edges - model-reasoned connections that need verification._
- **Are the 23 inferred relationships involving `BaseAgent` (e.g. with `AgentContext` and `AgentResult`) actually correct?**
  _`BaseAgent` has 23 INFERRED edges - model-reasoned connections that need verification._