# Grafo de conocimiento del código — Resumen ejecutivo

> Versión legible del [`GRAPH_REPORT.md`](GRAPH_REPORT.md) completo. Pensado para
> quien revisa el proyecto y quiere entender **la forma del sistema en 5 minutos**,
> sin leer las 136 comunidades una por una. Grafo generado con
> [graphify](https://github.com/) sobre el commit `c2c96455` (2026-06-30).

## Qué es este grafo

`graphify` analiza el repositorio completo (166 archivos, ~227.000 palabras) y
construye un **mapa de dependencias**: qué función llama a qué, qué módulo usa
qué, y cómo se agrupan las piezas en "comunidades" (módulos cohesivos). El
resultado son **1.772 nodos** y **2.683 relaciones**. Sirve para responder de un
vistazo dos preguntas: *¿cuáles son las abstracciones centrales?* y *¿está el
sistema bien modularizado o hay un "god object" que lo enreda todo?*

- **Ver el grafo interactivo:** abrir [`graph.html`](graph.html) en un navegador
  (buscar, filtrar y navegar los 1.772 nodos).
- **Reporte técnico completo:** [`GRAPH_REPORT.md`](GRAPH_REPORT.md).

## Lo que dice de la salud del sistema

| Señal | Valor | Lectura |
|-------|-------|---------|
| Nodos / relaciones | 1.772 / 2.683 | Sistema de tamaño mediano, bien conectado |
| Extracción confiable | 87 % EXTRACTED · 13 % INFERRED | La mayoría de relaciones son reales (leídas del código), no adivinadas |
| Comunidades | 136 (116 mostradas) | Alta modularidad: cada comunidad ≈ un módulo con una responsabilidad |
| Ciclos de import reales | 0 | Los 3 "ciclos" reportados son auto-referencias de un archivo consigo mismo (artefacto de la herramienta), no deuda técnica |

**Conclusión:** el sistema está **bien modularizado**. No hay un god object que
concentre el poder. El nodo más conectado, `cn()` (97 relaciones), es un helper
trivial del frontend (junta clases CSS) — que lidere el ranking es una buena
señal: significa que ninguna pieza de lógica de negocio es un cuello de botella.

## Las abstracciones centrales (god nodes)

Los nodos más conectados son exactamente los que uno esperaría del diseño
descrito en el [ADR-005](../docs/adr-005-agentes-reales-y-orquestador.md):

| Nodo | Relaciones | Qué es |
|------|-----------|--------|
| `PipelineController` | 32 | Orquesta las 4 etapas Recon→Scan→Analysis→Reporter |
| `BaseAgent` | 30 | Contrato común de los 4 agentes (`run(AgentContext)→AgentResult`) |
| `AgentResult` / `AgentContext` | 28 / 27 | Entrada y salida estandarizadas de todo agente |
| `is_target_in_scope()` | 24 | Gate de scope — la validación de alcance autorizado |
| `AnalysisAgent` / `ScanAgent` | 22 / 22 | Dos de los cuatro workers |

Que el contrato de agente (`BaseAgent`, `AgentContext`, `AgentResult`) y el
`PipelineController` estén en la cima **confirma que la arquitectura implementada
coincide con la diseñada**: un orquestador que coordina cuatro agentes que
comparten un contrato único. El gate de scope (`is_target_in_scope`) también
aparece arriba, lo que refleja que es un control transversal real en el código,
no una idea suelta en el prompt.

## Mapa comunidad → módulo del sistema

Las comunidades más relevantes para revisar el proyecto:

| Comunidad | Módulo | Archivo(s) clave |
|-----------|--------|------------------|
| 2 | Validación de scope | `services/scope_validator.py` |
| 35, 60 | Contrato de agentes + ADR-005 | `services/agent_base.py` |
| 49, 37, 117 | Orquestador conversacional + ejecutor | `services/orchestrator_agent.py` |
| 39, 60 | PipelineController (4 etapas) | `services/pipeline_controller.py` |
| 27, 3, 18 | ReconAgent + ScanAgent + política | `services/recon_agent.py`, `scan_agent.py`, `scan_policy.py` |
| 4, 45, 102, 47 | AnalysisAgent (CVE/CVSS/ATT&CK) | `services/analysis_agent.py` |
| 20, 63, 121 | ReporterAgent + render PDF | `services/reporter_agent.py`, `report_renderer.py` |
| 43, 22, 62 | HITL (backend + UI) | `routers/hitl.py`, vistas HITL |
| 14, 23, 42, 111 | Persistencia Mongo (schemas + índices) | `mongo_schemas.py`, `mongo_client.py` |
| 66, 36, 59 | Modelo relacional (engagements/scope/hitl) | `models.py`, `routers/scope.py` |
| 8, 12, 77, 93 | Normalizadores de findings + tests | `services/findings_service.py`, `nmap_service.py` |

## Cómo regenerarlo

El grafo refleja el commit `c2c96455`. Si el código cambió después:

```bash
git rev-parse HEAD          # commit actual
graphify update .           # regenera el grafo (sin costo de API)
```

El resto de la arquitectura (diagramas ER, frontera dual-store) está en
[`docs/architecture.html`](../docs/architecture.html), derivada leyendo el código
fuente además del grafo.
