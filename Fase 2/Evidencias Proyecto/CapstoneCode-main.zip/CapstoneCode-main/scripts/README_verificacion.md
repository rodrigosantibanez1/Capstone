# Scripts de verificación por consola — ETH-MAS

Estos scripts demuestran, **por terminal**, que lo que se ve en el frontend es
**real**: recorren un engagement ya corrido golpeando los **mismos endpoints REST
que usa la UI** y luego **contrastan los conteos contra MongoDB directo**. Si la
API y la base coinciden, queda probado que la interfaz no muestra datos mock.

> Pensados para correr en **PowerShell** (Windows). Son **solo lectura**: no
> modifican nada del engagement.

## Requisitos

```powershell
# 1) Stack arriba (incluye el laboratorio):
docker compose --profile lab up -d

# 2) Backend respondiendo en http://localhost:8000
#    Contenedor de Mongo llamado eth_mas_mongo (para la reconciliación)
```

Los **GET** de verificación **no requieren** `X-API-Key` (la auth opt-in solo
protege POST/PATCH). Si la activaste, pasa `-ApiKey "<secreto>"` igual.

## Los tres scripts

| Script | Qué hace | Cuándo usarlo |
|---|---|---|
| `list_engagements.ps1` | Lista los engagements y sus IDs/estado | Para descubrir qué `-Id` usar |
| `verify_eth_mas.ps1` | **El principal.** Recorre el engagement por API + reconcilia contra Mongo | La demo de verificación completa |
| `verify_mongo_deep.ps1` | Imprime documentos crudos de Mongo (un finding, el análisis, los PDFs) | El momento "muéstrame el dato en bruto" |

## Uso típico (defensa)

```powershell
cd CapstoneCode/scripts

# 1. ¿Qué engagements hay?
./list_engagements.ps1

# 2. Verificación completa de Metasploitable2 (#26):
./verify_eth_mas.ps1 -Id 26

# 3. Idem DVWA (#27):
./verify_eth_mas.ps1 -Id 27

# 4. Para mostrar los documentos crudos guardados:
./verify_mongo_deep.ps1 -Id 26
```

Si `Invoke-RestMethod` da error de URL o el contenedor de Mongo se llama distinto:

```powershell
./verify_eth_mas.ps1 -Id 26 -BaseUrl http://localhost:8000 -MongoContainer eth_mas_mongo
./verify_eth_mas.ps1 -Id 26 -SkipMongo     # salta la reconciliación con la base
```

## Qué prueba cada sección y a qué corresponde en el front

| Sección de `verify_eth_mas.ps1` | Garantía / vista del front | Diapositiva |
|---|---|---|
| 0. Salud del backend | el sistema está vivo | — |
| 1. Engagement + Scope | vista **Engagements** | 8, 11 |
| 2. **Scope enforcement en vivo** | garantía **@enforce_scope** (AUTORIZADO/DENEGADO) | 4 ① |
| 3. Findings | vista **Hallazgos** + `raw_output` real | 13, 14, 15 |
| 4. Análisis MITRE/CVE | vista **Analysis** (heatmap, kill chains) | 13, 14 |
| 5. HITL | garantía **control humano** (aprobaciones) | 4 ②, 14 |
| 6. Pipeline runs | vista **Pipeline** (4/4 etapas) | 13, 14 |
| 7. Reportes PDF | vista **Reports** | 13, 15 |
| 8. **Reconciliación API vs Mongo** | la prueba dura: mismos números | 16 |

## El argumento de fondo (para decir en voz alta)

1. **El front llama a un endpoint.** Yo llamo al **mismo** endpoint desde consola
   → sale lo mismo. La UI no inventa: refleja la API.
2. **Consulto MongoDB a mano**, sin pasar por la API → **mismo conteo**.
   Por lo tanto la cadena **front → API → base** es consistente.
3. **Scope enforcement**: un target autorizado pasa, uno no autorizado se
   rechaza — y eso ocurre en código, no en el prompt del LLM.
4. **HITL**: las acciones quedaron registradas con su decisión → el pipeline
   pasó por el gate humano.
5. **`raw_output`**: cada hallazgo conserva la salida cruda de la herramienta
   real → no son datos de demo.

## Números esperados (referencia del deck)

- **#26 (Metasploitable2):** ~38 findings · 38/38 con MITRE · 4/4 etapas · 2 PDFs
- **#27 (DVWA):** ~12 findings web · 4/4 etapas · 2 PDFs

> Si los números difieren de los de las diapositivas, puede ser que el engagement
> se haya vuelto a correr; lo importante para la defensa es la **consistencia
> API↔Mongo**, no el valor exacto.
