#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────────
# dump_demo_seed.sh — regenera el SEED de demo (demo-seed/) desde las BD locales.
# Lo corre quien tiene la corrida persistida, para actualizar el seed que el
# equipo restaura con restore_demo_seed.sh.
#
# Uso:   ./scripts/dump_demo_seed.sh
# ──────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SEED_DIR="$(cd "$(dirname "$0")/.." && pwd)/demo-seed"
mkdir -p "$SEED_DIR"
PG_CONTAINER="${PG_CONTAINER:-eth_mas_postgres}"
MONGO_CONTAINER="${MONGO_CONTAINER:-eth_mas_mongo}"
PG_DB="${PG_DB:-eth_mas_db}"
PG_USER="${PG_USER:-postgres}"
MONGO_DB="${MONGO_DB:-eth_mas}"

echo "▶ pg_dump ($PG_DB) → demo-seed/eth_mas_pg.sql"
docker exec "$PG_CONTAINER" pg_dump -U "$PG_USER" -d "$PG_DB" --clean --if-exists > "$SEED_DIR/eth_mas_pg.sql"

echo "▶ mongodump ($MONGO_DB, incluye GridFS reports) → demo-seed/eth_mas_mongo.archive"
docker exec "$MONGO_CONTAINER" mongodump --db "$MONGO_DB" --archive > "$SEED_DIR/eth_mas_mongo.archive"

echo "✅ Seed regenerado:"
ls -la "$SEED_DIR"
