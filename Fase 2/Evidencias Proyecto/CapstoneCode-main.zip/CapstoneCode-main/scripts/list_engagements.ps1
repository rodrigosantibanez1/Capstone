<#
 list_engagements.ps1 — Lista los engagements disponibles (para descubrir IDs).
 Uso:  ./list_engagements.ps1            (todos)
       ./list_engagements.ps1 -BaseUrl http://localhost:8000
#>
param(
    [string] $BaseUrl = "http://localhost:8000",
    [string] $ApiKey  = ""
)
$ErrorActionPreference = "Stop"
$headers = @{}
if ($ApiKey -ne "") { $headers["X-API-Key"] = $ApiKey }

try {
    $engs = Invoke-RestMethod -Uri "$BaseUrl/engagements" -Headers $headers -Method Get -TimeoutSec 30
} catch {
    Write-Host "[X] No pude consultar $BaseUrl/engagements -> $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "    ¿Está el backend arriba? docker compose --profile lab up -d" -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host ("{0,-5} {1,-26} {2,-14} {3,-8} {4}" -f "ID","NOMBRE","ESTADO","SCOPE","CREADO") -ForegroundColor Cyan
Write-Host ("-" * 80) -ForegroundColor DarkGray
@($engs) | Sort-Object id | ForEach-Object {
    $name = "$($_.name)"; if ($name.Length -gt 25) { $name = $name.Substring(0,25) }
    $sc = $_.scope_count; if ($null -eq $sc) { $sc = "-" }
    Write-Host ("{0,-5} {1,-26} {2,-14} {3,-8} {4}" -f $_.id, $name, $_.status, $sc, $_.created_at)
}
Write-Host ""
Write-Host "Luego:  ./verify_eth_mas.ps1 -Id <ID>" -ForegroundColor Gray
Write-Host ""
