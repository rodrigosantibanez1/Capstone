#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────────
# restore_demo_seed.sh — carga el SEED de demo (engagement #37 ya persistido)
# en las BD locales, para que el equipo vea exactamente la corrida de la sesión
# sin tener que re-ejecutar el pipeline (~15 min).
#
# Restaura:
#   - PostgreSQL (eth_mas_db): engagements, scope, hitl_actions de #37.
#   - MongoDB (eth_mas): findings, analysis, conversación del orquestador,
#     pipeline/agent runs y los 2 PDFs en GridFS (bucket 'reports').
#
# Requisitos: el stack debe estar ARRIBA (docker compose --profile lab up -d).
#
# ⚠️ DESTRUCTIVO: reemplaza el contenido actual de esas BD (drop + load). Pensado
# para un entorno de demo limpio. Si tienes engagements propios, haz backup antes.
#
# Uso:   ./scripts/restore_demo_seed.sh
# ──────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SEED_DIR="$(cd "$(dirname "$0")/.." && pwd)/demo-seed"
PG_CONTAINER="${PG_CONTAINER:-eth_mas_postgres}"
MONGO_CONTAINER="${MONGO_CONTAINER:-eth_mas_mongo}"
PG_DB="${PG_DB:-eth_mas_db}"
PG_USER="${PG_USER:-postgres}"
MONGO_DB="${MONGO_DB:-eth_mas}"

[ -f "$SEED_DIR/eth_mas_pg.sql" ]      || { echo "Falta $SEED_DIR/eth_mas_pg.sql"; exit 1; }
[ -f "$SEED_DIR/eth_mas_mongo.archive" ] || { echo "Falta $SEED_DIR/eth_mas_mongo.archive"; exit 1; }

echo "▶ Restaurando PostgreSQL ($PG_DB) desde el seed…"
docker exec -i "$PG_CONTAINER" psql -U "$PG_USER" -d "$PG_DB" -q < "$SEED_DIR/eth_mas_pg.sql"

echo "▶ Restaurando MongoDB ($MONGO_DB) desde el seed (drop + load)…"
docker exec -i "$MONGO_CONTAINER" mongorestore --archive --drop --quiet < "$SEED_DIR/eth_mas_mongo.archive"

echo "▶ Reiniciando backend para refrescar conexiones…"
docker compose restart backend >/dev/null 2>&1 || true

echo "✅ Seed restaurado. El engagement #37 'Defensa Capstone - Metasploitable2' está disponible."
echo "   Verifica: curl -s http://localhost:8000/engagements/37/findings?limit=200 | grep -o '\"total\":[0-9]*'"
