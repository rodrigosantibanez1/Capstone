#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# smoke_engagement.sh — Smoke test del cableado end-to-end de ETH-MAS.
#
# Valida, SIN ejecutar scans activos (no dispara HITL ni toca el lab):
#   1. Salud del stack            → GET /health/services (overall: up)
#   2. Crear engagement           → POST /engagements
#   3. Definir scope              → el target del lab queda autorizado
#   4. Scope enforcement          → un target fuera de scope es DENEGADO
#   5. Orquestador (modo plan)    → POST /engagements/{id}/orchestrator (no ejecuta)
#   6. Conversación persistida    → GET /engagements/{id}/orchestrator/conversation
#
# Imprime PASS/FAIL por paso y termina con código !=0 si algo falla.
#
# Uso:
#   ETH_MAS_API_KEY=... ./scripts/smoke_engagement.sh
#   API_BASE=http://localhost:8000 SCOPE_TARGET=10.42.0.10 ./scripts/smoke_engagement.sh
#
# Requiere: curl, jq.
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail

API_BASE="${API_BASE:-http://localhost:8000}"
API_KEY="${ETH_MAS_API_KEY:-dev-key-insecure-change-me}"
SCOPE_TARGET="${SCOPE_TARGET:-10.42.0.10}"
OUT_OF_SCOPE="${OUT_OF_SCOPE:-1.1.1.1}"
HDR_KEY=(-H "X-API-Key: ${API_KEY}")
HDR_JSON=(-H "Content-Type: application/json")

pass=0; fail=0
ok()   { echo "  ✅ PASS — $1"; pass=$((pass+1)); }
ko()   { echo "  ❌ FAIL — $1"; fail=$((fail+1)); }
step() { echo ""; echo "▶ $1"; }

command -v jq   >/dev/null 2>&1 || { echo "jq no instalado. Abortando."; exit 2; }
command -v curl >/dev/null 2>&1 || { echo "curl no instalado. Abortando."; exit 2; }

# ── POST de JSON robusto en Windows ───────────────────────────────────────────
# Git Bash + curl.exe corrompe el UTF-8 (em-dash, acentos) cuando el body viaja
# por argv (-d "..."). Se manda por archivo temporal (--data-binary @) para
# preservar los bytes UTF-8 intactos en cualquier plataforma.
TMP_BODY="$(mktemp 2>/dev/null || echo "${TMPDIR:-/tmp}/eth_mas_smoke_body.$$")"
trap 'rm -f "$TMP_BODY"' EXIT
post_json() { # uso: post_json <url> <json-body> [max-time-seg]
  printf '%s' "$2" > "$TMP_BODY"
  curl -s --max-time "${3:-60}" -X POST "$1" "${HDR_KEY[@]}" "${HDR_JSON[@]}" --data-binary @"$TMP_BODY"
}

echo "═══════════════════════════════════════════════════════════"
echo " ETH-MAS smoke test"
echo "   API_BASE     = ${API_BASE}"
echo "   SCOPE_TARGET = ${SCOPE_TARGET}"
echo "═══════════════════════════════════════════════════════════"

# 1. Salud del stack ──────────────────────────────────────────────────────────
step "1. Salud del stack (GET /health/services)"
health="$(curl -s --max-time 15 "${API_BASE}/health/services")"
overall="$(echo "$health" | jq -r '.overall // .status // "unknown"' 2>/dev/null)"
if [[ "$overall" == "up" ]]; then
  ok "overall: up"
else
  ko "overall != up (=${overall}). Detalle:"; echo "$health" | jq . 2>/dev/null || echo "$health"
fi

# 2. Crear engagement ─────────────────────────────────────────────────────────
step "2. Crear engagement (POST /engagements)"
create_body="$(jq -n --arg t "$SCOPE_TARGET" '{
  name: "Smoke test — Lab",
  client_name: "DUOC UC (smoke)",
  scope_targets: [ { target_value: $t, target_type: "ip" } ]
}')"
create_resp="$(post_json "${API_BASE}/engagements" "$create_body" 20)"
ENG_ID="$(echo "$create_resp" | jq -r '.id // empty' 2>/dev/null)"
if [[ -n "$ENG_ID" ]]; then
  ok "engagement creado id=${ENG_ID}"
else
  ko "no se pudo crear engagement. Respuesta:"; echo "$create_resp"
  echo ""; echo "Resumen: ${pass} PASS / ${fail} FAIL"; exit 1
fi

# 3. Scope autorizado ─────────────────────────────────────────────────────────
step "3. Scope enforcement — target en scope (debe AUTORIZAR)"
val_in="$(curl -s --max-time 15 "${HDR_KEY[@]}" \
  "${API_BASE}/engagements/${ENG_ID}/validate?target=${SCOPE_TARGET}")"
in_scope="$(echo "$val_in" | jq -r '.in_scope // (.status=="AUTORIZADO")' 2>/dev/null)"
[[ "$in_scope" == "true" ]] && ok "${SCOPE_TARGET} AUTORIZADO" || { ko "${SCOPE_TARGET} no autorizado. Resp:"; echo "$val_in"; }

# 4. Scope denegado ───────────────────────────────────────────────────────────
step "4. Scope enforcement — target fuera de scope (debe DENEGAR)"
val_out="$(curl -s --max-time 15 "${HDR_KEY[@]}" \
  "${API_BASE}/engagements/${ENG_ID}/validate?target=${OUT_OF_SCOPE}")"
out_scope="$(echo "$val_out" | jq -r '.in_scope // (.status=="AUTORIZADO")' 2>/dev/null)"
[[ "$out_scope" == "false" ]] && ok "${OUT_OF_SCOPE} DENEGADO (correcto)" || { ko "${OUT_OF_SCOPE} no fue denegado. Resp:"; echo "$val_out"; }

# 5. Orquestador modo plan (no ejecuta nada) ──────────────────────────────────
step "5. Orquestador modo PLAN (POST /engagements/${ENG_ID}/orchestrator)"
orch_body='{"message":"Resume qué harías para auditar este lab, sin ejecutar nada todavía.","mode":"plan"}'
orch_resp="$(post_json "${API_BASE}/engagements/${ENG_ID}/orchestrator" "$orch_body" 60)"
reply="$(echo "$orch_resp" | jq -r '.reply // empty' 2>/dev/null)"
if [[ -n "$reply" ]]; then
  ok "el orquestador respondió un plan (${#reply} chars)"
  echo "      ↳ ${reply:0:160}..."
else
  ko "sin respuesta del orquestador. Verifica ANTHROPIC_API_KEY / ORCHESTRATOR_MODEL. Resp:"; echo "$orch_resp"
fi

# 6. Conversación persistida ──────────────────────────────────────────────────
step "6. Conversación persistida (GET .../orchestrator/conversation)"
conv="$(curl -s --max-time 15 "${HDR_KEY[@]}" \
  "${API_BASE}/engagements/${ENG_ID}/orchestrator/conversation")"
total="$(echo "$conv" | jq -r '.total // 0' 2>/dev/null)"
[[ "$total" -ge 2 ]] && ok "conversación persistida (${total} turnos)" || { ko "conversación vacía/incompleta (total=${total})"; }

# Resumen ─────────────────────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════════"
echo " Resultado: ${pass} PASS / ${fail} FAIL   (engagement #${ENG_ID})"
echo "═══════════════════════════════════════════════════════════"
[[ "$fail" -eq 0 ]] && exit 0 || exit 1
