<#
================================================================================
 verify_eth_mas.ps1  —  Verificador de extremo a extremo para la defensa
================================================================================
 OBJETIVO
   Demostrar por consola que lo que se ve en el frontend es REAL:
   recorre un engagement ya corrido (p. ej. #26 Metasploitable2, #27 DVWA)
   golpeando exactamente los mismos endpoints REST que usa el front, y luego
   CONTRASTA los conteos contra MongoDB directo. Si API y base coinciden,
   queda probado que la UI no muestra datos inventados.

 QUÉ PRUEBA, SECCIÓN POR SECCIÓN
   0. Salud del backend            → el sistema está vivo
   1. Engagement + Scope           → vista "Engagements"
   2. Scope enforcement (en vivo)  → garantía @enforce_scope (AUTORIZADO/DENEGADO)
   3. Findings                     → vista "Hallazgos"
   4. Análisis (MITRE/CVE)         → vista "Analysis" (heatmap, kill chains)
   5. HITL                         → garantía control humano (aprobaciones)
   6. Pipeline runs                → vista "Pipeline" (4/4 etapas)
   7. Reportes PDF                 → vista "Reports"
   8. RECONCILIACIÓN API vs Mongo  → la prueba dura: mismos números

 USO
   # Engagement 26 (Metasploitable2), todo por defecto:
   ./verify_eth_mas.ps1 -Id 26

   # DVWA, contra otra URL, sin tocar Mongo:
   ./verify_eth_mas.ps1 -Id 27 -BaseUrl http://localhost:8000 -SkipMongo

   # Si la auth X-API-Key está activa (GETs no la exigen, pero por si acaso):
   ./verify_eth_mas.ps1 -Id 26 -ApiKey "tu-secreto"

 REQUISITOS
   - Stack arriba:  docker compose --profile lab up -d
   - Backend en :8000  ·  contenedor Mongo "eth_mas_mongo" para la reconciliación
================================================================================
#>

param(
    [int]    $Id              = 26,
    [string] $BaseUrl         = "http://localhost:8000",
    [string] $ApiKey          = "",
    [string] $MongoContainer  = "eth_mas_mongo",
    [string] $MongoDb         = "eth_mas",
    [string] $OutOfScopeTarget = "8.8.8.8",   # target fuera de scope para la demo de enforcement
    [switch] $SkipMongo
)

$ErrorActionPreference = "Stop"

# ── Helpers de presentación ────────────────────────────────────────────────────
function Section($n, $t) {
    Write-Host ""
    Write-Host ("=" * 78) -ForegroundColor DarkCyan
    Write-Host ("  [{0}]  {1}" -f $n, $t) -ForegroundColor Cyan
    Write-Host ("=" * 78) -ForegroundColor DarkCyan
}
function Ok($m)   { Write-Host "  [OK]   $m"   -ForegroundColor Green }
function Info($m) { Write-Host "  [i]    $m"   -ForegroundColor Gray }
function Warn($m) { Write-Host "  [!]    $m"   -ForegroundColor Yellow }
function Bad($m)  { Write-Host "  [X]    $m"   -ForegroundColor Red }

# ── Cliente HTTP (mismos endpoints que el frontend) ─────────────────────────────
function Api($path) {
    $headers = @{}
    if ($ApiKey -ne "") { $headers["X-API-Key"] = $ApiKey }
    $url = "$BaseUrl$path"
    try {
        return Invoke-RestMethod -Uri $url -Headers $headers -Method Get -TimeoutSec 30
    } catch {
        Bad "GET $path  ->  $($_.Exception.Message)"
        return $null
    }
}

# ── Cross-check directo a Mongo (la prueba de que la API no miente) ──────────────
function MongoEval($jsExpr) {
    # Devuelve el string que imprime mongosh, o $null si falla.
    try {
        $out = & docker exec $MongoContainer mongosh $MongoDb --quiet --eval $jsExpr 2>$null
        if ($LASTEXITCODE -ne 0) { return $null }
        return ($out | Out-String).Trim()
    } catch {
        return $null
    }
}

Write-Host ""
Write-Host "################################################################################" -ForegroundColor White
Write-Host "#  ETH-MAS · Verificación de engagement #$Id  ·  $BaseUrl" -ForegroundColor White
Write-Host "################################################################################" -ForegroundColor White

# Acumulador para la reconciliación final
$recon = @()

# ============================================================================
# 0. SALUD DEL BACKEND
# ============================================================================
Section 0 "Salud del backend (¿el sistema está vivo?)"
$health = Api "/health/services"
if ($health) {
    Ok "Backend responde en $BaseUrl"
    $health.PSObject.Properties | ForEach-Object {
        $v = $_.Value
        if ($v -is [psobject]) { $v = ($v | ConvertTo-Json -Compress) }
        Info ("{0,-16}: {1}" -f $_.Name, $v)
    }
} else {
    Bad "El backend no responde. ¿Levantaste 'docker compose --profile lab up -d'?"
    Bad "Abortando."
    exit 1
}

# ============================================================================
# 1. ENGAGEMENT + SCOPE  (vista: Engagements)
# ============================================================================
Section 1 "Engagement + Scope  (corresponde a la vista 'Engagements')"
$eng = Api "/engagements/$Id"
if (-not $eng) { Bad "No existe el engagement #$Id. Prueba con -Id 26 o -Id 27."; exit 1 }

Ok "Engagement #$($eng.id) encontrado"
Info ("Nombre   : {0}" -f $eng.name)
Info ("Cliente  : {0}" -f $eng.client_name)
Info ("Estado   : {0}" -f $eng.status)
Info ("Creado   : {0}" -f $eng.created_at)

$scope = Api "/engagements/$Id/scope"
if ($scope) {
    $scopeList = @($scope)
    Ok "Scope autorizado: $($scopeList.Count) target(s)"
    $scopeList | ForEach-Object {
        Info ("  - {0,-22} ({1})" -f $_.target, $_.target_type)
    }
    # Guardamos el primer target in-scope para la demo de enforcement
    $script:InScopeTarget = $scopeList[0].target
}

# ============================================================================
# 2. SCOPE ENFORCEMENT EN VIVO  (garantía @enforce_scope)
# ============================================================================
Section 2 "Scope enforcement en vivo  (garantía: la IA NO puede salirse del alcance)"
Info "El backend valida cada target en código (scope_validator), no en el prompt."
Write-Host ""
if ($script:InScopeTarget) {
    $vIn = Api "/engagements/$Id/validate?target=$($script:InScopeTarget)"
    if ($vIn) {
        if ($vIn.in_scope) { Ok  ("Target IN-SCOPE   '{0}'  ->  {1}" -f $vIn.target, $vIn.status) }
        else               { Bad ("Target IN-SCOPE   '{0}'  ->  {1}  (inesperado)" -f $vIn.target, $vIn.status) }
    }
}
$vOut = Api "/engagements/$Id/validate?target=$OutOfScopeTarget"
if ($vOut) {
    if (-not $vOut.in_scope) { Ok  ("Target OUT-SCOPE  '{0}'  ->  {1}  (correctamente bloqueado)" -f $vOut.target, $vOut.status) }
    else                     { Bad ("Target OUT-SCOPE  '{0}'  ->  {1}  (NO debería autorizarse)" -f $vOut.target, $vOut.status) }
}
Write-Host ""
Info "Conclusión: lo autorizado pasa, lo no autorizado se rechaza. Sin tocar el LLM."

# ============================================================================
# 3. FINDINGS  (vista: Hallazgos)
# ============================================================================
Section 3 "Findings / Hallazgos  (corresponde a la vista 'Hallazgos')"
$findingsResp = Api "/engagements/$Id/findings?limit=1000"
$apiFindings = 0
if ($findingsResp) {
    $apiFindings = [int]$findingsResp.total
    Ok "Findings vía API: $apiFindings"

    $byTool = $findingsResp.findings | Group-Object tool | Sort-Object Count -Descending
    Write-Host ""
    Info "Por herramienta:"
    $byTool | ForEach-Object { Info ("  {0,-14} {1}" -f $_.Name, $_.Count) }

    $bySev = $findingsResp.findings | Group-Object severity | Sort-Object Count -Descending
    Write-Host ""
    Info "Por severidad:"
    $bySev | ForEach-Object { Info ("  {0,-14} {1}" -f $_.Name, $_.Count) }

    # Muestra 8 findings reales
    Write-Host ""
    Info "Muestra (primeros 8):"
    Write-Host ("  {0,-13} {1,-9} {2,-16} {3,-9} {4}" -f "TOOL","SEVERITY","TARGET","MITRE","RESUMEN") -ForegroundColor DarkGray
    $findingsResp.findings | Select-Object -First 8 | ForEach-Object {
        $sum = "$($_.summary)"
        if ($sum.Length -gt 42) { $sum = $sum.Substring(0,42) + "..." }
        $mitre = "$($_.mitre_technique)"; if ($mitre -eq "") { $mitre = "-" }
        Write-Host ("  {0,-13} {1,-9} {2,-16} {3,-9} {4}" -f $_.tool, $_.severity, $_.target, $mitre, $sum)
    }

    # Prueba de "esto NO es mock": mostrar raw_output real de un finding
    Write-Host ""
    $sampleRaw = ($findingsResp.findings | Where-Object { $_.raw_output } | Select-Object -First 1).raw_output
    if ($sampleRaw) {
        $snippet = "$sampleRaw"
        if ($snippet.Length -gt 200) { $snippet = $snippet.Substring(0,200) + " ..." }
        Info "Evidencia cruda (raw_output) de un hallazgo real — esto lo emitió la tool, no es mock:"
        Write-Host "  ---8<---" -ForegroundColor DarkGray
        Write-Host ("  " + ($snippet -replace "`n","`n  ")) -ForegroundColor DarkGray
        Write-Host "  --->8---" -ForegroundColor DarkGray
    }
} else {
    Warn "Sin findings vía API."
}

# ============================================================================
# 4. ANÁLISIS  (vista: Analysis — MITRE / kill chains)
# ============================================================================
Section 4 "Análisis MITRE/CVE  (corresponde a la vista 'Analysis')"
$analysis = Api "/engagements/$Id/analysis"
$apiEnriched = 0
if ($analysis) {
    $apiEnriched = @($analysis.enriched_findings).Count
    $vectors     = @($analysis.attack_vectors).Count
    $priority    = @($analysis.priority_order).Count
    Ok "Documento de análisis presente"
    Info ("Findings enriquecidos (CVE/CVSS/ATT&CK): {0}" -f $apiEnriched)
    Info ("Vectores de ataque / kill chains      : {0}" -f $vectors)
    Info ("Items en orden de prioridad           : {0}" -f $priority)
    Info ("Modelo usado                          : {0}" -f $analysis.model_used)
    if ($analysis.summary) {
        $s = "$($analysis.summary)"; if ($s.Length -gt 160) { $s = $s.Substring(0,160) + "..." }
        Info ("Resumen ejecutivo: {0}" -f $s)
    }
} else {
    Warn "Sin análisis (¿se corrió POST /analysis?)."
}

# ============================================================================
# 5. HITL  (garantía: control humano)
# ============================================================================
Section 5 "HITL — control humano  (garantía: aprobación antes de acciones activas)"
$hitl = Api "/engagements/$Id/hitl-actions"
if ($hitl) {
    $hitlList = @($hitl)
    Ok "Acciones HITL registradas: $($hitlList.Count)"
    $byDec = $hitlList | Group-Object decision | Sort-Object Count -Descending
    Info "Por decisión:"
    $byDec | ForEach-Object { Info ("  {0,-14} {1}" -f $_.Name, $_.Count) }
    Write-Host ""
    Info "Esto demuestra que el pipeline pasó por el gate humano (PENDING -> APPROVED/EXPIRED)."
} else {
    Warn "Sin acciones HITL."
}

# ============================================================================
# 6. PIPELINE RUNS  (vista: Pipeline — 4/4 etapas)
# ============================================================================
Section 6 "Pipeline runs  (corresponde a la vista 'Pipeline', etapas 4/4)"
$pruns = Api "/engagements/$Id/pipeline-runs"
if ($pruns) {
    $prList = @($pruns)
    Ok "Corridas de pipeline: $($prList.Count)"
    $last = $prList | Select-Object -First 1
    if ($last) {
        Info ("Última corrida  estado: {0}" -f $last.status)
        if ($last.stages) {
            Info "Etapas:"
            @($last.stages) | ForEach-Object {
                Info ("  {0,-16} {1}" -f $_.name, $_.status)
            }
        }
    }
}

# ============================================================================
# 7. REPORTES PDF  (vista: Reports)
# ============================================================================
Section 7 "Reportes PDF  (corresponde a la vista 'Reports')"
$reports = Api "/engagements/$Id/reports"
$apiReports = 0
if ($reports) {
    $apiReports = [int]$reports.total
    Ok "Reportes en GridFS: $apiReports"
    @($reports.reports) | ForEach-Object {
        $kb = [math]::Round(($_.length / 1KB), 1)
        Info ("  {0,-10} {1,8} KB  file_id={2}  {3}" -f $_.type, $kb, $_.file_id, $_.filename)
    }
    Write-Host ""
    Info "Descargar uno (verifica bytes reales del PDF):"
    Info ("  Invoke-WebRequest '$BaseUrl/engagements/$Id/report?type=technical' -OutFile eng_${Id}_tecnico.pdf")
}

# ============================================================================
# 8. RECONCILIACIÓN  API  vs  MongoDB directo   (LA PRUEBA DURA)
# ============================================================================
Section 8 "Reconciliación  API vs MongoDB directo  (¿la UI muestra la verdad?)"
if ($SkipMongo) {
    Warn "Omitido (-SkipMongo)."
} else {
    Info "Consultando MongoDB directamente dentro del contenedor '$MongoContainer'..."
    $mFindings = MongoEval "db.findings.countDocuments({engagement_id: $Id})"
    $mReports  = MongoEval "db['reports.files'].countDocuments({'metadata.engagement_id': $Id})"
    $mAnalysis = MongoEval "(db.analysis.findOne({engagement_id: $Id}) ? db.analysis.findOne({engagement_id: $Id}).enriched_findings.length : 0)"

    if ($null -eq $mFindings) {
        Warn "No pude consultar Mongo (¿contenedor '$MongoContainer' arriba? ¿mongosh disponible?)."
        Warn "Puedes correr con -SkipMongo para saltar esta sección."
    } else {
        function Row($name, $api, $db) {
            $match = if ("$api" -eq "$db") { "SI  <-- coinciden" } else { "NO  <-- REVISAR" }
            $color = if ("$api" -eq "$db") { "Green" } else { "Red" }
            Write-Host ("  {0,-24} API={1,-6} Mongo={2,-6} {3}" -f $name, $api, $db, $match) -ForegroundColor $color
        }
        Write-Host ""
        Write-Host ("  {0,-24} {1,-10} {2,-10} {3}" -f "PIEZA","FRONT/API","MONGO","¿COINCIDEN?") -ForegroundColor DarkGray
        Row "Findings"             $apiFindings $mFindings
        Row "Reportes PDF"         $apiReports  $mReports
        Row "Findings enriquecidos" $apiEnriched $mAnalysis
        Write-Host ""
        Info "Si las tres filas dicen SI, queda probado: el front -> API -> base son consistentes."
        Info "La UI no muestra datos inventados: salen de la misma base que acabás de consultar a mano."
    }
}

Write-Host ""
Write-Host "################################################################################" -ForegroundColor White
Write-Host "#  Fin de la verificación del engagement #$Id" -ForegroundColor White
Write-Host "################################################################################" -ForegroundColor White
Write-Host ""
