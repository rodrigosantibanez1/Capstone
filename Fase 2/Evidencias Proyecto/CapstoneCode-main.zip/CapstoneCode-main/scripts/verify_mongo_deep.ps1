<#
================================================================================
 verify_mongo_deep.ps1 — Exhibe los DATOS CRUDOS guardados en MongoDB
================================================================================
 Para el momento "muéstrame el dato en bruto": entra al contenedor de Mongo y
 imprime documentos reales (un finding, el análisis, los archivos de reporte).
 Es el complemento de verify_eth_mas.ps1: aquel prueba consistencia por conteos;
 este muestra el contenido literal almacenado, sin pasar por la API.

 USO
   ./verify_mongo_deep.ps1 -Id 26
   ./verify_mongo_deep.ps1 -Id 27 -MongoContainer eth_mas_mongo
================================================================================
#>
param(
    [int]    $Id             = 26,
    [string] $MongoContainer = "eth_mas_mongo",
    [string] $MongoDb        = "eth_mas"
)
$ErrorActionPreference = "Stop"

function Section($t) {
    Write-Host ""
    Write-Host ("=" * 78) -ForegroundColor DarkCyan
    Write-Host "  $t" -ForegroundColor Cyan
    Write-Host ("=" * 78) -ForegroundColor DarkCyan
}

function Mongo($jsExpr) {
    $out = & docker exec $MongoContainer mongosh $MongoDb --quiet --eval $jsExpr 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  [X] mongosh falló. ¿Contenedor '$MongoContainer' arriba?" -ForegroundColor Red
        Write-Host ($out | Out-String) -ForegroundColor DarkGray
        return
    }
    Write-Host ($out | Out-String)
}

Write-Host ""
Write-Host "############################################################" -ForegroundColor White
Write-Host "#  Datos crudos en MongoDB ('$MongoDb') · engagement #$Id" -ForegroundColor White
Write-Host "############################################################" -ForegroundColor White

Section "Conteos por colección"
Mongo @"
print('findings        : ' + db.findings.countDocuments({engagement_id: $Id}));
print('surface_map     : ' + db.surface_map.countDocuments({engagement_id: $Id}));
print('agent_runs      : ' + db.agent_runs.countDocuments({engagement_id: $Id}));
print('pipeline_runs   : ' + db.pipeline_runs.countDocuments({engagement_id: $Id}));
print('analysis        : ' + db.analysis.countDocuments({engagement_id: $Id}));
print('reports.files   : ' + db['reports.files'].countDocuments({'metadata.engagement_id': $Id}));
"@

Section "UN finding real (documento completo)"
Mongo "printjson(db.findings.findOne({engagement_id: $Id}))"

Section "Resumen del análisis (MITRE/CVE)"
Mongo @"
var a = db.analysis.findOne({engagement_id: $Id});
if (!a) { print('(sin análisis)'); }
else {
  print('enriched_findings : ' + (a.enriched_findings||[]).length);
  print('attack_vectors    : ' + (a.attack_vectors||[]).length);
  print('priority_order    : ' + (a.priority_order||[]).length);
  print('model_used        : ' + a.model_used);
  print('summary           : ' + (a.summary||'').substring(0,200));
}
"@

Section "Archivos de reporte (GridFS bucket 'reports')"
Mongo @"
db['reports.files'].find({'metadata.engagement_id': $Id}).forEach(function(f){
  print(f._id + '  ' + (f.metadata||{}).type + '  ' + Math.round(f.length/1024) + ' KB  ' + f.filename);
});
"@

Write-Host ""
Write-Host "Estos documentos son los que la API sirve al frontend, sin intermediarios." -ForegroundColor Gray
Write-Host ""
